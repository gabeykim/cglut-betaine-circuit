#!/usr/bin/env python3
"""Single entry point for the C. glutamicum TCS cross-talk triage pipeline.

Runs, in order:
  1. scripts/fetch_sequences.py   -- fetch/cache every FASTA + write data/manifest.csv
  2. scripts/identity_matrix.py   -- full-length pairwise identity -> results/identity_full.csv
  3. scripts/domain_hmmer.py      -- HMMER REC/DHp domain boundaries + REC-only identity matrix
                                      -> results/identity_rec.csv, results/identity_dhp.csv (bonus)

Step 1 is network-dependent but fully cache-backed: once data/fasta/*.fasta and
data/manifest.csv exist, every later run is offline. Steps 2-3 are always
local/offline (steps operate only on cached FASTA files).

Task 4 (interface-residue comparison) has no script here: the response-regulator
side of the Skerker/Capra specificity-residue set could not be verified against
extractable primary-source text (see results/REPORT.md, "Task 4" section), so
it was skipped per the task's own instruction rather than guessed at.

Usage:
    python3 run_pipeline.py             # run everything
    python3 run_pipeline.py --skip-fetch  # reuse existing cache, skip network step
"""
import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(script: str, extra_args=None):
    cmd = [sys.executable, str(ROOT / "scripts" / script)] + (extra_args or [])
    print(f"\n{'='*70}\n>>> {' '.join(cmd)}\n{'='*70}")
    subprocess.run(cmd, check=True, cwd=ROOT)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-fetch", action="store_true",
                     help="skip scripts/fetch_sequences.py (reuse existing data/fasta cache)")
    args = ap.parse_args()

    if not args.skip_fetch:
        run("fetch_sequences.py")
    else:
        print("Skipping fetch step; reusing data/fasta/ cache and data/manifest.csv as-is.")

    run("identity_matrix.py")
    run("domain_hmmer.py")

    print("\n" + "=" * 70)
    print("Pipeline complete. Outputs:")
    print("  data/manifest.csv               locus tag -> accession -> description -> source URL")
    print("  results/identity_full.csv       full-length identity matrix (both denominators)")
    print("  results/identity_rec.csv        REC-domain-only identity matrix")
    print("  results/identity_dhp.csv        DHp-domain-only identity matrix (bonus)")
    print("  results/rec_domain_hits.csv     HMMER PF00072 boundaries per response regulator")
    print("  results/dhp_domain_hits.csv     HMMER HisKA-family boundaries per sensor kinase")
    print("  results/REPORT.md               findings, tagged EVIDENCE/INFERENCE/ESTIMATE/NOT FOUND")
    print("=" * 70)


if __name__ == "__main__":
    main()
