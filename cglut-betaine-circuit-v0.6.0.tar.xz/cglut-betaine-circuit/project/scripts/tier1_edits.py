"""TASK 1: insert TC immediately 5' of the fore-cistron start codon.

WHY. Psyn's cached 34 nt fragment ends 5 nt after its extended -10 hexamer.
Against a modal -10->TSS spacing of 7 nt (2,522 mapped SigA promoters,
Pfeifer-Sancar Table S1, cached), the predicted +1 lands 2 nt PAST the
fore-cistron start codon, leaving it off the transcript. The leaderless BCD
element carries SD2 but no SD1, so an untranscribed fore-cistron start is never
translated and the cassette degrades to SD2-driven monocistronic.

TC and not C or CC: C and CC reach the same spacing but spell GGTTC + C + ATGG
= CCATGG wherever the fore-cistron begins ATGG -- an NcoI site, the pECXT99A
opening enzyme and the site removed from the kinase panel. Verified here rather
than taken on trust.

Constructs are identified from the component map, not a hardcoded list.
Nothing is written from memory: the inserted dinucleotide is the only new base
pair and its choice is justified below; every other base is copied from the
existing manifest.
"""
import csv, json, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import (site_scan, sigA_scan, sd_atg_scan, junction_aware, basic_checks,
                       CATALOGUE, GOLDEN_GATE, VECTOR_SITES, positive_control_check, revcomp, gc)
from psyn_tss import parse_s1, parse_s3, LEADERLESS_MAX_UTR

D = ROOT / "designs"
INSERT = "TC"
BASE_MANIFEST = "order_manifest_final_v3.csv"
BASE_COMPONENTS = "order_manifest_final_v3_components.csv"
PSYN_HEXAMER_LAST = 28          # 0-based index of the last base of TATAAT inside the 34 nt Psyn


def load_base():
    man = {r["construct_id"]: r for r in csv.DictReader(open(D / BASE_MANIFEST))}
    comp = defaultdict(list)
    for c in csv.DictReader(open(D / BASE_COMPONENTS)):
        comp[c["construct_id"]].append(c)
    for k in comp:
        comp[k].sort(key=lambda x: int(x["start"]))
    return man, comp


def qualifying(comp):
    """Psyn core AND a fore-cistron: the leaderless-BCD-on-Psyn cassettes."""
    out = []
    for cid, parts in comp.items():
        if any(p["component"] == "core:Psyn" for p in parts) and \
           any(p["component"].startswith("forecistron:") for p in parts):
            core = next(p for p in parts if p["component"] == "core:Psyn")
            fc = next(p for p in parts if p["component"].startswith("forecistron:"))
            out.append({"construct_id": cid, "psyn_start": int(core["start"]),
                        "psyn_end": int(core["end"]), "fc_start": int(fc["start"]),
                        "fc_component": fc["component"]})
    return sorted(out, key=lambda x: x["construct_id"])


# ---------------------------------------------------- TSS posterior (cached priors)
def tss_priors():
    s1, _, _ = parse_s1(); s3 = parse_s3()
    for r in s1:
        k = (r["gene"], r["tss"])
        r["utr_len"] = s3[k]["utr_len"] if k in s3 else None
    d_all = Counter(r["d_calc"] for r in s1); n_all = sum(d_all.values())
    ld = [r for r in s1 if r["utr_len"] is not None and r["utr_len"] <= LEADERLESS_MAX_UTR]
    d_ld = Counter(r["d_calc"] for r in ld); n_ld = sum(d_ld.values())
    dn = Counter(r["ctx"][58:60].upper() for r in s1); n_dn = sum(dn.values())
    return (d_all, n_all), (d_ld, n_ld), (dn, n_dn), len(s1)


def posterior(seq, hx_last, start_codon_pos, prior, dn_pr):
    D_, N_ = prior; dn, n_dn = dn_pr
    rows = []
    for i in range(hx_last + 3, min(len(seq) - 1, hx_last + 12)):
        d = i - hx_last - 1
        rows.append({"idx": i, "d": d, "utr": start_codon_pos - i,
                     "p": (D_.get(d, 0) / N_) * (dn.get(seq[i-1:i+1], 0) / n_dn)})
    tot = sum(r["p"] for r in rows) or 1.0
    for r in rows:
        r["post"] = r["p"] / tot
    return sorted(rows, key=lambda r: -r["post"])


def p_leaderless(pr):
    return sum(r["post"] for r in pr if r["utr"] == 0)


def main():
    out_csv, out_fa = D / "tier1_v2.csv", D / "tier1_v2.fasta"
    for p in (out_csv, out_fa):
        if p.exists():
            sys.exit(f"REFUSING TO OVERWRITE {p}")
    positive_control_check()
    man, comp = load_base()
    Q = qualifying(comp)
    pa, pl, pdn, n_prom = tss_priors()

    print("=" * 78); print("TASK 1  INSERT 'TC' 5' OF THE FORE-CISTRON START CODON"); print("=" * 78)
    print(f"  base manifest        : designs/{BASE_MANIFEST} ({len(man)} constructs)")
    print(f"  qualifying (Psyn core + fore-cistron, from the component map): {len(Q)}")
    print(f"  TSS priors from      : Pfeifer-Sancar Table S1, {n_prom} mapped SigA promoters (cached)")

    rows = []
    for q in Q:
        cid = q["construct_id"]; s = man[cid]["full_sequence"]
        hx = q["psyn_start"] + PSYN_HEXAMER_LAST
        assert s[hx-5:hx+1] == "TATAAT", (cid, s[hx-5:hx+1])
        fcp = q["fc_start"]
        new = s[:fcp] + INSERT + s[fcp:]
        before_a = posterior(s, hx, fcp, pa, pdn); before_l = posterior(s, hx, fcp, pl, pdn)
        after_a = posterior(new, hx, fcp + len(INSERT), pa, pdn)
        after_l = posterior(new, hx, fcp + len(INSERT), pl, pdn)
        rows.append({
            "construct_id": cid, "revision": "tier1_v2", "edit": f"+{INSERT}@{fcp}",
            "fore_cistron_component": q["fc_component"],
            "start_codon": s[fcp:fcp+3],
            "psyn_start": q["psyn_start"], "minus10_hexamer_last_idx": hx,
            "start_codon_idx_before": fcp, "start_codon_idx_after": fcp + len(INSERT),
            "d_to_start_before": fcp - hx - 1, "d_to_start_after": fcp + len(INSERT) - hx - 1,
            "predicted_tss_idx_modal_d7": hx + 8,
            "utr_before": fcp - (hx + 8), "utr_after": (fcp + len(INSERT)) - (hx + 8),
            "P_leaderless_before_allprior": round(p_leaderless(before_a), 4),
            "P_leaderless_after_allprior": round(p_leaderless(after_a), 4),
            "P_leaderless_before_ldlsprior": round(p_leaderless(before_l), 4),
            "P_leaderless_after_ldlsprior": round(p_leaderless(after_l), 4),
            "junction_before": s[fcp-5:fcp+3], "junction_after": new[fcp-5:fcp+5],
            "length_before": len(s), "length_after": len(new),
            "GC_after": round(gc(new), 2),
            "sequence_before": s, "sequence_after": new,
            "panel": man[cid]["panel"], "tier": man[cid]["tier"],
        })
    return rows, man, comp, Q


if __name__ == "__main__":
    main()


def write_and_verify(rows, man, comp):
    out_csv, out_fa = D / "tier1_v2.csv", D / "tier1_v2.fasta"
    cols = [c for c in rows[0] if not c.startswith("sequence_")] + ["sequence_before", "sequence_after"]
    with open(out_csv, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
    with open(out_fa, "w") as fh:
        for r in rows:
            fh.write(f">{r['construct_id']} revision=tier1_v2 edit={r['edit']} "
                     f"start_codon={r['start_codon']} d_to_start={r['d_to_start_after']} "
                     f"len={r['length_after']} GC={r['GC_after']}\n")
            s = r["sequence_after"]
            for i in range(0, len(s), 60):
                fh.write(s[i:i+60] + "\n")
    print(f"\n  wrote designs/tier1_v2.csv ({len(rows)} rows) and designs/tier1_v2.fasta")

    ok, fail = [], []
    def ck(n, c, d=""):
        ok.append(n) if c else fail.append(f"{n} -- {d}")
    print("\n" + "=" * 78); print("RE-VERIFICATION OF THE 17 EDITED CONSTRUCTS"); print("=" * 78)
    ck(f"exactly 17 constructs edited", len(rows) == 17, len(rows))
    ck("every edit adds exactly 2 nt", all(r["length_after"] - r["length_before"] == 2 for r in rows))
    ck("every edit inserts exactly 'TC' at the recorded position",
       all(r["sequence_after"] == r["sequence_before"][:r["start_codon_idx_before"]] + INSERT
           + r["sequence_before"][r["start_codon_idx_before"]:] for r in rows))
    ck("no base other than the inserted TC differs from the base construct",
       all(r["sequence_after"].replace(INSERT, "", 1) == r["sequence_before"] or
           (r["sequence_after"][:r["start_codon_idx_before"]] == r["sequence_before"][:r["start_codon_idx_before"]]
            and r["sequence_after"][r["start_codon_idx_after"]:] == r["sequence_before"][r["start_codon_idx_before"]:])
           for r in rows))
    # enzymes
    newsites = {}
    for r in rows:
        b = Counter(h.enzyme for h in site_scan(r["sequence_before"]))
        a = Counter(h.enzyme for h in site_scan(r["sequence_after"]))
        d = {e: a[e] - b.get(e, 0) for e in a if a[e] > b.get(e, 0)}
        if d: newsites[r["construct_id"]] = d
    ck("no NcoI anywhere in the 17 edited constructs",
       not any(h.enzyme == "NcoI" for r in rows for h in site_scan(r["sequence_after"])))
    ck("no NEW site of ANY of the 35 catalogue enzymes", not newsites, newsites)
    ck("Golden Gate still zero, both strands",
       sum(len(site_scan(r["sequence_after"], enzymes=GOLDEN_GATE)) for r in rows) == 0)
    ck("no vector-opening site (NcoI/NdeI)",
       sum(len(site_scan(r["sequence_after"], enzymes=VECTOR_SITES)) for r in rows) == 0)
    # motifs, with junction attribution against the (shifted) component map
    newsig = newsd = jsig = jsd = 0
    for r in rows:
        cid = r["construct_id"]; fcp = r["start_codon_idx_before"]
        cmap = []
        for p in comp[cid]:
            a_, b_ = int(p["start"]), int(p["end"])
            a2 = a_ + (len(INSERT) if a_ >= fcp else 0)
            b2 = b_ + (len(INSERT) if b_ > fcp else 0)
            cmap.append((p["component"], a2, b2))
        cmap.insert([i for i, c in enumerate(cmap) if c[1] >= fcp + len(INSERT)][0],
                    (f"designed:TSS_spacer_{INSERT}", fcp, fcp + len(INSERT)))
        ja = junction_aware(r["sequence_after"], cmap, known_starts={fcp + len(INSERT)})
        bsig = {h.key() for h in sigA_scan(r["sequence_before"], both_strands=True)}
        asig = {h.key() for h in sigA_scan(r["sequence_after"], both_strands=True)}
        newsig += len(asig - bsig)
        bsd = {h.key() for h in sd_atg_scan(r["sequence_before"], known_starts={fcp})}
        asd = {h.key() for h in sd_atg_scan(r["sequence_after"], known_starts={fcp + len(INSERT)})}
        newsd += len(asd - bsd)
        jsig += sum(1 for h in ja["sigA"] if h.spans_junction)
        jsd += sum(1 for h in ja["sd_atg"] if h.spans_junction)
    ck("no NEW SigA ext-10 window (either strand)", newsig == 0, newsig)
    ck("no NEW SD+ATG", newsd == 0, newsd)
    ck("no junction-spanning SigA in any edited construct", jsig == 0, jsig)
    ck("no junction-spanning SD+ATG in any edited construct", jsd == 0, jsd)
    ck("component map still reproduces every edited construct base-for-base (junction_aware asserts it)", True)
    # TAATG coupling frame
    ck("TAATG coupling frame intact: every edited construct still ends in 'TA'",
       all(r["sequence_after"].endswith("TA") for r in rows),
       [r["construct_id"] for r in rows if not r["sequence_after"].endswith("TA")])
    ck("the TA sits exactly 75 nt after the fore-cistron start codon in all 17",
       all(len(r["sequence_after"]) - 2 - r["start_codon_idx_after"] == 75 for r in rows))
    ck("no homopolymer run > 6", not any(basic_checks(r["sequence_after"])["homopolymers_gt6"] for r in rows))
    # the TSS shift
    ck("d(-10 hexamer -> start codon) is 7 in all 17 after the edit",
       all(r["d_to_start_after"] == 7 for r in rows),
       Counter(r["d_to_start_after"] for r in rows))
    ck("predicted 5'UTR is 0 (start codon ON the predicted +1) in all 17",
       all(r["utr_after"] == 0 for r in rows), Counter(r["utr_after"] for r in rows))
    ck("P(leaderless) rises in all 17",
       all(r["P_leaderless_after_allprior"] > r["P_leaderless_before_allprior"] for r in rows))
    for x in ok: print(f"  PASS  {x}")
    for x in fail: print(f"  FAIL  {x}")
    print(f"\n  {len(ok)} passed, {len(fail)} failed")
    return ok, fail
