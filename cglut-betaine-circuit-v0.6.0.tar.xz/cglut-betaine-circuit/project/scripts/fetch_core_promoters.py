"""Task 1: assemble the core promoter set with full provenance.

Source: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838) --
"Improved Plasmid-Based Inducible and Constitutive Gene Expression in
Corynebacterium glutamicum" (authors verified via NCBI esummary, not
assumed). This is the paper the task's starting-strength table (PsodA
10.8%, PgapA 19%, Ptuf 50%, P45 56%, Psyn 286% of IPTG-induced Ptrc) is
drawn from.

Native promoters (PsodA, PgapA, Ptuf): rather than guessing a window size
upstream of the translation start (an earlier attempt at that missed a real
element for Ptuf entirely at 150 bp, then broke PsodA's assignment when
widened to 250 bp with an arbitrary proximal-zone cutoff -- an unstable,
essentially made-up parameter with nothing to calibrate it against), this
script instead recovers the EXACT fragment the paper itself amplified,
cloned, and functionally characterized: the primer table (Methods 2.3,
Table 1) gives the actual PCR primers (HN12/13 for Ptuf, HN14/15 for PgapA,
HN30/31 for PsodA), each with a constant Gibson-homology tail (forward:
CTGTGCGGTATTTCACACCGCA; reverse: CCGGGTACCGAGCTCGAATTCCATG, the ATG being
the vector's NcoI-supplied start codon the promoter is fused to) followed by
a gene-specific annealing sequence. Stripping the constant tails and
locating the gene-specific remainders in the cached BX927147.1 genome
identifies the exact amplicon boundaries -- i.e. the real, published,
functionally-validated promoter fragment, not an assumed window. This is
strictly better evidence than any window-size choice this analysis could
make on its own.

Synthetic promoters (P45, Psyn): explicit sequences are given verbatim in
the paper's Methods text (section 2.3) and are transcribed exactly as
fetched -- verified against the raw HTML to confirm no page-break artifact
splits the sequence (PH36, from the same paper, WAS found to have such an
artifact mid-sequence across a PDF-to-HTML paragraph break and is DROPPED
per the task's explicit instruction to drop rather than reconstruct).

The two "also consider" sets named in the task (the native gradient PUTR set,
Microb Cell Fact 19:76 2020; Shen et al. 2018 Biotechnol Lett, PMID 29605941)
were both checked and are NOT usable from this environment: the PUTR paper's
actual sequences live only in a supplementary table not present in the
fetched body text (no locus tags or sequences appear anywhere in the main
text); Shen et al. 2018 has no PMC full text and returned 404 from the
publisher. Both are reported as [NOT FOUND] in designs/REPORT_promoter.md
rather than reconstructed, per the task's explicit instruction.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from annotate_hits import load_genes
from pwm_lib import revcomp
from Bio import SeqIO

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

FW_TAIL = "CTGTGCGGTATTTCACACCGCA"
RV_TAIL = "CCGGGTACCGAGCTCGAATTCCATG"

# raw primer sequences, transcribed verbatim from the PMC7835838 HTML table
# (each verified individually against the raw, un-stripped HTML -- see
# scripts/fetch_core_promoters.py commit history / dev notes for the check)
NATIVE_PRIMERS = {
    "Ptuf": {"locus_tag": "cg0587", "tss": 526375, "strand": "+",
              "fw": "CTGTGCGGTATTTCACACCGCAGTTTTAGCGTGTCAGTAGGC",
              "rv": "CCGGGTACCGAGCTCGAATTCCATGTTACTGAATCCTAAGGGCAACG"},
    "PgapA": {"locus_tag": "cg1791", "tss": 1685093, "strand": "-",
              "fw": "CTGTGCGGTATTTCACACCGCAGTGTCTGTATGATTTTGCATCTG",
              "rv": "CCGGGTACCGAGCTCGAATTCCATGCACGCACCAAACCTACTCACA"},
    "PsodA": {"locus_tag": "cg3237", "tss": 3099699, "strand": "+",
              "fw": "CTGTGCGGTATTTCACACCGCATACTTAGCTGCCAATTATTCCG",
              "rv": "CCGGGTACCGAGCTCGAATTCCATGCCGCACCGAGCATATACATCT"},
}

# verbatim from PMC7835838 Methods 2.3, transcribed and individually checked
# against the raw HTML for page-break artifacts (see module docstring)
SYNTHETIC_SEQS = {
    "P45": "TTGGTCAGGGATTTTTTCCCGAGGGCACTAATTTTGCTAAAGTAAGTGACGAAGAAGTTC",
    "Psyn": "TTGACATTAATTTGAATCTGTGTTATAATGGTTC",
}

STRENGTH_PCT_OF_PTRC = {
    "PsodA": 10.8, "PgapA": 19, "Ptuf": 50, "P45": 56, "Psyn": 286,
}

SEARCH_FLANK = 400  # generous window around the translation start to locate primer-anneal sites in


def extract_amplicon(genome: str, spec: dict):
    fw_gene = spec["fw"][len(FW_TAIL):]
    rv_gene = spec["rv"][len(RV_TAIL):]
    tss, strand = spec["tss"], spec["strand"]

    if strand == "+":
        region = genome[tss - 1 - SEARCH_FLANK: tss - 1 + SEARCH_FLANK]
        origin = tss - 1 - SEARCH_FLANK
    else:
        region = revcomp(genome[tss - SEARCH_FLANK: tss + SEARCH_FLANK])
        origin = None  # coordinates in revcomp space; not translated back (not needed downstream)

    fw_idx = region.find(fw_gene)
    rv_idx = region.find(revcomp(rv_gene))
    assert fw_idx != -1, f"forward primer anneal site not found for {spec}"
    assert rv_idx != -1, f"reverse primer anneal site not found for {spec}"
    assert fw_idx < rv_idx, f"primer sites out of order for {spec}"

    amplicon = region[fw_idx:rv_idx + len(rv_gene)]
    return amplicon


def main():
    genome = str(next(SeqIO.parse(DATA / "cache" / "BX927147.fasta", "fasta")).seq).upper()
    genes = load_genes(DATA / "cache" / "BX927147.ft.txt")
    by_tag = {g["locus_tag"]: g for g in genes}

    promoters = {}

    for name, spec in NATIVE_PRIMERS.items():
        g = by_tag[spec["locus_tag"]]
        assert g["tss"] == spec["tss"] and g["strand"] == spec["strand"], \
            f"genome record for {spec['locus_tag']} does not match expected coordinates -- verify before trusting"
        amplicon = extract_amplicon(genome, spec)
        promoters[name] = {
            "sequence": amplicon, "source": "genome_primer_validated", "locus_tag": spec["locus_tag"],
            "gene": g["gene"], "strand": spec["strand"], "translation_start": spec["tss"],
            "provenance": f"exact amplicon recovered from BX927147.1 using the primer pair PMC7835838 "
                          f"Methods 2.3 states was used to amplify {name} (locus {spec['locus_tag']}/{g['gene']}) "
                          f"for functional characterization; amplicon runs from the forward-primer anneal site "
                          f"to the reverse-primer anneal site immediately preceding the native ATG "
                          f"(replaced by the vector's own NcoI-supplied start codon in the actual construct)",
            "strength_pct_ptrc": STRENGTH_PCT_OF_PTRC[name],
        }

    for name, seq in SYNTHETIC_SEQS.items():
        promoters[name] = {
            "sequence": seq, "source": "literature_explicit", "locus_tag": None, "gene": None,
            "strand": None, "translation_start": None,
            "provenance": "PMC7835838 Methods 2.3, verbatim quoted sequence, verified against raw HTML "
                          "(no page-break artifact)",
            "strength_pct_ptrc": STRENGTH_PCT_OF_PTRC[name],
        }

    out = DATA / "cache" / "core_promoters.json"
    out.write_text(json.dumps(promoters, indent=1))
    print(f"Assembled {len(promoters)} core promoters -> {out}")
    for name, p in sorted(promoters.items(), key=lambda x: x[1]["strength_pct_ptrc"]):
        print(f"  {name:8s} {p['strength_pct_ptrc']:>6.1f}% of Ptrc  ({len(p['sequence'])} bp, source={p['source']})")
        print(f"           {p['sequence']}")


if __name__ == "__main__":
    main()
