"""Pairwise global alignment identity matrix.

Aligner: Biopython Bio.Align.PairwiseAligner, BLOSUM62, gap open -11 / extend -1,
global (Needleman-Wunsch) mode, terminal gaps unpenalised (end-gap score = 0).

For every pair, reports percent identity on BOTH denominators:
  (a) identities / aligned columns after trimming terminal gap columns
  (b) identities / length of the shorter of the two input sequences

Can be pointed at either full-length sequences (data/fasta/*.fasta) or
domain-extracted sequences (results/rec_domains.fasta, results/dhp_domains.fasta)
via --input / --output / --label.
"""
import argparse
import csv
import itertools
from pathlib import Path

from Bio import Align, SeqIO
from Bio.Align import substitution_matrices

ROOT = Path(__file__).resolve().parent.parent


def make_aligner():
    aligner = Align.PairwiseAligner()
    aligner.substitution_matrix = substitution_matrices.load("BLOSUM62")
    aligner.mode = "global"
    aligner.open_gap_score = -11
    aligner.extend_gap_score = -1
    # terminal gaps unpenalised
    aligner.target_end_gap_score = 0.0
    aligner.query_end_gap_score = 0.0
    return aligner


def trimmed_identity(aligned_target: str, aligned_query: str):
    """identities / aligned columns after trimming terminal all-gap columns."""
    cols = list(zip(aligned_target, aligned_query))
    start = 0
    end = len(cols)
    while start < end and (cols[start][0] == "-" or cols[start][1] == "-"):
        start += 1
    while end > start and (cols[end - 1][0] == "-" or cols[end - 1][1] == "-"):
        end -= 1
    core = cols[start:end]
    if not core:
        return 0, 0, 0.0
    identities = sum(1 for a, b in core if a == b and a != "-")
    return identities, len(core), (100.0 * identities / len(core) if core else 0.0)


def compute_pair(aligner, seq_a: str, seq_b: str):
    alignment = aligner.align(seq_a, seq_b)[0]
    aligned = str(alignment).split("\n")
    # Bio.Align alignment string format: target, match-line, query (3 lines, possibly wrapped)
    a_lines, b_lines = [], []
    lines = str(alignment).splitlines()
    # Robust extraction via alignment.aligned indices + alignment[0]/[1] strings instead of parsing text
    t_aligned, q_aligned = alignment[0], alignment[1]
    ident, aligned_cols, pct_a = trimmed_identity(t_aligned, q_aligned)
    shorter = min(len(seq_a), len(seq_b))
    pct_b = 100.0 * ident / shorter if shorter else 0.0
    return {
        "identities": ident,
        "aligned_columns_trimmed": aligned_cols,
        "pct_identity_aligned_columns": round(pct_a, 2),
        "pct_identity_shorter_seq": round(pct_b, 2),
        "len_a": len(seq_a),
        "len_b": len(seq_b),
        "score": alignment.score,
    }


def load_fasta_dir_or_file(path: Path, labels: dict):
    """labels: accession -> display label. Loads sequences either from a directory
    of per-accession fasta files (data/fasta/ACC.fasta) or a single multi-fasta file."""
    seqs = {}
    if path.is_dir():
        for acc in labels:
            fp = path / f"{acc}.fasta"
            if not fp.exists():
                print(f"  WARNING: missing fasta for {acc} at {fp}")
                continue
            rec = next(SeqIO.parse(fp, "fasta"))
            seqs[acc] = str(rec.seq).replace("*", "")
    else:
        for rec in SeqIO.parse(path, "fasta"):
            acc = rec.id.split("|")[0]
            seqs[acc] = str(rec.seq).replace("*", "")
    return seqs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=str(ROOT / "data" / "manifest.csv"))
    ap.add_argument("--fasta-source", default=str(ROOT / "data" / "fasta"),
                     help="directory of per-accession fasta, or a single multi-fasta file")
    ap.add_argument("--out", default=str(ROOT / "results" / "identity_full.csv"))
    ap.add_argument("--flag-threshold", type=float, default=15.0,
                     help="flag pairs where the two denominators diverge by more than this many points")
    args = ap.parse_args()

    manifest_rows = list(csv.DictReader(open(args.manifest)))
    labels = {row["accession"]: row for row in manifest_rows}
    fasta_source = Path(args.fasta_source)
    seqs = load_fasta_dir_or_file(fasta_source, labels)

    donors = [r["accession"] for r in manifest_rows if r["category"] == "donor" and r["accession"] in seqs]
    natives = [r["accession"] for r in manifest_rows
               if r["category"] in ("native_RR", "native_HK") and r["accession"] in seqs]

    aligner = make_aligner()

    out_rows = []
    flagged = []
    total_pairs = len(donors) * len(natives)
    done = 0
    for d_acc, n_acc in itertools.product(donors, natives):
        d_row, n_row = labels[d_acc], labels[n_acc]
        # only compare RR-vs-RR and HK-vs-HK biologically, but report all for completeness;
        # mark same_class for filtering downstream
        d_is_rr = "RR" in d_row["role"] or d_row["category"] == "donor" and "RR" in d_row["role"] or d_row["gene_label"] in ("Sal_PhoP", "Ec_PhoP", "Ec_OmpR", "Ec_NarL")
        d_is_hk = d_row["gene_label"] in ("Sal_PhoQ", "Ec_EnvZ")
        n_is_rr = n_row["category"] == "native_RR"
        n_is_hk = n_row["category"] == "native_HK"
        same_class = (d_is_rr and n_is_rr) or (d_is_hk and n_is_hk)

        res = compute_pair(aligner, seqs[d_acc], seqs[n_acc])
        row = {
            "donor_label": d_row["gene_label"], "donor_accession": d_acc,
            "native_label": n_row["gene_label"], "native_locus_tag": n_row["locus_tag"],
            "native_accession": n_acc, "native_category": n_row["category"],
            "same_class": same_class,
            **res,
        }
        out_rows.append(row)
        divergence = abs(res["pct_identity_aligned_columns"] - res["pct_identity_shorter_seq"])
        if divergence > args.flag_threshold:
            flagged.append((row, divergence))
        done += 1
        if done % 25 == 0:
            print(f"  {done}/{total_pairs} pairs computed...")

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="") as fh:
        fieldnames = list(out_rows[0].keys()) if out_rows else []
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in out_rows:
            writer.writerow(row)

    print(f"\nWrote {len(out_rows)} pairwise comparisons to {out_path}")
    if flagged:
        print(f"\n{len(flagged)} pairs flagged (denominators diverge >{args.flag_threshold} points):")
        for row, div in sorted(flagged, key=lambda x: -x[1])[:20]:
            print(f"  {row['donor_label']} vs {row['native_label']} ({row['native_locus_tag']}): "
                  f"aligned-col={row['pct_identity_aligned_columns']}% shorter-seq={row['pct_identity_shorter_seq']}% "
                  f"(divergence {div:.1f})")


if __name__ == "__main__":
    main()
