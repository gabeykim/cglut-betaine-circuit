"""Fetch every protein sequence referenced in data/resolved_loci.json.

Donor sequences come from UniProt REST (rest.uniprot.org).
Native C. glutamicum sequences come from NCBI Entrez (protein db, EMBL/GenBank
CAF#### accessions from BX927147), via Biopython Bio.Entrez.

Every fetched record is cached to data/fasta/<ACCESSION>.fasta. On rerun, a
cached file is reused (never re-derived, never hand-written) so the pipeline
runs fully offline after the first fetch. A manifest CSV is (re)written
mapping locus tag -> accession -> description -> source URL.
"""
import csv
import json
import ssl
import time
import urllib.request
import urllib.error
from pathlib import Path

import certifi
from Bio import Entrez, SeqIO

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
FASTA_DIR = DATA / "fasta"
MANIFEST = DATA / "manifest.csv"

# Some macOS python.org builds ship without a populated CA trust store, which
# makes urllib (and Bio.Entrez, which uses urllib internally) fail every HTTPS
# request with CERTIFICATE_VERIFY_FAILED. Point both at certifi's bundle
# explicitly rather than requiring a one-off system fix.
_SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
https_handler = urllib.request.HTTPSHandler(context=_SSL_CONTEXT)
urllib.request.install_opener(urllib.request.build_opener(https_handler))

Entrez.email = "gabe.y.kim@gmail.com"
Entrez.tool = "cglutamicum-crosstalk-pipeline"

UNIPROT_FASTA_URL = "https://rest.uniprot.org/uniprotkb/{acc}.fasta"
NCBI_SOURCE_URL = "https://www.ncbi.nlm.nih.gov/protein/{acc}"
UNIPROT_SOURCE_URL = "https://www.uniprot.org/uniprotkb/{acc}"


def fetch_uniprot(accession: str) -> str:
    cache = FASTA_DIR / f"{accession}.fasta"
    if cache.exists():
        return cache.read_text()
    url = UNIPROT_FASTA_URL.format(acc=accession)
    with urllib.request.urlopen(url, timeout=30) as resp:
        text = resp.read().decode()
    if not text.strip().startswith(">"):
        raise RuntimeError(f"UniProt fetch for {accession} did not return FASTA: {text[:200]}")
    cache.write_text(text)
    return text


def fetch_ncbi_protein(accession: str) -> str:
    cache = FASTA_DIR / f"{accession}.fasta"
    if cache.exists():
        return cache.read_text()
    handle = Entrez.efetch(db="protein", id=accession, rettype="fasta", retmode="text")
    text = handle.read()
    handle.close()
    if not text.strip().startswith(">"):
        raise RuntimeError(f"NCBI fetch for {accession} did not return FASTA: {text[:200]}")
    cache.write_text(text)
    time.sleep(0.34)  # NCBI rate limit: max 3 req/s without an API key
    return text


def seq_len(fasta_text: str) -> int:
    from io import StringIO
    rec = next(SeqIO.parse(StringIO(fasta_text), "fasta"))
    return len(rec.seq)


def main():
    FASTA_DIR.mkdir(parents=True, exist_ok=True)
    resolved = json.loads((DATA / "resolved_loci.json").read_text())

    rows = []
    unresolved = []

    print("=== Donor sequences (UniProt) ===")
    for d in resolved["donors"]:
        acc = d["resolved_accession"]
        try:
            text = fetch_uniprot(acc)
            n = seq_len(text)
            print(f"  {d['label']:8s} {d['organism']:28s} {acc:10s} ({n} aa) [{d['role']}]")
            rows.append({
                "locus_tag": "-", "gene_label": d["label"], "organism": d["organism"],
                "accession": acc, "role": d["role"], "length_aa": n,
                "description": d["note"], "source_url": UNIPROT_SOURCE_URL.format(acc=acc),
                "category": "donor",
            })
        except Exception as e:
            print(f"  FAILED  {d['label']} {acc}: {e}")
            unresolved.append((d["label"], acc, str(e)))

    print("=== Native response regulators (NCBI protein, from BX927147) ===")
    for r in resolved["native_response_regulators"]:
        acc = r["protein_accession"]
        try:
            text = fetch_ncbi_protein(acc)
            n = seq_len(text)
            print(f"  {r['label']:16s} {r['cg_locus_tag']:9s} {acc:12s} ({n} aa) [{r['family_task']}]")
            rows.append({
                "locus_tag": r["cg_locus_tag"], "gene_label": r["label"], "organism": "C. glutamicum ATCC 13032",
                "accession": acc, "role": f"native_RR:{r['family_task']}", "length_aa": n,
                "description": r["product_bx"], "source_url": NCBI_SOURCE_URL.format(acc=acc),
                "category": "native_RR",
            })
        except Exception as e:
            print(f"  FAILED  {r['label']} {acc}: {e}")
            unresolved.append((r["label"], acc, str(e)))

    print("=== Native sensor kinases (NCBI protein, from BX927147) ===")
    for k in resolved["native_kinases"]:
        acc = k["protein_accession"]
        try:
            text = fetch_ncbi_protein(acc)
            n = seq_len(text)
            print(f"  {k['label']:16s} {k['cg_locus_tag']:9s} {acc:12s} ({n} aa) paired with {k['paired_rr']}")
            rows.append({
                "locus_tag": k["cg_locus_tag"], "gene_label": k["label"], "organism": "C. glutamicum ATCC 13032",
                "accession": acc, "role": f"native_HK:paired_with:{k['paired_rr']}", "length_aa": n,
                "description": k["product_bx"], "source_url": NCBI_SOURCE_URL.format(acc=acc),
                "category": "native_HK",
            })
        except Exception as e:
            print(f"  FAILED  {k['label']} {acc}: {e}")
            unresolved.append((k["label"], acc, str(e)))

    with open(MANIFEST, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "category", "locus_tag", "gene_label", "organism", "accession",
            "role", "length_aa", "description", "source_url",
        ])
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    print(f"\nWrote {len(rows)} rows to {MANIFEST}")
    if unresolved:
        print(f"\n{len(unresolved)} FETCH FAILURES:")
        for label, acc, err in unresolved:
            print(f"  {label} ({acc}): {err}")
    else:
        print("All sequences fetched/cached successfully.")


if __name__ == "__main__":
    main()
