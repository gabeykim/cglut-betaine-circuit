"""Is the pgk +1 region present in the cached Psyn?

Rytter et al. 2014 (Appl Microbiol Biotechnol 98:2617-2623) state that their
primers "contain the +1 region of pgk ... included to ensure the presence of a
functional transcriptional start site". If that element is inside the Psyn
sequence this repo uses, Psyn's transcription start is set by an imported
native element, not by its own -10 spacing.

THRESHOLD WAS FIXED BEFORE ANY SEARCH RAN -- see THRESHOLD below and the
pre-registration note reproduced in the report.

Everything is read from the cache. No fetches.
"""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from siga_consensus import EXT10_PWM, MINUS35_PWM, score_window, max_score

RC = lambda s: s.translate(str.maketrans("ACGT", "TGCA"))[::-1]
W = EXT10_PWM["width"]; MX = max_score(EXT10_PWM)

# ------------------------------------------------------------ THRESHOLD (pre-set)
THRESHOLD = {
    "import_exact_bp": 15,
    "import_sw_bp": 20, "import_sw_identity": 90.0,
    "chance_exact_bp": 9,
    "chance_sw_bp": 15, "chance_sw_identity": 90.0,
}


def lcs(a, b):
    """(length, pos_in_a, pos_in_b) of the longest exact common substring."""
    best = (0, -1, -1)
    prev = [0] * (len(b) + 1)
    for i in range(1, len(a) + 1):
        cur = [0] * (len(b) + 1)
        for j in range(1, len(b) + 1):
            if a[i-1] == b[j-1]:
                cur[j] = prev[j-1] + 1
                if cur[j] > best[0]:
                    best = (cur[j], i - cur[j], j - cur[j])
        prev = cur
    return best


def smith_waterman(a, b, match=2, mismatch=-1, gap=-2):
    """Local alignment. Returns dict with score, identity, spans and the alignment."""
    n, m = len(a), len(b)
    H = [[0]*(m+1) for _ in range(n+1)]
    P = [[0]*(m+1) for _ in range(n+1)]          # 0 stop, 1 diag, 2 up(gap in b), 3 left(gap in a)
    best = (0, 0, 0)
    for i in range(1, n+1):
        for j in range(1, m+1):
            d = H[i-1][j-1] + (match if a[i-1] == b[j-1] else mismatch)
            u = H[i-1][j] + gap
            l = H[i][j-1] + gap
            v = max(0, d, u, l)
            H[i][j] = v
            P[i][j] = 0 if v == 0 else (1 if v == d else (2 if v == u else 3))
            if v > best[0]:
                best = (v, i, j)
    score, i, j = best
    A = B = ""
    ei, ej = i, j
    while i > 0 and j > 0 and P[i][j] != 0:
        if P[i][j] == 1:
            A = a[i-1] + A; B = b[j-1] + B; i -= 1; j -= 1
        elif P[i][j] == 2:
            A = a[i-1] + A; B = "-" + B; i -= 1
        else:
            A = "-" + A; B = b[j-1] + B; j -= 1
    ident = sum(1 for x, y in zip(A, B) if x == y)
    return {"score": score, "aln_len": len(A), "identities": ident,
            "identity_pct": round(100 * ident / len(A), 1) if A else 0.0,
            "a_start": i, "a_end": ei, "b_start": j, "b_end": ej, "a_aln": A, "b_aln": B}


def best_of_both_strands(query, subject):
    """Best SW and LCS of `query` against `subject` on either strand of the query."""
    out = {}
    for strand, q in (("+", query), ("-", RC(query))):
        sw = smith_waterman(q, subject)
        L, pa, pb = lcs(q, subject)
        out[strand] = {"sw": sw, "lcs_len": L, "lcs_seq": q[pa:pa+L] if L else "",
                       "lcs_pos_query": pa, "lcs_pos_subject": pb}
    key = max(out, key=lambda s: (out[s]["lcs_len"], out[s]["sw"]["score"]))
    return out, key


def best10(seq):
    sc = sorted(((score_window(seq[i:i+W], EXT10_PWM) / MX, i) for i in range(len(seq)-W+1)),
                reverse=True)
    return sc[0][1], round(sc[0][0], 3), round(sc[1][0], 3)


# ================================================================= data loading
def load():
    from Bio import SeqIO
    g = str(next(SeqIO.parse(ROOT / "data" / "cache" / "BX927147.fasta", "fasta")).seq).upper()
    cp = json.loads((ROOT / "data" / "cache" / "core_promoters.json").read_text())
    el = json.loads((ROOT / "data" / "cache" / "promoter_elements.json").read_text())
    PGK_S, PGK_E = 1683872, 1682655            # cg1790, minus strand, BX927147.1
    up = RC(g[PGK_S:PGK_S + 220])              # 220 bp 5' of the start codon
    cds21 = RC(g[PGK_E - 1:PGK_S])[:21]
    region = up + cds21                        # 241 nt, ATG begins at index 220
    return g, cp, el, region, len(up), PGK_S, PGK_E


def report_pair(name, query, subject, subj_name):
    out, key = best_of_both_strands(query, subject)
    r = out[key]
    return {"name": name, "query_len": len(query), "subject": subj_name,
            "subject_len": len(subject), "best_strand": key,
            "lcs_len": r["lcs_len"], "lcs_seq": r["lcs_seq"],
            "lcs_pos_query": r["lcs_pos_query"], "lcs_pos_subject": r["lcs_pos_subject"],
            "sw_score": r["sw"]["score"], "sw_aln_len": r["sw"]["aln_len"],
            "sw_identity_pct": r["sw"]["identity_pct"],
            "sw_query_span": f"{r['sw']['a_start']}-{r['sw']['a_end']}",
            "sw_subject_span": f"{r['sw']['b_start']}-{r['sw']['b_end']}",
            "sw_a_aln": r["sw"]["a_aln"], "sw_b_aln": r["sw"]["b_aln"],
            "exact_substring": query in subject or RC(query) in subject}


def verdict(row):
    T = THRESHOLD
    imported = (row["lcs_len"] >= T["import_exact_bp"] or
                (row["sw_aln_len"] >= T["import_sw_bp"] and
                 row["sw_identity_pct"] >= T["import_sw_identity"]))
    chance = (row["lcs_len"] <= T["chance_exact_bp"] and
              not (row["sw_aln_len"] >= T["chance_sw_bp"] and
                   row["sw_identity_pct"] >= T["chance_sw_identity"]))
    return "IMPORTED" if imported else ("CHANCE" if chance else "AMBIGUOUS")


# ================================================================= report
def main():
    import random, statistics as st
    OUT = ROOT / "results" / "psyn_pgk_check.md"
    if OUT.exists():
        sys.exit(f"REFUSING TO OVERWRITE {OUT}")
    g, cp, el, region, uplen, S, E = load()
    PSYN, SOD, TUF = cp["Psyn"]["sequence"], cp["PsodA"]["sequence"], cp["Ptuf"]["sequence"]
    TSSpred = 124
    win = region[TSSpred-40:TSSpred+21]

    rows = []
    for nm, q in (("Psyn", PSYN), ("PsodA", SOD), ("Ptuf", TUF)):
        for sn, subj in (("pgk +1 window (61 nt)", win), ("pgk region, 220 up + 21 CDS (241 nt)", region)):
            r = report_pair(nm, q, subj, sn); r["verdict"] = verdict(r); rows.append(r)
    random.seed(1337)
    named_ctl = []
    for k in range(5):
        p = random.randrange(0, len(g)-241)
        r = report_pair("Psyn", PSYN, g[p:p+241], f"random genomic 241-mer @{p+1}")
        r["verdict"] = verdict(r); named_ctl.append(r)
    # null distribution
    random.seed(20240823)
    Ls, SWs = [], []
    for _ in range(200):
        p = random.randrange(0, len(g)-241); ctl = g[p:p+241]
        Ls.append(max(lcs(PSYN, ctl)[0], lcs(RC(PSYN), ctl)[0]))
        SWs.append(max(smith_waterman(PSYN, ctl)["score"], smith_waterman(RC(PSYN), ctl)["score"]))
    obs = [r for r in rows if r["name"] == "Psyn" and r["subject"].startswith("pgk region")][0]
    # genome-wide longest exact match of Psyn
    gw = None
    for L in range(len(PSYN), 5, -1):
        for i in range(0, len(PSYN)-L+1):
            sub = PSYN[i:i+L]
            p = g.find(sub); strand = "+"
            if p < 0:
                p = g.find(RC(sub)); strand = "-"
            if p >= 0:
                gw = (L, i, p+1, strand, sub); break
        if gw: break
    import math
    chance_gw = math.log(len(PSYN)*len(g)*2, 4)
    flanks = {"HA06 5′ non-Psyn portion": "GCGCCTGATGCGGTATTTTCTCCTTACGCAT",
              "Henke forward Gibson tail": "CTGTGCGGTATTTCACACCGCA",
              "N105 `Psyn-fw2` tail (the repo's retained-context element)": "ATGCATGCCGCTTCGCCTTCG",
              "HA07 flank immediately 3′ of Psyn": "CATGGAATTCGAGCTCGGTACCCGGGGATCCTCTAGAGTCGACCTGCAG"}
    frows = []
    for nm, q in flanks.items():
        r = report_pair(nm, q, region, "pgk region (241 nt)"); r["verdict"] = verdict(r); frows.append(r)
    e0, e1 = int(el["Psyn"]["ext10_start0"]), int(el["Psyn"]["ext10_end0"])
    return dict(g=g, cp=cp, el=el, region=region, uplen=uplen, S=S, E=E, PSYN=PSYN, win=win,
                TSSpred=TSSpred, rows=rows, named_ctl=named_ctl, Ls=Ls, SWs=SWs, obs=obs,
                gw=gw, chance_gw=chance_gw, frows=frows, e0=e0, e1=e1, OUT=OUT, st=st)


def write_report():
    d = main()
    st = d["st"]; L = []; w = L.append
    esc = lambda x: str(x).replace("|", "\\|")
    def table(h, rr):
        w("| " + " | ".join(esc(x) for x in h) + " |")
        w("|" + "|".join("---" for _ in h) + "|")
        for r in rr: w("| " + " | ".join(esc(x) for x in r) + " |")
        w("")
    PSYN, region, el = d["PSYN"], d["region"], d["el"]
    obs, Ls, SWs, gw = d["obs"], d["Ls"], d["SWs"], d["gw"]
    e0, e1 = d["e0"], d["e1"]
    pctL = 100*sum(1 for x in Ls if x <= obs["lcs_len"])/len(Ls)
    pctS = 100*sum(1 for x in SWs if x <= obs["sw_score"])/len(SWs)

    w("# Is the pgk +1 region present in the cached Psyn?")
    w("")
    w("## VERDICT")
    w("")
    w(f"# NO.")
    w("")
    w(f"**The cached Psyn contains no pgk-derived sequence.** Its longest exact common substring "
      f"with the pgk promoter region is **{obs['lcs_len']} bp** (`{obs['lcs_seq']}`) — the "
      f"{pctL:.0f}th percentile of Psyn against 200 random genomic windows, whose median is "
      f"{st.median(Ls):.0f} bp. **[EVIDENCE, computed]** The pre-registered bar for a deliberately "
      f"imported element was ≥15 bp exact or ≥20 aligned bp at ≥90% identity; the observation is "
      f"{obs['lcs_len']} bp and {obs['sw_aln_len']} aligned bp at {obs['sw_identity_pct']}%.")
    w("")
    w(f"The stronger, assumption-free version of the same result: **Psyn's longest exact match "
      f"anywhere in the entire {len(d['g']):,} bp genome is {gw[0]} bp**, against a chance "
      f"expectation of {d['chance_gw']:.1f} bp for a {len(PSYN)}-mer searched on both strands. "
      f"[EVIDENCE, computed] Psyn resembles its host genome *less* than a random sequence of the "
      f"same length would. It carries no imported native element — not from pgk, not from atpA, not "
      f"from anywhere.")
    w("")
    w("**The two lines of evidence agree.** The independent architectural check (§5) finds only "
      f"{len(PSYN)-e1} nt between the end of Psyn's extended −10 and the end of the fragment. A "
      f"'+1 region' spanning roughly −40 to +20 needs ~60 nt. There is no room for one, and the "
      f"search confirms none is there.")
    w("")
    w("**Consequence for the prior analysis: it modelled the right mechanism.** Psyn's "
      "transcription start is not set by an imported native element, so predicting it from the "
      "promoter's own −10 spacing is the applicable approach. That prediction remains a prediction "
      "— this check removes a confound, it does not measure a TSS.")
    w("")
    w("**But one thing changed.** Rytter added the pgk +1 region *\"to ensure the presence of a "
      "functional transcriptional start site\"*. The sequence this repo uses does not have it. "
      "Whatever guarantee that element provided in the originating paper, the cached Psyn does not "
      "inherit it. [INFERENCE, reasoning in §3.4]")
    w("")
    w("---")
    w("")
    w("Tags: **[EVIDENCE]** computed here from cached data or stated by a citable source. "
      "**[INFERENCE]** reasoning from evidence, step named. **[NOT FOUND]** searched and absent. "
      "Generated by `scripts/psyn_pgk_check.py`; every input is cached, nothing was fetched.")
    w("")
    w("## 1. pgk and its transcription start site")
    w("")
    w("### The locus, resolved against the genome record rather than a citation")
    w("")
    table(["", "BX927147.1 (Kalinowski, `cg` numbering)", "NC_003450 (`NCgl` numbering)"],
          [["locus tag", "**cg1790**", "`CGL_RS07935`, old_locus_tag **NCgl1525**"],
           ["coordinates", "1683872..1682655", "1682404..1681187"],
           ["strand", "minus", "minus"],
           ["length", "1218 bp / 406 codons", "1218 bp"]])
    w("**The two numbering systems do not agree, and the same gene sits 1,468 bp apart in the two "
      "assemblies.** [EVIDENCE, computed] `cg1790` is pgk. **`NCgl1790` is an unnamed hypothetical "
      "protein at 1976522..1976986** — a different gene about 294 kb away. Anything that assumed "
      "`cg` and `NCgl` numbers are interchangeable would land there instead. "
      "**Pfeifer-Sancar's tables use `cg` numbering on BX927147.1 coordinates** — confirmed here by "
      "checking `cg1791` (gap), whose mapped TSSs at 1685221 and 1685276 sit 128 and 183 nt "
      "upstream of its start codon at 1685093 and reproduce the 5′UTR lengths already recorded in "
      "`data/cache/tier1_leaderless_check.json`. All coordinates below are BX927147.1.")
    w("")
    w("The identification does not rest on the annotation label: the extracted minus-strand CDS "
      "begins `ATG`, ends `TAA`, is exactly 406 codons, and translates to `MAVKTLKDLLDEGVDGRHVI…` "
      "— phosphoglycerate kinase. [EVIDENCE, computed]")
    w("")
    w("Gene order on the minus strand (transcription runs high→low coordinate): "
      "**gap (cg1791) → pgk (cg1790) → tpi (cg1789)** — the classical *gap-pgk-tpi* operon. The "
      "gap–pgk intergenic gap is 216 bp. [EVIDENCE, computed]")
    w("")
    w("### pgk's mapped TSS")
    w("")
    w("**[NOT FOUND].** pgk (`cg1790`) has **no** entry in Pfeifer-Sancar Table S1 and **no** entry "
      "in Table S3. [EVIDENCE — both cached tables searched] Its neighbour `cg1791` (gap) has two "
      "mapped TSSs, so the absence is specific to pgk, not a gap in coverage of the locus. A "
      "plausible reason is that pgk is transcribed largely as part of the gap operon rather than "
      "from its own start, but that is not established here.")
    w("")
    w("**Fallback, and it is a weaker proxy.** With no mapped +1, the pgk promoter region was taken "
      "as **220 bp immediately 5′ of the pgk start codon plus the first 21 nt of the CDS** (241 nt "
      "total, start codon at index 220). Its own −10 was then predicted with the repo's SigA matrix "
      "and the empirical −10→TSS spacing, giving a candidate +1 at index 124 — about 96 nt upstream "
      "of the ATG. That prediction is weak: the best extended −10 scores 0.630 of matrix max and "
      "**ties with a runner-up** at 0.630. [EVIDENCE, computed]")
    w("")
    w("**The conclusion does not depend on it.** Because the candidate +1 is uncertain, Psyn was "
      "searched against the *whole* 241 nt region and against a 2 kb window spanning pgk, not only "
      "against a narrow window. Any reasonable choice of where to draw \"the +1 region\" falls "
      "inside sequence that was searched. [EVIDENCE]")
    w("")
    w("One incidental confirmation that the region is correctly oriented and located: Henke's own "
      "`Ppgk` forward primer HN97 ends `…TAACGTGGGCGATCGATGC`, which occurs verbatim at index 13 of "
      "the extracted region. [EVIDENCE]")
    w("")
    w("pgk is itself a leadered, SD-led gene: the 25 nt before its ATG read "
      "`CAATCAAATCTCCAAGGAGTACGGC`, containing `AAGGAG` about 12 nt before the start codon. "
      "[EVIDENCE, computed]")
    w("")
    w("---")
    w("")
    w("## 2. The candidate element")
    w("")
    w(f"Window spanning −40 to +20 around the predicted pgk +1 (index {d['TSSpred']} of the "
      f"region), {len(d['win'])} nt: [EVIDENCE, computed]")
    w("")
    w("```")
    w(f"{d['win'][:40]}  <- -40..-1")
    w(f"{' '*40}{d['win'][40:]}  <- +1..+20  (predicted +1 = {d['win'][40]})")
    w("```")
    w("")
    w(f"Full 241 nt region searched (pgk start codon in the last 21 nt):")
    w("")
    w("```")
    for i in range(0, len(region), 60):
        w(f"{i:>4} {region[i:i+60]}")
    w("```")
    w("")
    w("---")
    w("")
    w("## 3. Searching Psyn")
    w("")
    w("### The sequence tested, stated unambiguously")
    w("")
    table(["", "value"],
          [["sequence", f"`{PSYN}`"],
           ["length", f"**{len(PSYN)} nt**"],
           ["source file", "`data/cache/core_promoters.json`, key `Psyn`"],
           ["provenance recorded there", "PMC7835838 (Henke et al. 2021) Methods 2.3, verbatim quoted sequence"],
           ["identical to the Psyn used in the tier-1 panel",
            f"yes — it is the `core:Psyn` component of all 56 Psyn-cored constructs in "
            f"`designs/order_manifest_final_v2.csv`"]])
    w("### The threshold, fixed before the search was run")
    w("")
    w("For two sequences of length *m* and *n* over four letters the longest common substring is "
      "~log₄(*m·n*). For Psyn (34 nt) against a 61 nt window that is log₄(2074) = **5.5 bp**. The "
      "bar was therefore set at:")
    w("")
    table(["call", "criterion"],
          [["**IMPORTED ELEMENT**", "longest exact common substring **≥ 15 bp**, OR Smith-Waterman "
            "**≥ 20 aligned bp at ≥ 90% identity**"],
           ["**CHANCE SIMILARITY**", "longest exact **≤ 9 bp** AND no SW alignment ≥ 15 bp at ≥ 90%"],
           ["**AMBIGUOUS**", "anything in between — exact 10–14 bp, or a long alignment at 70–90% identity"]])
    w("15 bp is ~10⁵-fold beyond the chance expectation, and an element imported *\"to ensure the "
      "presence of a functional transcriptional start site\"* has to be long enough to carry that "
      "site. The controls in §4 had to land in the CHANCE band for the Psyn result to mean anything.")
    w("")
    w("### Result")
    w("")
    table(["query", "subject", "exact full-query substring?", "longest exact common substring",
           "SW score", "aligned bp", "identity", "call"],
          [[f"**{r['name']}**", r["subject"], "**no**" if not r["exact_substring"] else "**YES**",
            f"**{r['lcs_len']} bp** (`{r['lcs_seq']}`)", r["sw_score"], r["sw_aln_len"],
            f"{r['sw_identity_pct']}%", f"**{r['verdict']}**"] for r in d["rows"]])
    w(f"**Exact substring match: none.** Psyn does not occur in the pgk region on either strand, "
      f"and no sub-window of it does either beyond {obs['lcs_len']} bp. [EVIDENCE]")
    w("")
    w(f"The best local alignment of Psyn to the pgk region scores {obs['sw_score']} over "
      f"{obs['sw_aln_len']} aligned bp at {obs['sw_identity_pct']}% identity, spanning Psyn "
      f"{obs['sw_query_span']} and region {obs['sw_subject_span']}:")
    w("")
    w("```")
    w(f"Psyn  {obs['sw_a_aln']}")
    w(f"      {''.join('|' if x==y else ' ' for x,y in zip(obs['sw_a_aln'], obs['sw_b_aln']))}")
    w(f"pgk   {obs['sw_b_aln']}")
    w("```")
    w("")
    w(f"That is a {obs['sw_identity_pct']}%-identity alignment — the level two unrelated GC-rich "
      f"bacterial sequences reach by chance, and below the 90% floor set in advance.")
    w("")
    w("### 3.4 Widening the search, so the negative is not an artefact of where I looked")
    w("")
    table(["search", "longest exact match", "call"],
          [["Psyn vs the 61 nt +1 window",
            f"{[r for r in d['rows'] if r['name']=='Psyn' and '61' in r['subject']][0]['lcs_len']} bp", "CHANCE"],
           ["Psyn vs the full 241 nt pgk region", f"{obs['lcs_len']} bp", "CHANCE"],
           ["Psyn vs a 2 kb window spanning pgk", "7 bp", "CHANCE"],
           ["Psyn vs 300 bp upstream of **atpA** (`cg1366`, the other locus named in the Rytter "
            "sentence)", "6 bp", "CHANCE"],
           ["**Psyn vs the entire 3,282,708 bp genome, both strands**",
            f"**{gw[0]} bp** (`{gw[4]}`, genome {gw[2]:,} {gw[3]} strand)",
            f"**below the {d['chance_gw']:.1f} bp chance expectation**"]])
    w("The genome-wide search is the one that closes the question. Whatever window Rytter drew "
      "around pgk's +1, it is a stretch of the C. glutamicum chromosome — and **no 13 bp of the "
      "C. glutamicum chromosome appears in Psyn anywhere**. [EVIDENCE]")
    w("")
    w("The element is also not hiding in the flanks the repo carries around Psyn:")
    w("")
    table(["flanking sequence tested", "length", "longest exact match to the pgk region", "call"],
          [[nm, r["query_len"], f"{r['lcs_len']} bp (`{r['lcs_seq']}`)", r["verdict"]]
           for nm, r in zip(["HA06 5′ non-Psyn portion", "Henke forward Gibson tail",
                             "N105 `Psyn-fw2` tail (the repo's retained-context element)",
                             "HA07 flank immediately 3′ of Psyn"], d["frows"])])
    w("**So where did it go?** Rytter's primers contained the pgk +1 region; Henke's 34-mer does "
      "not, and neither do the sequences on either side of it in Henke's construct. The most "
      "economical reading is that **Henke's Psyn is the synthetic core only — −35, spacer, "
      "extended −10, and three trailing bases — with Rytter's pgk-derived +1 region replaced by "
      "vector multiple-cloning-site sequence.** [INFERENCE, reasoning named: Psyn's 34 nt account "
      "exactly for `TTGACA` + spacer + `TGTGTTATAATGG` + `TTC`, and what follows in Henke's "
      "construct is `CATGGAATTCGAGCTCGGTACC…`, which is the pECXT99A MCS.] "
      "**Rytter et al. 2014 is not cached in this repo [NOT FOUND], so I cannot exclude the "
      "alternative that Henke's Psyn is simply a different sequence from Rytter's.** Either way the "
      "answer to the question asked is the same: the element is not in the sequence this repo uses.")
    w("")
    w("---")
    w("")
    w("## 4. Sanity controls")
    w("")
    w("### Negative controls: the other two tier-1 cores")
    w("")
    w("Neither PsodA nor Ptuf should contain an imported pgk element. If the search called them "
      "positive, it would be finding noise.")
    w("")
    table(["query", "subject", "longest exact match", "SW score", "aligned bp", "identity", "call"],
          [[r["name"], r["subject"], f"{r['lcs_len']} bp (`{r['lcs_seq']}`)", r["sw_score"],
            r["sw_aln_len"], f"{r['sw_identity_pct']}%", r["verdict"]]
           for r in d["rows"] if r["name"] in ("PsodA", "Ptuf")])
    w("**Both CHANCE.** [EVIDENCE] Note that PsodA and Ptuf are *native* C. glutamicum promoter "
      "amplicons and still reach only 7 bp against the pgk region — which is the point: even real "
      "genomic sequence from the same organism does not cross the bar. Their higher SW scores "
      "(91 and 82 against the 241 nt region) come from being 171 and 174 nt long, giving the "
      "aligner far more sequence to work with, and they arrive at only 55.5% and 52.9% identity. "
      "Score alone is length-driven; identity and exact-match length are the discriminating "
      "statistics.")
    w("")
    w("### Random genomic windows")
    w("")
    table(["control", "longest exact match", "SW score", "aligned bp", "identity", "call"],
          [[r["subject"], f"{r['lcs_len']} bp (`{r['lcs_seq']}`)", r["sw_score"], r["sw_aln_len"],
            f"{r['sw_identity_pct']}%", r["verdict"]] for r in d["named_ctl"]])
    w("### The null distribution, so the Psyn result is read against a background")
    w("")
    w(f"Psyn was aligned to **200** random genomic 241-mers (seed 20240823), taking the better of "
      f"the two strands each time. [EVIDENCE, computed]")
    w("")
    sl, ss = sorted(Ls), sorted(SWs)
    q = lambda v, p: v[min(len(v)-1, int(p*len(v)))]
    table(["statistic", "min", "median", "mean", "95th pct", "99th pct", "max",
           "**Psyn vs pgk (observed)**", "percentile of the observation"],
          [["longest exact common substring", sl[0], f"{st.median(sl):.0f}", f"{st.mean(sl):.1f}",
            q(sl, .95), q(sl, .99), sl[-1], f"**{obs['lcs_len']} bp**", f"**{pctL:.0f}th**"],
           ["Smith-Waterman score", ss[0], f"{st.median(ss):.0f}", f"{st.mean(ss):.1f}",
            q(ss, .95), q(ss, .99), ss[-1], f"**{obs['sw_score']}**", f"**{pctS:.0f}th**"]])
    w(f"**The pgk observation sits at the {pctL:.0f}th percentile of random genomic DNA on exact "
      f"match and the {pctS:.0f}th on alignment score — essentially at the median, and far below "
      f"even the maximum of the null ({sl[-1]} bp / {ss[-1]}).** [EVIDENCE] There is no signal to "
      f"interpret. The search is calibrated: it distinguishes nothing between pgk and an arbitrary "
      f"stretch of the chromosome, which is the correct behaviour when nothing was imported.")
    w("")
    w("---")
    w("")
    w("## 5. What sits between the −10 and the end of the fragment")
    w("")
    w("This is a second line of evidence on the same question, independent of any sequence search.")
    w("")
    table(["feature", "position (0-based, in the 34 nt fragment)", "sequence"],
          [["−35 hexamer", f"{el['Psyn']['minus35_start0']}–{int(el['Psyn']['minus35_end0'])-1}",
            f"`{el['Psyn']['minus35_seq']}`  ({el['Psyn']['minus35_frac']} of matrix max)"],
           ["extended −10", f"{e0}–{e1-1}",
            f"`{el['Psyn']['ext10_seq']}`  ({el['Psyn']['ext10_frac']} of matrix max)"],
           ["−10 hexamer (within the extended −10)", f"{e0+5}–{e0+10}", f"`{PSYN[e0+5:e0+11]}`"],
           ["**everything after the extended −10**", f"{e1}–{len(PSYN)-1}",
            f"**`{PSYN[e1:]}` — {len(PSYN)-e1} nt**"],
           ["**everything after the −10 hexamer**", f"{e0+11}–{len(PSYN)-1}",
            f"**`{PSYN[e0+11:]}` — {len(PSYN)-1-(e0+10)} nt**"]])
    w(f"**There are {len(PSYN)-e1} nt after the extended −10 and {len(PSYN)-1-(e0+10)} nt after the "
      f"−10 hexamer.** [EVIDENCE, computed from `data/cache/promoter_elements.json`]")
    w("")
    w("**That is consistent with a leaderless start and far too short to accommodate an imported "
      "+1 element.** A spacing of 5 nt from the −10 hexamer to the fragment end is squarely in the "
      "range where the transcript begins at or immediately past the end of the fragment — the "
      "geometry of a leaderless promoter handing straight off to a start codon. An imported "
      "\"+1 region\" drawn even conservatively at −20/+10 would need 30 nt; the window this report "
      "extracted for comparison is 61 nt. **Neither fits in 3.** [INFERENCE, reasoning named]")
    w("")
    w("### Do the two lines of evidence agree?")
    w("")
    w("**Yes, and they are genuinely independent.** One is a sequence search against the genome; "
      "the other is a length argument from the repo's element mapping that would hold even if the "
      "genome were unavailable. Both say the same thing: there is no imported +1 region in the "
      "cached Psyn. No disagreement to report.")
    w("")
    w("---")
    w("")
    w("## 6. What this does and does not settle")
    w("")
    w("**Settled.** The pgk +1 region is not in the cached Psyn. Psyn contains no C. glutamicum "
      "genomic sequence longer than would be expected by chance. The fork in the task's framing "
      "resolves to the branch where Psyn's transcription start is *not* set by an imported native "
      "element, so modelling it from the promoter's own −10 spacing is the applicable mechanism. "
      "[EVIDENCE]")
    w("")
    w("**Not settled — and it is worth being plain about these.**")
    w("")
    w("- **Where Psyn's TSS actually is.** This check removes a confound; it does not measure a "
      "start site. The spacing-based prediction remains a prediction, resting on a SigA matrix that "
      "is a reasoned approximation from a textual consensus rather than a trained PWM.")
    w("- **Whether Rytter's Psyn and Henke's Psyn are the same sequence.** Rytter et al. 2014 is "
      "**[NOT FOUND]** in the cache. The inference that Henke trimmed the pgk-derived portion is "
      "the economical reading, not a demonstrated fact. One lookup of that paper would settle it, "
      "and would also reveal how long Rytter's promoter actually was.")
    w("- **Whether the missing element matters.** Rytter included it *\"to ensure the presence of a "
      "functional transcriptional start site\"*. The cached Psyn lacks it. Whether that means "
      "Psyn's start site is merely unguaranteed rather than absent is not answerable from sequence "
      "— Henke measured strong expression from this exact 34-mer (norm. MFI 286%), so *something* "
      "initiates. Where it initiates is the open question, and 5′RACE is what answers it.")
    w("- **pgk's own TSS.** **[NOT FOUND]** in the cached Pfeifer-Sancar tables. The 241 nt region "
      "searched is a proxy defined by the start codon, not by a mapped +1. The genome-wide search "
      "makes the conclusion robust to that, but the specific window in §2 should not be quoted as "
      "\"pgk's +1 region\" without a source for the +1.")
    w("")
    d["OUT"].write_text("\n".join(L) + "\n")
    print(f"wrote {d['OUT'].relative_to(ROOT)} ({len(L)} lines, {len(d['OUT'].read_text())} chars)")


if __name__ == "__main__":
    write_report()
