"""Task 2: build the Ec_PhoP (and, as a bonus for the fallback mitigation, Ec_OmpR)
log-odds PWM against the OBSERVED C. glutamicum genome base composition."""
from pathlib import Path

from pwm_lib import build_pwm, genome_background, load_aligned_fasta, write_pwm_txt, save_pwm_json

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    bg, total_bases, genome_len = genome_background(DATA / "cache" / "BX927147.fasta")
    print(f"C. glutamicum BX927147.1 observed background (n={total_bases} of {genome_len} bp, "
          f"non-ACGT excluded): A={bg['A']:.4f} C={bg['C']:.4f} G={bg['G']:.4f} T={bg['T']:.4f} "
          f"(GC={100*(bg['G']+bg['C']):.2f}%)")

    for tf in ["phop", "ompr"]:
        seqs = load_aligned_fasta(DATA / "sites" / f"{tf}_ecoli_sites.fasta")
        pwm = build_pwm(seqs, bg)
        out = RESULTS / ("pwm.txt" if tf == "phop" else f"pwm_{tf}.txt")
        write_pwm_txt(pwm, name=f"{tf} (E. coli-confirmed sites, RegulonDB)",
                      out_path=out, site_fasta=DATA / "sites" / f"{tf}_ecoli_sites.fasta")
        save_pwm_json(pwm, DATA / "cache" / f"pwm_{tf}.json")
        print(f"\n{tf}: {pwm['n_sites']} sites, width {pwm['width']}, total IC = {pwm['total_ic']:.2f} bits "
              f"-> {out}")


if __name__ == "__main__":
    main()
