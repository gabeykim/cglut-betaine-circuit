"""TASK 2: two calibration anchors reproducing Henke's measured architecture.

WHY. Psyn's only published strength -- 286% of IPTG-induced Ptrc (Henke et al.
2021, PMC7835838, Figure 1) -- was measured in a construct with 43 nt and a
consensus RBS between Psyn and the gfpUV start codon. The panel deletes that
spacer. So the 286% figure is a composite of transcription AND RBS-driven
translation, and the transcript 5' end differs between the two designs (Psyn's
fragment ends before its own +1, so the +1 falls in the MCS in Henke's
construct and in the fore-cistron in the panel's). Without an anchor, panel
measurements cannot be related to the published number at all.

THE SPACER IS RECONSTRUCTED, NOT REMEMBERED. Every base is derived here from
the primer sequences printed in Henke Table 2, extracted from the cached HTML.

THE PAIR. Each anchor is a 1:1 partner of a construct already in the panel,
differing ONLY by the 43 nt Henke spacer:
  CAL-01  =  V2-OTH-01_Psyn_noop_ctrl_v2   + spacer   (no operator)
  CAL-02  =  V2-SUB-04_SUB_Psyn_opA_gap03  + spacer   (operator at gap 3)
CAL-01 is the closest reproduction of Henke's own construct, which had no
operator, so it is the direct anchor to 286%. CAL-02 adds the operator at the
panel's own cross-core reference position, so the pair also reports what the
operator does inside the Henke architecture. Each vs its partner isolates the
architecture change; CAL-01 vs CAL-02 isolates the operator.

These are CALIBRATION ANCHORS, not phasing variants.
"""
import csv, json, re, html, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import (site_scan, sigA_scan, sd_atg_scan, junction_aware, basic_checks,
                       CATALOGUE, GOLDEN_GATE, VECTOR_SITES, positive_control_check, revcomp, gc)

D = ROOT / "designs"
LIT = ROOT / "data" / "cache" / "literature" / "pmc7835838.html"

PARTNERS = [
    ("CAL-01_Psyn_HenkeRBS_noop",  "V2-OTH-01_Psyn_noop_ctrl_v2",
     "no operator -- the closest reproduction of Henke's own construct, which carried none. "
     "Direct anchor to the published 286% of Ptrc."),
    ("CAL-02_Psyn_HenkeRBS_opA_gap03", "V2-SUB-04_SUB_Psyn_opA_gap03",
     "operator opA_phoP at gap 3, the panel's cross-core reference position, in the substitution "
     "arm's fixed-length geometry. Reports what the operator does inside the Henke architecture."),
]


def henke_primers():
    raw = LIT.read_text(encoding="utf-8", errors="replace")
    t = re.sub(r"(?is)<(script|style).*?</\1>", " ", raw)
    t = re.sub(r"(?s)<[^>]+>", " ", t)
    t = re.sub(r"[ \t\xa0]+", " ", html.unescape(t))
    out = {}
    for m in re.finditer(r"\b(H[AN]\d{2})\s+([A-Za-z0-9\- ]{3,20}?)\s+([ACGT]{18,90})\s", t):
        out.setdefault(m.group(1), m.group(3))
    psyn = re.search(r"P syn \(5.-([ACGT]+)-3.\)", t).group(1)
    return out, psyn


def reconstruct_spacer():
    """43 nt between Psyn's 3' end and the gfpUV ATG, rebuilt from HA06/HA07/HN49."""
    P, PSYN = henke_primers()
    HA06, HA07, HN49 = P["HA06"], P["HA07"], P["HN49"]
    assert HA06.endswith(PSYN[:26]), "HA06 does not end with Psyn[0:26]"
    top3 = revcomp(HA07)
    amp = HA06 + PSYN[26:]
    ov1 = next(k for k in range(len(top3), 5, -1) if amp.endswith(top3[:k]))
    amp = amp + top3[ov1:]
    ov2 = next(k for k in range(60, 8, -1) if HN49[:k] in amp)
    final = amp[:amp.index(HN49[:ov2])] + HN49
    pe = final.index(PSYN) + len(PSYN)
    atg = final.index("ATGAGTAAAGGAGAAGAACTTTTCA")
    spacer = final[pe:atg]
    prov = {
        "length": len(spacer),
        "from_HA07_revcomp": spacer[:len(top3) - top3.index("CATGG")]
        if spacer[:len(top3) - top3.index("CATGG")] in top3 else None,
        "gibson_overlap_nt": ov2,
        "amplicon_overlap_nt": ov1,
        "unsourced_bases": 0,
        "rbs": "GAAAGGAGG", "rbs_offset": spacer.find("GAAAGGAGG"),
        "rbs_to_atg_nt": len(spacer) - (spacer.find("GAAAGGAGG") + 9),
    }
    return PSYN, spacer, prov, P


PROV_SPACER = (
    "Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838) Table 2 primers, "
    "reconstructed base-for-base by scripts/calibration_constructs.py: nt 0-27 from the reverse "
    "complement of HA07 (Psyn-rv), nt 28-42 from HN49 (gfpUV-fw), with a 27 nt Gibson homology arm "
    "attested by BOTH primers. Contains the C. glutamicum consensus RBS GAAAGGAGG, which the same "
    "paper names verbatim in its Discussion. NO base is unsourced."
)


def main():
    out_csv, out_fa = D / "calibration_constructs.csv", D / "calibration_constructs.fasta"
    for p in (out_csv, out_fa):
        if p.exists():
            sys.exit(f"REFUSING TO OVERWRITE {p}")
    positive_control_check()
    PSYN, SPACER, prov, primers = reconstruct_spacer()
    man = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v3.csv"))}
    print("=" * 78); print("TASK 2  CALIBRATION ANCHORS"); print("=" * 78)
    print(f"  Henke spacer reconstructed: {SPACER} ({len(SPACER)} nt)")
    print(f"  unsourced bases: {prov['unsourced_bases']}   Gibson homology arm: "
          f"{prov['gibson_overlap_nt']} nt attested by two primers")
    print(f"  RBS GAAAGGAGG at offset {prov['rbs_offset']}, {prov['rbs_to_atg_nt']} nt from the reporter ATG")

    rows = []
    for cid, partner, why in PARTNERS:
        base = man[partner]["full_sequence"]
        assert base.endswith(PSYN), f"{partner} does not end with the cached Psyn fragment"
        seq = base + SPACER
        rows.append({
            "construct_id": cid, "panel": "calibration_anchor",
            "tier": "calibration (NOT a phasing variant)",
            "partner_construct": partner,
            "partner_sequence_is_exact_prefix": seq.startswith(base),
            "controlled_difference": why,
            "architecture": "Psyn -> 43 nt Henke MCS spacer with consensus RBS -> reporter ATG "
                            "(vector-supplied, as for every other fragment in this panel)",
            "spacer_nt": len(SPACER), "spacer_seq": SPACER,
            "length_bp": len(seq), "GC_percent": round(gc(seq), 2),
            "full_sequence": seq,
            "provenance": f"promoter part: identical to {partner} in "
                          f"designs/order_manifest_final_v3.csv || Henke spacer: {PROV_SPACER}",
            "rank_or_rationale": (
                "CALIBRATION ANCHOR, not part of the phasing sweep. Reproduces the architecture in "
                "which Psyn's only published strength value (286% of IPTG-induced Ptrc, Henke 2021 "
                "Figure 1) was measured, so panel readings can be tied to that number. "
                + why),
        })
    return rows, PSYN, SPACER, prov, man


if __name__ == "__main__":
    main()


def write_and_verify(rows, PSYN, SPACER, prov, man):
    out_csv, out_fa = D / "calibration_constructs.csv", D / "calibration_constructs.fasta"
    cols = [c for c in rows[0] if c != "full_sequence"] + ["full_sequence"]
    with open(out_csv, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
    with open(out_fa, "w") as fh:
        for r in rows:
            fh.write(f">{r['construct_id']} panel=calibration_anchor partner={r['partner_construct']} "
                     f"len={r['length_bp']} GC={r['GC_percent']}\n")
            for i in range(0, len(r["full_sequence"]), 60):
                fh.write(r["full_sequence"][i:i+60] + "\n")
    print(f"\n  wrote designs/calibration_constructs.csv ({len(rows)}) and .fasta")

    ok, fail, sites = [], [], []
    def ck(n, c, d=""):
        ok.append(n) if c else fail.append(f"{n} -- {d}")
    print("\n" + "=" * 78); print("CHECKS ON THE CALIBRATION ANCHORS"); print("=" * 78)
    for r in rows:
        s = r["full_sequence"]; base = man[r["partner_construct"]]["full_sequence"]
        cmap = [("partner:" + r["partner_construct"], 0, len(base)),
                ("henke_spacer(HA07rc+HN49)", len(base), len(s))]
        ja = junction_aware(s, cmap, known_starts=())
        for h in ja["sites"]:
            sites.append({"construct_id": r["construct_id"], "enzyme": h.enzyme, "start": h.start,
                          "strand": h.strand, "spans_junction": h.spans_junction,
                          "components": "|".join(h.components)})
        ck(f"{r['construct_id']}: partner sequence is an exact 5' prefix", s.startswith(base))
        ck(f"{r['construct_id']}: only the 43 nt spacer was appended",
           s == base + SPACER and len(s) - len(base) == 43)
        ck(f"{r['construct_id']}: Golden Gate zero, both strands",
           not site_scan(s, enzymes=GOLDEN_GATE))
        ck(f"{r['construct_id']}: no homopolymer > 6", not basic_checks(s)["homopolymers_gt6"])
        ck(f"{r['construct_id']}: no spurious SD+ATG", not sd_atg_scan(s))
        ck(f"{r['construct_id']}: ends immediately before the reporter ATG (panel convention)",
           s.endswith("CCCTTCAG"))
    ck("the two anchors are not replicates", rows[0]["full_sequence"] != rows[1]["full_sequence"])
    ck("neither anchor duplicates an existing panel construct",
       not any(r["full_sequence"] == m["full_sequence"] for r in rows for m in man.values()))
    for x in ok: print(f"  PASS  {x}")
    for x in fail: print(f"  FAIL  {x}")
    print(f"\n  {len(ok)} passed, {len(fail)} failed")
    print("\n  ENZYME SITES THE ANCHORS ADD (they reproduce Henke's MCS, so these are inherent):")
    from collections import Counter
    for e, n in Counter(x["enzyme"] for x in sites).most_common():
        w_ = [x for x in sites if x["enzyme"] == e]
        print(f"    {e:7} {n} instances, {len({x['construct_id'] for x in w_})} constructs, "
              f"junction-spanning: {sum(1 for x in w_ if x['spans_junction'])}")
    jn = [x for x in sites if x["spans_junction"]]
    print(f"\n  junction-created (Psyn 3' C + spacer CATGG = CCATGG): "
          f"{sorted({x['enzyme'] for x in jn})} -- unavoidable when reproducing the architecture")
    return ok, fail, sites
