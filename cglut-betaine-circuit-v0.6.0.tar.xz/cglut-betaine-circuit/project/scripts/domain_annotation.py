"""Pfam domain annotation, TM prediction and H-box location for a set of
bacterial signalling proteins.

Everything runs from cached data. The fetch step is cache-backed: once
data/fasta/<ACC>.fasta and data/cache/pfam/<PF>.hmm exist, reruns are offline.

METHODS, stated up front because the numbers are only as good as these:
  * Domains      : hmmscan (HMMER 3.4) against a pressed database of the seven
                   requested Pfam models. hmmscan (not hmmsearch) because the
                   query set is proteins and the database is profiles.
  * TM helices   : NO TM predictor (DeepTMHMM / TMHMM / Phobius / TOPCONS) is
                   installed or installable in this environment -- see the
                   report. Fallback is Kyte-Doolittle hydropathy, window 19,
                   which is a WEAKER method; boundaries from it are approximate.
                   Topology is assigned by the positive-inside rule.
  * H-box        : calibrated transfer. The HisKA match-state column occupied by
                   an EXPERIMENTALLY CONFIRMED phosphohistidine is established
                   from a reference protein, then read off the same column in
                   every other protein hitting the same model.
                   Reference: E. coli EnvZ (P0AEJ4) His243, UniProt
                   "Phosphohistidine; by autocatalysis", evidence ECO:0000269
                   (experimental). Cross-checked against Salmonella PhoQ
                   (P0DM80) His277, same annotation and evidence code.
"""
import csv
import json
import re
import ssl
import subprocess
import sys
import urllib.request
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA, RESULTS, CACHE = ROOT / "data", ROOT / "results", ROOT / "data" / "cache"
PFAM = CACHE / "pfam"
FASTA = DATA / "fasta"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120 Safari/537.36")

MODELS = ["PF02743", "PF00672", "PF00512", "PF07568", "PF07730", "PF02518", "PF00072"]
MODEL_NAME = {"PF02743": "dCache_1", "PF00672": "HAMP", "PF00512": "HisKA",
              "PF07568": "HisKA_2", "PF07730": "HisKA_3", "PF02518": "HATPase_c",
              "PF00072": "Response_reg"}
HISKA_FAMILY = {"HisKA", "HisKA_2", "HisKA_3"}

# requested accession -> (accession actually used, organism, how it was resolved)
TARGETS = [
    # requested,        used,      organism,                               resolution note
    ("P14147",   "P0DM80", "Salmonella Typhimurium (strain LT2)",
     "REQUESTED ACCESSION IS DEAD. UniProt reports P14147 as Inactive / DEMERGED into "
     "E1WFA0 (strain SL1344) and P0DM80 (strain LT2). LT2 used: it is the strain cognate "
     "to P0DM78 in this same set, so the pair stays strain-consistent."),
    ("P0DM78",   "P0DM78", "Salmonella Typhimurium (strain LT2)", "active accession, used as given"),
    ("P0AEJ4",   "P0AEJ4", "Escherichia coli K-12", "active accession, used as given"),
    ("P0AA16",   "P0AA16", "Escherichia coli K-12", "active accession, used as given"),
    ("PA4633",   "Q9HVF8", "Pseudomonas aeruginosa PAO1",
     "locus tag, not a UniProt accession. Resolved to Q9HVF8 by two independent routes: "
     "(1) RCSB entry 7PRQ/7PRR polymer-entity UniProt cross-reference; (2) UniProt gene "
     "search gene:pctD AND organism_id:208964. Both give Q9HVF8 / PA4633."),
    ("ECA_RS10935", "Q6D515", "Pectobacterium atrosepticum SCRI1043",
     "RefSeq locus tag, not a UniProt accession. Resolved to Q6D515 via the RCSB entry "
     "7PSG polymer-entity UniProt cross-reference, which reports gene ECA2226 -- the "
     "original EMBL locus tag for the same gene that RefSeq renumbered ECA_RS10935."),
    ("McpX (S. meliloti)", "Q92SH9", "Sinorhizobium (Rhizobium) meliloti 1021",
     "name only, no accession supplied. Resolved to Q92SH9 by two independent routes: "
     "(1) RCSB entry 6D8V polymer-entity UniProt cross-reference (gene mcpX, SMc01104); "
     "(2) UniProt gene search gene:mcpX AND organism_id:266834. Both give Q92SH9."),
]

# Kyte & Doolittle 1982, J Mol Biol 157:105-132 -- hydropathy index
KD = {"A": 1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5, "Q": -3.5, "E": -3.5,
      "G": -0.4, "H": -3.2, "I": 4.5, "L": 3.8, "K": -3.9, "M": 1.9, "F": 2.8,
      "P": -1.6, "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2}
KD_WINDOW, KD_THRESHOLD, KD_MIN_LEN = 19, 1.6, 15


def ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def fetch(url, dest, binary=False):
    if dest.exists():
        return dest.read_bytes() if binary else dest.read_text()
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=90, context=ctx()) as r:
        blob = r.read()
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(blob)
    print(f"    fetched {dest.name}")
    return blob if binary else blob.decode()


def ensure_inputs():
    """Cache every FASTA and every HMM. Returns {accession: (seq, header, fetched_on)}."""
    print("Inputs (cache-backed; reruns are offline):")
    seqs = {}
    for _req, acc, _org, _note in TARGETS:
        p = FASTA / f"{acc}.fasta"
        existed = p.exists()
        txt = fetch(f"https://rest.uniprot.org/uniprotkb/{acc}.fasta", p)
        lines = txt.strip().split("\n")
        seqs[acc] = ("".join(lines[1:]).replace("*", ""), lines[0][1:],
                     date.fromtimestamp(p.stat().st_mtime).isoformat())
        print(f"  {acc:8} {len(seqs[acc][0]):>4} aa  {'cached' if existed else 'FETCHED'}")
    for pf in MODELS:
        h = PFAM / f"{pf}.hmm"
        if not h.exists():
            gz = fetch(f"https://www.ebi.ac.uk/interpro/wwwapi/entry/pfam/{pf}/?annotation=hmm",
                       PFAM / f"{pf}.hmm.gz", binary=True)
            import gzip
            h.write_bytes(gzip.decompress(gz))
        print(f"  {pf} ({MODEL_NAME[pf]}) HMM cached")
    return seqs


def build_db():
    db = PFAM / "domains7.hmm"
    db.write_text("".join((PFAM / f"{pf}.hmm").read_text() for pf in MODELS))
    subprocess.run(["hmmpress", "-f", str(db)], check=True, capture_output=True)
    return db


def run_hmmscan(db, seqs):
    """hmmscan every query; keep the domain table AND the alignments (needed for the H-box)."""
    qf = CACHE / "domain_queries.fasta"
    with open(qf, "w") as fh:
        for acc, (s, _h, _d) in seqs.items():
            fh.write(f">{acc}\n{s}\n")
    dom = CACHE / "domain_hits.domtblout"
    aln = CACHE / "domain_hits.txt"
    subprocess.run(["hmmscan", "--domtblout", str(dom), "-o", str(aln),
                    "--domE", "1e-3", str(db), str(qf)], check=True)
    rows = []
    for line in open(dom):
        if line.startswith("#"):
            continue
        f = line.split()
        rows.append({"model": f[0], "model_acc": f[1], "accession": f[3],
                     "i_evalue": float(f[12]), "bit_score": float(f[7]),
                     "dom_bitscore": float(f[13]),
                     "hmm_from": int(f[15]), "hmm_to": int(f[16]),
                     "start": int(f[17]), "end": int(f[18])})
    return rows, aln


def parse_alignments(aln_path):
    """Extract per-domain (query_acc, model, hmm_from, ali_from, hmm_line, query_line).

    hmmscan text output prints, per domain, a consensus line then the query line.
    Mapping query residues to HMM match-state columns is what lets an
    experimentally confirmed H-box position be transferred between proteins.
    """
    out, cur_q, cur_m = [], None, None
    lines = open(aln_path).read().split("\n")
    for i, ln in enumerate(lines):
        if ln.startswith("Query:"):
            cur_q = ln.split()[1]
        elif ln.startswith(">> "):
            cur_m = ln.split()[1]
        elif ln.strip().startswith("== domain"):
            block = lines[i:i + 12]
            hmm_line = q_line = None
            for b in block:
                mm = re.match(r"\s+\S+\s+(\d+)\s+(\S+)\s+(\d+)\s*$", b)
                if not mm:
                    continue
                if hmm_line is None:
                    hmm_line = (int(mm.group(1)), mm.group(2), int(mm.group(3)))
                elif q_line is None and mm.group(2).upper() != mm.group(2).lower():
                    q_line = (int(mm.group(1)), mm.group(2), int(mm.group(3)))
            if hmm_line and q_line:
                out.append({"accession": cur_q, "model": cur_m,
                            "hmm_from": hmm_line[0], "hmm_seq": hmm_line[1],
                            "ali_from": q_line[0], "q_seq": q_line[1]})
    return out


def residue_to_hmm_column(a, target_pos):
    """Which HMM match-state column does full-length residue target_pos occupy?"""
    h, q = a["hmm_seq"], a["q_seq"]
    hc, qp = a["hmm_from"] - 1, a["ali_from"] - 1
    for i in range(len(q)):
        if h[i] != ".":
            hc += 1
        if q[i] != "-":
            qp += 1
            if qp == target_pos:
                return hc if h[i] != "." else None
    return None


def hmm_column_to_residue(a, col):
    """Inverse: which full-length residue sits at HMM match-state column `col`?"""
    h, q = a["hmm_seq"], a["q_seq"]
    hc, qp = a["hmm_from"] - 1, a["ali_from"] - 1
    for i in range(len(q)):
        if h[i] != ".":
            hc += 1
        if q[i] != "-":
            qp += 1
        if hc == col and h[i] != "." and q[i] != "-":
            return qp, q[i].upper()
    return None, None


def kyte_doolittle_tm(seq):
    """Fallback TM prediction. WEAKER than a trained predictor -- boundaries approximate."""
    w, half = KD_WINDOW, KD_WINDOW // 2
    if len(seq) < w:
        return [], []
    prof = [sum(KD.get(c, 0.0) for c in seq[i:i + w]) / w for i in range(len(seq) - w + 1)]
    above = [i for i, v in enumerate(prof) if v >= KD_THRESHOLD]
    segs, cur = [], []
    for i in above:
        if cur and i == cur[-1] + 1:
            cur.append(i)
        else:
            if cur:
                segs.append(cur)
            cur = [i]
    if cur:
        segs.append(cur)
    helices = []
    for s in segs:
        start, end = s[0] + 1, s[-1] + w
        if end - start + 1 >= KD_MIN_LEN:
            peak = max(prof[s[0]:s[-1] + 1])
            helices.append({"start": start, "end": end, "peak_kd": round(peak, 2)})
    # positive-inside rule (von Heijne 1992): the flank richer in K+R is cytoplasmic
    topo = []
    if helices:
        bounds = [0] + [h["end"] for h in helices] + [len(seq)]
        starts = [0] + [h["start"] - 1 for h in helices]
        loops = []
        prev_end = 0
        for h in helices:
            loops.append(seq[prev_end:h["start"] - 1])
            prev_end = h["end"]
        loops.append(seq[prev_end:])
        kr = [sum(1 for c in L if c in "KR") / max(1, len(L)) for L in loops]
        first_in = kr[0] >= kr[1] if len(kr) > 1 else True
        side = "cytoplasmic" if first_in else "periplasmic"
        prev_end = 0
        for j, h in enumerate(helices):
            topo.append({"region": f"loop{j}", "start": prev_end + 1, "end": h["start"] - 1,
                         "side": side, "kr_frac": round(kr[j], 3)})
            side = "periplasmic" if side == "cytoplasmic" else "cytoplasmic"
            prev_end = h["end"]
        topo.append({"region": f"loop{len(helices)}", "start": prev_end + 1, "end": len(seq),
                     "side": side, "kr_frac": round(kr[-1], 3)})
    return helices, topo


def confidence(i_evalue, methods_agree=True, weak=False):
    if weak:
        return "LOW"
    if i_evalue < 1e-10 and methods_agree:
        return "HIGH"
    return "MEDIUM"
