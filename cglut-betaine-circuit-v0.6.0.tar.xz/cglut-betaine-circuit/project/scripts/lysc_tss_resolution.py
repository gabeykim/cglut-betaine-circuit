"""Close the lysC operator-distance question using the experimentally mapped TSS.

TSS source: Pfeifer-Sancar, Mentz, Rueckert & Kalinowski 2013, BMC Genomics
14:888 (PMC3890552), Additional file 1, Tables S1 and S3.

How the data was obtained (this matters -- an earlier pass on this project
reported the lysC TSS as [NOT FOUND]): PMC's own supplementary-file endpoint
sits behind a JavaScript proof-of-work bot challenge that a plain HTTP client
cannot solve, and the Springer/BMC mirror returns 403. Europe PMC serves the
identical supplementary bundle from different infrastructure with no such
gate, at
    https://www.ebi.ac.uk/europepmc/webservices/rest/PMC3890552/supplementaryFiles
which returns a zip containing Additional file 1 (itself a zip of Tables
S1-S10 as .xlsx). Tables S1 and S3 are cached in
data/cache/literature/pfeifer2013_tables/.

Two independent tables are cross-checked against each other and against the
cached BX927147.1 genome sequence, so the coordinate system is verified
rather than assumed.
"""
import json
import sys
from pathlib import Path

import openpyxl
from Bio import SeqIO

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pwm_lib import load_pwm_json, revcomp

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
TABLES = DATA / "cache" / "literature" / "pfeifer2013_tables"

LYSC_TAG = "cg0306"
ASD_TAG = "cg0307"
OPERATOR_LO, OPERATOR_HI = 269204, 269220  # 1-based inclusive, + strand (from results/hits_high_concern.csv)


def read_rows(path: Path):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    return [r for r in ws.iter_rows(values_only=True) if r and r[0] is not None]


def main():
    genome = str(next(SeqIO.parse(DATA / "cache" / "BX927147.fasta", "fasta")).seq).upper()

    # ---------- Table S1: TSS + promoter motifs ----------
    s1 = read_rows(TABLES / "Table_S1.xlsx")
    s1_lysc = [r for r in s1 if r[2] == LYSC_TAG]
    s1_asd = [r for r in s1 if r[2] == ASD_TAG]
    assert len(s1_lysc) == 1, f"expected exactly 1 S1 row for {LYSC_TAG}, got {len(s1_lysc)}"
    tss_s1, strand, gene, imp10, imp35, context60, dist10, spacer = s1_lysc[0]

    # ---------- Table S3: TSS + gene start + 5'UTR ----------
    s3 = read_rows(TABLES / "Table_S3.xlsx")
    s3_lysc = [r for r in s3 if r[0] == LYSC_TAG]
    s3_asd = [r for r in s3 if r[0] == ASD_TAG]
    assert len(s3_lysc) == 1, f"expected exactly 1 S3 row for {LYSC_TAG}, got {len(s3_lysc)}"
    _, strand3, tss_s3, gene_start, start_codon, utr_len, utr_seq = s3_lysc[0]

    print("=== Cross-check 1: do Tables S1 and S3 agree on the lysC TSS? ===")
    print(f"  S1 TSS = {tss_s1}   S3 TSS = {tss_s3}   agree = {tss_s1 == tss_s3}")
    assert tss_s1 == tss_s3
    print(f"  S3: gene start {gene_start}, start codon '{start_codon}', 5'-UTR length {utr_len} nt")
    print(f"  arithmetic: gene_start - TSS = {gene_start - tss_s3}  (matches stated UTR length: "
          f"{gene_start - tss_s3 == utr_len})")
    assert gene_start - tss_s3 == utr_len

    print("\n=== Cross-check 2: does the published sequence match the cached genome at those coords? ===")
    # S3 5'-UTR: runs from TSS (+1) through the base before the start codon
    genome_utr = genome[tss_s3 - 1: gene_start - 1]
    print(f"  S3 5'-UTR (published): {utr_seq.upper()}")
    print(f"  BX927147.1 {tss_s3}..{gene_start - 1}: {genome_utr}")
    utr_match = genome_utr == utr_seq.upper()
    print(f"  MATCH: {utr_match}")

    # S1 context: 60 bases, -59..+1, so genomic tss-59 .. tss
    genome_ctx = genome[tss_s1 - 59 - 1: tss_s1]
    print(f"  S1 -59..+1 (published): {context60.upper()}")
    print(f"  BX927147.1 {tss_s1-59}..{tss_s1}: {genome_ctx}")
    ctx_match = genome_ctx == context60.upper()
    print(f"  MATCH: {ctx_match}")
    assert utr_match and ctx_match, "coordinate system MISMATCH -- do not trust these coordinates"
    print("  => coordinate system CONFIRMED: table coordinates are BX927147.1 coordinates.")

    # ---------- locate the -10 element ----------
    upper_runs = []
    i = 0
    while i < len(context60):
        if context60[i].isupper():
            j = i
            while j < len(context60) and context60[j].isupper():
                j += 1
            upper_runs.append((i, j, context60[i:j]))
            i = j
        else:
            i += 1
    # genomic position of each uppercase (motif) run
    motifs = []
    for (a, b, s) in upper_runs:
        g_lo = (tss_s1 - 59) + a
        g_hi = (tss_s1 - 59) + b - 1
        motifs.append({"seq": s, "lo": g_lo, "hi": g_hi})
    print(f"\n=== Promoter motifs annotated by the authors (Improbizer) ===")
    for m in motifs:
        print(f"  {m['seq']} at BX927147.1 {m['lo']}..{m['hi']}")
    print(f"  Improbizer score -10 = {imp10}; -35 = {imp35}; distance(-10 -> TSS) = {dist10}; "
          f"spacer(-35..-10) = {spacer}")
    minus10 = motifs[0] if motifs else None

    # ---------- distances ----------
    op_center = (OPERATOR_LO + OPERATOR_HI) / 2
    d_tss_from_3p = tss_s1 - OPERATOR_HI          # operator 3' edge -> TSS
    d_tss_from_center = tss_s1 - op_center        # operator center -> TSS
    d_tss_from_5p = tss_s1 - OPERATOR_LO
    d_atg = gene_start - OPERATOR_HI              # the originally-reported 151 bp
    d_minus10 = (minus10["lo"] - OPERATOR_HI) if minus10 else None

    print("\n=== Distances ===")
    print(f"  operator (BX927147.1 {OPERATOR_LO}..{OPERATOR_HI}, + strand), TSS at {tss_s1}, ATG/GTG at {gene_start}")
    print(f"  operator 3' edge -> translation start : {d_atg} bp   <- the ORIGINALLY REPORTED number")
    print(f"  operator 3' edge -> TSS               : {d_tss_from_3p} bp")
    print(f"  operator center  -> TSS               : {d_tss_from_center} bp  (i.e. centred near position "
          f"-{d_tss_from_center:.0f} relative to TSS)")
    print(f"  operator 5' edge -> TSS               : {d_tss_from_5p} bp")
    if minus10:
        print(f"  operator 3' edge -> -10 element 5' end: {d_minus10} bp")

    # ---------- operon context: asd ----------
    print("\n=== Operon context ===")
    print(f"  S3 rows for {ASD_TAG} (asd):")
    for r in s3_asd:
        print(f"    TSS={r[2]}  gene_start={r[3]}  start_codon={r[4]}  5'UTR_len={r[5]}")
    print(f"  S1 rows for {ASD_TAG} (asd): {len(s1_asd)}")
    for r in s1_asd:
        print(f"    TSS={r[0]} strand={r[1]} imp10={r[3]} imp35={r[4]} dist10={r[6]}")
    s3_cg0305 = [r for r in s3 if r[0] == "cg0305"]
    print(f"  S3 rows for cg0305 (upstream neighbour): {len(s3_cg0305)}  "
          f"{'-> no mapped TSS' if not s3_cg0305 else s3_cg0305}")

    facts = {
        "tss": tss_s1, "tss_source": "Pfeifer-Sancar et al. 2013 BMC Genomics 14:888, Additional file 1 "
                                      "Tables S1 and S3 (via Europe PMC supplementaryFiles endpoint)",
        "strand": strand, "gene_start": gene_start, "start_codon": start_codon,
        "utr_len": utr_len, "utr_seq": utr_seq.upper(),
        "coordinate_check_utr_match": utr_match, "coordinate_check_context_match": ctx_match,
        "improbizer_minus10_score": imp10, "improbizer_minus35_score": imp35,
        "minus10_motif": minus10, "minus10_to_tss": dist10, "minus35_spacer": spacer,
        "context_minus59_to_plus1": context60,
        "operator_lo": OPERATOR_LO, "operator_hi": OPERATOR_HI,
        "d_operator3p_to_atg": d_atg, "d_operator3p_to_tss": d_tss_from_3p,
        "d_operatorcenter_to_tss": d_tss_from_center, "d_operator5p_to_tss": d_tss_from_5p,
        "d_operator3p_to_minus10": d_minus10,
        "asd_s3_rows": [{"tss": r[2], "gene_start": r[3], "start_codon": r[4], "utr_len": r[5]} for r in s3_asd],
        "cg0305_has_mapped_tss": bool(s3_cg0305),
    }
    (DATA / "cache" / "lysc_tss_facts.json").write_text(json.dumps(facts, indent=1))
    print("\nWrote data/cache/lysc_tss_facts.json")


if __name__ == "__main__":
    main()
