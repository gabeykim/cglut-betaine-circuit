"""Task 5: rebuild the consolidated 93-construct manifest on junctions_v4.

Same component maps, same verified base-for-base reconstruction, same checks as
scripts/consolidate_final.py -- only the kinase source and the output suffix
differ. The 69 non-kinase constructs are untouched; the 24 kinase constructs are
the ones re-optimised against the full 35-enzyme catalogue.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import consolidate_final as CF
from seqchecks import positive_control_check

CF.SUFFIX = "_v3"
CF.KIN_CSV = "junctions_v4.csv"
CF.KIN_FA = "junctions_v4.fasta"

if __name__ == "__main__":
    if len(sys.argv) > 1:
        CF.OUTDIR = Path(sys.argv[1]); CF.OUTDIR.mkdir(parents=True, exist_ok=True)
    positive_control_check()
    CF.main()
