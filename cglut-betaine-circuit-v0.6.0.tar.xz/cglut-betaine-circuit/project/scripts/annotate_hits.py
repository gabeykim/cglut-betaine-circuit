"""Task 4: classify every scan hit as INTERGENIC-near-CDS-start (HIGH CONCERN),
INTERGENIC-elsewhere (LOW), or INSIDE-a-CDS (NOISE, unless exceptionally
high-scoring), using the cached genome feature table (never re-fetched).

"Within 400 bp upstream of an annotated CDS start" is evaluated relative to
the CDS's own strand: for a '+' gene, upstream means the hit sits before
(lower coordinate than) the annotated translation start; for a '-' gene,
upstream means the hit sits after (higher coordinate than) the start. This
is independent of which strand the PWM hit itself was called on -- an
operator is functional based on its position relative to the promoter, not
the strand orientation the motif happened to align to.
"""
import bisect
import csv
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from parse_feature_table import parse_ft, merge_gene_cds

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

UPSTREAM_WINDOW = 400
EXCEPTIONAL_P = 1e-4  # "unless exceptionally high-scoring" -- gate on the strict empirical-p tier


def _clean_coord(s: str) -> int:
    return int(re.sub(r"[^0-9]", "", s))


def load_genes(ft_path: Path):
    feats = parse_ft(str(ft_path))
    merged = merge_gene_cds(feats)
    genes = []
    for r in merged:
        a, b = _clean_coord(r["start"]), _clean_coord(r["end"])
        strand = "+" if a <= b else "-"
        # NCBI feature-table convention: the first coordinate ("start") is ALWAYS
        # the translation start in genomic-position terms, regardless of strand
        # (for a '-' gene this is numerically the LARGER value, since the gene
        # reads right-to-left). Using min()/max() here instead of `a` directly
        # was an earlier bug: it silently used the wrong end of every '-' strand
        # gene as its TSS, caught only by the positive-control check finding
        # phoP's own autoregulatory site misclassified.
        tss = a
        cds_lo, cds_hi = min(a, b), max(a, b)
        genes.append({
            "locus_tag": r["locus_tag"], "gene": r["gene"], "product": r["product"],
            "strand": strand, "tss": tss, "cds_lo": cds_lo, "cds_hi": cds_hi,
        })
    return genes


class GeneIndex:
    def __init__(self, genes):
        self.genes = sorted(genes, key=lambda g: g["cds_lo"])
        self.cds_lo = [g["cds_lo"] for g in self.genes]
        self.cds_hi_running_max = []
        m = -1
        for g in self.genes:
            m = max(m, g["cds_hi"])
            self.cds_hi_running_max.append(m)
        self.by_tss = sorted(genes, key=lambda g: g["tss"])
        self.tss_vals = [g["tss"] for g in self.by_tss]

    def overlapping_cds(self, lo, hi):
        """Any gene whose [cds_lo,cds_hi] overlaps [lo,hi]? Linear-scan a small
        neighborhood found via bisect on cds_lo (genes don't densely overlap in
        bacteria, so this neighborhood is small in practice)."""
        idx = bisect.bisect_right(self.cds_lo, hi)
        # scan backwards while genes could still overlap
        i = idx - 1
        hits = []
        while i >= 0 and self.genes[i]["cds_hi"] >= lo - 20000:  # generous backstop window
            g = self.genes[i]
            if g["cds_lo"] <= hi and g["cds_hi"] >= lo:
                hits.append(g)
            if g["cds_lo"] < lo - 20000:
                break
            i -= 1
        return hits

    def nearest_gene(self, pos):
        """Nearest gene by TSS distance (any direction), for reporting."""
        idx = bisect.bisect_left(self.tss_vals, pos)
        candidates = []
        for i in (idx - 1, idx):
            if 0 <= i < len(self.by_tss):
                candidates.append(self.by_tss[i])
        if not candidates:
            return None, None
        best = min(candidates, key=lambda g: abs(g["tss"] - pos))
        return best, best["tss"] - pos  # signed distance (gene_tss - hit_pos)

    def upstream_distance(self, hit_lo, hit_hi):
        """Smallest upstream distance (hit -> a gene's own promoter side) among
        genes where the hit is strictly upstream. Returns (gene, distance) or (None, None)."""
        best_gene, best_dist = None, None
        # + strand candidates: gene.tss > hit_hi, distance = tss - hit_hi
        idx = bisect.bisect_right(self.tss_vals, hit_hi)
        for i in range(idx, min(idx + 5, len(self.by_tss))):
            g = self.by_tss[i]
            if g["strand"] != "+":
                continue
            d = g["tss"] - hit_hi
            if d >= 0 and (best_dist is None or d < best_dist):
                best_gene, best_dist = g, d
            break_check = True
        # - strand candidates: gene.tss < hit_lo, distance = hit_lo - tss
        idx2 = bisect.bisect_left(self.tss_vals, hit_lo)
        for i in range(idx2 - 1, max(idx2 - 6, -1), -1):
            g = self.by_tss[i]
            if g["strand"] != "-":
                continue
            d = hit_lo - g["tss"]
            if d >= 0 and (best_dist is None or d < best_dist):
                best_gene, best_dist = g, d
            break
        return best_gene, best_dist


def classify(hit, gidx: GeneIndex):
    lo, hi = int(hit["start"]), int(hit["end"])
    inside = gidx.overlapping_cds(lo, hi)
    p = float(hit["empirical_p"])
    if inside:
        g = inside[0]
        exceptional = p <= EXCEPTIONAL_P
        return {
            "classification": "INSIDE_CDS" if not exceptional else "INSIDE_CDS_EXCEPTIONAL",
            "nearest_gene_locus_tag": g["locus_tag"], "nearest_gene_name": g["gene"] or "",
            "nearest_gene_product": g["product"] or "", "nearest_gene_strand": g["strand"],
            "distance_bp": 0, "upstream_of_nearest": False,
        }
    gene, dist = gidx.upstream_distance(lo, hi)
    if gene is not None and dist is not None and dist <= UPSTREAM_WINDOW:
        return {
            "classification": "HIGH_CONCERN",
            "nearest_gene_locus_tag": gene["locus_tag"], "nearest_gene_name": gene["gene"] or "",
            "nearest_gene_product": gene["product"] or "", "nearest_gene_strand": gene["strand"],
            "distance_bp": dist, "upstream_of_nearest": True,
        }
    nearest, signed_dist = gidx.nearest_gene((lo + hi) // 2)
    return {
        "classification": "INTERGENIC_LOW",
        "nearest_gene_locus_tag": nearest["locus_tag"] if nearest else "",
        "nearest_gene_name": (nearest["gene"] or "") if nearest else "",
        "nearest_gene_product": (nearest["product"] or "") if nearest else "",
        "nearest_gene_strand": nearest["strand"] if nearest else "",
        "distance_bp": abs(signed_dist) if signed_dist is not None else "",
        "upstream_of_nearest": False,
    }


def annotate(hits_csv: Path, ft_path: Path, out_csv: Path, classify_up_to_p: float = 5e-2):
    genes = load_genes(ft_path)
    gidx = GeneIndex(genes)
    print(f"Loaded {len(genes)} genes from {ft_path.name}")

    rows = list(csv.DictReader(open(hits_csv)))
    rows = [r for r in rows if float(r["empirical_p"]) <= classify_up_to_p]
    print(f"Classifying {len(rows)} hits (empirical p <= {classify_up_to_p})")

    out_rows = []
    for hit in rows:
        cls = classify(hit, gidx)
        out_rows.append({**hit, **cls})

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["genome", "start", "end", "strand", "score", "empirical_p", "classification",
                  "nearest_gene_locus_tag", "nearest_gene_name", "nearest_gene_product",
                  "nearest_gene_strand", "distance_bp", "upstream_of_nearest"]
    with open(out_csv, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(out_rows)

    counts = {}
    for r in out_rows:
        counts[r["classification"]] = counts.get(r["classification"], 0) + 1
    print(f"Wrote {len(out_rows)} classified hits to {out_csv}")
    print("Classification breakdown:", counts)
    return out_rows


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--hits", required=True)
    ap.add_argument("--ft", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-p", type=float, default=5e-2)
    args = ap.parse_args()
    annotate(Path(args.hits), Path(args.ft), Path(args.out), classify_up_to_p=args.max_p)
