"""Shared PWM math: background composition, log-odds matrix construction,
information content, and sequence scoring. Used by build_pwm.py and
scan_genome.py so the scoring function is identical in both places.
"""
import json
import math
from pathlib import Path

import numpy as np
from Bio import SeqIO

BASES = ["A", "C", "G", "T"]
COMPLEMENT = str.maketrans("ACGTacgt", "TGCAtgca")


def revcomp(seq: str) -> str:
    return seq.translate(COMPLEMENT)[::-1]


def genome_background(fasta_path: Path) -> dict:
    """Observed mononucleotide composition of a genome FASTA, both strands
    pooled (equivalent to counting each strand once, since a genome and its
    reverse complement have identical base composition)."""
    rec = next(SeqIO.parse(fasta_path, "fasta"))
    seq = str(rec.seq).upper()
    total = 0
    counts = {b: 0 for b in BASES}
    for ch in seq:
        if ch in counts:
            counts[ch] += 1
            total += 1
    return {b: counts[b] / total for b in BASES}, total, len(seq)


def build_pwm(sequences: list, background: dict, pseudocount: float = 0.5):
    """log2-odds PWM: log2( (count+pseudocount)/(N+4*pseudocount) / background[b] )
    Also returns per-position and total information content (relative entropy
    to the supplied background, in bits -- the correct IC definition when the
    background is non-uniform)."""
    n = len(sequences)
    width = len(sequences[0])
    assert all(len(s) == width for s in sequences), "all PWM input sequences must be the same length"

    counts = [{b: 0 for b in BASES} for _ in range(width)]
    for seq in sequences:
        for i, ch in enumerate(seq.upper()):
            if ch in counts[i]:
                counts[i][ch] += 1

    log_odds = []
    freqs = []
    ic_per_pos = []
    for i in range(width):
        pos_freqs = {b: (counts[i][b] + pseudocount) / (n + 4 * pseudocount) for b in BASES}
        pos_logodds = {b: math.log2(pos_freqs[b] / background[b]) for b in BASES}
        pos_ic = sum(pos_freqs[b] * pos_logodds[b] for b in BASES)
        freqs.append(pos_freqs)
        log_odds.append(pos_logodds)
        ic_per_pos.append(pos_ic)

    return {
        "width": width, "n_sites": n, "background": background,
        "counts": counts, "freqs": freqs, "log_odds": log_odds,
        "ic_per_pos": ic_per_pos, "total_ic": sum(ic_per_pos),
        "pseudocount": pseudocount,
    }


def score_window(window: str, pwm: dict) -> float:
    """Sum of per-position log-odds for one ungapped window (must match pwm width)."""
    score = 0.0
    for i, ch in enumerate(window.upper()):
        row = pwm["log_odds"][i]
        score += row.get(ch, -10.0)  # non-ACGT (N etc.) heavily penalised, not crashed on
    return score


def max_possible_score(pwm: dict) -> float:
    return sum(max(row.values()) for row in pwm["log_odds"])


def min_possible_score(pwm: dict) -> float:
    return sum(min(row.values()) for row in pwm["log_odds"])


_BASE2INT = {"A": 0, "C": 1, "G": 2, "T": 3}


def encode_seq(seq: str) -> np.ndarray:
    """Integer-encode a sequence; non-ACGT characters get -1 (never matches any base)."""
    arr = np.full(len(seq), -1, dtype=np.int8)
    for base, code in _BASE2INT.items():
        arr[np.frombuffer(seq.encode(), dtype=np.uint8) == ord(base)] = code
    return arr


def score_all_windows(seq: str, pwm: dict) -> np.ndarray:
    """Vectorized forward-strand scan: score of the ungapped window starting at
    every position 0..len(seq)-width. Windows touching a non-ACGT base score -inf."""
    w = pwm["width"]
    L = len(seq)
    n_windows = L - w + 1
    if n_windows <= 0:
        return np.array([])
    enc = encode_seq(seq.upper())
    logodds = np.array([[pwm["log_odds"][i][b] for b in BASES] for i in range(w)])  # (w,4)

    scores = np.zeros(n_windows)
    invalid = np.zeros(n_windows, dtype=bool)
    for i in range(w):
        window_bases = enc[i:i + n_windows]
        bad = window_bases < 0
        invalid |= bad
        safe_bases = np.where(bad, 0, window_bases)
        scores += logodds[i][safe_bases]
    scores[invalid] = -np.inf
    return scores


def load_aligned_fasta(path: Path) -> list:
    return [str(rec.seq).upper() for rec in SeqIO.parse(path, "fasta")]


def write_pwm_txt(pwm: dict, name: str, out_path: Path, site_fasta: Path):
    lines = []
    lines.append(f"PWM: {name}")
    lines.append(f"Built from {pwm['n_sites']} sites (see {site_fasta.name}), width {pwm['width']} bp, "
                 f"pseudocount {pwm['pseudocount']}")
    if pwm["n_sites"] < 8:
        lines.append(f"WARNING: fewer than 8 sites -- this PWM is weakly determined.")
    bg = pwm["background"]
    lines.append(f"Background (observed genome composition): A={bg['A']:.4f} C={bg['C']:.4f} "
                 f"G={bg['G']:.4f} T={bg['T']:.4f} (GC={100*(bg['G']+bg['C']):.2f}%)")
    lines.append("")
    lines.append(f"Total information content: {pwm['total_ic']:.2f} bits over {pwm['width']} positions "
                 f"({pwm['total_ic']/pwm['width']:.2f} bits/position average)")
    if pwm["total_ic"] < 12:
        lines.append("NOTE: total IC below ~12 bits is low for a specific scan -- expect a noisy hit list; "
                     "see REPORT.md for how this is handled (empirical p-values, multiple stringencies).")
    lines.append("")
    lines.append("Per-position information content (bits):")
    for i, ic in enumerate(pwm["ic_per_pos"]):
        lines.append(f"  pos {i+1:2d}: {ic:.3f}")
    lines.append("")
    lines.append("Log-odds matrix (log2 score vs. background; rows=position, cols=A,C,G,T):")
    header = "pos  " + "  ".join(f"{b:>7s}" for b in BASES) + "    IC"
    lines.append(header)
    for i in range(pwm["width"]):
        row = pwm["log_odds"][i]
        vals = "  ".join(f"{row[b]:7.3f}" for b in BASES)
        lines.append(f"{i+1:3d}  {vals}   {pwm['ic_per_pos'][i]:.3f}")
    lines.append("")
    lines.append(f"Max possible score: {max_possible_score(pwm):.3f}   Min possible score: {min_possible_score(pwm):.3f}")

    out_path.write_text("\n".join(lines) + "\n")


def save_pwm_json(pwm: dict, path: Path):
    path.write_text(json.dumps({
        "width": pwm["width"], "n_sites": pwm["n_sites"], "background": pwm["background"],
        "log_odds": pwm["log_odds"], "ic_per_pos": pwm["ic_per_pos"], "total_ic": pwm["total_ic"],
        "pseudocount": pwm["pseudocount"],
    }))


def load_pwm_json(path: Path) -> dict:
    return json.loads(path.read_text())
