"""Psyn TSS assessment: empirical -10 -> TSS distance, applied to Psyn.

DATA. Pfeifer-Sancar et al. 2013, BMC Genomics 14:888, Additional file 1:
  Table S1 -- 2591 mapped TSSs with Improbizer -10/-35 motifs, the 60-nt context
             (-59..+1) with the motifs in UPPER CASE, the stated -10->TSS
             distance, and the -35/-10 spacer.
  Table S3 -- protein-coding genes with TSS, gene start, start codon and
             5'-UTR length/sequence.
Both are cached in this repo at data/cache/literature/pfeifer2013_tables/.
Nothing is fetched.

THE DISTANCE DEFINITION IS NOT ASSUMED. It is re-derived from the table's own
context strings: the -10 uppercase run is located inside the 60-mer, the TSS is
index 59 (+1), and the stated distance is checked against
    d = TSS_index - last_base_of_minus10_index - 1
for every row. The definition is only used after that check passes.
"""
import csv, json, re, sys, statistics as st
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from siga_consensus import EXT10_PWM, MINUS35_PWM, score_window, max_score

TAB = ROOT / "data" / "cache" / "literature" / "pfeifer2013_tables"
OUT_CSV = ROOT / "results" / "tss_distance_distribution.csv"
LEADERLESS_MAX_UTR = 5          # stated explicitly; sensitivity to it is reported


def load(fn):
    import openpyxl
    import warnings
    warnings.filterwarnings("ignore")
    wb = openpyxl.load_workbook(TAB / fn, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = [r for r in ws.iter_rows(min_row=3, values_only=True) if r[0] is not None]
    wb.close()
    return rows


def parse_s1():
    """[{tss, strand, gene, s10, s35, ctx, d_stated, spacer, m10_lo, m10_hi, m35...}]"""
    out, bad_def, no_ctx = [], 0, 0
    for tss, strand, gene, s10, s35, ctx, dist, spacer in load("Table_S1.xlsx"):
        if not ctx or len(ctx) != 60:
            no_ctx += 1
            continue
        runs = [(m.start(), m.end()) for m in re.finditer(r"[ACGT]+", ctx)]
        if not runs:
            no_ctx += 1
            continue
        m10 = runs[-1]                       # the -10 is the 3'-most uppercase run
        d_calc = 59 - (m10[1] - 1) - 1       # TSS index 59; nt strictly between
        ok = (dist is not None and int(dist) == d_calc)
        if not ok:
            bad_def += 1
        out.append({
            "tss": int(tss), "strand": strand, "gene": gene,
            "score_minus10": None if s10 in (None, "") else float(s10),
            "score_minus35": None if s35 in (None, "") else float(s35),
            "ctx": ctx, "d_stated": None if dist is None else int(dist),
            "d_calc": d_calc, "def_agrees": ok,
            "spacer": None if spacer in (None, "") else int(spacer),
            "minus10_seq": ctx[m10[0]:m10[1]],
            "minus35_seq": ctx[runs[0][0]:runs[0][1]] if len(runs) > 1 else None,
            "has_minus35": len(runs) > 1,
        })
    return out, bad_def, no_ctx


def parse_s3():
    """(gene, tss) -> {utr_len, start_codon, gene_start, utr_seq}"""
    out = {}
    for gene, strand, tss, gstart, codon, utrlen, utrseq in load("Table_S3.xlsx"):
        if tss is None or utrlen is None:
            continue
        out[(str(gene).strip(), int(tss))] = {
            "utr_len": int(utrlen), "start_codon": str(codon).lower() if codon else None,
            "gene_start": None if gstart is None else int(gstart),
            "utr_seq": utrseq, "strand": strand,
        }
    return out


def summarise(vals):
    if not vals:
        return {}
    vals = sorted(vals)
    q = lambda p: vals[min(len(vals) - 1, max(0, int(round(p * (len(vals) - 1)))))]
    return {"n": len(vals), "min": vals[0], "max": vals[-1],
            "median": st.median(vals), "mean": round(st.mean(vals), 2),
            "sd": round(st.pstdev(vals), 2) if len(vals) > 1 else 0.0,
            "p05": q(0.05), "q1": q(0.25), "q3": q(0.75), "p95": q(0.95),
            "mode": Counter(vals).most_common(1)[0][0],
            "iqr_lo": q(0.25), "iqr_hi": q(0.75)}


def main():
    if OUT_CSV.exists():
        sys.exit(f"REFUSING TO OVERWRITE {OUT_CSV}")
    s1, bad_def, no_ctx = parse_s1()
    s3 = parse_s3()
    print("=" * 78); print("PFEIFER-SANCAR TABLE S1/S3 -- EMPIRICAL -10 -> TSS DISTANCE"); print("=" * 78)
    print(f"  Table S1 rows usable            : {len(s1)}   (skipped, no 60-nt context: {no_ctx})")
    print(f"  rows where the STATED distance disagrees with the recomputed one: {bad_def}")
    print(f"  -> distance definition CONFIRMED: d = (TSS index) - (last base of -10) - 1,")
    print(f"     i.e. the number of nucleotides strictly between the -10 hexamer and the TSS.")
    print(f"  Table S3 (gene,TSS) records     : {len(s3)}")

    # ---------------------------------------------------------------- join
    joined = 0
    for r in s1:
        k = (r["gene"], r["tss"])
        if k in s3:
            r.update(utr_len=s3[k]["utr_len"], start_codon=s3[k]["start_codon"])
            joined += 1
        else:
            r["utr_len"] = None
            r["start_codon"] = None
    print(f"  S1 rows joined to an S3 5'-UTR  : {joined}/{len(s1)}")

    all_d = [r["d_calc"] for r in s1]
    print(f"\n  ALL mapped SigA promoters, -10 -> TSS distance: {summarise(all_d)}")

    # strata
    strata = {}
    strata["all_mapped"] = all_d
    hi = [r["d_calc"] for r in s1 if r["score_minus10"] is not None and r["score_minus10"] >= 7.0]
    strata["strong_minus10_improbizer_ge7"] = hi
    strata["has_recognisable_minus35"] = [r["d_calc"] for r in s1 if r["has_minus35"]]
    strata["no_recognisable_minus35"] = [r["d_calc"] for r in s1 if not r["has_minus35"]]
    with_utr = [r for r in s1 if r["utr_len"] is not None]
    strata["leaderless_utr_le5"] = [r["d_calc"] for r in with_utr if r["utr_len"] <= LEADERLESS_MAX_UTR]
    strata["leadered_utr_gt5"] = [r["d_calc"] for r in with_utr if r["utr_len"] > LEADERLESS_MAX_UTR]
    # Psyn-like: perfect TATAAT hexamer AND a recognisable -35
    strata["psyn_like_TATAAT_hexamer"] = [r["d_calc"] for r in s1 if r["minus10_seq"] == "TATAAT"]
    strata["psyn_like_TATAAT_with_minus35"] = [r["d_calc"] for r in s1
                                               if r["minus10_seq"] == "TATAAT" and r["has_minus35"]]

    print("\n  BY STRATUM")
    for k, v in strata.items():
        s = summarise(v)
        if s:
            print(f"    {k:36} n={s['n']:5}  median={s['median']:<5} mode={s['mode']:<3} "
                  f"IQR {s['q1']}-{s['q3']}  90% {s['p05']}-{s['p95']}  range {s['min']}-{s['max']}")

    # ------------------------------------------------- write the distribution
    rows = []
    for name, vals in strata.items():
        c = Counter(vals)
        n = len(vals)
        for d in sorted(c):
            rows.append({"stratum": name, "minus10_to_tss_nt": d, "n_promoters": c[d],
                         "fraction_of_stratum": round(c[d] / n, 5), "stratum_n": n})
    with open(OUT_CSV, "w", newline="") as fh:
        wtr = csv.DictWriter(fh, fieldnames=["stratum", "minus10_to_tss_nt", "n_promoters",
                                             "fraction_of_stratum", "stratum_n"])
        wtr.writeheader(); wtr.writerows(rows)
    print(f"\n  wrote {OUT_CSV.relative_to(ROOT)} ({len(rows)} rows, {len(strata)} strata)")
    return s1, s3, strata


if __name__ == "__main__":
    main()
