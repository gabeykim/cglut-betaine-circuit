"""Task 1 (motif scan): extract experimentally confirmed TF binding sites from
cached RegulonDB GraphQL responses.

Source: RegulonDB (regulondb.ccg.unam.mx), the curated resource for E. coli
K-12 MG1655 transcriptional regulation. Every site below carries the genomic
coordinates (NC_000913.3-relative), the DNA strand, and the PMID(s) of the
primary experimental evidence (DNase footprinting, EMSA, ChIP, etc.) as
curated by RegulonDB -- not a consensus string invented for this project.

RegulonDB itself marks each site's core protected/footprinted region in
uppercase within lowercase flanking sequence; that uppercase core is what is
extracted here as "the site" for alignment and PWM-building.

CollecTF (the other named source, which additionally covers Salmonella) was
attempted and was unreachable from this environment (connection refused on
both a direct HTTP client and the fetch tool) -- see results/REPORT.md for
the full account. All sites here are therefore E. coli K-12 MG1655 sites.
This is disclosed, not hidden.
"""
import csv
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
SITES_DIR = DATA / "sites"


def load_regulondb_sites(json_path: Path, organism: str, tf: str):
    d = json.loads(json_path.read_text())
    ri = d["data"]["getRegulonBy"]["data"][0]["regulatoryInteractions"]
    sites = []
    seen = set()
    for r in ri:
        bs = r.get("regulatoryBindingSites")
        if not bs or not bs.get("sequence"):
            continue
        seq = bs["sequence"]
        left, right = bs["leftEndPosition"], bs["rightEndPosition"]
        key = (left, right, seq)
        if key in seen:
            continue
        seen.add(key)
        m = re.search(r"([A-Z]+)", seq)
        core = m.group(1) if m else None
        pmids = sorted({c["publication"]["pmid"] for c in r["citations"]
                         if c.get("publication") and c["publication"].get("pmid")})
        sites.append({
            # Publication reproduction fix: downstream code and archived manifests
            # use organism-prefixed labels. Keep the database query label unchanged.
            "tf": {"PhoP": "Ec_PhoP", "OmpR": "Ec_OmpR"}.get(tf, tf), "organism": organism, "promoter": r["regulatedEntity"]["name"],
            "full_context": seq, "core": core, "core_len": len(core) if core else 0,
            "strand": bs["strand"], "left": left, "right": right,
            "pmids": pmids, "source": "RegulonDB",
            "source_url": f"https://regulondb.ccg.unam.mx/regulon?term={tf}&format=jsp",
        })
    return sites


def main():
    SITES_DIR.mkdir(parents=True, exist_ok=True)
    all_rows = []

    for tf, jf in [("PhoP", "phop_ecoli_regulon.json"), ("OmpR", "ompr_ecoli_regulon.json")]:
        sites = load_regulondb_sites(DATA / "cache" / "regulondb" / jf,
                                      organism="Escherichia coli K-12 MG1655", tf=tf)
        lens = Counter(s["core_len"] for s in sites)
        modal_len = lens.most_common(1)[0][0]
        print(f"{tf}: {len(sites)} unique confirmed sites; core-length distribution {dict(sorted(lens.items()))}; "
              f"modal length = {modal_len} bp")

        pwm_seqs = []
        for s in sites:
            include = s["core_len"] == modal_len
            s["included_in_pwm"] = include
            s["exclusion_reason"] = "" if include else f"core length {s['core_len']} != modal {modal_len}"
            all_rows.append(s)
            if include:
                pwm_seqs.append(s["core"])

        fasta_path = SITES_DIR / f"{tf.lower()}_ecoli_sites.fasta"
        with open(fasta_path, "w") as fh:
            for s in sites:
                if s["included_in_pwm"]:
                    header = f">{s['promoter']}_{s['left']}_{s['right']}_{s['strand']} pmids={','.join(s['pmids'])}"
                    fh.write(f"{header}\n{s['core']}\n")
        print(f"  -> {len(pwm_seqs)} sites (all {modal_len} bp) written to {fasta_path} for PWM construction")

    manifest_path = DATA / "sites_manifest.csv"
    with open(manifest_path, "w", newline="") as fh:
        fieldnames = ["tf", "organism", "promoter", "core", "core_len", "included_in_pwm",
                      "exclusion_reason", "strand", "left", "right", "pmids", "source", "source_url"]
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for s in all_rows:
            row = dict(s)
            row["pmids"] = ";".join(s["pmids"])
            writer.writerow({k: row[k] for k in fieldnames})
    print(f"\nWrote {len(all_rows)} total confirmed sites (PWM-included + excluded) to {manifest_path}")


if __name__ == "__main__":
    main()
