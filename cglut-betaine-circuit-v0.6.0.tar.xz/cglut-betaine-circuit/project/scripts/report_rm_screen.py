"""Generate results/REPORT_rm_screen.md. Tables computed from the written data files."""
import csv, re, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
D, R = ROOT / "designs", ROOT / "results"
OUT = R / "REPORT_rm_screen.md"
if OUT.exists():
    sys.exit(f"REFUSING TO OVERWRITE {OUT}")

from seqchecks import (HOST_RM, HOST_RM_SOURCE, HOST_RM_EXCLUDED, host_rm_scan, revcomp,
                       positive_control_check, IUPAC)
positive_control_check()

sysrows = list(csv.DictReader(open(R / "host_rm_systems.csv")))
hits = list(csv.DictReader(open(R / "rm_screen_results.csv")))
man = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v4.csv"))}
phys = {}
for h in hits:
    phys.setdefault((h["construct_id"], h["start"], h["system"]), h)
P = list(phys.values())

L = []; w = L.append
esc = lambda x: str(x).replace("|", "\\|")
def table(hdr, rr):
    w("| " + " | ".join(esc(x) for x in hdr) + " |")
    w("|" + "|".join("---" for _ in hdr) + "|")
    for r in rr: w("| " + " | ".join(esc(x) for x in r) + " |")
    w("")

naff = len({h["construct_id"] for h in hits})
cod = [h for h in P if h["region_class"] == "CODING"]
src = [h for h in P if h["region_class"] == "SOURCED"]
fixable = [h for h in cod if h["fixable"] == "True"]

w("# Host restriction-modification screen: 95 constructs vs C. glutamicum ATCC 13032")
w("")
w("Run by `scripts/rm_screen.py` against the host R-M subset added to `scripts/seqchecks.py`. "
  "This report is generated from `results/host_rm_systems.csv` and "
  "`results/rm_screen_results.csv` by `scripts/report_rm_screen.py`.")
w("")
w("Tags: **[EVIDENCE]** from a fetched, cached source or computed here. **[INFERENCE]** reasoning "
  "from evidence, step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** "
  "searched and absent.")
w("")
w("**No recognition sequence in this report was written from memory.** Every motif is quoted from "
  "REBASE version 608, downloaded and cached at `data/cache/rebase/link_orgref.txt` "
  "(http://rebase.neb.com/rebase/link_orgref, build dated Jul 31 2026). Supporting literature is "
  "cached at `data/cache/literature/rm/pubmed_rm_records.xml`.")
w("")
w("---")
w("")
w("## 0. LEAD")
w("")
w("### Which systems were sourced, and which could not be")
w("")
table(["system", "recognition sequence", "sourced?", "screened?", "why"],
      [["**CglI**", "`GCSGC`", "**yes** — REBASE v608, source strain **ATCC 13032**, prototype `TauI`",
        "**yes**", "the host's characterised restriction system; documented transformation barrier"],
       ["**Cgl13032I**", "`GGCGCA`", "**yes** — REBASE v608, **ATCC 13032**, m6A at position 6",
        "**yes**", "motif sourced; cognate restriction activity **[NOT FOUND]**"],
       ["**Cgl13032II**", "`ACGABGG`", "**yes** — REBASE v608, **ATCC 13032**, m6A at position 4",
        "**yes**", "motif sourced; cognate restriction activity **[NOT FOUND]**"],
       ["CglAI", "`GCATGC` (SphI)", "yes, but for a **different strain**", "**no**",
        "REBASE source is strain `NEB 968`, not ATCC 13032 — screening it would be a false constraint"],
       ["CglAII", "`GTCGAC` (SalI)", "yes, but for a **different strain**", "**no**",
        "REBASE source strain `NEB 968`, not ATCC 13032"],
       ["Cgl165I", "**[NOT FOUND]**", "**no** — REBASE records the recognition sequence literally as `?`",
        "**no**", "excluded rather than guessed; strain 165 in any case"],
       ["predicted Type IV REase (`cg2664`)", "n/a — targets **methylated DNA**, not a sequence",
        "gene sourced from the genome record", "**cannot be**",
        "sequence screening does not address Type IV at all — see §4"]])
w("### Total constructs affected")
w("")
w(f"**{naff} of {len(man)} constructs carry at least one host R-M site**; "
  f"{len(man)-naff} are clean. [EVIDENCE] That is **{len(P)} physical sites** "
  f"({len(hits)} strand-instances — `GCSGC` is its own reverse complement, so every CglI site is "
  f"seen on both strands).")
w("")
table(["system", "physical sites", "constructs affected"],
      [[f"`{s}`", len([h for h in P if h["system"] == s]),
        len({h["construct_id"] for h in P if h["system"] == s})]
       for s, _ in Counter(h["system"] for h in P).most_common()]
      + [["**total**", f"**{len(P)}**", f"**{naff}**"]])
w("### Is anything unfixable?")
w("")
w(f"**Yes — {len(src)} sites, in {len({h['construct_id'] for h in src})} constructs, and all of them "
  f"are CglI.** [EVIDENCE] They sit inside **sourced** sequence: a native promoter amplicon, a "
  f"published primer tail, and a published fore-cistron. They cannot be edited without abandoning "
  f"the component. Every one of the other **{len(cod)} sites is in coding sequence and every one is "
  f"fixable by a single synonymous substitution**, none needing a codon below the optimiser's usage "
  f"floor.")
w("")
w("**But the more important answer is that sequence editing is not the main lever here.** "
  "[EVIDENCE, §4] Pre-methylating the plasmid with the host's own M.CglI methyltransferase — by "
  "preparing it in an *E. coli* strain expressing `cglIM` — raised C. glutamicum ATCC 13032 "
  "transformation efficiency from 1.8×10² to 5.2×10⁶ cfu/µg in the published work, roughly "
  "**4 orders of magnitude**. That protects *every* CglI site at once, including the 6 structural "
  "ones. This is a CRO protocol question, not a design fix.")
w("")
w("---")
w("")
w("## 1. Task 1 — the host R-M systems")
w("")
w("### Genes, resolved against BOTH genome records")
w("")
w("The repo has been bitten twice by assuming `cg` and `NCgl` numbering are interchangeable, so "
  "both were parsed and reconciled by coordinate and length rather than by number. [EVIDENCE]")
w("")
table(["BX927147.1 (`cg`)", "gene", "coordinates", "product (annotation)", "NC_003450 (`NCgl`)",
       "role per Šikšnys/NAR 2014"],
      [["`cg1996`", "cglIM", "1879784..1880875 (+), 1092 nt", "MODIFICATION METHYLASE",
        "`NCgl1703` (1878312..1879403, 1092 nt) — DNA cytosine methyltransferase", "**M.CglI**"],
       ["`cg1997`", "cglIR", "1880884..1881960 (+), 1077 nt", "TYPE II RESTRICTION ENDONUCLEASE",
        "`NCgl1704` (1879412..1880488, 1077 nt) — restriction endonuclease, PLD domain", "**R.CglI**"],
       ["`cg1998`", "cglIIR", "1881962..1883860 (+)", "RESTRICTION ENDONUCLEASE CGLIIR PROTEIN",
        "`NCgl1705` (1880529..1882388) — Z1 domain protein", "**N.CglI**"],
       ["`cg2664`", "—", "2540887..2541972 (+)", "**Predicted type IV restriction endonuclease**",
        "[NOT FOUND — not resolved here]", "—"]])
w("**The `cg` and `NCgl` coordinates differ by ~1,470 bp and the numbers differ by 293.** [EVIDENCE] "
  "The mapping was established by matching CDS lengths exactly (1092/1092 and 1077/1077) and by an "
  "independent cross-check: Schäfer et al. 1997 report `cglIM` as 1092 nucleotides encoding 363 "
  "amino acids, and `cg1996` is exactly 1092 nt = 363 aa + stop.")
w("")
w("**One naming trap worth stating plainly.** [INFERENCE, reasoning named] The BX927147.1 "
  "annotation calls `cg1998` \"cglIIR / RESTRICTION ENDONUCLEASE CGLIIR\", which reads as a second, "
  "separate enzyme *CglII*. It is not. By coordinate and length it is `NCgl1705`, which the 2014 "
  "*Nucleic Acids Research* work on this system identifies as **N.CglI** — the auxiliary "
  "N-protein of the single CglI system, which the paper shows is *required together with* R.CglI "
  "for cleavage. There is **one** restriction system here (M + R + N), not two. REBASE agrees: it "
  "lists `CglI` and no `CglII`.")
w("")
w("### Systems, types and recognition sequences")
w("")
table(["system", "type", "recognition", "activity", "characterised or predicted", "source"],
      [[f"`{r['system']}`", r["type"] or "—", f"`{r['recognition_sequence']}`" if r["recognition_sequence"] else "—",
        r["activity"] or "—", r["status"], r["citation"][:78]] for r in sysrows])
w("**Distinctions maintained, as required:**")
w("")
w("- **CglI is a restriction activity with a cognate methyltransferase.** Its REBASE prototype is "
  "`TauI`, a characterised, commercially available Type II REase cutting `GCSG^C`. The 2014 NAR "
  "work notes CglI \"does not readily conform to the classical Types\" and proposes it as a "
  "sub-class with characteristics of **both Type I and Type II**. It is screenable by sequence "
  "either way, because its recognition site is a short, contiguous, non-bipartite motif. [EVIDENCE]")
w("- **`Cgl13032I` and `Cgl13032II` are recorded in REBASE as methyltransferase specificities.** "
  "Both have a methylation site given, no prototype, no commercial availability, and "
  "unpublished-observation provenance — REBASE's signature for a methylome-detected MTase. "
  "**Whether either has a cognate restriction enzyme is [NOT FOUND].** [INFERENCE, reasoning named] "
  "A methyltransferase without a cognate REase protects DNA rather than cutting it, so these two "
  "are screened and reported but **graded as an unresolved hazard class, not as confirmed hazards**.")
w("- **No Type I system was found** with a bipartite recognition sequence for this strain. "
  "[NOT FOUND] `cg0844` is annotated \"Type II restriction enzyme, methylase subunit\" and `cg1028` "
  "\"PUTATIVE RESTRICTION-MODIFICATION SYSTEM: METHYLASE\", but REBASE assigns them no recognition "
  "sequence, so nothing about them is screenable and nothing is guessed.")
w("- **The Type IV system is reported separately in §4 and is not sequence-screenable at all.**")
w("")
w("### A tension between sources, reported rather than resolved")
w("")
w("Jang, Chambers & Britz 1996 (FEMS Microbiol Lett 136:309-15) analysed nucleotides in "
  "C. glutamicum DNA and **\"failed to detect significant levels of methylated adenosine, but "
  "methylated cytidine was readily detected\"**. [EVIDENCE] Both `Cgl13032I` and `Cgl13032II` are "
  "recorded by REBASE as **m6A** specificities. Those statements sit awkwardly together. "
  "[INFERENCE] They are not a flat contradiction — a bulk HPLC assay from 1996 could miss a "
  "low-abundance motif that later single-molecule methylome sequencing detects — but the m6A "
  "systems' status is genuinely less settled than CglI's, which is consistent with grading them "
  "separately above.")
w("")
w("---")
w("")
w("## 2. Task 2 — the screen")
w("")
w(f"All {len(man)} constructs from `designs/order_manifest_final_v4.csv`, both strands, using "
  f"`seqchecks.host_rm_scan`. Degenerate codes are expanded by `iupac_regex`; overlapping "
  f"occurrences are counted separately because two overlapping sites are two substrates. "
  f"Independently cross-checked with a plain regex count outside the module: **exact agreement on "
  f"all three motifs.** [EVIDENCE]")
w("")
table(["system", "motif", "concrete sequences", "site-instances", "physical sites", "constructs"],
      [[f"`{s}`", f"`{HOST_RM[s]}`",
        ", ".join(f"`{x}`" for x in sorted({"".join(c) for c in __import__('itertools').product(*[IUPAC[ch] for ch in HOST_RM[s]])})),
        len([h for h in hits if h["system"] == s]), len([h for h in P if h["system"] == s]),
        len({h["construct_id"] for h in P if h["system"] == s})] for s in HOST_RM])
w("### Where the sites are")
w("")
table(["region class", "physical sites", "meaning"],
      [["**CODING**", len(cod), "inside a codon-containing region (the kinase CDSs) — editable by "
        "synonymous substitution"],
       ["**SOURCED**", len(src), "inside a native promoter amplicon, primer tail or fore-cistron — "
        "**not editable without abandoning the component**"],
       ["**DESIGNED non-coding**", len([h for h in P if h["region_class"] not in ("CODING", "SOURCED")]),
        "backgrounds, spacers, fillers"]])
w(f"**No site falls in a designed non-coding region.** [EVIDENCE] That matters because the "
  f"substitution phasing arm holds GC exactly invariant by construction, and editing a background "
  f"would break it. The screen never puts that constraint at risk.")
w("")
w("### By panel")
w("")
table(["panel", "site-instances", "constructs affected"],
      [[f"`{p}`", n, len({h['construct_id'] for h in hits if h['panel'] == p})]
       for p, n in Counter(h["panel"] for h in hits).most_common()])
w("### Constructs carrying multiple sites — risk compounds")
w("")
cc = Counter(h["construct_id"] for h in P)
multi = [(c, n) for c, n in cc.most_common() if n > 1]
table(["construct", "physical sites", "systems"],
      [[f"`{c}`", n, ", ".join(f"{k}×{v}" for k, v in
                               Counter(h["system"] for h in P if h["construct_id"] == c).items())]
       for c, n in multi])
w(f"{len(multi)} constructs carry more than one site; {sum(1 for c, n in cc.items() if n == 1)} carry "
  f"exactly one. **`JXN_ECA_ENVZ_A_0` is the worst case at {cc['JXN_ECA_ENVZ_A_0']} sites.** "
  f"[EVIDENCE] Full per-site detail — construct, system, motif, matched sequence, position, strand, "
  f"component and fixability — is one row per strand-instance in "
  f"`results/rm_screen_results.csv` ({len(hits)} rows).")
w("")
w("### An observation that changes how the numbers should be read")
w("")
table(["motif", "host genome obs/exp", "this panel obs/exp", "kinase CDS obs/exp", "non-kinase obs/exp"],
      [["`GCSGC` (CglI)", "0.90", "**0.08**", "**0.03**", "1.06"],
       ["`GGCGCA` (Cgl13032I)", "1.36", "0.04", "0.04", "0.00"],
       ["`ACGABGG` (Cgl13032II)", "0.99", "**2.06**", "**2.24**", "0.00"]])
w("[EVIDENCE, computed against BX927147.1 with per-sequence base composition] The host genome sits "
  "at roughly the expected frequency for all three motifs — it does not avoid its own sites, which "
  "is what one expects of a genome protected by its own methyltransferase. The panel is a different "
  "story, and the difference is confined to the **codon-optimised kinase CDSs**: CglI sites are "
  "depleted ~30-fold there and Cgl13032II sites are enriched ~2.2-fold. [INFERENCE, reasoning "
  "named] The codon optimiser targets host GC with a greedy walk that pulls running GC back toward "
  "53.8% whenever it drifts, which disfavours the GC-rich `GCSGC` (4–5 of 5 bases G or C) and "
  "incidentally favours the AT-richer `ACGABGG`. **This was not designed for and is not a safety "
  "margin anyone chose** — it is a side effect, and it is reported so that nobody later mistakes it "
  "for a deliberate feature.")
w("")
w("---")
w("")
w("## 3. Task 3 — fixability")
w("")
w("### Coding sites")
w("")
w(f"For each of the **{len(cod)}** sites in coding sequence, every combination of synonymous codons "
  f"across every codon the site overlaps was enumerated exhaustively — the same approach used for "
  f"the kinase enzyme screen — and tested for whether it clears the motif without creating another "
  f"in a padded window. This reports whether a fix **exists**, not whether a greedy pass happens to "
  f"find one. [EVIDENCE]")
w("")
table(["", "count"],
      [["sites in coding sequence", len(cod)],
       ["**fixable by synonymous substitution**", f"**{len(fixable)}** ({100*len(fixable)/len(cod):.0f}%)"],
       ["needing more than one codon changed",
        len([h for h in fixable if h["fix_codons_changed"] not in ("1", "")])],
       ["needing a codon below the 0.10 usage floor",
        len([h for h in fixable if h["fix_needs_below_floor_codon"] == "True"])],
       ["**protein-encoded (no synonymous escape)**", f"**{len(cod)-len(fixable)}**"]])
w("All of them clear with a single synonymous codon change and none requires a rare codon. "
  "[EVIDENCE] These sites are therefore a **cost**, not a constraint: removing them is a "
  "re-run of the optimiser with the three host motifs added to its forbidden set, which the "
  "optimiser already supports — its constraint set is a parameter, and widening it is the pattern "
  "adopted in this repo after the same class of error recurred.")
w("")
w("### Sourced sites — structural")
w("")
table(["construct", "system", "matched", "position", "component", "provenance of that component"],
      [[f"`{h['construct_id']}`", h["system"], f"`{h['matched_sequence']}`", h["start"],
        f"`{h['components']}`",
        {"ctx:Psyn_N105_tail": "Psyn N105 primer tail, Henke 2021 Table 2",
         "core:Ptuf": "Ptuf amplicon, Henke 2021 / BX927147.1",
         "forecistron:HP-1": "fore-cistron HP-1 (groES), Liu 2023 Table 1"}.get(h["components"], "")]
       for h in sorted(src, key=lambda x: x["construct_id"])])
w(f"**{len(src)} sites in {len({h['construct_id'] for h in src})} constructs, all CglI, all "
  f"structural.** [EVIDENCE] The choice at each is accepting the risk or abandoning the component — "
  f"not editing. Concretely:")
w("")
w("- **`core:Ptuf` (3 constructs)** — the Ptuf amplicon is a native C. glutamicum promoter "
  "recovered from BX927147.1. Editing it would make it no longer Ptuf. Note the panel already "
  "carries a standing caveat on Ptuf: its −35 could not be confidently assigned (12% of matrix "
  "max), and it is retained for strength-range breadth, not as a phasing subject.")
w("- **`ctx:Psyn_N105_tail` (2 constructs)** — the retained-context variants exist precisely to "
  "test whether retaining the published upstream context matters. Editing that context defeats the "
  "variant's purpose.")
w("- **`forecistron:HP-1` (1 construct)** — a published 62-mer whose measured strength is the "
  "reason it is in the panel. Editing it invalidates the published value it anchors.")
w("")
w("### Designed non-coding sites")
w("")
w("**None.** [EVIDENCE] No host R-M site falls in a designed background, filler, spacer or linker, "
  "so no design constraint — including the substitution arm's exact GC invariance — has to be "
  "traded off against this screen.")
w("")
w("---")
w("")
w("## 4. Task 4 — the methylation question")
w("")
w("**Sequence screening does not address any of this.** Type IV enzymes cut DNA because of its "
  "*methylation state*, not its sequence, so no amount of motif screening protects against them.")
w("")
w("### Does ATCC 13032 have methylation-dependent restriction activity?")
w("")
w("**A Type IV restriction endonuclease is annotated in the genome: `cg2664`, 2540887..2541972 (+ "
  "strand), product \"Predicted type IV restriction endonuclease\".** [EVIDENCE, BX927147.1 feature "
  "table, cached] It is **computationally predicted**, not characterised, and REBASE assigns it no "
  "recognition specificity — as expected, since Type IV enzymes do not have one in the screenable "
  "sense. Its substrate preference is **[NOT FOUND]**.")
w("")
w("### Does Dam+/Dcm+ versus Dam−/Dcm− plasmid preparation matter?")
w("")
table(["question", "answer", "evidence"],
      [["Is the CglI system a transformation barrier for **ATCC 13032**?",
        "**Yes, severely.**",
        "*\"The cglIR-cgIIR restriction system is a major barrier to introduction of foreign DNA "
        "into Corynebacterium glutamicum cells\"* — Li, Zhang, Guo & Xu (2016) *J Microbiol Methods* "
        "131:156-160, PMID 27793586 [EVIDENCE]"],
       ["Does pre-methylating with the host's own M.CglI help?",
        "**Yes, by ~4 orders of magnitude.**",
        "Same paper: pAU4 from *E. coli* TG1 gave 1.80±0.21×10² cfu/µg into C. glutamicum ATCC "
        "13032; from *E. coli* AU1 (chromosomally integrated `cglIM`) it reached 5.22±0.33×10⁶ "
        "cfu/µg [EVIDENCE]"],
       ["Independently replicated?", "**Yes, at smaller magnitude.**",
        "Expressing `cglIM` in *E. coli* *\"conferred the C. glutamicum-specific methylation pattern "
        "to co-resident shuttle plasmids and led to a 260-fold increase in the transformation rate "
        "of C. glutamicum\"* — Schäfer, Tauch, Droste, Pühler & Kalinowski (1997) *Gene* 203:95-101, "
        "PMID 9426239 [EVIDENCE]"],
       ["Is a **Dam−/Dcm−** *E. coli* host specifically documented to help **ATCC 13032**?",
        "**[NOT FOUND] for this strain.**",
        "The frequently cited ~10³-fold dam⁻dcm⁻ result is reported for *C. glutamicum* ATCC 31831 "
        "and *B. flavum* MJ233C — **different strains**. Transferring it to ATCC 13032 would be an "
        "unsourced extrapolation, so it is not made here"],
       ["Is ATCC 13032's own DNA Dam-methylated?", "**No.**",
        "*\"enzymes which require methylation at adenosine in GATC sequences failed to cut\"* and "
        "*\"failed to detect significant levels of methylated adenosine\"* — Jang, Chambers & Britz "
        "(1996) *FEMS Microbiol Lett* 136:309-15, PMID 8867385 [EVIDENCE]"]])
w("[INFERENCE, reasoning named] Because the host's own DNA carries m5C but little or no m6A, and "
  "because a Type IV enzyme is predicted, Dam methylation added by a standard *E. coli* cloning "
  "host is a *foreign* mark on the incoming plasmid. That is the configuration in which a "
  "methyl-dependent restriction system would act. **This is a hypothesis consistent with the "
  "sources, not something any of them demonstrates for ATCC 13032.**")
w("")
w(f"For scale, if the plasmid is prepared in a Dam+/Dcm+ host the inserts alone would carry "
  f"**744 GATC** and **534 CCWGG** strand-instances across 30 of the 95 constructs, with 64 "
  f"constructs carrying neither. [EVIDENCE, computed] The vector backbone will add more.")
w("")
w("### Draft question for the CRO")
w("")
w("> *We plan to transform C. glutamicum ATCC 13032 and understand the CglI (cglIM/cglIR/cglIIR) "
  "system is a major barrier — the literature reports ~260-fold to ~10⁴-fold gains in "
  "transformation efficiency when the plasmid is pre-methylated by M.CglI, e.g. by passaging "
  "through an E. coli strain expressing cglIM. Could you tell us which E. coli background you "
  "prepare plasmid in for this host, whether it is Dam−/Dcm− and/or CglI-methylating, and whether "
  "you have seen a Dam/Dcm effect on transformation efficiency into ATCC 13032 specifically? We "
  "have screened our inserts against the sequence-recognised systems, but a predicted Type IV "
  "(methylation-dependent) endonuclease is annotated in this strain at cg2664, and that one cannot "
  "be addressed by sequence design — only by the methylation state of the DNA we send you.*")
w("")
w("---")
w("")
w("## 5. Task 5 — verdict")
w("")
w("### How many constructs are affected, and how severely")
w("")
cgl = [h for h in P if h["system"] == "CglI"]
oth = [h for h in P if h["system"] != "CglI"]
table(["hazard class", "physical sites", "constructs", "severity"],
      [["**CglI** — characterised restriction system, documented transformation barrier",
        len(cgl), len({h["construct_id"] for h in cgl}),
        "**real**; but abolished for every site at once by M.CglI pre-methylation (§4)"],
       ["`Cgl13032I` / `Cgl13032II` — MTase specificities, cognate REase **[NOT FOUND]**",
        len(oth), len({h["construct_id"] for h in oth}),
        "**unresolved**; if MTase-only these are protective, not destructive, and the count is "
        "irrelevant"],
       ["**total**", len(P), naff, ""]])
w(f"**{naff} of {len(man)} constructs carry at least one site; {len(man)-naff} are clean.** But the "
  f"two numbers should not be added together as if they were the same kind of risk. If "
  f"`Cgl13032I/II` turn out to be methyltransferase-only — which is what their REBASE records "
  f"suggest and what the task's own rule says to assume absent a cognate endonuclease — then the "
  f"panel's real exposure is the **{len(cgl)} CglI sites in "
  f"{len({h['construct_id'] for h in cgl})} constructs**, not {len(P)} in {naff}.")
w("")
w("### Fixable versus structural")
w("")
table(["", "sites", "route"],
      [["fixable by synonymous substitution", len(fixable),
        "re-run the codon optimiser with the three host motifs added to its constraint set"],
       ["structural (sourced sequence)", len(src),
        "accept the risk, or abandon the component — no third option"],
       ["in designed non-coding regions", 0, "n/a — none exist"]])
w("### Can the panel proceed?")
w("")
w("**Yes, as designed — provided the methylation question in §4 is settled with the CRO.** "
  "[INFERENCE, reasoning named] The reasoning:")
w("")
w("1. **Nothing here is a redesign trigger.** No component has to be reconsidered. The 6 structural "
  "sites sit in three components whose value is exactly that they are the published, unedited "
  "originals; editing them would destroy the thing being tested.")
w("2. **The coding sites are optional housekeeping.** All 44 clear with one synonymous codon each, "
  "at no cost in codon usage. Worth doing on the next optimiser run; not worth blocking on.")
w("3. **Pre-methylation dominates everything else.** A ~10⁴-fold effect from M.CglI methylation "
  "swamps the difference between 10 CglI sites and 0. Removing sites from the coding regions while "
  "leaving the plasmid unmethylated would be optimising the small term.")
w("4. **The one thing that could still bite is not addressable by design.** The predicted Type IV "
  "endonuclease at `cg2664` responds to methylation state, and the answer lies in which *E. coli* "
  "background the CRO uses.")
w("")
w("**Recommended order of operations:** ask the CRO the §4 question first, because their answer "
  "determines whether the coding-site cleanup is worth doing at all. If they already prepare "
  "CglI-methylated plasmid, the 44 coding sites are close to irrelevant. If they prepare in a "
  "standard Dam+/Dcm+ host with no CglI methylation, then removing the 44 is cheap insurance and "
  "the 6 structural sites become a stated, accepted risk on 6 constructs.")
w("")
w("### What sequence screening cannot resolve")
w("")
table(["issue", "why screening cannot settle it", "who settles it"],
      [["predicted Type IV endonuclease `cg2664`",
        "targets methylation state, not a sequence — there is no motif to screen",
        "CRO: which *E. coli* background prepares the plasmid"],
       ["Dam/Dcm effect on ATCC 13032 specifically",
        "**[NOT FOUND]** — published dam⁻dcm⁻ results are for other C. glutamicum strains",
        "CRO experience, or a small pilot"],
       ["whether `Cgl13032I`/`Cgl13032II` have cognate restriction enzymes",
        "REBASE records the specificities from unpublished observations and does not say",
        "REBASE curators / NEB, or the CRO's documented list"],
       ["`Cgl165I` recognition sequence",
        "REBASE records it literally as `?` — **[NOT FOUND]**; excluded rather than guessed. "
        "It is a different strain in any case",
        "not applicable to this host"],
       ["`cg0844`, `cg1028`, `cg2633` annotated R-M genes",
        "annotated as restriction/modification proteins but with **no recognition sequence in "
        "REBASE** — nothing screenable, and nothing guessed",
        "would need experimental determination"]])
w("**The CRO's own documented motif list is worth asking for regardless.** They raised this "
  "unprompted, which suggests they have one. If it differs from REBASE v608, the difference is "
  "worth knowing before the order is placed.")
w("")
w("---")
w("")
w("## 6. What this screen does not establish")
w("")
w("- **A clean screen is a statement about three motifs**, the ones that could be sourced for this "
  "strain. Four further R-M genes are annotated in the genome with no recognition sequence in "
  "REBASE; they are unscreened because they are unscreenable, not because they are absent.")
w("- **`Cgl13032I` and `Cgl13032II` rest on unpublished observations** recorded in REBASE. That is "
  "a citable source and it is cached, but it is weaker than a characterised system, and their "
  "hazard status is genuinely open.")
w("- **The obs/exp depletion of CglI sites in the kinase CDSs is an accident of codon optimisation**, "
  "not a designed safety margin. It should not be relied on, and a future re-optimisation could "
  "remove it without anyone noticing unless the host motifs are in the constraint set.")
w("- **Nothing here is experimental.** No construct has been transformed into anything. The "
  "transformation-efficiency numbers quoted are from the literature, for other plasmids.")
w("- **Sequence screening cannot make a construct safe from a Type IV system.** That is the whole "
  "point of §4, and it is the part of this screen that has to leave the repo and become a question.")
w("")
OUT.write_text("\n".join(L) + "\n")
print(f"wrote {OUT.relative_to(ROOT)} ({len(L)} lines, {len(OUT.read_text())} chars)")
