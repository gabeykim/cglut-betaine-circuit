"""Task 2 (follow-up): rebuild the null model from INTERGENIC composition
instead of whole-genome composition, and rescore every HIGH_CONCERN hit
against it.

Intergenic regions are derived from the cached feature table (BX927147.ft.txt,
already fetched by the original cross-talk analysis -- no GFF3 was ever
fetched for this repo, and none is re-fetched here; the feature table carries
the same gene-coordinate information a GFF3 would). Intergenic = genome
positions not covered by the union of all annotated CDS/gene intervals.
BX927147.1 is a circular chromosome, but its first annotated gene (dnaA)
starts at position 1, so the region between the last gene and the genome end
is an ordinary (non-wrapping) 76 bp terminal segment -- verified directly,
not assumed -- and no special circular handling is needed.

Null construction: EACH intergenic segment is independently dinucleotide-
shuffled (Altschul-Erikson) and scored on both strands. Shuffling segments
independently -- rather than concatenating them first -- avoids inventing
spurious dinucleotide transitions at segment junctions, and lets every null
window be mapped back to its position within the real segment it came from,
which is what makes the by-chance HIGH_CONCERN-rate estimate below exact
rather than approximate: a null window's "would this classify as
HIGH_CONCERN" status is computed with the SAME edge-based distance rule
(scripts/annotate_hits.py's upstream_distance) applied to its real genomic
coordinates, since shuffling a segment does not change its length or its
position relative to the gene(s) it sits next to.
"""
import csv
import json
import sys
from pathlib import Path

import numpy as np
from Bio import SeqIO
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent))
from annotate_hits import load_genes, UPSTREAM_WINDOW
from dinuc_shuffle import dinuc_shuffle
from pwm_lib import (BASES, build_pwm, load_aligned_fasta, score_all_windows,
                      revcomp, save_pwm_json, write_pwm_txt, max_possible_score, min_possible_score)

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"
GENOME_FASTA = DATA / "cache" / "BX927147.fasta"
FT_PATH = DATA / "cache" / "BX927147.ft.txt"
SEED = 1337
P_THRESH = 1e-4


def load_genome() -> str:
    rec = next(SeqIO.parse(GENOME_FASTA, "fasta"))
    return str(rec.seq).upper()


def merge_intervals(intervals):
    ivs = sorted(intervals)
    merged = []
    for lo, hi in ivs:
        if merged and lo <= merged[-1][1] + 1:
            merged[-1] = (merged[-1][0], max(merged[-1][1], hi))
        else:
            merged.append((lo, hi))
    return merged


def intergenic_segments(genome_len: int, genes: list):
    """Returns list of (lo,hi) 1-based inclusive intergenic intervals."""
    cds_intervals = merge_intervals([(g["cds_lo"], g["cds_hi"]) for g in genes])
    segments = []
    for i in range(len(cds_intervals) - 1):
        gap_lo = cds_intervals[i][1] + 1
        gap_hi = cds_intervals[i + 1][0] - 1
        if gap_hi >= gap_lo:
            segments.append((gap_lo, gap_hi))
    # terminal segment after the last CDS; verified (see module docstring) that
    # the first CDS starts at position 1, so this is an ordinary tail segment,
    # not a genuine circular wrap.
    tail_lo = cds_intervals[-1][1] + 1
    first_lo = cds_intervals[0][0]
    assert first_lo == 1, f"first CDS does not start at position 1 (starts at {first_lo}) -- wrap handling needed"
    if tail_lo <= genome_len:
        segments.append((tail_lo, genome_len))
    return segments, cds_intervals


def window_hc_eligibility(w_lo: np.ndarray, w_hi: np.ndarray, plus_tss: np.ndarray, minus_tss: np.ndarray):
    """For arrays of window left/right genomic edges (1-based inclusive),
    replicate annotate_hits.GeneIndex.upstream_distance's exact rule:
    a window is HIGH_CONCERN-eligible if some '+' gene has 0<=tss-w_hi<=W,
    or some '-' gene has 0<=w_lo-tss<=W."""
    mask = np.zeros(len(w_lo), dtype=bool)
    if len(plus_tss):
        lo_idx = np.searchsorted(plus_tss, w_hi, side="left")
        hi_idx = np.searchsorted(plus_tss, w_hi + UPSTREAM_WINDOW, side="right")
        mask |= (hi_idx > lo_idx)
    if len(minus_tss):
        lo_idx = np.searchsorted(minus_tss, w_lo - UPSTREAM_WINDOW, side="left")
        hi_idx = np.searchsorted(minus_tss, w_lo, side="right")
        mask |= (hi_idx > lo_idx)
    return mask


def main():
    print("=== Loading genome and gene annotations (cached, not re-fetched) ===")
    genome = load_genome()
    L = len(genome)
    genes = load_genes(FT_PATH)
    print(f"genome length {L} bp, {len(genes)} genes")

    segments, cds_intervals = intergenic_segments(L, genes)
    print(f"{len(cds_intervals)} merged CDS intervals, {len(segments)} intergenic segments")

    seg_seqs = []
    total_ig_bp = 0
    counts = {b: 0 for b in BASES}
    for seg in segments:
        lo, hi = seg
        s = genome[lo - 1:hi]
        seg_seqs.append((seg, s))
        total_ig_bp += len(s)
        for b in BASES:
            counts[b] += s.count(b)

    genome_counts = {b: genome.count(b) for b in BASES}
    genome_total = sum(genome_counts.values())
    genome_bg = {b: genome_counts[b] / genome_total for b in BASES}

    ig_bg = {b: counts[b] / total_ig_bp for b in BASES}
    ig_gc = ig_bg["G"] + ig_bg["C"]
    genome_gc = genome_bg["G"] + genome_bg["C"]

    print(f"\nTotal intergenic bp: {total_ig_bp} / {L} = {100*total_ig_bp/L:.2f}% of genome")
    print(f"Intergenic composition: A={ig_bg['A']:.4f} C={ig_bg['C']:.4f} G={ig_bg['G']:.4f} T={ig_bg['T']:.4f} "
          f"(GC={100*ig_gc:.2f}%)")
    print(f"Whole-genome composition: A={genome_bg['A']:.4f} C={genome_bg['C']:.4f} G={genome_bg['G']:.4f} "
          f"T={genome_bg['T']:.4f} (GC={100*genome_gc:.2f}%)")
    ig_at, genome_at = ig_bg["A"] + ig_bg["T"], genome_bg["A"] + genome_bg["T"]
    print(f"AT enrichment: {100*ig_at:.2f}% AT (intergenic) vs {100*genome_at:.2f}% AT (genome) "
          f"= {100*(ig_at-genome_at):.2f} percentage-point enrichment")

    # --- rebuild PWM against intergenic background ---
    phop_sites = load_aligned_fasta(DATA / "sites" / "phop_ecoli_sites.fasta")
    pwm_ig = build_pwm(phop_sites, ig_bg)
    write_pwm_txt(pwm_ig, name="Ec_PhoP (intergenic-background)", out_path=RESULTS / "pwm_intergenic.txt",
                  site_fasta=DATA / "sites" / "phop_ecoli_sites.fasta")
    save_pwm_json(pwm_ig, DATA / "cache" / "pwm_phop_intergenic.json")
    print(f"\nIntergenic-background PWM: {pwm_ig['n_sites']} sites, total IC = {pwm_ig['total_ic']:.2f} bits "
          f"(whole-genome-background PWM was 9.56 bits)")

    # --- empirical null: shuffle each intergenic segment independently, score both strands ---
    print("\n=== Building intergenic empirical null (dinucleotide-shuffled per segment) ===")
    plus_tss = np.array(sorted(g["tss"] for g in genes if g["strand"] == "+"))
    minus_tss = np.array(sorted(g["tss"] for g in genes if g["strand"] == "-"))
    w = pwm_ig["width"]

    null_scores = []
    null_hc_scores = []
    real_hc_eligible_windows = 0

    for seg_i, (seg, seq) in enumerate(seg_seqs):
        if len(seq) < w:
            continue
        lo, hi = seg
        n_windows = len(seq) - w + 1
        starts = np.arange(lo, lo + n_windows)  # genomic 1-based start of each window
        w_lo, w_hi = starts, starts + w - 1
        window_hc = window_hc_eligibility(w_lo, w_hi, plus_tss, minus_tss)
        real_hc_eligible_windows += int(window_hc.sum()) * 2  # scored once per strand at the same positions

        shuffled = dinuc_shuffle(seq, seed=SEED + seg_i)
        fwd_scores = score_all_windows(shuffled, pwm_ig)
        rev_scores = score_all_windows(revcomp(shuffled), pwm_ig)

        fwd_valid = np.isfinite(fwd_scores)
        null_scores.append(fwd_scores[fwd_valid])
        null_hc_scores.append(fwd_scores[fwd_valid & window_hc[:len(fwd_scores)]])

        rev_valid = np.isfinite(rev_scores)
        null_scores.append(rev_scores[rev_valid])
        # reverse-strand score at index k corresponds to the ORIGINAL window at
        # position (n_windows-1-k) (see scan_genome.strand_hits) -> reverse the HC mask
        rev_hc_mask = window_hc[::-1][:len(rev_scores)]
        null_hc_scores.append(rev_scores[rev_valid & rev_hc_mask])

    null_pool = np.concatenate(null_scores)
    null_pool_sorted = np.sort(null_pool)
    null_hc_pool = np.concatenate(null_hc_scores)
    n_null = len(null_pool_sorted)
    print(f"Intergenic null pool: {n_null} scores from {len(seg_seqs)} independently-shuffled segments")
    print(f"  of which {len(null_hc_pool)} fall in HIGH_CONCERN-eligible territory (both strands)")
    print(f"Real genome HIGH_CONCERN-eligible scoreable windows (both strands, exact count): {real_hc_eligible_windows}")

    rank_idx = max(0, n_null - int(np.ceil(P_THRESH * n_null)))
    score_thresh = null_pool_sorted[rank_idx]
    print(f"Score threshold for empirical p<={P_THRESH} under intergenic null: {score_thresh:.4f} "
          f"(max possible={max_possible_score(pwm_ig):.2f}, min possible={min_possible_score(pwm_ig):.2f})")

    expected_analytical = real_hc_eligible_windows * P_THRESH
    frac_hc_exceeding = float(np.mean(null_hc_pool >= score_thresh)) if len(null_hc_pool) else 0.0
    expected_simulation = frac_hc_exceeding * real_hc_eligible_windows
    print(f"\nExpected HIGH_CONCERN hits by chance under intergenic null:")
    print(f"  analytical (N_HC_eligible_windows x p_threshold): {real_hc_eligible_windows} x {P_THRESH} = {expected_analytical:.3f}")
    print(f"  simulation (fraction of HC-eligible null windows exceeding threshold x N_HC_eligible_windows): "
          f"{frac_hc_exceeding:.6f} x {real_hc_eligible_windows} = {expected_simulation:.3f}")

    # --- rescore the 304 HIGH_CONCERN hits ---
    print("\n=== Rescoring the HIGH_CONCERN hits against the intergenic PWM + null ===")
    hc_hits_raw = list(csv.DictReader(open(RESULTS / "hits_high_concern.csv")))
    # idempotent: if this script already ran once, hits_high_concern.csv carries the
    # 3 added columns from that run -- strip them before recomputing so a rerun
    # overwrites cleanly instead of duplicating the fieldnames.
    added_cols = ("score_intergenic_bg", "empirical_p_intergenic_null", "passes_p1e-4_intergenic_null")
    hc_hits = [{k: v for k, v in row.items() if k not in added_cols} for row in hc_hits_raw]
    logodds = pwm_ig["log_odds"]

    def score_seq(s):
        return sum(logodds[i].get(ch, -10.0) for i, ch in enumerate(s))

    out_rows = []
    for h in hc_hits:
        start, end, strand = int(h["start"]), int(h["end"]), h["strand"]
        raw_fwd = genome[start - 1:end]
        window_seq = raw_fwd if strand == "+" else revcomp(raw_fwd)
        new_score = score_seq(window_seq)
        idx = np.searchsorted(null_pool_sorted, new_score, side="left")
        rank_ge = n_null - idx
        new_p = float(max(rank_ge, 1) / n_null)
        out_rows.append({
            **h,
            "score_intergenic_bg": round(float(new_score), 4),
            "empirical_p_intergenic_null": new_p,
            "passes_p1e-4_intergenic_null": bool(new_p <= 1e-4),
        })

    with open(RESULTS / "intergenic_null.csv", "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(out_rows[0].keys()))
        writer.writeheader()
        writer.writerows(out_rows)

    n_survive = sum(1 for r in out_rows if r["passes_p1e-4_intergenic_null"])
    print(f"Of the original {len(out_rows)} HIGH_CONCERN hits (old whole-genome null, p<=1e-4):")
    print(f"  {n_survive}/{len(out_rows)} also pass p<=1e-4 under the NEW intergenic null")
    print(f"Wrote {len(out_rows)} rescored rows to results/intergenic_null.csv")

    # is the observed survivor count distinguishable from the chance expectation? (Task 3 support)
    p_vs_analytical = float(stats.poisson.sf(n_survive - 1, expected_analytical))
    p_vs_simulation = float(stats.poisson.sf(n_survive - 1, expected_simulation))
    print(f"\nPoisson tail test, observed={n_survive} vs expected-by-chance:")
    print(f"  P(X>={n_survive} | lambda={expected_analytical:.2f} [analytical]) = {p_vs_analytical:.4f}")
    print(f"  P(X>={n_survive} | lambda={expected_simulation:.2f} [simulation]) = {p_vs_simulation:.4f}")

    # update hits_high_concern.csv with additional columns, preserving originals
    hc_all_fields = list(hc_hits[0].keys())
    updated_fields = hc_all_fields + ["score_intergenic_bg", "empirical_p_intergenic_null", "passes_p1e-4_intergenic_null"]
    with open(RESULTS / "hits_high_concern.csv", "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=updated_fields)
        writer.writeheader()
        for h, extra in zip(hc_hits, out_rows):
            row = dict(h)
            row["score_intergenic_bg"] = extra["score_intergenic_bg"]
            row["empirical_p_intergenic_null"] = extra["empirical_p_intergenic_null"]
            row["passes_p1e-4_intergenic_null"] = extra["passes_p1e-4_intergenic_null"]
            writer.writerow(row)
    print("Updated results/hits_high_concern.csv with 3 additional columns (original columns unchanged).")

    # what happens to the 9 hits previously described as "as extreme as confirmed E. coli sites" (old null p<=1e-6)?
    nine = [r for r in out_rows if float(r["empirical_p"]) <= 1e-6]
    print(f"\nOf the 9 hits previously at old-null p<=1e-6:")
    for r in sorted(nine, key=lambda r: float(r["empirical_p"])):
        print(f"  {r['start']}-{r['end']} {r['strand']} {r.get('nearest_gene_name') or r['nearest_gene_locus_tag']}: "
              f"old_p={float(r['empirical_p']):.2e} -> new_score={r['score_intergenic_bg']} new_p={r['empirical_p_intergenic_null']:.4g} "
              f"passes={r['passes_p1e-4_intergenic_null']}")

    summary = {
        "total_ig_bp": total_ig_bp, "genome_len": L, "ig_fraction": total_ig_bp / L,
        "ig_bg": ig_bg, "genome_bg": genome_bg, "ig_gc": ig_gc, "genome_gc": genome_gc,
        "ig_at": ig_at, "genome_at": genome_at,
        "pwm_ig_total_ic": pwm_ig["total_ic"], "pwm_ig_n_sites": pwm_ig["n_sites"], "pwm_ig_width": pwm_ig["width"],
        "n_intergenic_segments": len(segments), "n_cds_intervals": len(cds_intervals),
        "null_pool_size": int(n_null), "score_thresh_p1e-4": float(score_thresh),
        "real_hc_eligible_windows": int(real_hc_eligible_windows),
        "expected_by_chance_analytical": float(expected_analytical),
        "expected_by_chance_simulation": float(expected_simulation),
        "n_survive_intergenic_p1e-4": int(n_survive), "n_original_hc": len(out_rows),
        "poisson_p_vs_analytical": p_vs_analytical, "poisson_p_vs_simulation": p_vs_simulation,
        "nine_old_p1e-6_now": [
            {"start": r["start"], "gene": r.get("nearest_gene_name") or r["nearest_gene_locus_tag"],
             "old_p": float(r["empirical_p"]), "new_score": r["score_intergenic_bg"],
             "new_p": r["empirical_p_intergenic_null"], "passes": r["passes_p1e-4_intergenic_null"]}
            for r in sorted(nine, key=lambda r: float(r["empirical_p"]))
        ],
    }
    (DATA / "cache" / "intergenic_null_summary.json").write_text(json.dumps(summary, indent=1))
    print("\nSummary stats written to data/cache/intergenic_null_summary.json")


if __name__ == "__main__":
    main()
