"""Fetch step for the operator-motif scan (separate from the cross-talk
analysis's fetch_sequences.py). Fetches, and caches to data/cache/:
  - BX927147.1 genome FASTA (C. glutamicum ATCC 13032) -- the feature table
    for this accession was already cached by the earlier cross-talk analysis
    and is reused as-is here, not re-fetched.
  - NC_000913.3 genome FASTA + feature table (E. coli K-12 MG1655) -- needed
    fresh for the Task 5 positive control.
  - Ec_PhoP and Ec_OmpR regulon data from RegulonDB (GraphQL API), the source of
    every binding site used in this analysis.

Idempotent: skips any file that is already cached.
"""
import ssl
import subprocess
import sys
import urllib.request
from pathlib import Path

import certifi

# See scripts/fetch_sequences.py for why this is needed on some macOS python.org builds.
_SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
urllib.request.install_opener(urllib.request.build_opener(urllib.request.HTTPSHandler(context=_SSL_CONTEXT)))

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
CACHE = DATA / "cache"

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
GRAPHQL = "https://regulondb.ccg.unam.mx/graphql"


def fetch(url: str, out: Path, timeout: int = 90):
    if out.exists():
        print(f"  [cached] {out.name}")
        return
    print(f"  fetching {out.name} ...")
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        data = resp.read()
    out.write_bytes(data)


def fetch_regulondb(tf_name: str, out: Path, timeout: int = 30):
    if out.exists():
        print(f"  [cached] {out.name}")
        return
    query = (
        'query { getRegulonBy(search: "%s", limit: 50, page: 0) { data { '
        "regulator { name abbreviatedName } regulatoryInteractions { "
        "regulatedEntity { name type } function distanceToFirstGene distanceToPromoter "
        "regulatoryBindingSites { sequence strand leftEndPosition rightEndPosition } "
        "citations { publication { pmid title year } } } } "
        "pagination { totalResults } } }" % tf_name
    )
    import json
    req = urllib.request.Request(
        GRAPHQL, data=json.dumps({"query": query}).encode(),
        headers={"Content-Type": "application/json"}, method="POST",
    )
    print(f"  fetching {tf_name} regulon from RegulonDB GraphQL API ...")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        out.write_bytes(resp.read())


def main():
    CACHE.mkdir(parents=True, exist_ok=True)
    (CACHE / "regulondb").mkdir(exist_ok=True)

    print("=== C. glutamicum genome FASTA (BX927147.1) ===")
    fetch(f"{EUTILS}?db=nuccore&id=BX927147&rettype=fasta&retmode=text", CACHE / "BX927147.fasta")
    ft = CACHE / "BX927147.ft.txt"
    if ft.exists():
        print(f"  [reused from earlier cross-talk analysis] {ft.name}")
    else:
        print("  WARNING: BX927147.ft.txt not found -- fetching fresh (expected to already be cached)")
        fetch(f"{EUTILS}?db=nuccore&id=BX927147&rettype=ft&retmode=text", ft)

    print("=== E. coli K-12 MG1655 genome + annotation (NC_000913.3) -- positive control ===")
    fetch(f"{EUTILS}?db=nuccore&id=NC_000913.3&rettype=fasta&retmode=text", CACHE / "NC_000913.fasta")
    fetch(f"{EUTILS}?db=nuccore&id=NC_000913.3&rettype=ft&retmode=text", CACHE / "NC_000913.ft.txt")

    print("=== RegulonDB: Ec_PhoP and Ec_OmpR confirmed binding sites ===")
    fetch_regulondb("PhoP", CACHE / "regulondb" / "phop_ecoli_regulon.json")
    fetch_regulondb("Ec_OmpR", CACHE / "regulondb" / "ompr_ecoli_regulon.json")

    print("\nAll inputs present.")


if __name__ == "__main__":
    main()
