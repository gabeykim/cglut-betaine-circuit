"""SigA -35 / extended -10 consensus scoring for C. glutamicum promoters.

[INFERENCE, reasoning named]: this is NOT an empirically-trained PWM like the
Sal_PhoP matrix built earlier in this project. It is built directly from the
textual IUPAC consensus reported by Patek & Nesvera 2011 (J Biotechnol,
PMID 21277915) and Pfeifer-Sancar et al. 2013 (BMC Genomics 14:888), as
given in this task's brief:
    extended -10: t g n g n T A (c/t) a a T g g   (13 nt; uppercase = highly
                  conserved, lowercase = weakly conserved but has a preferred
                  base, n = no preference)
    -35:          t t g n c a                      (6 nt; much less conserved
                  than the extended -10 -- explicitly stated in the source)
Patek & Nesvera 2011's full text was attempted (no PMC id; ScienceDirect
returned 403 to a direct fetch) -- the consensus is used exactly as given in
the task brief, cited to that source, rather than re-derived. A genuinely
site-derived PWM would need a table of many individually mapped, confirmed
C. glutamicum SigA promoters with sequence-level alignments; no such
extractable table was found in the sources checked for this project (see
designs/REPORT_promoter.md). This scoring matrix is therefore a reasoned
approximation, used consistently for both element-mapping (Task 2) and the
spurious-internal-promoter scan (Task 4), and is flagged as such everywhere
it is used.

Each conservation tier is converted to a simple probability profile, then to
a log2-odds matrix against a uniform 25%-per-base background (not the
genome's 53.8% GC background used for the Sal_PhoP PWM -- SigA recognition itself
is not obviously GC-biased the way an AT-rich response-regulator box is, and
the task gives no basis for a non-uniform background here; this choice is
stated explicitly rather than silently assumed).
"""
import math

BASES = ["A", "C", "G", "T"]

# consensus strings: uppercase = highly conserved, lowercase = weakly
# conserved-with-preference, 'n' = fully degenerate, 'y' = pyrimidine (C or T)
EXT10_CONSENSUS = "tgngnTAyaaTgg"   # 13 nt
MINUS35_CONSENSUS = "ttgnca"        # 6 nt

HIGH_CONS_MAIN = 0.85   # probability mass on the consensus base at an UPPERCASE position
LOW_CONS_MAIN = 0.40    # probability mass on the consensus base at a lowercase position
Y_MAIN_EACH = 0.425     # split between C and T at a 'y' (pyrimidine) position, high-conservation tier


def _position_profile(symbol: str) -> dict:
    if symbol == "n":
        return {b: 0.25 for b in BASES}
    if symbol == "y":
        return {"C": Y_MAIN_EACH, "T": Y_MAIN_EACH, "A": (1 - 2 * Y_MAIN_EACH) / 2, "G": (1 - 2 * Y_MAIN_EACH) / 2}
    upper = symbol.isupper()
    base = symbol.upper()
    main = HIGH_CONS_MAIN if upper else LOW_CONS_MAIN
    rest = (1 - main) / 3
    return {b: (main if b == base else rest) for b in BASES}


def build_consensus_pwm(consensus: str, background: dict = None):
    background = background or {b: 0.25 for b in BASES}
    profiles = [_position_profile(s) for s in consensus]
    log_odds = [{b: math.log2(p[b] / background[b]) for b in BASES} for p in profiles]
    ic_per_pos = [sum(p[b] * lo[b] for b in BASES) for p, lo in zip(profiles, log_odds)]
    return {
        "width": len(consensus), "consensus": consensus, "log_odds": log_odds,
        "ic_per_pos": ic_per_pos, "total_ic": sum(ic_per_pos), "background": background,
    }


def score_window(seq: str, pwm: dict) -> float:
    seq = seq.upper()
    return sum(pwm["log_odds"][i].get(ch, -10.0) for i, ch in enumerate(seq))


def max_score(pwm: dict) -> float:
    return sum(max(row.values()) for row in pwm["log_odds"])


def best_hit(seq: str, pwm: dict):
    """Best-scoring ungapped window for this PWM anywhere in seq. Returns (start0based, score)."""
    w = pwm["width"]
    seq = seq.upper()
    best = None
    for i in range(len(seq) - w + 1):
        s = score_window(seq[i:i + w], pwm)
        if best is None or s > best[1]:
            best = (i, s)
    return best


EXT10_PWM = build_consensus_pwm(EXT10_CONSENSUS)
MINUS35_PWM = build_consensus_pwm(MINUS35_CONSENSUS)


if __name__ == "__main__":
    print("Extended -10 consensus PWM:")
    print(f"  consensus: {EXT10_CONSENSUS}  width={EXT10_PWM['width']}  total_IC={EXT10_PWM['total_ic']:.2f} bits  "
          f"max_score={max_score(EXT10_PWM):.2f}")
    print("-35 consensus PWM:")
    print(f"  consensus: {MINUS35_CONSENSUS}  width={MINUS35_PWM['width']}  total_IC={MINUS35_PWM['total_ic']:.2f} bits  "
          f"max_score={max_score(MINUS35_PWM):.2f}")

    # self-test: the consensus sequence itself must score at (or extremely near) the max
    # ('n' positions score identically for any base -- substitute a concrete base so the
    # test string is valid ACGT; 'y' -> T, one of its two equally-weighted options)
    test = EXT10_CONSENSUS.upper().replace("Y", "T").replace("N", "A")
    s = score_window(test, EXT10_PWM)
    print(f"\nself-test: exact-consensus extended-10 ({test}) scores {s:.2f} vs max {max_score(EXT10_PWM):.2f}")
    assert abs(s - max_score(EXT10_PWM)) < 1e-6
    test35 = MINUS35_CONSENSUS.upper().replace("N", "A")
    s35 = score_window(test35, MINUS35_PWM)
    print(f"self-test: exact-consensus -35 ({test35}) scores {s35:.2f} vs max {max_score(MINUS35_PWM):.2f}")
    assert abs(s35 - max_score(MINUS35_PWM)) < 1e-6
    print("PASS")
