"""Altschul-Erikson (1985) dinucleotide-preserving shuffle.

Standard mononucleotide (Fisher-Yates) shuffling only preserves single-base
composition; it destroys dinucleotide structure, which understates the null
for motifs (like a GTTTA-repeat direct repeat) whose scoring is sensitive to
adjacent-base correlations. This implementation preserves the exact
dinucleotide (and therefore mononucleotide) count spectrum of the input
sequence, and the first and last symbols.

Algorithm: build, for each symbol c, the ordered list of symbols that follow
each occurrence of c in the original sequence (an edge list per node of the
de Bruijn-style transition graph). For every symbol except the last symbol of
the whole sequence, shuffle all but the LAST edge out of that symbol,
keeping that last edge fixed in place; this guarantees the shuffled edge
multiset still admits an Eulerian path ending at the original last symbol.
Reconstruct the shuffled sequence by walking the graph from the original
first symbol, consuming each node's outgoing edges in the (now shuffled)
order.
"""
import random
from pathlib import Path

from Bio import SeqIO


def dinuc_shuffle(seq: str, seed: int) -> str:
    rng = random.Random(seed)
    chars = seq
    n = len(chars)
    if n < 2:
        return seq

    edges = {}
    for i in range(n - 1):
        edges.setdefault(chars[i], []).append(chars[i + 1])

    # For every node, the LAST outgoing edge (in the shuffled order) must be
    # the same as the last outgoing edge in the original sequence -- this is
    # what guarantees the shuffled edge multiset still admits a walk from
    # chars[0] to chars[-1] that consumes every edge (no premature dead end).
    # Only the remaining edges of each node are free to permute.
    shuffled_edges = {}
    for c, lst in edges.items():
        if len(lst) > 1:
            fixed_last = lst[-1]
            rest = lst[:-1]
            rng.shuffle(rest)
            shuffled_edges[c] = rest + [fixed_last]
        else:
            shuffled_edges[c] = lst[:]

    pointers = {c: 0 for c in shuffled_edges}
    out = [chars[0]]
    cur = chars[0]
    for _ in range(n - 1):
        nxt = shuffled_edges[cur][pointers[cur]]
        pointers[cur] += 1
        out.append(nxt)
        cur = nxt
    return "".join(out)


def dinuc_counts(seq: str) -> dict:
    counts = {}
    for i in range(len(seq) - 1):
        di = seq[i:i + 2]
        counts[di] = counts.get(di, 0) + 1
    return counts


def shuffle_fasta(in_path: Path, out_path: Path, seed: int = 1337, force: bool = False):
    if out_path.exists() and not force:
        return out_path
    rec = next(SeqIO.parse(in_path, "fasta"))
    seq = str(rec.seq).upper()
    shuffled = dinuc_shuffle(seq, seed=seed)
    with open(out_path, "w") as fh:
        fh.write(f">{rec.id}_dinucshuffled_seed{seed}\n")
        for i in range(0, len(shuffled), 70):
            fh.write(shuffled[i:i + 70] + "\n")
    return out_path


if __name__ == "__main__":
    import sys
    # self-test: verify exact dinucleotide-count preservation on a random sequence
    rng = random.Random(0)
    test_seq = "".join(rng.choice("ACGT") for _ in range(20000))
    shuffled = dinuc_shuffle(test_seq, seed=42)
    orig_counts = dinuc_counts(test_seq)
    shuf_counts = dinuc_counts(shuffled)
    assert orig_counts == shuf_counts, "DINUCLEOTIDE COMPOSITION NOT PRESERVED -- algorithm bug"
    assert test_seq[0] == shuffled[0] and test_seq[-1] == shuffled[-1]
    assert sorted(test_seq) == sorted(shuffled), "mononucleotide composition changed"
    print("Self-test passed: dinucleotide counts, mononucleotide counts, first/last symbol all preserved exactly.")
    print(f"  original length {len(test_seq)}, {len(orig_counts)} distinct dinucleotides, all counts identical.")
