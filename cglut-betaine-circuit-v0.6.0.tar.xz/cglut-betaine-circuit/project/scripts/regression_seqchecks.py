"""Regression analysis for the seqchecks refactor.

Compares every panel output BEFORE and AFTER the refactor and decides, per
difference, whether it is a NEW FIND (an enzyme the old narrow list could not
see) or a REGRESSION (anything else). The rule is deliberately strict:

    new_sites must be a SUPERSET of old_sites          -- nothing may disappear
    every added site must name an enzyme OUTSIDE the old list  -- nothing may
                                                          change for an enzyme
                                                          that was already screened
    every sequence must be byte-identical               -- a refactor of the
                                                          checks must not touch
                                                          the designs

Usage:  python3 scripts/regression_seqchecks.py <before_dir> <after_dir>
"""
import csv, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import CATALOGUE

# Built from the catalogue's ACTUAL names, never from a shape heuristic. An earlier
# version of this file used r"[A-Za-z][A-Za-z0-9]*I+[a-zA-Z]*" and silently dropped
# EcoRV -- the one catalogue name with no "I" in it -- which would have hidden an
# EcoRV regression completely. A tool that decides what counts as a finding must not
# guess at the vocabulary it is parsing.
SITE_RE = re.compile(r"\b(" + "|".join(sorted(CATALOGUE, key=len, reverse=True))
                     + r")@(\d+)\(([+-])\)")

# the enzyme list each script used BEFORE the refactor, read off the git-free snapshot
OLD_LISTS = {
    "design_checks.csv": ["BsaI", "BsmBI", "BbsI", "EcoRI", "BamHI", "HindIII", "NcoI", "NdeI",
                          "XbaI", "SalI", "PstI", "KpnI", "SacI"],
    "translational_variants.csv": ["BsaI", "BsmBI", "BbsI", "EcoRI", "BamHI", "HindIII", "NcoI",
                                   "NdeI", "XbaI", "SalI", "PstI", "KpnI", "SacI"],
    "order_manifest.csv": ["BsaI", "BsmBI", "BbsI", "NcoI", "NdeI", "KpnI", "SacI", "EcoRI",
                           "NsiI", "SphI", "PstI", "SalI", "XbaI", "BamHI", "HindIII"],
    "order_manifest_checks.csv": ["BsaI", "BsmBI", "BbsI", "NcoI", "NdeI", "KpnI", "SacI", "EcoRI",
                                  "NsiI", "SphI", "PstI", "SalI", "XbaI", "BamHI", "HindIII"],
    "order_manifest_v2.csv": None,          # filled in at run time from the derived working list
    "order_manifest_v2_checks.csv": None,
}
SEQ_COLS = ("full_sequence", "sequence", "seq")
KEY_COLS = ("construct_id", "name", "variant", "design_id")


def rows(p):
    with open(p) as fh:
        return list(csv.DictReader(fh))


def key_of(r):
    for k in KEY_COLS:
        if k in r:
            return r[k]
    return str(sorted(r.items())[:1])


def sites_of(r):
    """Every Name@pos(strand) token anywhere in the row, as a set."""
    return {(m.group(1), int(m.group(2)), m.group(3))
            for v in r.values() for m in SITE_RE.finditer(v or "")}


def analyse(before_dir, after_dir, old_list_override=None):
    verdicts = []
    for name, old_list in OLD_LISTS.items():
        b, a = Path(before_dir) / name, Path(after_dir) / name
        if not (b.exists() and a.exists()):
            continue
        if old_list is None:
            old_list = old_list_override or []
        old_set = set(old_list)
        rb, ra = {key_of(r): r for r in rows(b)}, {key_of(r): r for r in rows(a)}
        v = {"file": name, "rows_before": len(rb), "rows_after": len(ra),
             "row_keys_identical": set(rb) == set(ra),
             "seq_identical": True, "seq_changed": [],
             "sites_added": [], "sites_removed": [], "other_field_changes": []}
        for k in sorted(set(rb) & set(ra)):
            x, y = rb[k], ra[k]
            for c in SEQ_COLS:
                if c in x and (x.get(c) or "") != (y.get(c) or ""):
                    v["seq_identical"] = False
                    v["seq_changed"].append(k)
            sb, sa = sites_of(x), sites_of(y)
            for s in sorted(sa - sb):
                v["sites_added"].append((k, s))
            for s in sorted(sb - sa):
                v["sites_removed"].append((k, s))
            # any non-sequence, non-site-token field that changed
            for c in set(x) | set(y):
                if c in SEQ_COLS:
                    continue
                bx, by = x.get(c) or "", y.get(c) or ""
                if bx != by and SITE_RE.sub("", bx).strip(" ;,|") != SITE_RE.sub("", by).strip(" ;,|"):
                    v["other_field_changes"].append((k, c, bx[:60], by[:60]))
        v["added_enzymes"] = sorted({s[0] for _k, s in v["sites_added"]})
        v["added_inside_old_list"] = sorted({e for e in v["added_enzymes"] if e in old_set})
        v["removed_enzymes"] = sorted({s[0] for _k, s in v["sites_removed"]})
        v["old_list_size"] = len(old_set)
        v["verdict"] = ("REGRESSION" if (v["sites_removed"] or v["added_inside_old_list"]
                                         or not v["seq_identical"] or not v["row_keys_identical"])
                        else ("NEW FIND" if v["sites_added"] else "UNCHANGED"))
        verdicts.append(v)
    return verdicts


def main():
    before, after = sys.argv[1], sys.argv[2]
    vs = analyse(before, after)
    print("=" * 78)
    print("REFACTOR REGRESSION ANALYSIS")
    print("=" * 78)
    bad = 0
    for v in vs:
        print(f"\n  {v['file']}   [{v['verdict']}]")
        print(f"    rows {v['rows_before']} -> {v['rows_after']}, same keys: {v['row_keys_identical']}")
        print(f"    sequences byte-identical: {v['seq_identical']}"
              + ("" if v["seq_identical"] else f"  CHANGED: {v['seq_changed'][:5]}"))
        print(f"    old list {v['old_list_size']} enzymes -> shared catalogue {len(CATALOGUE)}")
        print(f"    sites added: {len(v['sites_added'])}  enzymes: {v['added_enzymes']}")
        print(f"    sites removed: {len(v['sites_removed'])}  enzymes: {v['removed_enzymes']}")
        print(f"    added for an enzyme ALREADY in the old list (would be a bug): "
              f"{v['added_inside_old_list'] or 'none'}")
        if v["other_field_changes"]:
            print(f"    non-site field changes: {len(v['other_field_changes'])}")
            for c in v["other_field_changes"][:4]:
                print(f"       {c}")
        if v["verdict"] == "REGRESSION":
            bad += 1
    print(f"\n  {len(vs)} files compared, {bad} regressions")
    return bad


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
