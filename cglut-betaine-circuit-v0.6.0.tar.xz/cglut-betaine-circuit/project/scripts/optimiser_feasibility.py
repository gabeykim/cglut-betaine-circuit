"""TASK 1: is a 35-enzyme constraint set SATISFIABLE for the kinase panel?

Method, and why it is exhaustive rather than greedy. For every catalogue site
present in the current sequences, enumerate EVERY combination of synonymous
codons across every codon the site overlaps, and ask whether any combination
removes the site without creating another inside the affected window. If no
combination works, the site is PROTEIN-ENCODED: it is forced by the amino-acid
sequence and no codon optimiser of any design can remove it. That is the only
kind of position for which a fallback policy is needed.

A site can only be protein-encoded when every nucleotide it occupies sits on a
position the genetic code does not let us vary -- Met/Trp codons (one option),
or the first two bases of a 4-fold degenerate family.
"""
import csv, json, re, sys
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import CATALOGUE, GOLDEN_GATE, site_scan, revcomp, positive_control_check

MAXSITE = max(len(s) for s in CATALOGUE.values())          # 8 (NotI)
CODON = {}
def _mk():
    t = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
    for i, (a, b, c) in enumerate(product("TCAG", repeat=3)):
        CODON[a+b+c] = t[i]
_mk()
translate = lambda d: "".join(CODON[d[i:i+3]] for i in range(0, len(d)-2, 3))


def codon_table():
    tbl = json.loads((ROOT / "data" / "cache" / "codon" / "cglut_codon_usage.json").read_text())["table"]
    return {aa: {c: v["rel_freq"] for c, v in t.items()} for aa, t in tbl.items()}


def read_fasta(p):
    o, k, b = {}, None, []
    for line in open(p):
        line = line.strip()
        if line.startswith(">"):
            if k: o[k] = "".join(b)
            k, b = line[1:].split()[0], []
        elif line: b.append(line)
    if k: o[k] = "".join(b)
    return o


def sites_in_window(dna, lo, hi):
    """Catalogue sites overlapping [lo,hi) -- scan a padded window so nothing is missed."""
    a, b = max(0, lo - MAXSITE), min(len(dna), hi + MAXSITE)
    return [(h.enzyme, a + h.start, h.strand)
            for h in site_scan(dna[a:b]) if a + h.start < hi and a + h.end > lo]


def analyse_site(dna, protein, freq, start, end, min_rel=0.10):
    """Exhaustively test whether this site can be removed by synonymous change.

    Returns a dict describing the cheapest fix found, or marks it unfixable.
    """
    lo_c, hi_c = start // 3, (end - 1) // 3
    codons = [dna[i:i+3] for i in range(0, len(dna), 3)]
    idxs = list(range(lo_c, hi_c + 1))
    aas = [protein[i] for i in idxs]
    opts = [sorted(freq[a], key=lambda c: -freq[a][c]) for a in aas]
    n_combos = 1
    for o in opts:
        n_combos *= len(o)
    baseline = {(e, p, s) for e, p, s in sites_in_window(dna, start, end)}
    target = None
    best = None                       # (n_changed, below_floor, combo)
    for combo in product(*opts):
        if all(combo[k] == codons[idxs[k]] for k in range(len(idxs))):
            continue
        trial = list(codons)
        for k, ci in enumerate(idxs):
            trial[ci] = combo[k]
        t = "".join(trial)
        now = {(e, p, s) for e, p, s in sites_in_window(t, start, end)}
        if now:                       # any catalogue site still overlapping the window
            continue
        n_changed = sum(1 for k, ci in enumerate(idxs) if combo[k] != codons[ci])
        below = [(aas[k], combo[k], round(freq[aas[k]][combo[k]], 4))
                 for k in range(len(idxs))
                 if combo[k] != codons[idxs[k]] and freq[aas[k]][combo[k]] < min_rel]
        key = (n_changed, len(below), -min(freq[aas[k]][combo[k]] for k in range(len(idxs))))
        if best is None or key < best[0]:
            best = (key, {"codons": idxs, "aas": aas,
                          "from": [codons[ci] for ci in idxs], "to": list(combo),
                          "n_codons_changed": n_changed, "below_floor": below})
    return {"fixable": best is not None, "n_combos_tested": n_combos,
            "fix": best[1] if best else None,
            "degeneracy": [len(o) for o in opts], "aas": aas, "codon_idxs": idxs}


def main():
    positive_control_check()
    freq = codon_table()
    v3 = read_fasta(ROOT / "designs" / "junctions_v3.fasta")
    rows = {r["design_id"]: r for r in csv.DictReader(open(ROOT / "designs" / "junctions_v3.csv"))}
    print("=" * 80)
    print("TASK 1  FEASIBILITY OF A 35-ENZYME CONSTRAINT SET")
    print("=" * 80)
    print(f"  positive controls: PASS   catalogue: {len(CATALOGUE)} enzymes, "
          f"longest site {MAXSITE} bp")

    unfix, fixes, per_site = [], [], []
    for did, dna in v3.items():
        prot = rows[did]["protein_seq"]
        assert translate(dna[:-3]) == prot, did
        seen = set()
        for h in site_scan(dna):
            key = (h.start, h.end)
            if key in seen:
                continue
            seen.add(key)
            a = analyse_site(dna, prot + "*", freq, h.start, h.end)
            rec = {"design_id": did, "enzyme": h.enzyme, "start": h.start, "end": h.end,
                   "aas": "".join(a["aas"]), "degeneracy": a["degeneracy"],
                   "fixable": a["fixable"], "fix": a["fix"]}
            per_site.append(rec)
            (fixes if a["fixable"] else unfix).append(rec)

    print(f"\n  physical sites examined                : {len(per_site)}")
    print(f"  removable by synonymous change         : {len(fixes)}")
    print(f"  PROTEIN-ENCODED (no synonymous escape) : {len(unfix)}")
    if unfix:
        print("\n  UNFIXABLE POSITIONS:")
        for r in unfix:
            print(f"    {r['design_id']:34} {r['enzyme']:7} @{r['start']:<5} residues {r['aas']} "
                  f"degeneracy {r['degeneracy']}")
    changed = Counter(r["fix"]["n_codons_changed"] for r in fixes)
    print(f"\n  codons changed per fix: {dict(sorted(changed.items()))}")
    floor = [r for r in fixes if r["fix"]["below_floor"]]
    print(f"  cheapest fix needs a codon below the 0.10 usage floor: {len(floor)} of {len(fixes)}")
    for r in floor[:10]:
        print(f"    {r['design_id']:34} {r['enzyme']:7} @{r['start']:<5} {r['fix']['below_floor']}")
    return per_site, fixes, unfix


if __name__ == "__main__":
    main()
