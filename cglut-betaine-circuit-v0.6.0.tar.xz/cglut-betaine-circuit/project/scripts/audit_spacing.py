"""Task 1: spacing-coverage audit of designs/variants.csv. Read-only; rebuilds nothing.

A spacing "sweep" is only interpretable if everything except spacing is held
constant, so contiguity is assessed WITHIN comparable series (same core
promoter, same operator identity, same copy number, same upstream mode)
rather than by pooling every variant on a core. Pooling would let, e.g., a
2x-operator variant at gap=5 fill a hole in a 1x series and make coverage
look better than it is.

No-operator controls are excluded from spacing analysis: their gap_bp field
is 0 by construction but means "no operator exists", not "operator at 0".

Helical-turn reference: B-DNA ~10.5 bp/turn.
"""
import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HELICAL_TURN_BP = 10.5


def longest_contiguous_run(sorted_vals):
    """Longest run of consecutive integers (step exactly 1). Returns the run as a list."""
    if not sorted_vals:
        return []
    best = cur = [sorted_vals[0]]
    for v in sorted_vals[1:]:
        if v == cur[-1] + 1:
            cur.append(v)
        else:
            cur = [v]
        if len(cur) > len(best):
            best = list(cur)
    return best


def main():
    rows = list(csv.DictReader(open(ROOT / "designs" / "variants.csv")))
    with_op = [r for r in rows if int(r["n_operators"]) > 0]
    print(f"{len(rows)} variants total; {len(with_op)} carry an operator "
          f"({len(rows) - len(with_op)} no-operator controls excluded from spacing analysis)\n")

    by_core = defaultdict(list)
    for r in with_op:
        by_core[r["core"]].append(r)

    for core in sorted(by_core, key=lambda c: -len(by_core[c])):
        rs = by_core[core]
        all_gaps = sorted({int(r["gap_bp"]) for r in rs})
        print("=" * 78)
        print(f"CORE PROMOTER: {core}   ({len(rs)} operator-bearing variants)")
        print("=" * 78)
        print(f"  Union of spacing values (all series pooled): {all_gaps}")
        if len(all_gaps) > 1:
            steps = [b - a for a, b in zip(all_gaps, all_gaps[1:])]
            print(f"  Steps between consecutive pooled values:    {steps}")
            print(f"  Pooled span (max - min):                    {all_gaps[-1] - all_gaps[0]} bp "
                  f"({len(all_gaps)} distinct values)")
        else:
            print(f"  Pooled span: 0 bp (single spacing value only)")

        # comparable series
        series = defaultdict(list)
        for r in rs:
            key = (r["operator_names"], r["n_operators"], r["upstream_mode"])
            series[key].append(int(r["gap_bp"]))

        print(f"\n  Comparable series (operator identity / copy number / upstream mode held constant):")
        core_best_run = []
        for key, gaps in sorted(series.items(), key=lambda kv: -len(kv[1])):
            g = sorted(set(gaps))
            run = longest_contiguous_run(g)
            if len(run) > len(core_best_run):
                core_best_run = run
            steps = [b - a for a, b in zip(g, g[1:])] if len(g) > 1 else []
            step_desc = "n/a (single value)" if not steps else (
                f"uniform {steps[0]}" if len(set(steps)) == 1 else f"irregular {steps}")
            span = (g[-1] - g[0]) if len(g) > 1 else 0
            print(f"    - {key[0]} x{key[1]} / {key[2]}")
            print(f"        values: {g}")
            print(f"        step: {step_desc}   span: {span} bp   n={len(g)}")
            print(f"        longest single-base contiguous run: {run} "
                  f"({len(run)} values, {run[-1]-run[0] if len(run)>1 else 0} bp span)")

        n_pos = len(core_best_run)
        span_bp = (core_best_run[-1] - core_best_run[0]) if len(core_best_run) > 1 else 0
        print(f"\n  --> BEST single-base contiguous sweep on {core}: {n_pos} consecutive values, "
              f"{span_bp} bp end-to-end span")
        print(f"      vs one helical turn ({HELICAL_TURN_BP} bp): "
              f"{'COVERS' if span_bp >= HELICAL_TURN_BP else 'DOES NOT COVER'} a full turn by end-to-end span "
              f"({span_bp}/{HELICAL_TURN_BP} = {span_bp/HELICAL_TURN_BP:.2f} turns)")
        print(f"      distinct helical phases sampled: {n_pos} "
              f"(consecutive 1-bp steps => {n_pos} distinct rotational positions)\n")

    # panel-level verdict
    print("=" * 78)
    print("PANEL-LEVEL VERDICT")
    print("=" * 78)
    verdicts = {}
    for core, rs in by_core.items():
        series = defaultdict(list)
        for r in rs:
            series[(r["operator_names"], r["n_operators"], r["upstream_mode"])].append(int(r["gap_bp"]))
        best = []
        for gaps in series.values():
            run = longest_contiguous_run(sorted(set(gaps)))
            if len(run) > len(best):
                best = run
        span = (best[-1] - best[0]) if len(best) > 1 else 0
        verdicts[core] = (len(best), span)
    for core, (n, span) in sorted(verdicts.items(), key=lambda kv: -kv[1][1]):
        print(f"  {core:6s}: {n} consecutive values, {span} bp span, "
              f"{span/HELICAL_TURN_BP:.2f} helical turns")
    any_full = any(span >= HELICAL_TURN_BP for _, span in verdicts.values())
    any_11_positions = any(n >= 11 for n, _ in verdicts.values())
    print(f"\n  Any core with >=11 bp end-to-end contiguous span?      {any_full}")
    print(f"  Any core with >=11 consecutive single-base positions?  {any_11_positions}")


if __name__ == "__main__":
    main()
