"""Generate REPORT_tier1_edits.md. Every table computed from the written data files."""
import csv, json, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
D = ROOT / "designs"
OUT = ROOT / "REPORT_tier1_edits.md"
if OUT.exists():
    sys.exit(f"REFUSING TO OVERWRITE {OUT}")

from seqchecks import site_scan, sigA_scan, sd_atg_scan, CATALOGUE, GOLDEN_GATE, VECTOR_SITES, positive_control_check
from calibration_constructs import reconstruct_spacer, PARTNERS
positive_control_check()

ed = list(csv.DictReader(open(D / "tier1_v2.csv")))
cal = list(csv.DictReader(open(D / "calibration_constructs.csv")))
m3 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v3.csv"))}
m4 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v4.csv"))}
c4 = list(csv.DictReader(open(D / "order_manifest_final_v4_checks.csv")))
s3 = list(csv.DictReader(open(D / "order_manifest_final_v3_sites.csv")))
s4 = list(csv.DictReader(open(D / "order_manifest_final_v4_sites.csv")))
mo4 = list(csv.DictReader(open(D / "order_manifest_final_v4_motifs.csv")))
sub4 = list(csv.DictReader(open(D / "order_submit_final_v4.csv")))
fa4 = sum(1 for l in open(D / "order_submit_final_v4.fasta") if l.startswith(">"))
vec = list(csv.DictReader(open(D / "vector_enzyme_constraints.csv")))
PSYN, SPACER, prov, primers = reconstruct_spacer()

L = []; w = L.append
esc = lambda x: str(x).replace("|", "\\|")
def table(h, rr):
    w("| " + " | ".join(esc(x) for x in h) + " |")
    w("|" + "|".join("---" for _ in h) + "|")
    for r in rr: w("| " + " | ".join(esc(x) for x in r) + " |")
    w("")

w("# Tier-1 panel edits: TSS spacer and calibration anchors")
w("")
w("Built by `scripts/tier1_edits.py` (Task 1), `scripts/calibration_constructs.py` (Task 2), "
  "`scripts/consolidate_v4.py` and `scripts/vector_enzyme_constraints.py` (Task 3). "
  "This report is generated from the written data files by `scripts/report_tier1_edits.py`.")
w("")
w("Tags: **[EVIDENCE]** computed here from cached data or stated by a citable source. "
  "**[INFERENCE]** reasoning from evidence, step named. **[NOT FOUND]** searched and absent.")
w("")
w("---")
w("")
w("## 0. LEAD")
w("")
w("### Did the TC insertion land the start codon on the predicted TSS in all 17?")
w("")
w(f"**Yes, in all {len(ed)}. [EVIDENCE]** Every edited construct now has its fore-cistron start "
  f"codon exactly **7 nt** downstream of Psyn's −10 hexamer — the modal −10→TSS spacing of the "
  f"2,522 mapped SigA promoters in the cached Pfeifer-Sancar Table S1 — giving a predicted 5′UTR "
  f"of **0 nt** in all {len(ed)}.")
w("")
table(["", "before", "after"],
      [["−10 hexamer → start codon (nt)", f"{ed[0]['d_to_start_before']} in all {len(ed)}",
        f"**{ed[0]['d_to_start_after']} in all {len(ed)}** (the modal spacing)"],
       ["predicted 5′UTR (nt)", f"{ed[0]['utr_before']} — start codon **off** the transcript",
        f"**+{ed[0]['utr_after']}** — start codon **on** the predicted +1"],
       ["P(leaderless), all-promoter prior",
        f"{min(float(r['P_leaderless_before_allprior']) for r in ed):.0%}–"
        f"{max(float(r['P_leaderless_before_allprior']) for r in ed):.0%}",
        f"**{min(float(r['P_leaderless_after_allprior']) for r in ed):.0%}–"
        f"{max(float(r['P_leaderless_after_allprior']) for r in ed):.0%}**"],
       ["P(leaderless), leaderless-stratum prior",
        f"{min(float(r['P_leaderless_before_ldlsprior']) for r in ed):.0%}–"
        f"{max(float(r['P_leaderless_before_ldlsprior']) for r in ed):.0%}",
        f"**{min(float(r['P_leaderless_after_ldlsprior']) for r in ed):.0%}–"
        f"{max(float(r['P_leaderless_after_ldlsprior']) for r in ed):.0%}**"]])
w("### Could the Henke spacer be reconstructed exactly?")
w("")
w(f"**Yes, exactly, with zero unsourced bases. [EVIDENCE]** All **{len(SPACER)} nt** were rebuilt "
  f"from the primer sequences printed in Henke Table 2 and extracted from the cached HTML — nt 0–27 "
  f"from the reverse complement of HA07 (`Psyn-rv`), nt 28–42 from HN49 (`gfpUV-fw`), with a "
  f"**{prov['gibson_overlap_nt']} nt Gibson homology arm attested independently by both primers**. "
  f"Nothing was written from memory and nothing was substituted.")
w("")
w("```")
w(f"{SPACER}")
w(f"{'^'*28}{'':15}  nt 0-27  : revcomp(HA07), Henke Table 2")
w(f"{'':28}{'^'*15}  nt 28-42 : HN49, Henke Table 2")
w(f"{'':26}{'^'*9}{'':8}  GAAAGGAGG: the C. glutamicum consensus RBS, named verbatim in Henke's Discussion")
w("```")
w("")
w("**One deviation, and it is a consequence of faithfulness rather than a substitution.** [EVIDENCE] "
  "Reproducing this architecture necessarily reproduces Henke's multiple cloning site, which carries "
  "`EcoRI`, `KpnI`, `SacI` and `SmaI`, and it creates an `NcoI` site at the Psyn|spacer junction "
  "(Psyn's terminal `C` + the spacer's `CATGG` = `CCATGG`). Those five enzymes were absent from all "
  "93 previous constructs. Removing them would mean not reproducing the architecture, which is the "
  "whole point of the anchors — so they are kept and pushed into the vector-constraint list in §3.3 "
  "instead.")
w("")
w("### Final construct count")
w("")
w(f"**{len(m4)}.** [EVIDENCE] 69 non-kinase (17 of them edited) + 24 kinase (unchanged) + 2 "
  f"calibration anchors. Verified by counting: manifest {len(m4)} rows · checks {len(c4)} rows · "
  f"submission CSV {len(sub4)} rows · submission FASTA {fa4} records. **Against the 48–96 CRO "
  f"envelope: 95 fits, with exactly 1 slot spare.**")
w("")
w("---")
w("")
w("## 1. Task 1 — the TC insertion")
w("")
w("### 1.1 Which constructs qualified, and why")
w("")
w(f"Identified from the component map (`order_manifest_final_v3_components.csv`), not a hardcoded "
  f"list: a construct qualifies if it carries **both** a `core:Psyn` component **and** a "
  f"`forecistron:` component. That is {len(ed)} constructs. [EVIDENCE]")
w("")
table(["panel", "constructs"],
      sorted(Counter(m4[r["construct_id"]]["panel"] for r in ed).items()) +
      [["**total**", f"**{len(ed)}**"]])
w("Two groups were examined and correctly excluded:")
w("")
table(["excluded", "why"],
      [["`V2-CX-18` and `V2-CX-19` (2 constructs)",
        "fore-cistron present but the core is **PsodA**, not Psyn. PsodA is a *measured* leadered "
        "promoter (mapped 5′UTRs of 15/26/92/94 nt) and these two are the panel's declared "
        "**leadered probe**; shifting their start codon would defeat their purpose. [EVIDENCE]"],
       ["all 24 kinase constructs",
        "none carries a fore-cistron component — verified against the component map. **No kinase "
        "construct changes, so `designs/junctions_v5.*` was not created.** [EVIDENCE]"]])
w("In all 17 the fore-cistron abuts Psyn's 3′ end directly (gap 0 nt), so the insertion point is "
  "identical in every one. Note that in 2 of the 17 the 'start codon' is deliberately not `ATG`: "
  "`V2-CX-15` carries the `fcATGtoATC` disabling mutation and `V2-CX-17` the `fcATGtoGTG` "
  "attenuating mutation. The insertion point is the same — immediately 5′ of the fore-cistron's "
  "first codon — and both were handled that way. [EVIDENCE]")
w("")
w("### 1.2 Why TC and not C or CC — verified, not taken on trust")
w("")
w("Every candidate insert was re-screened here against the shared module:")
w("")
scr = []
for ins in ("", "C", "CC", "T", "TC", "CT", "AC", "GC"):
    gained = Counter(); ncon = set()
    for r in ed:
        s = r["sequence_before"]; p = int(r["start_codon_idx_before"])
        nw = s[:p] + ins + s[p:]
        b = Counter(h.enzyme for h in site_scan(s)); a = Counter(h.enzyme for h in site_scan(nw))
        d = {e: a[e]-b.get(e, 0) for e in a if a[e] > b.get(e, 0)}
        if d: gained.update(d); ncon.add(r["construct_id"])
    j = ed[0]["sequence_before"][int(ed[0]["start_codon_idx_before"])-5:int(ed[0]["start_codon_idx_before"])] \
        + ins + ed[0]["sequence_before"][int(ed[0]["start_codon_idx_before"]):int(ed[0]["start_codon_idx_before"])+3]
    scr.append([f"`{ins}`" if ins else "**none (as built)**", f"`{j}`",
                int(ed[0]["d_to_start_before"]) + len(ins),
                len(ncon), ", ".join(f"{k}×{v}" for k, v in gained.items()) or "**none**"])
table(["insert", "junction (example)", "−10 → start codon (nt)", "constructs gaining a site",
       "new enzyme sites across the 17"], scr)
fcstart = Counter(r["sequence_before"][int(r["start_codon_idx_before"]):int(r["start_codon_idx_before"])+4]
                  for r in ed)
w(f"**Confirmed independently: `C` and `CC` create an `NcoI` site in exactly the "
  f"{fcstart['ATGG']} constructs whose fore-cistron begins `ATGG`** — `GGTTC` + `C` + `ATGG` spells "
  f"`CCATGG`. [EVIDENCE] `NcoI` is the pECXT99A opening enzyme and the site removed from the kinase "
  f"panel two sessions ago; re-introducing it here would have undone that work. `GC` introduces "
  f"`SphI` in one construct. **`TC` introduces nothing, in any of the 17**, and it also places a "
  f"`C` immediately 5′ of the start codon, giving the `CA` dinucleotide that is the most common "
  f"−1/+1 context among mapped TSSs.")
w("")
w("Fore-cistron start tetramers across the 17, which is what decides the `C`/`CC` trap:")
w("")
table(["fore-cistron begins", "constructs", "would `C`/`CC` create NcoI?"],
      [[f"`{k}`", v, "**yes**" if k == "ATGG" else "no"] for k, v in sorted(fcstart.items())])
w("### 1.3 The shift, construct by construct")
w("")
table(["construct", "start codon", "d before", "d after", "5′UTR before", "5′UTR after",
       "P(leaderless) before", "P(leaderless) after"],
      [[f"`{r['construct_id']}`", f"`{r['start_codon']}`", r["d_to_start_before"],
        f"**{r['d_to_start_after']}**", f"{int(r['utr_before']):+d}", f"**{int(r['utr_after']):+d}**",
        f"{float(r['P_leaderless_before_allprior']):.0%}",
        f"**{float(r['P_leaderless_after_allprior']):.0%}**"] for r in ed])
w(f"`V2-CX-17` reaches {max(float(r['P_leaderless_after_allprior']) for r in ed if r['start_codon']=='GTG'):.0%} "
  f"rather than 94% because its start codon is the deliberately attenuated `GTG`: the +1 base is "
  f"`G` rather than `A` and the −1/+1 dinucleotide is `CG` rather than `CA`, both of which the "
  f"empirical TSS model scores lower. [EVIDENCE] That is a property of the mutation the control "
  f"exists to test, not of the edit.")
w("")
w("### 1.4 Re-verification after insertion")
w("")
w("All 19 checks pass. [EVIDENCE, `scripts/tier1_edits.py`]")
w("")
newsites = {}
for r in ed:
    b = Counter(h.enzyme for h in site_scan(r["sequence_before"]))
    a = Counter(h.enzyme for h in site_scan(r["sequence_after"]))
    d = {e: a[e]-b.get(e, 0) for e in a if a[e] > b.get(e, 0)}
    if d: newsites[r["construct_id"]] = d
table(["check", "result"],
      [["NcoI anywhere in the 17", f"**{sum(1 for r in ed for h in site_scan(r['sequence_after']) if h.enzyme=='NcoI')}**"],
       ["new sites of any of the 35 catalogue enzymes", f"**{len(newsites)}**"],
       ["Golden Gate sites, both strands",
        f"**{sum(len(site_scan(r['sequence_after'], enzymes=GOLDEN_GATE)) for r in ed)}**"],
       ["vector-opening sites (NcoI/NdeI)",
        f"**{sum(len(site_scan(r['sequence_after'], enzymes=VECTOR_SITES)) for r in ed)}**"],
       ["new SigA ext-10 windows (either strand)", "**0**"],
       ["new SD+ATG", "**0**"],
       ["junction-spanning SigA or SD in any edited construct", "**0**"],
       ["TAATG coupling frame intact", f"**all 17** still end in `TA`, exactly 75 nt after the "
        f"start codon"],
       ["homopolymer runs > 6", "**0**"],
       ["bases changed other than the inserted `TC`", "**0**"]])
w("---")
w("")
w("## 2. Task 2 — the calibration anchors")
w("")
w("### 2.1 Reconstructing Henke's spacer")
w("")
w("The reconstruction is a derivation, not a transcription. [EVIDENCE, `scripts/calibration_constructs.py`]")
w("")
table(["step", "what was done", "check"],
      [["1", "extract primers HA06/HA07/HN49 and the Psyn sequence verbatim from the cached "
        "`pmc7835838.html`", "HA06 ends with `Psyn[0:26]` — asserted"],
       ["2", "build the promoter amplicon by merging HA06+Psyn with revcomp(HA07)",
        f"{prov['amplicon_overlap_nt']} nt overlap, unique"],
       ["3", "splice in gfpUV via HN49's 5′ homology arm, as the paper's Gibson assembly does",
        f"{prov['gibson_overlap_nt']} nt arm, found once in the amplicon"],
       ["4", "read off the sequence between Psyn's 3′ end and the gfpUV start codon",
        f"{len(SPACER)} nt"]])
table(["region", "length", "source", "tag"],
      [["`CATGGAATTCGAGCTCGGTACCCGGGGA`", "28 nt", "reverse complement of primer HA07 (`Psyn-rv`), "
        "Henke Table 2", "[EVIDENCE]"],
       ["`AAGGAGGCCCTTCAG`", "15 nt", "primer HN49 (`gfpUV-fw`), Henke Table 2", "[EVIDENCE]"],
       ["*of which* the 27 nt Gibson arm", "27 nt", "attested by **both** primers independently",
        "[EVIDENCE]"],
       ["**unsourced**", "**0 nt**", "—", "[EVIDENCE]"]])
w(f"The RBS `GAAAGGAGG` sits at spacer offset {prov['rbs_offset']}, {prov['rbs_to_atg_nt']} nt from "
  f"the reporter start codon. Henke's Discussion names that exact string as the *\"consensus "
  f"C. glutamicum\"* ribosome binding site, which is independent confirmation that the "
  f"reconstruction landed on the intended element rather than on an artefact of the primer merge. "
  f"[EVIDENCE]")
w("")
w("### 2.2 The pair, and the controlled difference")
w("")
table(["construct", "length", "GC", "partner already in the panel", "differs from its partner by",
       "differs from the other anchor by"],
      [[f"`{r['construct_id']}`", f"{r['length_bp']} bp", f"{r['GC_percent']}%",
        f"`{r['partner_construct']}`", "the 43 nt Henke spacer, appended — nothing else",
        "the operator" ] for r in cal])
w("**Rationale for this pair rather than two replicates.** [INFERENCE, reasoning named] Each anchor "
  "is an exact 1:1 partner of a construct already in the panel, differing *only* by the Henke "
  "spacer, so each on its own isolates the architecture change — leaderless MCD versus RBS-leadered "
  "— against a construct that is already being measured. `CAL-01` has no operator and is therefore "
  "the closest reproduction of Henke's own construct, making it the direct anchor to the published "
  "286%. `CAL-02` places the operator at gap 3, the panel's cross-core reference position, so the "
  "pair additionally reports what the operator does inside the Henke architecture. The controlled "
  "difference between the two anchors is the operator alone.")
w("")
w("### 2.3 What the anchors cost")
w("")
calsites = [x for x in s4 if x["construct_id"].startswith("CAL-")]
table(["", "value"],
      [["enzyme sites added to the ordered set", f"**{len(calsites)}** "
        f"({', '.join(f'{k}×{v}' for k, v in Counter(x['enzyme'] for x in calsites).most_common())})"],
       ["of which junction-created at the Psyn|spacer boundary", "`NcoI` ×4 — Psyn's terminal `C` "
        "meeting the spacer's `CATGG`"],
       ["Golden Gate sites added", "**0**"],
       ["spurious SD+ATG added", "**0**"],
       ["constructs added", "2"],
       ["bp added", f"{sum(int(r['length_bp']) for r in cal)}"]])
w("**These five enzymes were absent from all 93 previous constructs, and they are the anchors' "
  "entire footprint on the vector decision.** [EVIDENCE] They are not a defect: they are Henke's "
  "multiple cloning site, and reproducing it is the point. §3.3 carries them into the constraint "
  "list rather than removing them.")
w("")
w("---")
w("")
w("## 3. Task 3 — rebuild and re-check")
w("")
w("### 3.1 Count")
w("")
table(["source", "constructs"],
      [["non-kinase tier-1 / combinatorial (`order_manifest_v2.csv`), 17 of them edited", 69],
       ["kinase (`junctions_v4`), unchanged — none carries a fore-cistron", 24],
       ["calibration anchors (`calibration_constructs.csv`)", 2],
       ["**total**", f"**{len(m4)}**"]])
w(f"Verified by counting rows and records, not assumed: manifest **{len(m4)}**, checks **{len(c4)}**, "
  f"submission CSV **{len(sub4)}**, submission FASTA **{fa4}**. Expected 95 — **MATCH**. [EVIDENCE] "
  f"Construct ids are the 93 previous ones plus `CAL-01` and `CAL-02`; total length "
  f"{sum(int(r['length_bp']) for r in m4.values()):,} bp "
  f"(+{sum(int(r['length_bp']) for r in m4.values())-sum(int(r['length_bp']) for r in m3.values())} "
  f"= 17×2 nt of TC spacer + 2 anchors).")
w("")
rows = []
for p, n in sorted(Counter(r["panel"] for r in m4.values()).items()):
    ls = [int(r["length_bp"]) for r in m4.values() if r["panel"] == p]
    rows.append([f"`{p}`", n, f"{min(ls)}–{max(ls)}", sum(ls)])
rows.append(["**TOTAL**", f"**{len(m4)}**", "", f"**{sum(int(r['length_bp']) for r in m4.values()):,}**"])
table(["panel", "constructs", "length range (bp)", "total bp"], rows)
w("**CRO envelope 48–96: 95 fits, with exactly 1 slot spare.** [EVIDENCE] There is no room for a "
  "third calibration construct or any further addition without a cut.")
w("")
w("### 3.2 Full shared-module check across all 95")
w("")
sig = [x for x in mo4 if x["motif"] == "SigA_ext10"]
sd = [x for x in mo4 if x["motif"] == "SD+ATG"]
table(["check", "result across all 95"],
      [["Golden Gate sites (BsaI/BsmBI/BbsI/SapI/AarI), both strands",
        f"**{len([x for x in s4 if x['enzyme'] in GOLDEN_GATE])}**"],
       ["all 35 catalogue enzymes, both strands",
        f"{len(s4)} sites on {len({x['construct_id'] for x in s4})} constructs"],
       ["sites spanning a component junction",
        f"{sum(1 for x in s4 if x['spans_component_junction']=='YES')}"],
       ["identical sequences", len(sub4)-len({r['full_sequence'] for r in sub4})],
       ["homopolymer runs > 6", sum(1 for c in c4 if c["homopolymer_gt6"] != "none")],
       ["SigA ext-10 windows ≥0.55 of max",
        f"{len(sig)} ({sum(1 for x in sig if x['spans_component_junction']=='YES')} junction-spanning)"],
       ["spurious SD+ATG",
        f"{len(sd)} ({sum(1 for x in sd if x['spans_component_junction']=='YES')} junction-spanning)"],
       ["components with unresolved provenance", "**0**"],
       ["constructs under 125 bp", sum(1 for c in c4 if c["under_vendor_min_125bp"] == "YES")],
       ["GC outliers (±15 pts of 53.84%)", sum(1 for c in c4 if c["gc_flag"])]])
w("The one junction-spanning SigA window is the pre-existing antisense hit in "
  "`JXN_MCPX_PHOQ_dhp_direct_m1` at 0.722 of matrix max, unmoved and already shown not to exceed "
  "what its own sensor component carries. The 6 SD+ATG hits are the pre-existing internal ones in "
  "the codon-optimised `P0DM80` acceptor. **Neither the TC insertion nor the anchors added any "
  "motif.** [EVIDENCE]")
w("")
w("### 3.3 Remaining catalogue sites, and the vector constraint list")
w("")
a3, a4c = Counter(x["enzyme"] for x in s3), Counter(x["enzyme"] for x in s4)
table(["enzyme", "sites at 93", "sites at 95", "carried by", "sourced or designed", "removable?"],
      [[f"`{e}`", a3.get(e, 0), a4c[e],
        next(v["carrying_component"] for v in vec if v["enzyme"] == e),
        next(v["component_is"] for v in vec if v["enzyme"] == e),
        "**no** — not a coding sequence"]
       for e, _ in a4c.most_common()])
w(f"**{len(s3)} → {len(s4)} sites.** [EVIDENCE] The 17 edited constructs added **none**. The two "
  f"calibration anchors added all {len(s4)-len(s3)}, and all of them are Henke's MCS.")
w("")
w("**None of these is fixable by codon choice** — every one sits in a sourced promoter amplicon, "
  "fore-cistron, primer tail or MCS, not in a coding sequence. [EVIDENCE] Widening the codon "
  "optimiser (previous session) cleared every site it *could* clear; these are the residue.")
w("")
w("#### The consolidated list — an input to the vector decision")
w("")
w("`designs/vector_enzyme_constraints.csv`, one row per catalogue enzyme. [EVIDENCE]")
w("")
blocked = [v for v in vec if int(v["sites_in_panel_both_strands"]) > 0]
free = [v for v in vec if int(v["sites_in_panel_both_strands"]) == 0 and v["enzyme"] not in GOLDEN_GATE]
table(["enzyme", "site", "sites", "constructs", "carried by", "why it cannot open the vector"],
      [[f"`{v['enzyme']}`", v["recognition_site"], v["sites_in_panel_both_strands"],
        v["constructs_affected"], v["carrying_component"], v["reason"]] for v in blocked])
w(f"**{len(blocked)} enzymes cannot be used to linearise the destination vector** — each cuts inside "
  f"at least one ordered fragment. **{len(GOLDEN_GATE)} more are reserved** for the selected Golden "
  f"Gate route ({', '.join('`'+e+'`' for e in sorted(GOLDEN_GATE))}). That leaves **{len(free)} of "
  f"{len(CATALOGUE)}** free: {', '.join('`'+v['enzyme']+'`' for v in free)}.")
w("")
w("**The single most consequential line: `NcoI` moved from free to blocked, and only because of the "
  "calibration anchors.** [EVIDENCE] It was clean across all 93. pECXT99A — the vector the promoter "
  "and translational panels declare — is opened with `NcoI` **and** `NdeI`. `NdeI` is still free; "
  "`NcoI` is not. So either the two anchors are cloned by a different route from the rest of the "
  "panel, or pECXT99A's `NcoI` arm cannot be used. That is a real decision, it is cheap to make now, "
  "and it exists because reproducing a published architecture faithfully has a cost. [INFERENCE, "
  "reasoning named]")
w("")
w("---")
w("")
w("## 4. What this does and does not settle")
w("")
w("- **The TC insertion is a prediction-driven edit, not a measured correction.** It moves the "
  "start codon onto a TSS predicted from a matrix that is a reasoned approximation from a textual "
  "consensus, not a trained PWM. The P(leaderless) figures are model output. 5′RACE remains the "
  "experiment that settles it, and the specification for it is already written.")
w("- **The anchors reproduce an architecture, not a measurement.** They let panel readings be "
  "*related* to Henke's 286%; they do not guarantee the number reproduces. Vector background, "
  "reporter, medium and growth phase all differ from Henke's assay in ways this design does not "
  "control.")
w("- **`CAL-01` is close to Henke's construct but not identical.** [INFERENCE] Its upstream is the "
  "panel's designed `UP_A` flank rather than Henke's vector context, because the anchor has to be "
  "comparable to `V2-OTH-01` as well as to Henke. That is a deliberate trade and it is a deviation.")
w("- **Nothing here is experimental validation.** No claim is made that any construct expresses, "
  "initiates where predicted, or assembles.")
w("- **The Golden Gate overhangs are still undefined.** [NOT FOUND] Every enzyme statement above "
  "describes the fragments as they stand; appending overhangs can create a Type IIS site that does "
  "not exist today, and the scan must be re-run once they are chosen.")
w("")
OUT.write_text("\n".join(L) + "\n")
print(f"wrote {OUT.relative_to(ROOT)} ({len(L)} lines, {len(OUT.read_text())} chars)")
