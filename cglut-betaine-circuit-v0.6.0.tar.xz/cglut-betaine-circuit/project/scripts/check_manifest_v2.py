"""Task 4: consolidate v2 and re-run every check across the full combined set.

ENZYME LIST DERIVATION. The list is not taken from the assembly strategy. It is
derived from the PROVENANCE of every sourced component actually used, by scanning
each borrowed sequence against a broad catalogue of common cloning enzymes. This
is the failure mode that produced both the HP-4 NcoI collision and the NsiI/SphI
collision: enzymes arrive WITH borrowed sequence, so the list has to be read off
the sequences, not off the plan.
"""
import csv
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pwm_lib import revcomp
from siga_consensus import EXT10_PWM, score_window as siga_score, max_score as siga_max
from seqchecks import (CATALOGUE, GOLDEN_GATE, site_scan, fmt_sites, sigA_scan, sd_atg_scan,
                       positive_control_check)
from build_order_manifest import homopolymers, fold, worst_local_hairpin, gc, identity

ROOT = Path(__file__).resolve().parent.parent
DATA, DESIGNS = ROOT / "data", ROOT / "designs"
HOST_GC, GC_TOL = 0.5384, 0.15

# Enzyme sites and every scanner come from scripts/seqchecks.py -- this module defines
# none of its own. `derive_enzyme_list` below still reports WHICH enzymes arrive with
# borrowed sequence, because that is real information about provenance -- but the
# construct scan no longer narrows to that derived list. Narrowing a screen to what
# you already expected to find is the exact move that missed ScaI, StuI, EcoRV and XhoI.


def sites_in(seq, enzymes=None):
    """Full 35-enzyme catalogue by default, both strands."""
    return fmt_sites(site_scan(seq, enzymes=enzymes))


def spurious_promoters(seq, exclude):
    """SigA ext-10 windows outside the intended core-promoter span. See sigA_scan's caveat."""
    return [f"ext10@{h.start}({h.score:.2f})" for h in sigA_scan(seq)
            if not (exclude and exclude[0] <= h.start < exclude[1])]


def spurious_initiation(seq, known):
    return [h.detail for h in sd_atg_scan(seq, known_starts=known)]


def derive_enzyme_list():
    """Scan every SOURCED component against the catalogue; anything found must be checked."""
    bg = json.loads((DATA / "cache" / "designed_backgrounds.json").read_text())
    cp = json.loads((DATA / "cache" / "core_promoters.json").read_text())
    el = json.loads((DATA / "cache" / "promoter_elements.json").read_text())
    raw = {r["name"]: r for r in json.loads((DATA / "cache" / "panel_variants_raw.json").read_text())}
    src = json.loads((DATA / "cache" / "translational_sources.json").read_text())
    sys.path.insert(0, str(ROOT / "scripts"))
    from design_promoter_panel import OPERATORS, PSYN_UPSTREAM_CONTEXT

    comps = {}
    for k in ("Psyn", "PsodA", "Ptuf"):
        comps[f"core:{k} (Henke PMC7835838 amplicon)"] = cp[k]["sequence"][el[k]["minus35_start0"]:]
    for k, v in OPERATORS.items():
        comps[f"operator:{k} (PRODORIC MX000339)"] = v
    comps["Psyn retained ctx (PMC7835838 primer N105 tail)"] = PSYN_UPSTREAM_CONTEXT
    comps["PsodA native ext (BX927147.1)"] = raw["PsodA_1x_opA_gap03_native"]["sequence"][:40]
    comps["Ptuf native ext (BX927147.1)"] = raw["Ptuf_1x_opA_gap03_reta"]["sequence"][:40]
    for e in src["approach_B_source"]["fore_cistrons"]:
        comps[f"fore-cistron:{e['id']} ({e['gene']}, Liu PMC10367133 Tbl1)"] = e["seq"]
    comps["SD2 (Liu PMC10367133 body text)"] = src["approach_B_source"]["sd_motif"]
    comps["Henke fwd Gibson tail (PMC7835838 Tbl2)"] = "CTGTGCGGTATTTCACACCGCA"
    comps["Henke rev Gibson tail (PMC7835838 Tbl2)"] = "CCGGGTACCGAGCTCGAATTCCATG"
    comps["Psyn N106 rev tail (PMC7835838 Tbl2)"] = "GGCCAGTGAATTCGAGCTCGCTGCAGGTCGACTCTAGAGGATC"
    for k, v in bg.items():
        comps[f"DESIGNED:{k}"] = v

    found = {}
    print("=" * 78)
    print("ENZYME LIST DERIVED FROM THE PROVENANCE OF EVERY SOURCED COMPONENT")
    print("=" * 78)
    for label, s in comps.items():
        hits = sorted({h.split("@")[0] for h in sites_in(s, CATALOGUE)})
        if hits:
            print(f"  {label:56} -> {', '.join(hits)}")
            for h in hits:
                found.setdefault(h, []).append(label)
    print(f"\n  enzymes arriving WITH borrowed sequence: {sorted(found)}")
    vector = ["NcoI", "NdeI"]      # pECXT99A opening sites (Henke et al. 2021)
    working = sorted(set(found) | set(vector) | set(GOLDEN_GATE))
    print(f"  + pECXT99A vector opening sites: {vector}")
    print(f"  + Golden Gate set (assembly route selected): {list(GOLDEN_GATE)}")
    print(f"\n  provenance-derived working list ({len(working)}): {working}")
    print(f"  CONSTRUCTS ARE SCANNED AGAINST ALL {len(CATALOGUE)} CATALOGUE ENZYMES, both strands;")
    print(f"  the derived list is reported as provenance information, NOT used to narrow the scan.")
    return working, found


def main():
    positive_control_check()
    working, provenance_hits = derive_enzyme_list()

    # Rebuild the arms FIRST, then read them back. (An earlier version read the CSVs
    # before calling the builder, so the manifest was assembled from the PREVIOUS run's
    # sequences -- caught because the spurious-SigA hits kept the same scores and
    # positions across two completely different backgrounds.)
    sys.path.insert(0, str(ROOT / "scripts"))
    import build_phasing_v2
    _s, _i, _c, other = build_phasing_v2.main()

    sub = list(csv.DictReader(open(DESIGNS / "phasing_substitution.csv")))
    ins = list(csv.DictReader(open(DESIGNS / "phasing_insertion.csv")))
    ctl = list(csv.DictReader(open(DESIGNS / "phasing_controls.csv")))
    t2 = {r["name"]: r for r in csv.DictReader(open(DESIGNS / "translational_variants.csv"))}
    combo = [r for r in csv.DictReader(open(DESIGNS / "combinatorial_design.csv"))
             if r["new_construct_required"] == "yes"]

    rows = []

    def add(cid, tier, panel, r, seq, t2name=None):
        rows.append({
            "construct_id": cid, "tier": tier, "panel_of_origin": panel,
            "arm": r.get("arm", "n-a"), "core_promoter": r.get("core", ""),
            "operator_identity": r.get("operator", ""), "operator_gap_bp": r.get("gap_bp", ""),
            "background_or_filler": r.get("background") or r.get("filler") or r.get("swapped_element") or "n-a",
            "translational_element": t2name or "none (direct ATG fusion = MCD)",
            "full_sequence": seq, "length_bp": len(seq), "GC_percent": round(gc(seq), 2),
            "provenance": r.get("provenance", ""), "rationale": r.get("rationale", ""),
            "_core": r.get("core", ""), "_t2": t2name,
        })

    for i, r in enumerate(sub, 1):
        add(f"V2-SUB-{i:02d}_{r['name']}", "1-substitution", "phasing substitution arm", r, r["sequence"])
    for i, r in enumerate(ins, 1):
        add(f"V2-INS-{i:02d}_{r['name']}", "1-insertion", "phasing insertion arm", r, r["sequence"])
    for i, r in enumerate(ctl, 1):
        add(f"V2-CTL-{i:02d}_{r['name']}", "control", "swap controls", r, r["sequence"])
    for i, r in enumerate(other, 1):
        tier = "control" if ("noop" in r["name"] or "scrambled" in r["name"]) else "1-other"
        add(f"V2-OTH-{i:02d}_{r['name']}", tier, "tier-1 non-phasing (rebuilt)", r, r["sequence"])

    # combinatorial: crosses hang off the SUBSTITUTION arm (the cleaner design), so that
    # trimming the insertion arm under envelope pressure cannot break them
    submap = {int(r["gap_bp"]): r for r in sub}
    insmap = {(r["core"], int(r["gap_bp"])): r for r in ins}
    n = 0
    for c in combo:
        old = c["promoter_variant"]
        if old.startswith("Psyn"):
            g = int(re.search(r"gap(\d+)", old).group(1))
            pr, pseq = submap[g], submap[g]["sequence"]
        else:
            pr, pseq = insmap[("PsodA", 3)], insmap[("PsodA", 3)]["sequence"]
        tn = c["translational_variant"]
        eseq = t2[tn]["sequence"]
        n += 1
        short = tn.replace("T2_BCD_", "").replace("T2_", "")
        tier = "control" if "_NEG" in tn else "combinatorial"
        add(f"V2-CX-{n:02d}_{pr['name']}__{short}", tier,
            f"combinatorial, {c['block']}",
            {**pr, "provenance": pr["provenance"] + " || " + t2[tn]["provenance"],
             "rationale": c["note"][:240]}, pseq + eseq, t2name=tn)

    # ---------------------------------------------------------------- checks
    checks, seqs = [], {}
    cp = json.loads((DATA / "cache" / "core_promoters.json").read_text())
    el = json.loads((DATA / "cache" / "promoter_elements.json").read_text())
    corelen = {k: len(cp[k]["sequence"]) - el[k]["minus35_start0"] for k in cp if el[k]["minus35_start0"] is not None}

    for r in rows:
        seq, cid = r["full_sequence"], r["construct_id"]
        seqs[cid] = seq
        known = set()
        if r["_t2"] and t2[r["_t2"]]["sequence"]:
            known.add(len(seq) - len(t2[r["_t2"]]["sequence"]))
        cl = corelen.get(r["_core"])
        prom_len = len(seq) - (len(t2[r["_t2"]]["sequence"]) if r["_t2"] and t2[r["_t2"]]["sequence"] else 0)
        exclude = (prom_len - cl, prom_len) if cl else None
        enz = sites_in(seq)          # FULL catalogue -- `working` is reported, not used to narrow
        gg = [h for h in enz if h.split("@")[0] in GOLDEN_GATE]
        checks.append({
            "construct_id": cid, "length_bp": len(seq), "GC_percent": round(gc(seq), 2),
            "gc_flag": "GC_OUT_OF_RANGE" if abs(gc(seq)/100 - HOST_GC) > GC_TOL else "",
            "restriction_sites": ";".join(enz) or "none",
            "golden_gate_sites": ";".join(gg) or "none",
            "homopolymer_gt6": ";".join(homopolymers(seq)) or "none",
            "dG_kcal_per_mol": fold(seq), "dG60_worst_local": worst_local_hairpin(seq),
            "spurious_sigA_ext10": ";".join(spurious_promoters(seq, exclude)) or "none",
            "spurious_initiation": ";".join(spurious_initiation(seq, known)) or "none",
            "synthesis_difficulty": "",
        })
    by = {c["construct_id"]: c for c in checks}

    # uniqueness / near-duplicates
    ids = list(seqs)
    dup = {}
    for cid, s in seqs.items():
        dup.setdefault(s, []).append(cid)
    identical = [v for v in dup.values() if len(v) > 1]
    near = []
    for i in range(len(ids)):
        for j in range(i+1, len(ids)):
            a, b = seqs[ids[i]], seqs[ids[j]]
            if abs(len(a) - len(b)) > 6:
                continue
            pid = identity(a, b)
            if pid >= 95:
                ra = next(r for r in rows if r["construct_id"] == ids[i])
                rb = next(r for r in rows if r["construct_id"] == ids[j])
                def bgk(x):
                    m = re.search(r"HP\d+", x["translational_element"] or "")
                    return m.group(0) if m else (x["translational_element"] or "")
                intended = (ra["arm"] == rb["arm"] and ra["core_promoter"] == rb["core_promoter"]
                            and bgk(ra) == bgk(rb))
                near.append((ids[i], ids[j], round(pid, 1), intended))

    for c in checks:
        s = seqs[c["construct_id"]]
        f = []
        g = c["GC_percent"]
        if g < 35 or g > 65:
            f.append(f"EXTREME_GC({g}%)")
        for m in re.finditer(r"(A{9,}|C{9,}|G{9,}|T{9,})", s):
            f.append(f"LONG_HOMOPOLYMER({m.group(0)[0]}x{len(m.group(0))})")
        seen = {}
        for i in range(len(s)-19):
            seen.setdefault(s[i:i+20], []).append(i)
        if any(len(v) > 1 for v in seen.values()):
            f.append("INTERNAL_REPEAT_20nt")
        if c["dG60_worst_local"] is not None and c["dG60_worst_local"] <= -20.6:
            f.append(f"STRONG_LOCAL_HAIRPIN(dG60={c['dG60_worst_local']})")
        if len(s) < 125:
            f.append(f"UNDER_VENDOR_MIN({len(s)}bp)")
        c["synthesis_difficulty"] = ";".join(f) or "none"
    for a, b, pid, it in near:
        if not it:
            for x in (a, b):
                by[x]["synthesis_difficulty"] = (by[x]["synthesis_difficulty"].replace("none", "").strip(";")
                                                 + f";UNINTENDED_NEAR_DUPLICATE(vs {b if x==a else a})").strip(";")

    print("\n" + "=" * 78); print("COMBINED-SET CHECKS, v2"); print("=" * 78)
    from collections import Counter
    print(f"constructs: {len(rows)}   by tier: {dict(Counter(r['tier'] for r in rows))}")
    nz = [c for c in checks if c["restriction_sites"] != "none"]
    print(f"restriction sites ({len(CATALOGUE)} enzymes, both strands): {len(nz)}/{len(checks)} constructs")
    ec = Counter(h.split('@')[0] for c in checks for h in c["restriction_sites"].split(';') if h != "none")
    for k, v in ec.most_common():
        print(f"    {k:8} {v} hits   {'<-- GOLDEN GATE' if k in GOLDEN_GATE else ''}")
    ggn = sum(1 for c in checks if c["golden_gate_sites"] != "none")
    print(f"  GOLDEN GATE VERDICT: {ggn} constructs carry a Golden Gate site "
          f"({'CLEAN' if ggn == 0 else 'NOT CLEAN'})")
    print(f"identical sequences: {len(identical)} | >=95% pairs: {len(near)} "
          f"({sum(1 for x in near if not x[3])} unintended)")
    print(f"spurious SigA: {sum(1 for c in checks if c['spurious_sigA_ext10']!='none')} | "
          f"spurious init: {sum(1 for c in checks if c['spurious_initiation']!='none')} | "
          f"homopolymer>6: {sum(1 for c in checks if c['homopolymer_gt6']!='none')}")
    print(f"GC out of range: {sum(1 for c in checks if c['gc_flag'])} | "
          f"synthesis flags: {sum(1 for c in checks if c['synthesis_difficulty']!='none')}")
    sd = Counter(re.sub(r'\(.*', '', f) for c in checks for f in c["synthesis_difficulty"].split(';') if f and f != "none")
    print(f"  breakdown: {dict(sd)}")

    mcols = ["construct_id", "tier", "panel_of_origin", "arm", "core_promoter", "operator_identity",
             "operator_gap_bp", "background_or_filler", "translational_element", "full_sequence",
             "length_bp", "GC_percent", "provenance", "rationale", "flags"]
    for r in rows:
        c = by[r["construct_id"]]
        fl = [x for x in (c["gc_flag"],
                          "" if c["restriction_sites"] == "none" else "RESTRICTION:" + c["restriction_sites"],
                          "" if c["homopolymer_gt6"] == "none" else "HOMOPOLYMER:" + c["homopolymer_gt6"],
                          "" if c["spurious_sigA_ext10"] == "none" else "SPURIOUS_SIGA:" + c["spurious_sigA_ext10"],
                          "" if c["spurious_initiation"] == "none" else "SPURIOUS_INIT:" + c["spurious_initiation"],
                          "" if c["synthesis_difficulty"] == "none" else "SYNTH:" + c["synthesis_difficulty"]) if x]
        r["flags"] = ";".join(fl) or "none"
    with open(DESIGNS / "order_manifest_v2.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=mcols, extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    with open(DESIGNS / "order_manifest_v2_checks.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(checks[0].keys())); w.writeheader(); w.writerows(checks)
    with open(DESIGNS / "order_submit_v2.fasta", "w") as fh:
        for r in rows:
            fh.write(f">{r['construct_id']}\n{r['full_sequence']}\n")
    print(f"\nWrote designs/order_manifest_v2.csv ({len(rows)}), _checks.csv, order_submit_v2.fasta")
    return rows, checks, near, working, provenance_hits


if __name__ == "__main__":
    main()
