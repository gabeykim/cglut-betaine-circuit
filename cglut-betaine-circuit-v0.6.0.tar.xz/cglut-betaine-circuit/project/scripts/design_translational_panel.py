r"""Tier-2 translational panel: design, checks, and the reduced factorial.

Approach chosen: leaderless bicistronic design (BCD) fore-cistrons from
Liu et al. 2023 (PMC10367133), conducted IN C. glutamicum. Approach A
(cRBS / CLM-RDR, Ding et al. 2020) is NOT used to generate any sequence or
any predicted value -- see designs/REPORT_translational.md Task 1 for the
provenance findings that rule it out.

Element grammar (5'->3'), exactly as published:

    [62 nt fore-cistron][AAAGGAGGACAAC][TA] | ATG <target ORF>
     \____ 20 codons + 2 ____/\__ SD, in-frame __/  \_ TAA stop overlaps ATG _/

  62 + 13 = 75 nt = exactly 25 codons, so the fore-cistron ORF terminates in
  the TAA formed by the 'TA' junction plus the target's own A -- the TAATG
  translational coupling frame. This is verified arithmetically and by
  translation for every element (no internal stop codon is permitted).

Every fore-cistron is genome-verified against BX927147.1 upstream in
scripts/fetch_translational_sources.py; this script consumes that cache and
refuses to run if verification is absent.
"""
import csv
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pwm_lib import revcomp
from seqchecks import site_scan, fmt_sites, positive_control_check, homopolymers as _homopolymers

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DESIGNS = ROOT / "designs"

SD_MOTIF = "AAAGGAGGACAAC"      # Liu 2023, body text, verbatim
JUNCTION = "TA"                  # completes TAA; its final A is the target ATG's A
HOST_GC = 0.5384
GC_TOL = 0.15
STOPS = {"TAA", "TAG", "TGA"}

# Enzyme sites come from scripts/seqchecks.py -- this module defines none of its own.
# This screen was 13 enzymes. HP-4 was excluded from this very panel for an internal
# NcoI site, and the same site later reached 18 kinase constructs because THAT panel
# screened 5. Both now read the same catalogue.

# ---------------------------------------------------------------- selection
# Anchors are the only elements with a PUBLISHED RANK (Liu 2023 body text:
# HP-7 > HP-12 > HP-6, consistent across EGFP, VHH and LacZ).
ANCHORS = {"HP-7": "high", "HP-12": "intermediate", "HP-6": "low"}
# Spanning set: chosen for compositional/structural DIVERSITY and clean design
# checks, NOT for predicted strength -- no validated predictor exists (see report).
SPANNING = ["HP-1", "HP-2", "HP-9", "HP-10", "HP-8"]
EXCLUDED = {
    "HP-4": "internal NcoI site (CCATGG@7) -- NcoI is the cloning enzyme of the tier-1 "
            "source vector pECXT99A (Henke et al. 2021); cannot be removed without "
            "altering the published element",
    "HP-3": "not selected -- dG/GC redundant with retained elements; no defect found",
    "HP-5": "not selected -- dG/GC redundant with retained elements; no defect found",
    "HP-11": "internal SD-like GGAG@6 inside the fore-cistron (spurious internal "
             "initiation risk); not selected",
}


def tag(hp):
    """HP-7 -> HP07, so names sort correctly."""
    return "HP%02d" % int(hp.split("-")[1])


def fold(seq):
    try:
        import RNA
        return round(RNA.fold(seq)[1], 2)
    except Exception:
        return None


def enzyme_hits(seq):
    """Full 35-enzyme catalogue, both strands."""
    return fmt_sites(site_scan(seq))


def homopolymers(seq, n=6):
    return [f"{h['base']}x{h['run']}@{h['start']}" for h in _homopolymers(seq, max_run=n)]


def orf_check(fore, sd):
    """Fore-cistron ORF = fore + sd, must be a whole number of codons with no
    internal stop, so that the next codon is the TAA of the TAATG junction."""
    orf = fore + sd
    if len(orf) % 3:
        return False, [f"ORF length {len(orf)} not a multiple of 3"]
    cods = [orf[i:i + 3] for i in range(0, len(orf), 3)]
    bad = [f"internal stop {c}@codon{i+1}" for i, c in enumerate(cods) if c in STOPS]
    return (not bad), bad


def internal_init_risk(fore):
    """Spurious internal translation-initiation signals inside the fore-cistron:
    an SD-like motif is only a real risk if an ATG follows it at a plausible
    spacing (Liu's own SD sits 8 nt upstream of the start codon)."""
    risks = []
    for m in re.finditer(r"GGAGG|AGGAG|GGAG", fore):
        for a in re.finditer(r"ATG", fore[m.end():m.end() + 14]):
            risks.append(f"SD-like {m.group(0)}@{m.start()}+ATG@{m.end()+a.start()}")
    return risks


def build_element(fore, sd=SD_MOTIF, junc=JUNCTION):
    return fore + sd + junc


def main():
    src = DATA / "cache" / "translational_sources.json"
    if not src.exists():
        sys.exit("Run scripts/fetch_translational_sources.py first.")
    S = json.loads(src.read_text())
    B = S["approach_B_source"]
    FC = {e["id"]: e for e in B["fore_cistrons"]}
    if not all(e.get("genome_verified") for e in FC.values()):
        sys.exit("ERROR: not every fore-cistron is genome-verified; refusing to design.")

    lo_f, hi_f = B["measured_range_fold_over_monocistronic"]
    lo_i, hi_i = B["measured_range_fluorescence"]

    variants = []

    def add(name, kind, source, fore, element, strength, prov, rationale, extra_flags=()):
        flags = list(extra_flags)
        if not element:                       # monocistronic control: no element at all
            gc = None
        else:
            gc = 100 * (element.count("G") + element.count("C")) / len(element)
            if abs(gc / 100 - HOST_GC) > GC_TOL:
                flags.append("GC_OUT_OF_RANGE")
        if fore is not None:
            sd_used = element[62:75] if "SDmut" in name else SD_MOTIF
            ok, bad = orf_check(fore, sd_used)
            if not ok:
                flags += bad
        flags += enzyme_hits(element)
        flags += homopolymers(element)
        if fore is not None:
            flags += internal_init_risk(fore)
        variants.append({
            "name": name, "approach": kind, "source_element": source,
            "length_bp": len(element), "gc_pct": None if gc is None else round(gc, 1),
            "dG_kcal_per_mol": fold(element) if element else None,
            "dG_with_target_ATG": fold(element + "ATG") if element else None,
            "predicted_or_measured_strength": strength,
            "provenance": prov, "flags": ";".join(flags) if flags else "none",
            "rationale": rationale, "sequence": element,
        })

    # 1. monocistronic baseline -- the denominator every fold-value is relative to
    add("T2_MCD_ctrl", "monocistronic_control", "none (no fore-cistron)", None, "",
        "1.00x by definition (MCD reference)",
        "Liu 2023 PMC10367133: 'MCD represents the EGFP fluorescence under the control of "
        "the monocistronic PH36'; the 1.27-15.44x fold range is defined against this.",
        "BASELINE: no translational element at all -- the target ORF's ATG is fused directly "
        "to the tier-1 promoter. Every BCD variant is read as a fold-change over this. Without "
        "it no tier-2 number is interpretable and the tuning curve has no origin.")

    # 2-4. published-rank anchors
    anchor_meta = {
        "HP-7": (f"{hi_i} intensity units / {hi_f}x MCD",
                 "HIGH ANCHOR. [EVIDENCE] Liu 2023 body text ranks HP-7 highest of the three "
                 "representatives across EGFP, VHH and LacZ, and uses H36-HP-7 as the control "
                 "the sorted library is benchmarked against. [INFERENCE] the published maximum "
                 "(3,813 units / 15.44x) is therefore attributed to HP-7."),
        "HP-12": ("intermediate (rank 2 of 3); value NOT MEASURED in extractable text",
                  "INTERMEDIATE ANCHOR. [EVIDENCE] ranked below HP-7 and above HP-6, "
                  "consistently across three different target proteins."),
        "HP-6": (f"low (rank 3 of 3); panel minimum is {lo_i} units / {lo_f}x MCD",
                 "LOW ANCHOR. [EVIDENCE] ranked lowest of the three representatives. "
                 "[INFERENCE] it is the L-group representative, but it is NOT established that "
                 "it is the weakest of all 12 -- per-element values live in Figure 1B, an image."),
    }
    for hp in ("HP-7", "HP-12", "HP-6"):
        e = FC[hp]; el = build_element(e["seq"])
        strength, why = anchor_meta[hp]
        add(f"T2_BCD_{tag(hp)}_{e['gene']}", "leaderless_BCD",
            f"{hp} ({e['ncgl']}, {e['gene']})", e["seq"], el, strength,
            f"Liu 2023 Table 1; 62 nt verified against BX927147.1 ({e['genome_note']})", why)

    # 5-9. spanning set (unranked)
    for hp in SPANNING:
        e = FC[hp]; el = build_element(e["seq"])
        add(f"T2_BCD_{tag(hp)}_{e['gene']}", "leaderless_BCD",
            f"{hp} ({e['ncgl']}, {e['gene']})", e["seq"], el,
            f"NOT MEASURED individually; within the published 12-element range "
            f"{lo_i}-{hi_i} units ({lo_f}-{hi_f}x MCD)",
            f"Liu 2023 Table 1; 62 nt verified against BX927147.1 ({e['genome_note']})",
            "SPANNING SET, unranked. Chosen for compositional/structural diversity and clean "
            "design checks, NOT for predicted strength: no validated predictor of fore-cistron "
            "strength exists, and fold energy demonstrably fails to reproduce the one known "
            "ranking (see report S3). Its position on the tuning curve is an experimental result, "
            "not a design input.")

    # 10-12. controls from the paper's OWN mutational analysis, all on the HP-7 background
    hp7 = FC["HP-7"]["seq"]
    dm = B["disabling_mutations"]

    add("T2_BCD_HP07_fcATGtoATC_NEG", "leaderless_BCD_disabled", "HP-7, fore-cistron AUG->AUC",
        "ATC" + hp7[3:], build_element("ATC" + hp7[3:]),
        "expected near-floor (not separately quantified in extractable text)",
        f"Liu 2023, disabling mutation quoted verbatim: {dm['fore_cistron_start_AUG_to_AUC']}",
        "NEGATIVE CONTROL, the paper's own disabling mutation. Kills translation of the "
        "fore-cistron while leaving all 77 nt otherwise identical to HP-7 -- isolates 'does the "
        "fore-cistron have to be TRANSLATED' from 'does this 77 nt of sequence have to be PRESENT'. "
        "If the BCD variants read the same as this, tier 2 is doing nothing mechanistically.")

    sd_mut = "AAA" + "CCTCC" + "ACAAC"          # GGAGG -> CCTCC: kills anti-SD pairing, GC-neutral
    add("T2_BCD_HP07_SDmut_NEG", "leaderless_BCD_disabled", "HP-7, SD core GGAGG->CCTCC",
        hp7, hp7 + sd_mut + JUNCTION,
        "expected reduced (direction published; magnitude NOT MEASURED in extractable text)",
        f"Liu 2023 establishes SD mutation reduces expression: {dm['SD_mutation']}. "
        "[INFERENCE] the exact mutant is in an SI figure, so THIS SPECIFIC SUBSTITUTION IS OUR "
        "DESIGN, not theirs: the GGAGG core is replaced by CCTCC, which cannot base-pair with the "
        "C. glutamicum 16S 3' anti-SD (also CCUCC-containing), is GC-neutral, keeps the 25-codon "
        "frame and introduces no stop codon.",
        "NEGATIVE CONTROL for the second published requirement. Separates 'fore-cistron must be "
        "translated' (above) from 'SD2 must be able to recruit the ribosome to the target'. "
        "Together the two controls bracket the mechanism the whole approach rests on.")

    add("T2_BCD_HP07_fcATGtoGTG_PARTIAL", "leaderless_BCD_attenuated", "HP-7, fore-cistron AUG->GUG",
        "GTG" + hp7[3:], build_element("GTG" + hp7[3:]),
        "expected intermediate: reduced, but LESS reduced than other start-codon mutations",
        f"Liu 2023, quoted verbatim: {dm['fore_cistron_start_AUG_to_GUG']}",
        "GRADED CONTROL. The paper found AUG->GUG attenuates less than AUG->AUC, i.e. 5'-AUG is "
        "preferred but not strictly required for C. glutamicum leaderless initiation. Gives the "
        "panel a point BETWEEN the functional elements and the hard floor, which is what turns "
        "two controls into a dose-response on the mechanism rather than an on/off pair.")

    # ------------------------------------------------------------------ write
    DESIGNS.mkdir(exist_ok=True)
    fa = DESIGNS / "translational_variants.fasta"
    with open(fa, "w") as fh:
        for v in variants:
            if v["sequence"]:
                fh.write(f">{v['name']}\n{v['sequence']}\n")
    cols = ["name", "approach", "source_element", "length_bp", "gc_pct",
            "dG_kcal_per_mol", "dG_with_target_ATG", "predicted_or_measured_strength",
            "provenance", "flags", "rationale", "sequence"]
    cv = DESIGNS / "translational_variants.csv"
    with open(cv, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(variants)
    print(f"Wrote {fa.relative_to(ROOT)} ({sum(1 for v in variants if v['sequence'])} sequences)")
    print(f"Wrote {cv.relative_to(ROOT)} ({len(variants)} rows)\n")
    for v in variants:
        print(f"  {v['name']:34} GC={str(v['gc_pct']):>5}%  dG={str(v['dG_kcal_per_mol']):>7}  "
              f"flags={v['flags']}")
    print("\nExcluded fore-cistrons (documented, not silently dropped):")
    for k, why in EXCLUDED.items():
        print(f"  {k:6} {why}")
    return variants




def tier1_leaderless_check():
    """TASK 2: are the tier-1 core promoters leadered or leaderless?

    Answered from measured TSS data, not inferred: Pfeifer-Sancar et al. 2013
    (BMC Genomics 14:888) Table S3, already cached in this repo by the lysC work.
    A promoter is leaderless iff its transcript has a 5'-UTR of length 0.
    """
    import openpyxl, warnings
    warnings.filterwarnings("ignore")
    xls = DATA / "cache" / "literature" / "pfeifer2013_tables" / "Table_S3.xlsx"
    ws = openpyxl.load_workbook(xls, read_only=True)["Table S3"]
    rows = [r for r in list(ws.iter_rows(values_only=True))[2:] if r and r[0]]

    def ui(r):
        try:
            return int(r[5])
        except (TypeError, ValueError):
            return None

    utrs = [u for u in (ui(r) for r in rows) if u is not None]
    n0 = sum(1 for u in utrs if u == 0)
    out = {
        "source": ("Pfeifer-Sancar et al. 2013, BMC Genomics 14:888, Additional file 1 Table S3 "
                   "(cached in this repo by the earlier lysC TSS work; not re-fetched)"),
        "definition": "leaderless == mapped 5'-UTR length of 0 nt",
        "genome_wide": {"tss_entries": len(utrs), "leaderless_entries": n0,
                        "leaderless_pct": round(100 * n0 / len(utrs), 1)},
        "cores": {},
    }
    for tag, core in (("cg3237", "PsodA"), ("cg0587", "Ptuf"), ("cg1791", "PgapA")):
        hits = [r for r in rows if r[0] == tag]
        u = sorted(x for x in (ui(r) for r in hits) if x is not None)
        out["cores"][core] = {
            "locus_tag": tag, "n_mapped_tss": len(hits), "utr_lengths_nt": u,
            "leaderless": bool(u) and min(u) == 0,
            "verdict": "LEADERED" if u and min(u) > 0 else ("LEADERLESS" if u else "NO MAPPED TSS"),
        }
    out["cores"]["Psyn"] = {
        "locus_tag": None, "n_mapped_tss": 0, "utr_lengths_nt": [],
        "leaderless": None,
        "verdict": "NO MAPPED TSS -- synthetic promoter, not in the genome, so Table S3 cannot "
                   "answer it. See report Task 2 for the -10-based inference and why it needs 5'RACE.",
    }
    dest = DATA / "cache" / "tier1_leaderless_check.json"
    dest.write_text(json.dumps(out, indent=1))
    print(f"\nWrote {dest.relative_to(ROOT)}")
    print(f"  genome-wide: {n0}/{len(utrs)} mapped TSS are leaderless "
          f"({out['genome_wide']['leaderless_pct']}%)")
    for k, v in out["cores"].items():
        print(f"  {k:6} {v['verdict']:14} 5'UTR lengths {v['utr_lengths_nt']}")
    return out


# ============================ TASK 4: reduced factorial ============================
# The tier-1 panel's constructs already end immediately before the target ATG, i.e.
# they ARE the monocistronic (MCD) column of the promoter x translation factorial.
# Only the non-MCD cells therefore cost new constructs.

PROMOTERS = {
    "P_ref":  ("Psyn_1x_opA_gap03_repl",
               "gap=3 is tier-1's own cross-core REFERENCE position: it is the position used for "
               "the Psyn scrambled control, both Ptuf variants, and the PsodA retained/scrambled/2x "
               "variants. Anchoring tier 2 here makes every tier-2 number comparable to the widest "
               "set of existing tier-1 constructs."),
    "P_phaseA": ("Psyn_1x_opA_gap00_repl",
                 "gap=0 (helical phase 0 deg). Designated by the tier-1 report as one of 'the two "
                 "most face-differentiated Psyn positions' and already used there for the operator-"
                 "identity and copy-number axes."),
    "P_phaseB": ("Psyn_1x_opA_gap05_repl",
                 "gap=5 (helical phase ~171 deg, i.e. the opposite face from gap=0). The second of "
                 "tier-1's two designated face-differentiated positions."),
    "P_leadered": ("PsodA_1x_opA_gap03_repl",
                   "LEADERED core, same operator position as P_ref. Included only as a 2-construct "
                   "probe of the leadered-junction question (Task 2), not as a full arm."),
}
CORE_ELEMENTS = ["T2_MCD_ctrl", "T2_BCD_HP06_NCgl2501", "T2_BCD_HP12_NCgl2826", "T2_BCD_HP07_gpmA"]


def build_combinatorial(variants):
    from Bio import SeqIO
    t1 = {r.id: str(r.seq) for r in SeqIO.parse(DESIGNS / "variants.fasta", "fasta")}
    byname = {v["name"]: v for v in variants}
    rows = []

    def cell(block, pkey, vname, exists, note):
        p_id, p_why = PROMOTERS[pkey]
        el = byname[vname]["sequence"]
        p_seq = t1[p_id]
        junction = p_seq[-40:] + el + "ATG"
        rows.append({
            "block": block, "promoter_variant": p_id, "promoter_role": pkey,
            "translational_variant": vname,
            "construct_name": f"{p_id}__{vname}",
            "already_exists_in_tier1_panel": exists,
            "new_construct_required": "no" if exists else "yes",
            "junction_dG_kcal_per_mol": fold(junction),
            "junction_window": "tier-1 3' 40 nt + tier-2 element + target ATG",
            "junction_flag": "",
            "promoter_selection_rationale": p_why,
            "note": note,
        })

    # Block 1: the independence test -- full 3 x 4 factorial
    for pk in ("P_phaseA", "P_ref", "P_phaseB"):
        for vn in CORE_ELEMENTS:
            mcd = (vn == "T2_MCD_ctrl")
            cell("1_independence_3x4", pk, vn, mcd,
                 "MCD column: already built as the tier-1 construct itself (promoter fused "
                 "directly to the target ATG)." if mcd else
                 "Interaction cell. Two-way ANOVA on log(output), separately for the induced and "
                 "uninduced states, tests whether tier 1 and tier 2 combine multiplicatively.")

    # Block 2: tier-2 tuning curve, on the reference promoter only
    for v in variants:
        if v["name"] in CORE_ELEMENTS:
            continue
        cell("2_tuning_curve", "P_ref", v["name"], False,
             "Establishes the shape of the tier-2 tuning curve (and its mechanistic floor, for the "
             "three control elements) at one fixed tier-1 context.")

    # Block 3: leadered-core probe
    for vn in ("T2_MCD_ctrl", "T2_BCD_HP07_gpmA", "T2_BCD_HP06_NCgl2501"):
        mcd = (vn == "T2_MCD_ctrl")
        cell("3_leadered_probe", "P_leadered", vn, mcd,
             "MCD column: already built as the tier-1 PsodA construct." if mcd else
             "REQUIRES MODIFICATION: PsodA is leadered (5'UTR 15-94 nt, Pfeifer-Sancar Table S3), so "
             "the fore-cistron cannot initiate by leaderless entry. Build as a CONVENTIONAL BCD by "
             "prefixing SD1 = AAAGGAGGACAAC (the same published C. glutamicum SD) 8 nt upstream of "
             "the fore-cistron ATG. That 5'UTR-fore-cistron junction is NOT published and is exactly "
             "the variability Liu et al. went leaderless to avoid -- treat as untested.")

    # Flag junctions at least as structured as the -20.6 kcal/mol the tier-1 panel
    # already flags for its Ptuf variants, so the two tiers use one consistent bar.
    for r in rows:
        dg = r["junction_dG_kcal_per_mol"]
        r["junction_flag"] = ("STRUCTURED_JUNCTION" if dg is not None and dg <= -20.6 else "")
    cols = ["block", "promoter_variant", "promoter_role", "translational_variant",
            "construct_name", "already_exists_in_tier1_panel", "new_construct_required",
            "junction_dG_kcal_per_mol", "junction_flag", "junction_window",
            "promoter_selection_rationale", "note"]
    out = DESIGNS / "combinatorial_design.csv"
    with open(out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    new = sum(1 for r in rows if r["new_construct_required"] == "yes")
    print(f"\nWrote {out.relative_to(ROOT)}: {len(rows)} cells, {new} NEW constructs "
          f"({len(rows)-new} already exist as tier-1 constructs)")
    from collections import Counter
    for b, n in sorted(Counter(r["block"] for r in rows).items()):
        nn = sum(1 for r in rows if r["block"] == b and r["new_construct_required"] == "yes")
        print(f"    {b:22} {n:>2} cells, {nn:>2} new")
    dgs = [r["junction_dG_kcal_per_mol"] for r in rows if r["junction_dG_kcal_per_mol"] is not None]
    print(f"    junction dG range: {min(dgs)} .. {max(dgs)} kcal/mol")
    return rows


if __name__ == "__main__":
    _v = main()
    tier1_leaderless_check()
    build_combinatorial(_v)
