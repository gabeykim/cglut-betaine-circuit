"""Task 5 (follow-up) data acquisition: fetch confirmed Sal_PhoP sites
from PRODORIC (prodoric.de), the source that worked after CollecTF proved
unreachable on both its old and rebuilt domains (see results/REPORT_followup.md
for the full account of both attempts).

Idempotent: skips the network entirely if the cached matrix JSON already
exists, and rewrites (not appends-on-top-of-itself) the Salmonella rows in
data/sites_manifest.csv so reruns never duplicate rows.
"""
import csv
import json
import ssl
import urllib.request
from pathlib import Path

import certifi

_SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
urllib.request.install_opener(urllib.request.build_opener(urllib.request.HTTPSHandler(context=_SSL_CONTEXT)))

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
CACHE = DATA / "cache" / "prodoric"
API = "https://www.prodoric.de/api"

DOI_MAP = {
    1: ("Perez, Latifi & Groisman 2008, J Biol Chem 283:26066-26076", "10.1074/jbc.M709843200"),
    2: ("Lejona, Aguirre, Cabeza, Vescovi & Soncini 2003, J Bacteriol 185:6287-6294", "10.1128/JB.185.21.6287-6294.2003"),
    3: ("Bijlsma & Groisman 2005, Mol Microbiol 57:85-96", "10.1111/j.1365-2958.2005.04668.x"),
    4: ("Tu, Latifi, Bougdour, Gottesman & Groisman 2006, PNAS 103:13503-13508", "10.1073/pnas.0606026103"),
}


def fetch_json(url: str, out: Path):
    if out.exists():
        print(f"  [cached] {out.name}")
        return json.loads(out.read_text())
    print(f"  fetching {url} ...")
    with urllib.request.urlopen(url, timeout=30) as resp:
        data = json.loads(resp.read())
    out.write_text(json.dumps(data))
    return data


def main():
    CACHE.mkdir(parents=True, exist_ok=True)

    orgs = fetch_json(f"{API}/organism", CACHE / "organisms.json")
    salmonella = next(o for o in orgs if "almonella" in o["name"])
    print(f"Salmonella enterica accession (PRODORIC): {salmonella['accession']}")

    net = fetch_json(f"{API}/prodonet/{salmonella['accession']}", CACHE / "salmonella_regulatory_network.json")
    phop_node = next(n for n in net["nodes"] if n.get("mx") and n["label"] == "PhoP")
    matrix_id = phop_node["mx"].replace("MX", "")
    print(f"Sal_PhoP matrix accession: MX{matrix_id}")

    d = fetch_json(f"{API}/matrix/MX{matrix_id}", CACHE / f"MX{matrix_id}_phop_salmonella.json")
    sites = d["bindingsites"]
    print(f"{len(sites)} confirmed Sal_PhoP binding sites")

    fasta_path = DATA / "sites" / "phop_salmonella_sites.fasta"
    with open(fasta_path, "w") as fh:
        for i, bs in enumerate(sites):
            header = f">{bs['operon']}_{i} regulation={bs['regulation']} refs={','.join(str(r) for r in bs['references'])}"
            fh.write(f"{header}\n{bs['sequence'].upper()}\n")
    print(f"Wrote {len(sites)} sites to {fasta_path}")

    new_rows = []
    for bs in sites:
        cite = "; ".join(DOI_MAP[r][0] for r in bs["references"])
        doi = "; ".join(DOI_MAP[r][1] for r in bs["references"])
        new_rows.append({
            "tf": "Sal_PhoP", "organism": "Salmonella enterica", "promoter": bs["operon"],
            "core": bs["sequence"].upper(), "core_len": len(bs["sequence"]), "included_in_pwm": True,
            "exclusion_reason": "", "strand": bs.get("orientation") or "", "left": "", "right": "",
            "pmids": doi, "source": f"PRODORIC MX{matrix_id}",
            "source_url": f"https://www.prodoric.de/matrix/MX{matrix_id}",
        })

    manifest_path = DATA / "sites_manifest.csv"
    existing = list(csv.DictReader(open(manifest_path)))
    fieldnames = list(existing[0].keys())
    # idempotent: drop any previously-written Salmonella rows before re-adding, so reruns don't duplicate
    kept = [r for r in existing if not (r["tf"] == "Sal_PhoP" and r["organism"] == "Salmonella enterica")]
    with open(manifest_path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in kept:
            writer.writerow(r)
        for r in new_rows:
            writer.writerow({k: r.get(k, "") for k in fieldnames})
    print(f"data/sites_manifest.csv: {len(kept)} existing rows kept, {len(new_rows)} Salmonella rows (re)written")


if __name__ == "__main__":
    main()
