"""Independent round-trip verification of the final order files.

Re-reads the SOURCE panel files and the written outputs and checks them against
each other. Nothing here imports the consolidation script's in-memory state.
"""
import csv, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
D = ROOT / "designs"


def read_fasta(p):
    out, k, buf = {}, None, []
    for line in open(p):
        line = line.strip()
        if line.startswith(">"):
            if k:
                out[k] = "".join(buf)
            k, buf = line[1:].split()[0], []
        elif line:
            buf.append(line)
    if k:
        out[k] = "".join(buf)
    return out



def run():
    ok, fail = [], []

    def check(name, cond, detail=""):
        (ok if cond else fail).append(f"{name}{(' -- ' + detail) if detail else ''}")


    man = list(csv.DictReader(open(D / "order_manifest_final.csv")))
    sub_csv = list(csv.DictReader(open(D / "order_submit_final.csv")))
    sub_fa = read_fasta(D / "order_submit_final.fasta")
    src_nk = {r["construct_id"]: r["full_sequence"] for r in csv.DictReader(open(D / "order_manifest_v2.csv"))}
    src_k = read_fasta(D / "junctions_v2.fasta")
    kin_csv = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v2.csv"))}

    check("manifest has 93 rows", len(man) == 93, str(len(man)))
    check("submit CSV has 93 rows", len(sub_csv) == 93, str(len(sub_csv)))
    check("submit FASTA has 93 records", len(sub_fa) == 93, str(len(sub_fa)))
    check("submit CSV has exactly 2 columns", list(sub_csv[0].keys()) == ["construct_id", "full_sequence"],
          str(list(sub_csv[0].keys())))
    check("manifest columns are exactly the required set",
          list(man[0].keys()) == ["construct_id", "panel", "tier", "component_provenance", "full_sequence",
                                  "length_bp", "GC_percent", "flags", "rank_or_rationale"],
          str(list(man[0].keys())))
    check("construct_ids unique", len({r["construct_id"] for r in man}) == 93)
    check("id sets match across manifest / submit CSV / submit FASTA",
          {r["construct_id"] for r in man} == {r["construct_id"] for r in sub_csv} == set(sub_fa))

    mismatch = [r["construct_id"] for r in man
                if r["full_sequence"] != next(x["full_sequence"] for x in sub_csv if x["construct_id"] == r["construct_id"])
                or r["full_sequence"] != sub_fa[r["construct_id"]]]
    check("manifest / submit CSV / submit FASTA sequences byte-identical", not mismatch, str(mismatch[:5]))

    back = []
    for r in man:
        cid, s = r["construct_id"], r["full_sequence"]
        if cid in src_nk:
            if s != src_nk[cid]:
                back.append((cid, "vs order_manifest_v2.csv"))
        elif cid in src_k:
            if s != src_k[cid]:
                back.append((cid, "vs junctions_v2.fasta"))
            elif len(s) != int(kin_csv[cid]["dna_len"]):
                back.append((cid, "length vs junctions_v2.csv dna_len"))
        else:
            back.append((cid, "not found in any source panel file"))
    check("every sequence byte-identical to its SOURCE panel file", not back, str(back[:5]))

    lenbad = [r["construct_id"] for r in man if int(r["length_bp"]) != len(r["full_sequence"])]
    check("length_bp equals len(full_sequence)", not lenbad, str(lenbad[:5]))
    gcbad = [r["construct_id"] for r in man
             if abs(float(r["GC_percent"]) -
                    round(100 * (r["full_sequence"].count("G") + r["full_sequence"].count("C")) /
                          len(r["full_sequence"]), 2)) > 1e-9]
    check("GC_percent recomputes correctly", not gcbad, str(gcbad[:5]))
    alpha = {c for r in man for c in r["full_sequence"]}
    check("sequences are ACGT only", alpha <= set("ACGT"), str(sorted(alpha)))
    check("no empty sequence", all(r["full_sequence"] for r in man))
    check("every row has a non-empty component_provenance", all(r["component_provenance"] for r in man))
    check("no row carries an UNRESOLVED provenance entry",
          not [r["construct_id"] for r in man if "UNRESOLVED" in r["component_provenance"]])
    check("every row has a non-empty rank_or_rationale", all(r["rank_or_rationale"].strip() for r in man))
    check("every row has a flags value", all(r["flags"].strip() for r in man))

    chk = list(csv.DictReader(open(D / "order_manifest_final_checks.csv")))
    check("checks file covers the same 93 ids", {c["construct_id"] for c in chk} == {r["construct_id"] for r in man})
    check("checks lengths agree with manifest",
          all(int(c["length_bp"]) == len(next(r["full_sequence"] for r in man if r["construct_id"] == c["construct_id"]))
              for c in chk))
    check("zero Golden Gate sites recorded in the checks file",
          all(c["golden_gate_sites"] == "none" for c in chk))
    sites = list(csv.DictReader(open(D / "order_manifest_final_sites.csv")))
    check("sites file agrees with the checks file on site counts per construct",
          all(int(c["n_restriction_sites_35cat"]) ==
              sum(1 for s in sites if s["construct_id"] == c["construct_id"]) for c in chk))
    comp = list(csv.DictReader(open(D / "order_manifest_final_components.csv")))
    bad = []
    for r in man:
        parts = [c for c in comp if c["construct_id"] == r["construct_id"]]
        parts.sort(key=lambda c: int(c["start"]))
        if "".join(r["full_sequence"][int(c["start"]):int(c["end"])] for c in parts) != r["full_sequence"]:
            bad.append(r["construct_id"])
        if parts and (int(parts[0]["start"]) != 0 or int(parts[-1]["end"]) != len(r["full_sequence"])):
            bad.append(r["construct_id"] + " (does not cover the whole sequence)")
    check("component map tiles every construct with no gap or overlap", not bad, str(bad[:5]))

    return ok, fail


if __name__ == "__main__":
    ok, fail = run()
    print("=" * 74)
    print("ROUND-TRIP VERIFICATION OF THE FINAL ORDER FILES")
    print("=" * 74)
    for x in ok:
        print(f"  PASS  {x}")
    for x in fail:
        print(f"  FAIL  {x}")
    print(f"\n  {len(ok)} passed, {len(fail)} failed")
    sys.exit(1 if fail else 0)
