"""TASK 3: rebuild the consolidated manifest at 95 constructs.

  69 non-kinase, 17 of them carrying the TC spacer inserted 5' of the
     fore-cistron start codon (scripts/tier1_edits.py)
  24 kinase, unchanged from junctions_v4 -- no kinase construct has a
     fore-cistron, so none qualifies for the TC edit and no junctions_v5 exists
   2 calibration anchors (scripts/calibration_constructs.py)
  -- 95
"""
import csv, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import consolidate_final as CF
from seqchecks import positive_control_check
from calibration_constructs import reconstruct_spacer, PARTNERS, PROV_SPACER

D = ROOT / "designs"
INSERT = "TC"

CF.SUFFIX = "_v4"
CF.KIN_CSV = "junctions_v4.csv"
CF.KIN_FA = "junctions_v4.fasta"

# --- the 17 edited tier-1 constructs
edits = {r["construct_id"]: r for r in csv.DictReader(open(D / "tier1_v2.csv"))}
CF.NK_SEQ_OVERRIDE = {k: v["sequence_after"] for k, v in edits.items()}
CF.CX_INSERT_PARTS = [(f"designed:TSS_spacer_{INSERT}", INSERT)]

# --- the 2 calibration anchors, built on the same component machinery
PSYN, SPACER, prov, _p = reconstruct_spacer()
C, bg, cp, el, raw, src = CF.load_components()
t2 = {r["name"]: r for r in csv.DictReader(open(D / "translational_variants.csv"))}
NKPARTS = CF.build_nonkinase_parts(C, bg, t2)
BASE_OF = {"V2-OTH-01_Psyn_noop_ctrl_v2": "Psyn_noop_ctrl_v2",
           "V2-SUB-04_SUB_Psyn_opA_gap03": "SUB_Psyn_opA_gap03"}
cal = {r["construct_id"]: r for r in csv.DictReader(open(D / "calibration_constructs.csv"))}
CF.EXTRA_CONSTRUCTS = []
for cid, partner, why in PARTNERS:
    parts = NKPARTS[BASE_OF[partner]] + [("henke_spacer:HA07rc+HN49", SPACER)]
    CF.EXTRA_CONSTRUCTS.append({
        "construct_id": cid, "panel": "calibration_anchor",
        "tier": "calibration (NOT a phasing variant)",
        "parts": parts,
        "rank_or_rationale": cal[cid]["rank_or_rationale"],
        "src": {"flags": "", "panel_of_origin": "calibration_anchor",
                "core_promoter": "Psyn", "translational_element": "none (RBS-leadered, Henke architecture)"},
    })
# provenance string for the new component
CF.PROV_EXTRA = {"henke_spacer:HA07rc+HN49": PROV_SPACER}
_orig = CF.component_provenance
def _cp(lab, prov_of, r):
    if lab.startswith("henke_spacer:"):
        return PROV_SPACER
    if lab.startswith("designed:TSS_spacer_"):
        return ("DESIGNED, NOT SOURCED - 2 nt spacer inserted to place the fore-cistron start codon "
                "on the predicted transcription start site; choice of TC justified in "
                "REPORT_tier1_edits.md §1 (C and CC recreate an NcoI site)")
    return _orig(lab, prov_of, r)
CF.component_provenance = _cp

if __name__ == "__main__":
    if len(sys.argv) > 1:
        CF.OUTDIR = Path(sys.argv[1]); CF.OUTDIR.mkdir(parents=True, exist_ok=True)
    positive_control_check()
    print(f"  tier-1 edits applied      : {len(CF.NK_SEQ_OVERRIDE)} constructs, +{INSERT}")
    print(f"  calibration anchors added : {len(CF.EXTRA_CONSTRUCTS)}")
    CF.main()
