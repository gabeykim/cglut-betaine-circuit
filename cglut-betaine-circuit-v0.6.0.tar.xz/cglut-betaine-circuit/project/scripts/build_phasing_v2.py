"""Rebuild the tier-1 operator phasing series as two matched arms.

WHY. The combined-set check found the old gap filler was the first n characters
of one fixed hash-derived string: gaps 1-3 were pure poly-G and filler GC fell
monotonically 100% -> 61.5% along the exact axis being swept. Helical face,
distance and filler composition therefore covaried, and gap 0 (no filler at all)
was structurally unlike every other point.

ARM 1 (primary) - SUBSTITUTION. The operator slides THROUGH a fixed 46 bp
background, replacing 16 bp of it rather than being inserted into a growing gap:

    BG_A[0 : 30-gap]  OPERATOR(16)  BG_A[46-gap : 46]  core_from_-35(34)
    \___ 30-gap bp __/              \____ gap bp ____/

  Total length is 80 bp at EVERY gap. Background contribution is always exactly
  30 bp. Only the operator's position inside the background changes.

ARM 2 (secondary) - INSERTION, rebuilt. Same geometry as the old series, but the
poly-G prefix is replaced by FILL_A, a designed non-repetitive 13-mer at host
composition whose growing prefixes stay as close to 53.8% GC as a prefix design
allows. Gaps 1-3 remain compositionally extreme and are reported, not hidden.

Nothing here is written from memory: the core promoters, the operator and the
retained upstream contexts all come from cached records (see the provenance
strings below); the backgrounds and fillers are DESIGNED by
scripts/design_backgrounds.py against an explicit criteria list.
"""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from design_promoter_panel import OPERATORS, scramble, PSYN_UPSTREAM_CONTEXT

ROOT = Path(__file__).resolve().parent.parent
DATA, DESIGNS = ROOT / "data", ROOT / "designs"
GAPS = list(range(0, 14))
SWAP_GAP = 7                      # in the clean region (>=4), away from the 1-3 extremes

PROV_CORE = ("core promoter: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838), "
             "amplicon recovered from BX927147.1 with the paper's own primers")
PROV_OP = ("operator: confirmed Sal_PhoP site, PRODORIC MX000339 "
           "(opA_phoP = the Sal_PhoP autoregulatory site, 94% of Salmonella-PWM max)")
PROV_BG = ("background/filler: DESIGNED, NOT SOURCED - seeded rejection sampling in "
           "scripts/design_backgrounds.py against an explicit criteria list; reproducible "
           "from that file alone; no natural record is cited because none exists")
PROV_RETA = ("retained upstream context: 21 nt vector-homology tail of primer N105 (Psyn-fw2), "
             "PMC7835838 Table 2, verified in a single unbroken <td> of the cached HTML")
PROV_NATIVE = ("retained upstream context: 40 bp of BX927147.1 immediately 5' of the "
               "validated amplicon, recovered from the cached genome")


def main():
    bg = json.loads((DATA / "cache" / "designed_backgrounds.json").read_text())
    cp = json.loads((DATA / "cache" / "core_promoters.json").read_text())
    el = json.loads((DATA / "cache" / "promoter_elements.json").read_text())
    raw = {r["name"]: r for r in json.loads((DATA / "cache" / "panel_variants_raw.json").read_text())}

    core = {k: cp[k]["sequence"][el[k]["minus35_start0"]:] for k in ("Psyn", "PsodA", "Ptuf")}
    OP, OPB = OPERATORS["opA_phoP"], OPERATORS["opB_mgtA"]
    SCR = scramble(OP)
    BG_A, BG_B, BG_C = bg["BG_A"], bg["BG_B"], bg["BG_C"]
    UP_A, FILL_A, FILL_B, TSP = bg["UP_A"], bg["FILL_A"], bg["FILL_B"], bg["TSP_A"]

    # native upstream extensions: taken from the already-built panel, which derived them
    # from the cached genome; re-verified here rather than re-derived
    nat_psoda = raw["PsodA_1x_opA_gap03_native"]["sequence"][:40]
    nat_ptuf = raw["Ptuf_1x_opA_gap03_reta"]["sequence"][:40]
    from Bio import SeqIO
    genome = str(next(SeqIO.parse(DATA / "cache" / "BX927147.fasta", "fasta")).seq).upper()
    rc = genome.translate(str.maketrans("ACGT", "TGCA"))[::-1]
    for nm, s in (("PsodA", nat_psoda), ("Ptuf", nat_ptuf)):
        assert s in genome or s in rc, f"native extension for {nm} not found in BX927147.1"
    print(f"native upstream extensions re-verified against BX927147.1: PsodA {len(nat_psoda)} bp, "
          f"Ptuf {len(nat_ptuf)} bp")

    BGLEN, OPLEN = len(BG_A), len(OP)
    assert BGLEN >= OPLEN + 14, "background too short for the full 0-13 range"

    sub, ins, ctl = [], [], []

    def substitute(background, gap):
        """Operator replaces background[BGLEN-gap-OPLEN : BGLEN-gap]. Length invariant."""
        lo = BGLEN - gap - OPLEN
        return background[:lo] + OP + background[BGLEN - gap:]

    # ---------------- ARM 1: substitution (Psyn) ----------------
    for g in GAPS:
        seq = substitute(BG_A, g) + core["Psyn"]
        wrap = {11: 0, 12: 1, 13: 2}.get(g)
        sub.append({
            "name": f"SUB_Psyn_opA_gap{g:02d}", "arm": "substitution", "core": "Psyn",
            "operator": "opA_phoP", "gap_bp": g, "background": "BG_A",
            "background_5p_bp": BGLEN - g - OPLEN, "background_3p_bp": g,
            "sequence": seq, "length_bp": len(seq),
            "gc_pct": round(100 * (seq.count("G") + seq.count("C")) / len(seq), 2),
            "provenance": f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (BG_A)",
            "rationale": (f"operator slides through a FIXED 46 bp background; {BGLEN-g-OPLEN} bp of "
                          f"background 5' of the operator and {g} bp 3' of it. Total length and total "
                          f"background contribution are identical at every gap, so helical face and "
                          f"distance vary while length and composition do not."
                          + ("" if wrap is None else
                             f" WRAP-AROUND: same helical face as gap{wrap:02d} one turn further out; "
                             f"the gap{g:02d}-vs-gap{wrap:02d} pair is the periodicity-vs-distance test.")),
        })

    # ---------------- ARM 2: insertion, rebuilt (Psyn) ----------------
    for g in GAPS:
        seq = UP_A + OP + FILL_A[:g] + core["Psyn"]
        wrap = {11: 0, 12: 1, 13: 2}.get(g)
        fg = (100 * (FILL_A[:g].count("G") + FILL_A[:g].count("C")) / g) if g else None
        ins.append({
            "name": f"INS_Psyn_opA_gap{g:02d}", "arm": "insertion", "core": "Psyn",
            "operator": "opA_phoP", "gap_bp": g, "filler": FILL_A[:g] or "(none)",
            "filler_gc_pct": None if fg is None else round(fg, 1),
            "sequence": seq, "length_bp": len(seq),
            "gc_pct": round(100 * (seq.count("G") + seq.count("C")) / len(seq), 2),
            "provenance": f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (UP_A upstream, FILL_A gap filler)",
            "rationale": (f"operator INSERTED into a growing gap; construct length grows with gap "
                          f"({len(seq)} bp here). Filler is FILL_A[:{g}] at {('n/a' if fg is None else f'{fg:.0f}%')} GC."
                          + (" NOTE: at gaps 1-3 a filler of 1-3 nt cannot sit at host composition; "
                             "this residual extremity is reported, not designed away."
                             if 1 <= g <= 3 else "")
                          + ("" if wrap is None else
                             f" WRAP-AROUND vs gap{wrap:02d} - but note this pair differs in LENGTH by "
                             f"{g-wrap} bp, unlike the substitution arm.")),
        })

    # ---------------- ARM 2b: PsodA coarse cross-check, rebuilt ----------------
    for g in (0, 3, 6, 10):
        seq = UP_A + OP + FILL_A[:g] + core["PsodA"]
        ins.append({
            "name": f"INS_PsodA_opA_gap{g:02d}", "arm": "insertion", "core": "PsodA",
            "operator": "opA_phoP", "gap_bp": g, "filler": FILL_A[:g] or "(none)",
            "filler_gc_pct": None if not g else round(100 * (FILL_A[:g].count("G") + FILL_A[:g].count("C")) / g, 1),
            "sequence": seq, "length_bp": len(seq),
            "gc_pct": round(100 * (seq.count("G") + seq.count("C")) / len(seq), 2),
            "provenance": f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (UP_A upstream, FILL_A gap filler)",
            "rationale": ("coarse 4-point cross-check of the position effect on an independently-sourced, "
                          "structurally different core. Rebuilt with the corrected filler: the old version "
                          "used the same poly-G prefix (gap=3 was 'GGG'). Not a full phasing series."),
        })

    # ---------------- Task 3: swap controls ----------------
    for tag, b in (("BGB", BG_B), ("BGC", BG_C)):
        seq = substitute(b, SWAP_GAP) + core["Psyn"]
        ctl.append({
            "name": f"CTL_SUB_{tag}_gap{SWAP_GAP:02d}", "arm": "substitution", "core": "Psyn",
            "operator": "opA_phoP", "gap_bp": SWAP_GAP, "swap_of": f"SUB_Psyn_opA_gap{SWAP_GAP:02d}",
            "swapped_element": f"background BG_A -> {tag.replace('BG','BG_')}",
            "sequence": seq, "length_bp": len(seq),
            "gc_pct": round(100 * (seq.count("G") + seq.count("C")) / len(seq), 2),
            "provenance": f"{PROV_CORE} | {PROV_OP} | {PROV_BG} ({tag.replace('BG','BG_')})",
            "rationale": ("BACKGROUND-SWAP CONTROL. Identical to the substitution variant at the same gap "
                          "except the background is a different designed sequence at matched composition. "
                          "If the swaps read the same, background identity does not matter and the phasing "
                          "series is clean; if they differ, that difference BOUNDS how much of any phasing "
                          "signal is sequence identity rather than position."),
        })
    seq = UP_A + OP + FILL_B[:SWAP_GAP] + core["Psyn"]
    ctl.append({
        "name": f"CTL_INS_FILLB_gap{SWAP_GAP:02d}", "arm": "insertion", "core": "Psyn",
        "operator": "opA_phoP", "gap_bp": SWAP_GAP, "swap_of": f"INS_Psyn_opA_gap{SWAP_GAP:02d}",
        "swapped_element": "filler FILL_A -> FILL_B (upstream UP_A held constant)",
        "sequence": seq, "length_bp": len(seq),
        "gc_pct": round(100 * (seq.count("G") + seq.count("C")) / len(seq), 2),
        "provenance": f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (UP_A upstream, FILL_B gap filler)",
        "rationale": ("FILLER-SWAP CONTROL. Identical to the insertion variant at the same gap except the "
                      "filler is a different designed 13-mer at matched composition, with the upstream held "
                      "constant so the swap isolates filler identity alone."),
    })

    # ---------------- rebuilt non-phasing tier-1 variants ----------------
    other = []

    def add(name, core_name, seq, prov, why, **kw):
        other.append({"name": name, "arm": "non-phasing", "core": core_name, "sequence": seq,
                      "length_bp": len(seq),
                      "gc_pct": round(100 * (seq.count("G") + seq.count("C")) / len(seq), 2),
                      "provenance": prov, "rationale": why, **kw})

    P, S, T = core["Psyn"], core["PsodA"], core["Ptuf"]
    add("Psyn_noop_ctrl_v2", "Psyn", UP_A + P, f"{PROV_CORE} | {PROV_BG} (UP_A)",
        "NEGATIVE CONTROL: strong core, no operator. Baseline for every Psyn variant.",
        operator="none", gap_bp=0)
    add("Psyn_1x_scrambled_gap03_v2", "Psyn", UP_A + SCR + FILL_A[:3] + P,
        f"{PROV_CORE} | {PROV_BG} (UP_A, FILL_A) | operator: composition-matched SCRAMBLE of opA_phoP (designed)",
        f"NEGATIVE CONTROL: same position as a real-operator variant, operator replaced by a "
        f"base-composition-matched scramble ({SCR}).", operator="scrambled_opA", gap_bp=3)
    for g in (0, 5):
        add(f"Psyn_2xopA_gap{g:02d}_v2", "Psyn", UP_A + OP + TSP + OP + FILL_A[:g] + P,
            f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (UP_A, FILL_A, TSP_A inter-copy spacer)",
            f"copy-number axis: two tandem operator copies, {len(TSP)}bp inter-copy spacer.",
            operator="opA_phoP+opA_phoP", gap_bp=g)
        add(f"Psyn_1x_opB_gap{g:02d}_v2", "Psyn", UP_A + OPB + FILL_A[:g] + P,
            f"{PROV_CORE} | operator: confirmed Sal_PhoP mgtA site, PRODORIC MX000339 | {PROV_BG} (UP_A, FILL_A)",
            "operator-identity axis: the second real confirmed site (mgtA) at a fixed position.",
            operator="opB_mgtA", gap_bp=g)
    for g in (3, 5):
        add(f"Psyn_1x_opA_gap{g:02d}_reta_v2", "Psyn", PSYN_UPSTREAM_CONTEXT + OP + FILL_A[:g] + P,
            f"{PROV_CORE} | {PROV_OP} | {PROV_RETA} | {PROV_BG} (FILL_A gap filler)",
            "RETAINED upstream context, matched to the replaced variant at the same gap. Separates "
            "'the architecture does not work' from 'we truncated something that was needed'.",
            operator="opA_phoP", gap_bp=g)
    add("PsodA_1x_opA_gap03_native_v2", "PsodA", nat_psoda + OP + FILL_A[:3] + S,
        f"{PROV_CORE} | {PROV_OP} | {PROV_NATIVE} | {PROV_BG} (FILL_A)",
        "RETAINED native upstream context on the weak core.", operator="opA_phoP", gap_bp=3)
    add("PsodA_1x_scrambled_gap03_v2", "PsodA", UP_A + SCR + FILL_A[:3] + S,
        f"{PROV_CORE} | {PROV_BG} (UP_A, FILL_A) | operator: designed scramble",
        "NEGATIVE CONTROL on the weak core.", operator="scrambled_opA", gap_bp=3)
    add("PsodA_2xopA_gap03_v2", "PsodA", UP_A + OP + TSP + OP + FILL_A[:3] + S,
        f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (UP_A, FILL_A, TSP_A)",
        "copy-number axis on the weak core.", operator="opA_phoP+opA_phoP", gap_bp=3)
    add("PsodA_noop_ctrl_v2", "PsodA", UP_A + S, f"{PROV_CORE} | {PROV_BG} (UP_A)",
        "NEGATIVE CONTROL: weak core, no operator.", operator="none", gap_bp=0)
    add("Ptuf_1x_opA_gap03_repl_v2", "Ptuf", UP_A + OP + FILL_A[:3] + T,
        f"{PROV_CORE} | {PROV_OP} | {PROV_BG} (UP_A, FILL_A)",
        "medium core; CAVEAT: this core's -35 could not be confidently assigned (best candidate 12% "
        "of max), so its gap value is not trustworthy. Strength-range breadth only.",
        operator="opA_phoP", gap_bp=3)
    add("Ptuf_1x_opA_gap03_reta_v2", "Ptuf", nat_ptuf + OP + FILL_A[:3] + T,
        f"{PROV_CORE} | {PROV_OP} | {PROV_NATIVE} | {PROV_BG} (FILL_A)",
        "medium core, retained native upstream context. Same -35 caveat.", operator="opA_phoP", gap_bp=3)
    add("Ptuf_noop_ctrl_v2", "Ptuf", UP_A + T, f"{PROV_CORE} | {PROV_BG} (UP_A)",
        "NEGATIVE CONTROL: medium core, no operator.", operator="none", gap_bp=0)

    # ---------------- write ----------------
    def dump(rows, path, cols):
        with open(path, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            w.writeheader(); w.writerows(rows)
        print(f"Wrote {path.relative_to(ROOT)} ({len(rows)} rows)")

    dump(sub, DESIGNS / "phasing_substitution.csv",
         ["name", "arm", "core", "operator", "gap_bp", "background", "background_5p_bp",
          "background_3p_bp", "length_bp", "gc_pct", "sequence", "provenance", "rationale"])
    dump(ins, DESIGNS / "phasing_insertion.csv",
         ["name", "arm", "core", "operator", "gap_bp", "filler", "filler_gc_pct",
          "length_bp", "gc_pct", "sequence", "provenance", "rationale"])
    dump(ctl, DESIGNS / "phasing_controls.csv",
         ["name", "arm", "core", "operator", "gap_bp", "swap_of", "swapped_element",
          "length_bp", "gc_pct", "sequence", "provenance", "rationale"])

    CRIT = ("DESIGNED (not sourced). Criteria all verified in scripts/design_backgrounds.py: "
            "GC within +/-4 pts of host 53.84%; no homopolymer >3; no direct repeat >6; no site for any "
            "of the repo's 15 assembly enzymes on either strand; no ATG and no SD-like GGAG/AGGA/GAGG; "
            "no SigA-like element (ext-10 <55% of max, -35 <70% of max -- CAVEAT: that matrix is a "
            "reasoned approximation from a textual consensus, not an empirically trained PWM); "
            "ViennaRNA MFE > -8 kcal/mol; shares no 10-mer with any of the 82 intergenic-null-surviving "
            "genomic Sal_PhoP matches (incl. the lysC site) and no window scores within 60% of the "
            "operator's own Sal_PhoP PWM score.")
    USE = {"BG_A": "primary substitution background", "BG_B": "background-swap control",
           "BG_C": "background-swap control", "UP_A": "insertion-arm upstream context",
           "UP_B": "DESIGNED SPARE - reserved, not used in any construct",
           "FILL_A": "insertion-arm gap filler", "FILL_B": "filler-swap control",
           "TSP_A": "tandem inter-operator spacer (2 bp: below the length at which the criteria apply)"}
    with open(DESIGNS / "background_sequences.fasta", "w") as fh:
        for k in ("BG_A", "BG_B", "BG_C", "UP_A", "UP_B", "FILL_A", "FILL_B", "TSP_A"):
            s = bg[k]
            g = 100 * (s.count("G") + s.count("C")) / len(s)
            fh.write(f">{k} len={len(s)} GC={g:.1f}% use={USE[k]} | {CRIT}\n{s}\n")
    print(f"Wrote designs/background_sequences.fasta (8 designed sequences)")

    # ---------------- GC invariance report ----------------
    gsub = [r["gc_pct"] for r in sub]
    gins = [r["gc_pct"] for r in ins if r["core"] == "Psyn"]
    print(f"\nSUBSTITUTION arm: length {sub[0]['length_bp']} bp at every gap "
          f"(constant={len({r['length_bp'] for r in sub})==1}); "
          f"GC {min(gsub):.2f}-{max(gsub):.2f}% (spread {max(gsub)-min(gsub):.2f} pts)")
    print(f"INSERTION arm (Psyn): length {min(r['length_bp'] for r in ins if r['core']=='Psyn')}-"
          f"{max(r['length_bp'] for r in ins if r['core']=='Psyn')} bp; "
          f"GC {min(gins):.2f}-{max(gins):.2f}% (spread {max(gins)-min(gins):.2f} pts)")
    return sub, ins, ctl, other


if __name__ == "__main__":
    main()
