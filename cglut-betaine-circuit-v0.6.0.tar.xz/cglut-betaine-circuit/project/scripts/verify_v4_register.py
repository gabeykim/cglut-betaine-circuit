"""TASK 3: did the register recentring survive the codon widening?

Codon choice is a DNA-level decision; join points, deltas and the H-box are
defined at the protein level. They should be untouched. This verifies rather
than assumes. Any difference here is a bug, not a new find.

Compares v4 against v3 (and v2, from which v3 inherited) on every protein-level
quantity, and back-translates the v4 DNA independently of the CSV.
"""
import csv, sys
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import site_scan, GOLDEN_GATE, CATALOGUE, positive_control_check

D = ROOT / "designs"
CODON = {}
_t = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
for _i, (_a, _b, _c) in enumerate(product("TCAG", repeat=3)):
    CODON[_a+_b+_c] = _t[_i]
translate = lambda d: "".join(CODON[d[i:i+3]] for i in range(0, len(d)-2, 3))


def read_fasta(p):
    o, k, b = {}, None, []
    for line in open(p):
        line = line.strip()
        if line.startswith(">"):
            if k: o[k] = "".join(b)
            k, b = line[1:].split()[0], []
        elif line: b.append(line)
    if k: o[k] = "".join(b)
    return o


PROTEIN_LEVEL = [
    "panel", "strategy", "previous_strategy", "strategy_contains", "register_offset",
    "sensor_accession", "sensor_last_residue", "sensor_element",
    "acceptor_accession", "acceptor_first_residue", "acceptor_element", "intended_element",
    "nominal_old", "nominal_new", "nominal_shift", "triplet_recentred",
    "linker", "linker_len", "protein_len",
    "junction_protein_pos", "junction_nt_pos",
    "heptad_delta", "heptad_in_phase", "up_contrast", "dn_contrast",
    "up_determinacy", "dn_determinacy", "junction_ad_hydrophobic_frac",
    "hbox_native_residue", "hbox_construct_position", "hbox_residue", "protein_seq",
]


def run():
    ok, fail = [], []
    def ck(n, c, d=""):
        ok.append(n) if c else fail.append(f"{n} -- {d}")
    positive_control_check()
    v2 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v2.csv"))}
    v3 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v3.csv"))}
    v4 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v4.csv"))}
    f3, f4 = read_fasta(D / "junctions_v3.fasta"), read_fasta(D / "junctions_v4.fasta")

    ck("v4 has 24 CSV rows and 24 FASTA records", len(v4) == len(f4) == 24, (len(v4), len(f4)))
    ck("v4 design_ids identical to v3 and v2", set(v4) == set(v3) == set(v2))

    # ---- every protein-level column, v4 vs v3 and v4 vs v2
    for src, nm in ((v3, "v3"), (v2, "v2")):
        diffs = {}
        for did in v4:
            for col in PROTEIN_LEVEL:
                if col in src[did] and col in v4[did] and src[did][col] != v4[did][col]:
                    diffs.setdefault(col, []).append(did)
        ck(f"all {len(PROTEIN_LEVEL)} protein-level columns identical v4 vs {nm}", not diffs, diffs)

    # ---- join residue positions
    ck("join residue position (sensor_last_residue) identical for all 24",
       all(v4[d]["sensor_last_residue"] == v3[d]["sensor_last_residue"] for d in v4))
    ck("join residue position (acceptor_first_residue) identical for all 24",
       all(v4[d]["acceptor_first_residue"] == v3[d]["acceptor_first_residue"] for d in v4))
    ck("junction_protein_pos identical for all 24",
       all(v4[d]["junction_protein_pos"] == v3[d]["junction_protein_pos"] for d in v4))
    ck("junction_nt_pos identical for all 24",
       all(v4[d]["junction_nt_pos"] == v3[d]["junction_nt_pos"] for d in v4))

    # ---- deltas per triplet, per offset
    trip = {}
    for d, r in v4.items():
        trip.setdefault((r["sensor_accession"], r["acceptor_accession"], r["strategy"]), {})[
            r["register_offset"]] = r["heptad_delta"]
    trip3 = {}
    for d, r in v3.items():
        trip3.setdefault((r["sensor_accession"], r["acceptor_accession"], r["strategy"]), {})[
            r["register_offset"]] = r["heptad_delta"]
    ck("8 triplets present", len(trip) == 8, len(trip))
    ck("delta at each of the three register offsets identical for all 8 triplets",
       trip == trip3, {k: (trip3[k], trip[k]) for k in trip if trip[k] != trip3.get(k)})

    # ---- recentring decisions
    rec4 = {d: v4[d]["triplet_recentred"] for d in v4}
    rec3 = {d: v3[d]["triplet_recentred"] for d in v3}
    ck("triplet_recentred flag identical for all 24", rec4 == rec3,
       {d: (rec3[d], rec4[d]) for d in rec4 if rec4[d] != rec3[d]})
    nr4 = sorted({(v4[d]["sensor_accession"], v4[d]["acceptor_accession"], v4[d]["strategy"])
                  for d in v4 if v4[d]["triplet_recentred"] == "NO"})
    ck("exactly 2 triplets remain deliberately un-recentred", len(nr4) == 2, nr4)
    ck("they are the two documented ones (PHOQ/linker_retained and MCPX/PHOQ/dhp_direct)",
       {t[2] for t in nr4} == {"linker_retained", "dhp_direct"}
       and any(t[0] == "Q92SH9" for t in nr4), nr4)

    # ---- protein identity, by independent back-translation of the v4 DNA
    bad = [d for d in f4 if translate(f4[d][:-3]) != v3[d]["protein_seq"]]
    ck("v4 DNA back-translates to the v3 protein, byte-identical, for all 24", not bad, bad)
    bad = [d for d in f4 if translate(f4[d][:-3]) != v2[d]["protein_seq"]]
    ck("v4 DNA back-translates to the v2 protein, byte-identical, for all 24", not bad, bad)
    ck("v4 CSV protein_seq equals the back-translation for all 24",
       all(v4[d]["protein_seq"] == translate(f4[d][:-3]) for d in f4))
    ck("all 24 stop codons still TAA", all(f4[d][-3:] == "TAA" for d in f4))
    ck("DNA lengths unchanged v3 -> v4", all(len(f4[d]) == len(f3[d]) for d in f4))

    # ---- H-box
    ck("H-box histidine present in all 24", all(v4[d]["hbox_residue"] == "H" for d in v4),
       {d: v4[d]["hbox_residue"] for d in v4 if v4[d]["hbox_residue"] != "H"})
    ck("H-box construct position identical to v3 for all 24",
       all(v4[d]["hbox_construct_position"] == v3[d]["hbox_construct_position"] for d in v4))
    hb = [d for d in f4
          if translate(f4[d][:-3])[int(v4[d]["hbox_construct_position"]) - 1] != "H"]
    ck("H-box position independently confirmed in the translated v4 protein", not hb, hb)

    # ---- in-phase set
    ip4 = sorted(d for d in v4 if v4[d]["heptad_in_phase"] == "YES")
    ip3 = sorted(d for d in v3 if v3[d]["heptad_in_phase"] == "YES")
    ck(f"the {len(ip3)} in-phase designs are still exactly the same {len(ip3)}", ip4 == ip3,
       (set(ip3) ^ set(ip4)))
    ck("6 designs are in phase", len(ip4) == 6, len(ip4))
    return ok, fail, ip4, nr4


if __name__ == "__main__":
    ok, fail, ip, nr = run()
    print("=" * 78); print("TASK 3  REGISTER-RECENTRING VERIFICATION (v4 vs v3 and v2)"); print("=" * 78)
    for x in ok: print(f"  PASS  {x}")
    for x in fail: print(f"  FAIL  {x}")
    print(f"\n  {len(ok)} passed, {len(fail)} failed")
    print(f"\n  in-phase designs ({len(ip)}): " + ", ".join(ip))
    print(f"  deliberately un-recentred triplets ({len(nr)}): " + "; ".join(str(t) for t in nr))
    sys.exit(1 if fail else 0)
