"""Single source of truth for every sequence check in this repo.

WHY THIS MODULE EXISTS
Enzyme and motif checks used to be reimplemented in each panel script with its
own enzyme list: 13 enzymes in `design_checks.py` and
`design_translational_panel.py`, 15 in `build_order_manifest.py`, 35 in
`design_backgrounds.py` and `check_manifest_v2.py`, and 5 -- the Golden Gate set
alone -- in `junction_design.py`. That is not five views of one check; it is five
different checks wearing the same name, and it produced a recurring defect:

    HP-4 was excluded from the translational panel for an internal NcoI site,
    NcoI being the tier-1 vector's own cloning enzyme. Two panels later, 18 of
    24 kinase constructs carried that same site -- because the kinase panel's
    screen was the 5-enzyme Golden Gate set and could not see it.

The check did not propagate because it was rewritten rather than reused. Every
panel script now imports from here and defines no enzyme list of its own.

THE DEFAULT IS THE FULL CATALOGUE. `site_scan` screens all 35 enzymes on both
strands unless a caller explicitly asks for fewer. Narrowing is a decision a
caller has to make out loud, in one place, with a reason next to it -- which is
exactly what did not happen before.
"""
from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from siga_consensus import EXT10_PWM, score_window as _siga_score, max_score as _siga_max

__all__ = [
    "CATALOGUE", "GOLDEN_GATE", "VECTOR_SITES", "PROVENANCE_DERIVED",
    "HOST_RM", "HOST_RM_SOURCE", "HOST_RM_EXCLUDED", "host_rm_scan", "iupac_regex", "IUPAC",
    "Site", "MotifHit", "site_scan", "sigA_scan", "sd_atg_scan", "basic_checks",
    "junction_aware", "positive_control_check", "ComponentMapError",
    "revcomp", "gc", "homopolymers", "fmt_sites", "fmt_site",
    "SIGA_THRESHOLD", "SIGA_WIDTH", "SIGA_MAX", "SD_MOTIFS",
]

# ============================================================ 1. THE CATALOGUE
# One constant. Every caller reads this; nobody redefines it.
#
# Insertion order is the historical order the repo built the list up in, and it
# is load-bearing for reporting: `site_scan` emits hits enzyme-by-enzyme in
# catalogue order so refactored scripts reproduce their previous output exactly
# for the enzymes they already screened.
CATALOGUE: dict[str, str] = {
    # Type IIS -- the selected Golden Gate assembly route
    "BsaI": "GGTCTC", "BsmBI": "CGTCTC", "BbsI": "GAAGAC", "SapI": "GCTCTTC", "AarI": "CACCTGC",
    # the original 10-enzyme MCS working list
    "EcoRI": "GAATTC", "BamHI": "GGATCC", "HindIII": "AAGCTT", "NcoI": "CCATGG", "NdeI": "CATATG",
    "XbaI": "TCTAGA", "SalI": "GTCGAC", "PstI": "CTGCAG", "KpnI": "GGTACC", "SacI": "GAGCTC",
    # added when provenance scanning found them inside SOURCED sequence
    "NsiI": "ATGCAT", "SphI": "GCATGC", "XhoI": "CTCGAG", "NotI": "GCGGCCGC", "SpeI": "ACTAGT",
    "SmaI": "CCCGGG", "ApaI": "GGGCCC", "ClaI": "ATCGAT", "EcoRV": "GATATC", "HpaI": "GTTAAC",
    "MluI": "ACGCGT", "NheI": "GCTAGC", "PvuII": "CAGCTG", "ScaI": "AGTACT", "StuI": "AGGCCT",
    "AflII": "CTTAAG", "AvrII": "CCTAGG", "BglII": "AGATCT", "SspI": "AATATT", "DraI": "TTTAAA",
}

# Named SUBSETS of the catalogue -- names only, so a site sequence is defined once.
GOLDEN_GATE: tuple[str, ...] = ("BsaI", "BsmBI", "BbsI", "SapI", "AarI")
VECTOR_SITES: tuple[str, ...] = ("NcoI", "NdeI")          # pECXT99A opening (Henke et al. 2021)
# Enzymes that were invisible to a plan-derived list and only ever surfaced by
# scanning the PROVENANCE of sourced components. Kept as a named subset so the
# lesson is greppable, not folklore.
PROVENANCE_DERIVED: tuple[str, ...] = (
    "NcoI", "NsiI", "SphI", "ScaI", "StuI", "EcoRV", "XhoI", "MluI", "BamHI",
)

for _s in (GOLDEN_GATE, VECTOR_SITES, PROVENANCE_DERIVED):
    _missing = [e for e in _s if e not in CATALOGUE]
    assert not _missing, f"subset names not in CATALOGUE: {_missing}"
assert len(CATALOGUE) == 35, f"catalogue is {len(CATALOGUE)} enzymes, expected 35"

# ==================================== HOST RESTRICTION-MODIFICATION SUBSET
# The 35-enzyme CATALOGUE above is COMMERCIAL CLONING enzymes. It is a different
# set from the HOST's own restriction system, and screening one does not screen
# the other. A construct carrying a host R-M site can be degraded on entry and
# never establish -- a failure that looks like a dead design, not a restriction
# event.
#
# EVERY MOTIF BELOW IS QUOTED FROM A FETCHED, CACHED SOURCE. None is written
# from memory: a wrong motif produces a screen that looks clean and means
# nothing. Source file: data/cache/rebase/link_orgref.txt (REBASE version 608,
# build dated Jul 31 2026, downloaded from http://rebase.neb.com/rebase/link_orgref).
#
# Motifs are IUPAC-degenerate, so they need iupac_regex/host_rm_scan rather than
# the literal-string matching site_scan uses. They are deliberately NOT added to
# CATALOGUE: that constant is the commercial cloning set, its members are
# ACGT-only, and conflating the two is the exact error this subset exists to
# prevent.
HOST_RM = {
    "CglI":       "GCSGC",      # S = C or G
    "Cgl13032I":  "GGCGCA",
    "Cgl13032II": "ACGABGG",    # B = C, G or T
}
HOST_RM_SOURCE = {
    "CglI": dict(
        rebase_recognition="GCSGC", rebase_prototype="TauI",
        microorganism="Corynebacterium glutamicum", rebase_source_strain="ATCC 13032",
        methylation="?(5)  (5-methylcytosine, position not specified)",
        activity="restriction endonuclease + cognate methyltransferase",
        status="characterised",
        note="Prototype TauI is a characterised, commercially available Type II REase "
             "cutting GCSG^C (REBASE 608). The C. glutamicum system is encoded by "
             "cglIM/cglIR/cglIIR and is documented as a transformation barrier.",
        citation="REBASE v608 (Roberts, R.J.), record CglI; ref therein Ikeda, M. & "
                 "Nakagawa, S. (2003) Appl. Microbiol. Biotechnol. 62:99-109"),
    "Cgl13032I": dict(
        rebase_recognition="GGCGCA", rebase_prototype="",
        microorganism="Corynebacterium glutamicum ATCC 13032", rebase_source_strain="S. Binder",
        methylation="6(6)  (N6-methyladenine at position 6)",
        activity="methyltransferase specificity; cognate restriction activity NOT STATED",
        status="specificity recorded in REBASE from unpublished observations",
        note="No prototype, no commercial availability, methylation site given -- REBASE's "
             "signature for a methylome-detected MTase specificity. Whether a cognate "
             "endonuclease exists is not stated by the source.",
        citation="REBASE v608, record Cgl13032I; ref Morgan, R.D., unpublished observations"),
    "Cgl13032II": dict(
        rebase_recognition="ACGABGG", rebase_prototype="",
        microorganism="Corynebacterium glutamicum ATCC 13032", rebase_source_strain="S. Binder",
        methylation="4(6)  (N6-methyladenine at position 4)",
        activity="methyltransferase specificity; cognate restriction activity NOT STATED",
        status="specificity recorded in REBASE from unpublished observations",
        note="Same signature as Cgl13032I.",
        citation="REBASE v608, record Cgl13032II; ref Binder, S., Schendzielorz, G., "
                 "Staebler, N., Krumbach, K., Hoffmann, K., Bott, M., Eggeling, L., "
                 "unpublished observations"),
}
# Present in REBASE for the species but deliberately NOT screened, with the reason.
HOST_RM_EXCLUDED = {
    "CglAI":   "recognition GCATGC (SphI), but REBASE source is strain 'NEB 968', NOT ATCC 13032. "
               "Screening a different strain's enzyme against this host would be a false constraint.",
    "CglAII":  "recognition GTCGAC (SalI), REBASE source strain 'NEB 968', NOT ATCC 13032.",
    "Cgl165I": "REBASE recognition sequence is literally '?' -- [NOT FOUND]. Excluded rather than "
               "guessed. Source strain is C. glutamicum 165, not ATCC 13032, in any case.",
}
IUPAC = {"A": "A", "C": "C", "G": "G", "T": "T",
         "R": "AG", "Y": "CT", "S": "CG", "W": "AT", "K": "GT", "M": "AC",
         "B": "CGT", "D": "AGT", "H": "ACT", "V": "ACG", "N": "ACGT"}

SIGA_THRESHOLD = 0.55                    # fraction of PWM max, repo convention
SIGA_WIDTH = EXT10_PWM["width"]
SIGA_MAX = _siga_max(EXT10_PWM)
SD_MOTIFS = r"GGAGG|AGGAG|GGAG"          # repo convention, longest-first
_COMPLEMENT = str.maketrans("ACGTN", "TGCAN")


def revcomp(s: str) -> str:
    return s.translate(_COMPLEMENT)[::-1]


def gc(s: str):
    return 100 * (s.count("G") + s.count("C")) / len(s) if s else None


# ================================================================ result types
@dataclass(frozen=True)
class Site:
    enzyme: str
    site: str
    start: int          # 0-based, always in FORWARD-strand coordinates
    end: int
    strand: str         # "+" or "-"
    components: tuple = field(default=())
    spans_junction: bool = False

    def key(self):
        """Identity of a physical finding, for set comparison across runs."""
        return (self.enzyme, self.start, self.strand)


@dataclass(frozen=True)
class MotifHit:
    kind: str           # "sigA_ext10" | "sd_atg"
    start: int
    end: int
    strand: str
    score: float | None
    detail: str
    components: tuple = field(default=())
    spans_junction: bool = False

    def key(self):
        return (self.kind, self.start, self.strand, self.detail)


def fmt_site(h: Site) -> str:
    """The repo's long-standing `Name@pos(strand)` string form."""
    return f"{h.enzyme}@{h.start}({h.strand})"


def fmt_sites(hits) -> list[str]:
    return [fmt_site(h) for h in hits]


# ============================================================== 2. site_scan
def site_scan(sequence: str, enzymes=None, both_strands: bool = True) -> list[Site]:
    """Every recognition site in `sequence`, on both strands by default.

    `enzymes` defaults to the FULL 35-enzyme CATALOGUE. A caller wanting fewer
    must name them -- e.g. `site_scan(dna, enzymes=GOLDEN_GATE)` -- so that every
    narrowing is explicit and greppable. Passing a narrower list is what caused
    the HP-4/kinase NcoI collision, so it is deliberately the harder path.

    Minus-strand hits are reported in FORWARD-strand coordinates, so `start` is
    directly comparable between strands and across constructs. A palindromic
    site therefore yields two Sites at the same `start`, one per strand.
    """
    if enzymes is None:
        enzymes = list(CATALOGUE)
    unknown = [e for e in enzymes if e not in CATALOGUE]
    if unknown:
        raise KeyError(f"enzyme(s) not in CATALOGUE: {unknown}")
    seq = sequence.upper()
    rc = revcomp(seq) if both_strands else None
    n = len(seq)
    out: list[Site] = []
    for name in enzymes:
        s = CATALOGUE[name]
        for m in re.finditer(s, seq):
            out.append(Site(name, s, m.start(), m.end(), "+"))
        if both_strands:
            for m in re.finditer(s, rc):
                out.append(Site(name, s, n - m.end(), n - m.start(), "-"))
    return out


def iupac_regex(motif: str) -> str:
    """IUPAC-degenerate motif -> regex character classes. Raises on an unknown code."""
    out = []
    for ch in motif.upper():
        if ch not in IUPAC:
            raise KeyError(f"unknown IUPAC code {ch!r} in motif {motif!r}")
        cl = IUPAC[ch]
        out.append(cl if len(cl) == 1 else f"[{cl}]")
    return "".join(out)


def host_rm_scan(sequence: str, motifs=None, both_strands: bool = True) -> list[Site]:
    """Scan for HOST restriction-modification recognition motifs (IUPAC-degenerate).

    Separate from `site_scan` because these motifs are degenerate and because the
    host's own R-M system is a different question from the commercial cloning
    catalogue: `site_scan` asks "can I still cut this with my enzymes", this asks
    "will the host destroy this DNA on entry".

    `motifs` defaults to HOST_RM. Minus-strand hits are reported in forward
    coordinates, as in `site_scan`. Overlapping occurrences are all reported
    (lookahead), because two overlapping sites are two substrates.
    """
    table = HOST_RM if motifs is None else (
        {k: HOST_RM[k] for k in motifs} if not isinstance(motifs, dict) else motifs)
    seq = sequence.upper()
    rc = revcomp(seq) if both_strands else None
    n = len(seq)
    out: list[Site] = []
    for name, motif in table.items():
        pat = re.compile("(?=(" + iupac_regex(motif) + "))")
        for m in pat.finditer(seq):
            out.append(Site(name, motif, m.start(), m.start() + len(motif), "+"))
        if both_strands:
            for m in pat.finditer(rc):
                out.append(Site(name, motif, n - m.start() - len(motif), n - m.start(), "-"))
    return sorted(out, key=lambda h: (h.start, h.enzyme, h.strand))


# ============================================================== 3. sigA_scan
def sigA_scan(sequence: str, threshold: float = SIGA_THRESHOLD,
              both_strands: bool = False) -> list[MotifHit]:
    """SigA-like extended -10 windows, scored as a FRACTION OF MATRIX MAXIMUM.

    STANDING CAVEAT, carried wherever this output goes. The matrix
    (`scripts/siga_consensus.py`) is a REASONED APPROXIMATION built from the
    TEXTUAL IUPAC consensus of Patek & Nesvera 2011 and Pfeifer-Sancar et al.
    2013. It is NOT a PWM trained on aligned, confirmed C. glutamicum promoters,
    and no such alignable table was found in the sources checked for this
    project. A clean scan therefore means "no consensus-like cryptic promoter",
    NOT "no cryptic promoter". Scores are a screening signal, never a
    calibrated probability.

    Sense strand only by default: the question the panels ask is whether a
    cryptic promoter drives the reporter. `both_strands=True` adds antisense
    windows, reported in forward coordinates with strand "-".
    """
    seq = sequence.upper()
    out: list[MotifHit] = []
    w, mx = SIGA_WIDTH, SIGA_MAX

    def _scan(s, strand):
        n = len(s)
        for i in range(n - w + 1):
            f = _siga_score(s[i:i + w], EXT10_PWM) / mx
            if f >= threshold:
                a, b = (i, i + w) if strand == "+" else (n - i - w, n - i)
                out.append(MotifHit("sigA_ext10", a, b, strand, round(f, 3), s[i:i + w]))

    _scan(seq, "+")
    if both_strands:
        _scan(revcomp(seq), "-")
    return out


def sigA_best(sequence: str):
    """(start, fraction_of_max) of the single best sense-strand window."""
    seq = sequence.upper()
    best = (None, float("-inf"))
    for i in range(len(seq) - SIGA_WIDTH + 1):
        f = _siga_score(seq[i:i + SIGA_WIDTH], EXT10_PWM) / SIGA_MAX
        if f > best[1]:
            best = (i, f)
    return best[0], round(best[1], 3)


# ============================================================ 4. sd_atg_scan
def sd_atg_scan(sequence: str, known_starts=()) -> list[MotifHit]:
    """Shine-Dalgarno-like motif followed by an ATG at initiation-plausible spacing.

    Repo convention, preserved exactly: SD core GGAGG/AGGAG/GGAG, then an ATG
    beginning 3-14 nt after the end of that motif. `known_starts` holds the
    design's OWN intended start positions (a fore-cistron AUG, a CDS initiator),
    which are excluded -- everything else is a candidate for unintended
    internal initiation.
    """
    seq = sequence.upper()
    known = set(known_starts)
    out: list[MotifHit] = []
    for m in re.finditer(SD_MOTIFS, seq):
        for a in re.finditer("ATG", seq[m.end() + 3:m.end() + 15]):
            pos = m.end() + 3 + a.start()
            if pos in known:
                continue
            out.append(MotifHit(
                "sd_atg", m.start(), pos + 3, "+", None,
                f"SD({m.group(0)}@{m.start()})+ATG@{pos}"))
    return out


# =========================================================== 5. basic_checks
def homopolymers(sequence: str, max_run: int = 6) -> list[dict]:
    """Runs STRICTLY LONGER than `max_run` (default: runs of 7 or more)."""
    n = max_run + 1
    return [{"base": m.group(0)[0], "run": len(m.group(0)), "start": m.start()}
            for m in re.finditer(r"(A{%d,}|C{%d,}|G{%d,}|T{%d,})" % ((n,) * 4), sequence.upper())]


def basic_checks(sequence: str) -> dict:
    seq = sequence.upper()
    return {
        "length_bp": len(seq),
        "GC_percent": None if not seq else round(gc(seq), 2),
        "homopolymers_gt6": homopolymers(seq),
        "n_homopolymers_gt6": len(homopolymers(seq)),
    }


# ========================================================== 6. junction_aware
class ComponentMapError(AssertionError):
    """The component map does not reproduce the construct sequence."""


def _normalise_map(construct_sequence: str, component_map):
    """Accept [(label,start,end)] or [(label,subsequence)] and return the triple form."""
    out, cursor = [], 0
    for item in component_map:
        if len(item) == 3:
            lab, a, b = item
            out.append((lab, int(a), int(b)))
        elif len(item) == 2:
            lab, sub = item
            out.append((lab, cursor, cursor + len(sub)))
            cursor += len(sub)
        else:
            raise ComponentMapError(f"component entry must be (label,start,end) or (label,seq): {item!r}")
    return out


def verify_component_map(construct_sequence: str, component_map) -> list[tuple]:
    """Assert the map tiles the construct exactly. Raises ComponentMapError if not.

    Without this, every 'this hit spans a junction' claim is guesswork: the
    junction coordinates would be asserted rather than known. Four defects in
    this project lived exactly at a component boundary, so the boundaries have
    to be proven, not assumed.
    """
    seq = construct_sequence.upper()
    bnds = _normalise_map(seq, component_map)
    if not bnds:
        raise ComponentMapError("component map is empty")
    ordered = sorted(bnds, key=lambda x: x[1])
    if ordered != bnds:
        raise ComponentMapError("component map is not in ascending coordinate order")
    for (l1, a1, b1), (l2, a2, b2) in zip(bnds, bnds[1:]):
        if b1 != a2:
            raise ComponentMapError(
                f"component map has a {'gap' if b1 < a2 else 'overlap'} between "
                f"{l1}[{a1}:{b1}] and {l2}[{a2}:{b2}]")
    if bnds[0][1] != 0 or bnds[-1][2] != len(seq):
        raise ComponentMapError(
            f"component map covers [{bnds[0][1]}:{bnds[-1][2]}] but the construct is 0:{len(seq)}")
    rebuilt = "".join(seq[a:b] for _l, a, b in bnds)
    if rebuilt != seq:
        raise ComponentMapError("component map does not reproduce the construct sequence base-for-base")
    return bnds


def _attribute(lo: int, hi: int, bnds):
    return tuple(lab for lab, a, b in bnds if a < hi and lo < b)


def junction_aware(construct_sequence: str, component_map, enzymes=None,
                   siga_threshold: float = SIGA_THRESHOLD, siga_both_strands: bool = True,
                   known_starts=()) -> dict:
    """Run every scan on the WHOLE construct and classify each hit by boundary.

    Returns {"boundaries", "sites", "sigA", "sd_atg", "basic"} where each hit
    carries `components` (everything it overlaps) and `spans_junction`
    (True when it overlaps more than one). A junction-spanning hit is created by
    two components MEETING and is invisible to any component-level check --
    the defect class this repo has hit four times.

    Raises ComponentMapError if the map does not reproduce the construct.
    """
    seq = construct_sequence.upper()
    bnds = verify_component_map(seq, component_map)

    def _mark(hits):
        out = []
        for h in hits:
            comps = _attribute(h.start, h.end, bnds)
            out.append(type(h)(**{**h.__dict__, "components": comps,
                                  "spans_junction": len(comps) > 1}))
        return out

    return {
        "boundaries": bnds,
        "sites": _mark(site_scan(seq, enzymes=enzymes)),
        "sigA": _mark(sigA_scan(seq, threshold=siga_threshold, both_strands=siga_both_strands)),
        "sd_atg": _mark(sd_atg_scan(seq, known_starts=known_starts)),
        "basic": basic_checks(seq),
    }


# ===================================================== 7. positive_control_check
_PC_CACHE = {"passed": False}


def positive_control_check(force: bool = False) -> list[str]:
    """Prove every scanner FINDS a known positive before any null is trusted.

    A zero from a broken scanner is indistinguishable from a real zero. Any
    script that reports a zero result must call this first; it raises
    AssertionError naming the scanner that failed.
    """
    if _PC_CACHE["passed"] and not force:
        return _PC_CACHE["log"]
    log = []

    def ck(name, cond, detail=""):
        if not cond:
            raise AssertionError(f"POSITIVE CONTROL FAILED -- {name}"
                                 + (f" ({detail})" if detail else ""))
        log.append(name)

    # -- site_scan: sense strand, exact position
    h = site_scan("AAA" + CATALOGUE["BsaI"] + "AAA", enzymes=["BsaI"])
    ck("site_scan finds a sense-strand site at the right position",
       [(x.enzyme, x.start, x.strand) for x in h] == [("BsaI", 3, "+")], str(h))
    # -- site_scan: non-palindromic site present ONLY on the minus strand
    h = site_scan("AAA" + revcomp(CATALOGUE["BsaI"]) + "AAA", enzymes=["BsaI"])
    ck("site_scan finds a minus-strand-only site, in forward coordinates",
       [(x.enzyme, x.start, x.strand) for x in h] == [("BsaI", 3, "-")], str(h))
    # -- site_scan: palindrome reported on both strands at the same coordinate
    h = site_scan("AA" + CATALOGUE["NcoI"] + "AA", enzymes=["NcoI"])
    ck("site_scan reports a palindrome on both strands at one coordinate",
       sorted((x.start, x.strand) for x in h) == [(2, "+"), (2, "-")], str(h))
    # -- site_scan: both_strands=False really does suppress the minus strand
    ck("site_scan(both_strands=False) suppresses minus-strand hits",
       site_scan("AAA" + revcomp(CATALOGUE["BsaI"]) + "AAA", enzymes=["BsaI"],
                 both_strands=False) == [])
    # -- site_scan: the DEFAULT is the whole catalogue, not a subset
    ck("site_scan defaults to the full 35-enzyme catalogue",
       len(site_scan(CATALOGUE["XhoI"] + CATALOGUE["ScaI"])) >= 2
       and any(x.enzyme == "XhoI" for x in site_scan(CATALOGUE["XhoI"])))
    # -- site_scan: every catalogue entry is findable (no typo'd site string)
    dead = [e for e, s in CATALOGUE.items() if not site_scan("TT" + s + "TT", enzymes=[e])]
    ck("every one of the 35 catalogue sites is detectable", not dead, str(dead))
    # -- site_scan: rejects an unknown enzyme name rather than silently skipping it
    try:
        site_scan("AAAA", enzymes=["NotAnEnzyme"])
        raise RuntimeError
    except KeyError:
        log.append("site_scan rejects an unknown enzyme name")
    except RuntimeError:
        raise AssertionError("POSITIVE CONTROL FAILED -- site_scan silently accepted an unknown enzyme")

    # -- sigA_scan: the exact consensus must score 1.000 of max
    cons = EXT10_PWM["consensus"].upper().replace("Y", "T").replace("N", "A")
    h = sigA_scan("GGGG" + cons + "GGGG")
    ck("sigA_scan finds the exact consensus at 1.000 of max",
       any(x.score == 1.0 and x.start == 4 for x in h), str(h))
    ck("sigA_scan finds nothing in a G-tract", not sigA_scan("G" * 40))
    h = sigA_scan("GGGG" + revcomp(cons) + "GGGG", both_strands=True)
    ck("sigA_scan(both_strands=True) finds an antisense consensus",
       any(x.strand == "-" and x.score == 1.0 for x in h), str(h))

    # -- sd_atg_scan
    h = sd_atg_scan("TTGGAGGTTTTATGCC")
    ck("sd_atg_scan finds SD+ATG at plausible spacing",
       [(x.start, x.end, x.detail) for x in h] == [(2, 14, "SD(GGAGG@2)+ATG@11")], str(h))
    ck("sd_atg_scan honours known_starts",
       sd_atg_scan("TTGGAGGTTTTATGCC", known_starts=[11]) == [])

    # -- basic_checks
    b = basic_checks("AAAAAAAGGCC")
    ck("basic_checks finds a run of 7", b["n_homopolymers_gt6"] == 1, str(b))
    ck("basic_checks does NOT fire on a run of 6", basic_checks("AAAAAAGG")["n_homopolymers_gt6"] == 0)
    ck("basic_checks computes GC and length", basic_checks("GGCCAATT") == {
        "length_bp": 8, "GC_percent": 50.0, "homopolymers_gt6": [], "n_homopolymers_gt6": 0})

    # -- host_rm_scan: degenerate motifs, both strands, and the IUPAC expansion itself
    ck("iupac_regex expands S to [CG] and B to [CGT]",
       iupac_regex("GCSGC") == "GC[CG]GC" and iupac_regex("ACGABGG") == "ACGA[CGT]GG",
       (iupac_regex("GCSGC"), iupac_regex("ACGABGG")))
    try:
        iupac_regex("GCZGC"); raise RuntimeError
    except KeyError:
        log.append("iupac_regex rejects an unknown IUPAC code")
    except RuntimeError:
        raise AssertionError("POSITIVE CONTROL FAILED -- iupac_regex accepted a bad IUPAC code")
    ck("host_rm_scan finds BOTH resolutions of a degenerate motif",
       {h.start for h in host_rm_scan("TT" + "GCCGC" + "TT", motifs=["CglI"], both_strands=False)} == {2}
       and {h.start for h in host_rm_scan("TT" + "GCGGC" + "TT", motifs=["CglI"], both_strands=False)} == {2})
    ck("host_rm_scan finds every host motif in its own fixture",
       all(any(h.enzyme == k for h in host_rm_scan("TT" + v.replace("S", "C").replace("B", "C") + "TT"))
           for k, v in HOST_RM.items()),
       [k for k, v in HOST_RM.items()
        if not any(h.enzyme == k for h in host_rm_scan("TT" + v.replace("S", "C").replace("B", "C") + "TT"))])
    ck("host_rm_scan reports minus-strand hits in forward coordinates",
       [(h.enzyme, h.start, h.strand) for h in
        host_rm_scan("AAAA" + revcomp("GGCGCA") + "AAAA", motifs=["Cgl13032I"])]
       == [("Cgl13032I", 4, "-")],
       host_rm_scan("AAAA" + revcomp("GGCGCA") + "AAAA", motifs=["Cgl13032I"]))
    ck("host_rm_scan finds OVERLAPPING occurrences",
       len(host_rm_scan("GCCGCCGC", motifs=["CglI"], both_strands=False)) == 2,
       host_rm_scan("GCCGCCGC", motifs=["CglI"], both_strands=False))
    ck("host_rm_scan finds nothing in a motif-free fixture",
       not host_rm_scan("A" * 40))
    ck("host_rm motifs are NOT in the commercial CATALOGUE (the two sets stay distinct)",
       not (set(HOST_RM) & set(CATALOGUE)))

    # -- junction_aware: a site that exists ONLY because two components meet
    a, b = "AAAAGGTC", "TCTTTTTT"          # BsaI GGTCTC formed across the a|b join
    r = junction_aware(a + b, [("compA", a), ("compB", b)])
    ck("junction_aware finds a site created by two components meeting",
       any(x.enzyme == "BsaI" and x.spans_junction for x in r["sites"]), str(r["sites"]))
    # -- junction_aware: a site wholly inside one component is NOT called junction-spanning
    r = junction_aware("AAGGTCTCAA" + "GGGG", [("compA", "AAGGTCTCAA"), ("compB", "GGGG")])
    ck("junction_aware does not mis-call a within-component site as spanning",
       [x.spans_junction for x in r["sites"] if x.enzyme == "BsaI"] == [False], str(r["sites"]))
    # -- junction_aware: a SigA element spanning a join
    r = junction_aware("GGGG" + cons + "GGGG", [("l", "GGGG"), ("m", cons), ("r", "GGGG")])
    ck("junction_aware classifies a SigA window that crosses a boundary",
       any(x.kind == "sigA_ext10" and x.score == 1.0 for x in r["sigA"]), str(r["sigA"]))
    # -- junction_aware: the map assertion actually fires
    for bad, why in (([("x", 0, 4)], "short map"),
                     ([("x", 0, 4), ("y", 5, 8)], "gap"),
                     ([("x", 0, 5), ("y", 4, 8)], "overlap"),
                     ([], "empty map")):
        try:
            junction_aware("AAAACCCC", bad)
            raise RuntimeError(why)
        except ComponentMapError:
            pass
        except RuntimeError:
            raise AssertionError(f"POSITIVE CONTROL FAILED -- junction_aware accepted a bad map ({why})")
    log.append("junction_aware rejects a map with a gap, an overlap, a short span, or no entries")
    ck("junction_aware accepts a correct map", len(junction_aware(
        "AAAACCCC", [("x", 0, 4), ("y", 4, 8)])["boundaries"]) == 2)

    _PC_CACHE.update(passed=True, log=log)
    return log


if __name__ == "__main__":
    passed = positive_control_check(force=True)
    print(f"seqchecks positive controls: {len(passed)} checks, all PASS")
    for p in passed:
        print(f"  PASS  {p}")
    print(f"\ncatalogue: {len(CATALOGUE)} enzymes")
    print(f"  Golden Gate subset      : {list(GOLDEN_GATE)}")
    print(f"  vector opening subset   : {list(VECTOR_SITES)}")
    print(f"  provenance-derived subset: {list(PROVENANCE_DERIVED)}")
