"""Task 2: apply the organism-prefix protein naming convention repo-wide.

WHY. In C. glutamicum the response regulator is named PhoR and its sensor
kinase PhoS -- INVERTED relative to the B. subtilis PhoP/PhoR convention used
in most of the literature. This design imports Salmonella PhoP into a host
that already contains a protein called PhoR doing the same job. Two different
proteins, confusable names, one letter apart. Every protein reference is
therefore given an organism prefix.

WHAT IS AND IS NOT REWRITTEN.
  rewritten : scripts, run_*.py, README, derived CSV/JSON/TXT outputs under
              results/ and designs/, and the derived ledgers data/manifest.csv,
              data/resolved_loci.json, data/sites_manifest.csv
  EXEMPT    : data/cache/** and data/fasta/**   -- fetched records, must stay
              byte-identical to source
  EXEMPT    : results/hits_all.csv `nearest_gene_product` -- verbatim product
              descriptions copied out of the BX927147.1 feature table; these are
              fetched annotation text, and rewriting them would falsify the
              annotation the hit is anchored to
  EXEMPT    : results/REPORT.md, results/REPORT_crosstalk.md,
              designs/REPORT_promoter.md -- write-protected by the task
  EXEMPT    : PROTECTED_STRINGS below -- literals that are API query parameters
              or lookup keys into cached JSON. Renaming these would break the
              code against the cached records we are forbidden to modify.

DISAMBIGUATION. Only "PhoP" is genuinely ambiguous: this repo contains both
Salmonella PhoP (P0DM78, the donor) and E. coli PhoP (P23836, the proxy whose
sites built the original PWM). Every other token maps to exactly one organism
(PhoQ->Salmonella, PhoR/PhoS->C. glutamicum, OmpR/EnvZ/NarL/NarX->E. coli).
PhoP is resolved by accession where a column carries one, otherwise by organism
words on the same line, otherwise by a per-file default -- and EVERY
default-resolved occurrence is logged so the guess is auditable.
"""
import csv
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ----------------------------------------------------------------- mapping
DONOR_BY_ACCESSION = {
    "P0DM78": "Sal_PhoP", "P0DM80": "Sal_PhoQ",
    "P23836": "Ec_PhoP",                       # extension: the task's scheme omits E. coli PhoP,
                                               # but this repo uses it as the proxy donor
    "P0AA16": "Ec_OmpR", "P0AEJ4": "Ec_EnvZ", "P0AF28": "Ec_NarL",
}
# unambiguous single-organism tokens, longest-first so CgtR10/CgtR11 are not
# clipped by the CgtR1 rule
UNAMBIGUOUS = [
    ("PhoR-associated RR", "Cg_PhoR(CgtR3)"),
    ("CgtR2/MprA", "Cg_MprA(CgtR2)"), ("RegX3/CgtR4", "Cg_RegX3(CgtR4)"),
    ("CopR/CgtR9", "Cg_CopR(CgtR9)"), ("ChrA/CgtR8", "Cg_ChrA(CgtR8)"),
    ("HrrA/CgtR11", "Cg_HrrA(CgtR11)"), ("PhoS(CgtS3)", "Cg_PhoS(CgtS3)"),
    ("CgtR10", "Cg_CgtR10"), ("CgtR11", "Cg_CgtR11"),
    ("CgtS10", "Cg_CgtS10"), ("CgtS11", "Cg_CgtS11"),
    ("CgtR1", "Cg_CgtR1"), ("CgtR2", "Cg_CgtR2"), ("CgtR3", "Cg_CgtR3"),
    ("CgtR4", "Cg_CgtR4"), ("CgtR5", "Cg_CgtR5"), ("CgtR6", "Cg_CgtR6"),
    ("CgtR7", "Cg_CgtR7"), ("CgtR8", "Cg_CgtR8"), ("CgtR9", "Cg_CgtR9"),
    ("CgtS1", "Cg_CgtS1"), ("CgtS2", "Cg_CgtS2"), ("CgtS3", "Cg_CgtS3"),
    ("CgtS4", "Cg_CgtS4"), ("CgtS5", "Cg_CgtS5"), ("CgtS6", "Cg_CgtS6"),
    ("CgtS7", "Cg_CgtS7"), ("CgtS9", "Cg_CgtS9"),
    ("MtrA", "Cg_MtrA"), ("MtrB", "Cg_MtrB"), ("MprA", "Cg_MprA"),
    ("CopR", "Cg_CopR"), ("HrrA", "Cg_HrrA"), ("ChrA", "Cg_ChrA"),
    ("ChrS", "Cg_ChrS"), ("CitA", "Cg_CitA"), ("CitB", "Cg_CitB"),
    ("RegX3", "Cg_RegX3"), ("PhoS", "Cg_PhoS"), ("PhoR", "Cg_PhoR"),
    ("PhoQ", "Sal_PhoQ"),
    ("OmpR", "Ec_OmpR"), ("EnvZ", "Ec_EnvZ"), ("NarL", "Ec_NarL"), ("NarX", "Ec_NarX"),
]
# forward-looking, for the chemoreceptor ligand-binding-domain donors named in the
# convention but not yet present anywhere in this repo (verified by search)
FORWARD_ONLY = {"PctD": "Pa_PctD", "PacA": "Pat_PacA", "McpX": "Sm_McpX"}

SAL_WORDS = re.compile(r"Salmonella|Typhimurium|PRODORIC|MX000339|P0DM78|P0DM80|salmonella", re.I)
EC_WORDS = re.compile(r"E\.\s*coli|Escherichia|K-?12|MG1655|RegulonDB|P23836|ecoli|_ecoli", re.I)

# Literals that are API query parameters or keys into cached JSON. Renaming any of
# these silently breaks the fetch/parse code against records we cannot modify.
PROTECTED_STRINGS = [
    'fetch_regulondb("PhoP"',
    'n["label"] == "PhoP"',
    '("PhoP", "phop_ecoli_regulon.json")',
    '("OmpR", "ompr_ecoli_regulon.json")',
]

PER_FILE_DEFAULT = {
    # E. coli-site context: the PWM, the scan, and everything built from RegulonDB sites
    "scripts/build_pwm.py": "Ec_PhoP", "scripts/prepare_sites.py": "Ec_PhoP",
    "scripts/fetch_scan_data.py": "Ec_PhoP", "run_scan_pipeline.py": "Ec_PhoP",
    "scripts/intergenic_null.py": "Ec_PhoP", "scripts/annotate_hits.py": "Ec_PhoP",
    "results/pwm.txt": "Ec_PhoP", "results/pwm_intergenic.txt": "Ec_PhoP",
    "results/intergenic_null.csv": "Ec_PhoP", "results/hits_high_concern.csv": "Ec_PhoP",
    # Salmonella-donor context: the imported protein and the operator sites used in the designs
    "scripts/salmonella_pwm.py": "Sal_PhoP", "scripts/fetch_prodoric_salmonella.py": "Sal_PhoP",
    "scripts/lysc_leakiness.py": "Sal_PhoP", "scripts/design_promoter_panel.py": "Sal_PhoP",
    "scripts/design_translational_panel.py": "Sal_PhoP", "results/pwm_salmonella.txt": "Sal_PhoP",
    "designs/variants.csv": "Sal_PhoP", "designs/REPORT_translational.md": "Sal_PhoP",
    "designs/lysc_resolution.md": "Sal_PhoP", "results/lysc_analysis.md": "Sal_PhoP",
    "results/REPORT_followup.md": "Sal_PhoP", "run_followup.py": "Sal_PhoP",
    "README.md": "Sal_PhoP",
    "scripts/identity_matrix.py": "Sal_PhoP", "scripts/verify_crosstalk_report.py": "Sal_PhoP",
    "scripts/siga_consensus.py": "Sal_PhoP",
}

EXEMPT_DIRS = ("data/cache/", "data/fasta/", "__pycache__", ".git")
WRITE_PROTECTED = {"results/REPORT.md", "results/REPORT_crosstalk.md", "designs/REPORT_promoter.md"}

log = []


def rename_text(text: str, relpath: str):
    """Apply the convention to free text / code, protecting API + cache-key literals."""
    default = PER_FILE_DEFAULT.get(relpath)
    # 1. mask protected literals so no rule can touch them
    masks = {}
    for i, lit in enumerate(PROTECTED_STRINGS):
        if lit in text:
            key = f"\x00PROT{i}\x00"
            masks[key] = lit
            text = text.replace(lit, key)

    # 2. organism-adjacent compounds first (collapse "Salmonella PhoP" -> "Sal_PhoP")
    pairs = [
        (r"\bSalmonella\s+PhoP\b", "Sal_PhoP"), (r"\bSalmonella\s+PhoQ\b", "Sal_PhoQ"),
        (r"\bS\.\s*Typhimurium\s+PhoP\b", "Sal_PhoP"),
        (r"\bE\.\s*coli\s+PhoP\b", "Ec_PhoP"), (r"\bE\.\s*coli\s+OmpR\b", "Ec_OmpR"),
        (r"\bPhoQ/PhoP\b", "Sal_PhoQ/Sal_PhoP"), (r"\bPhoP/PhoQ\b", "Sal_PhoP/Sal_PhoQ"),
        (r"\bEnvZ/OmpR\b", "Ec_EnvZ/Ec_OmpR"), (r"\bOmpR/EnvZ\b", "Ec_OmpR/Ec_EnvZ"),
    ]
    for pat, rep in pairs:
        text = re.sub(pat, rep, text)

    # 3. unambiguous single-organism tokens. Substituted output is parked in a
    #    placeholder so that a LATER rule cannot fire on a name we just wrote --
    #    without this, "CopR/CgtR9" -> "Cg_CopR(CgtR9)" is then re-matched by the
    #    CgtR9 rule and becomes "Cg_CopR(Cg_CgtR9)".
    subs = {}
    for i, (old, new) in enumerate(UNAMBIGUOUS):
        key = f"\x00N{i}\x00"
        pat = r"(?<![\w_])" + re.escape(old) + r"(?![\w])"
        if re.search(pat, text):
            subs[key] = new
            text = re.sub(pat, key, text)

    # 4. remaining bare PhoP -> per-line organism context, else per-file default
    out_lines = []
    for ln, line in enumerate(text.split("\n"), 1):
        if re.search(r"(?<![\w_])PhoP(?![\w])", line):
            if SAL_WORDS.search(line) and not EC_WORDS.search(line):
                repl, how = "Sal_PhoP", "line-context:Salmonella"
            elif EC_WORDS.search(line) and not SAL_WORDS.search(line):
                repl, how = "Ec_PhoP", "line-context:E.coli"
            elif default:
                repl, how = default, "FILE-DEFAULT"
            else:
                log.append((relpath, ln, "UNRESOLVED", line.strip()[:100]))
                out_lines.append(line)
                continue
            n = len(re.findall(r"(?<![\w_])PhoP(?![\w])", line))
            line = re.sub(r"(?<![\w_])PhoP(?![\w])", repl, line)
            log.append((relpath, ln, f"{how}->{repl} x{n}", line.strip()[:100]))
        out_lines.append(line)
    text = "\n".join(out_lines)

    for key, new in subs.items():
        text = text.replace(key, new)
    for key, lit in masks.items():
        text = text.replace(key, lit)
    return text


def rename_csv_by_accession(path: Path, relpath: str):
    """CSV rows that carry an accession are disambiguated by accession, not by text."""
    rows = list(csv.DictReader(open(path)))
    if not rows:
        return False
    cols = list(rows[0].keys())
    pairs = [(l, a) for l, a in
             [("donor_label", "donor_accession"), ("native_label", "native_accession"),
              ("gene_label", "accession")] if l in cols and a in cols]
    if not pairs:
        return False
    for r in rows:
        for lab, acc in pairs:
            a = (r.get(acc) or "").strip()
            if a in DONOR_BY_ACCESSION:
                r[lab] = DONOR_BY_ACCESSION[a]
            else:
                v = r.get(lab) or ""
                for old, new in UNAMBIGUOUS:
                    if v == old:
                        r[lab] = new
                        break
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    log.append((relpath, 0, "accession-disambiguated", f"{len(rows)} rows, cols={[p[0] for p in pairs]}"))
    return True


def rename_sites_manifest(path: Path, relpath: str):
    """sites_manifest.csv: the `tf` column is disambiguated by its `organism` column."""
    rows = list(csv.DictReader(open(path)))
    cols = list(rows[0].keys())
    for r in rows:
        tf, org = r.get("tf", ""), r.get("organism", "")
        if tf == "PhoP":
            r["tf"] = "Sal_PhoP" if "Salmonella" in org else "Ec_PhoP"
        elif tf == "OmpR":
            r["tf"] = "Ec_OmpR"
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    log.append((relpath, 0, "organism-disambiguated", f"{len(rows)} rows"))


def main():
    targets = []
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        rel = str(p.relative_to(ROOT))
        if any(s in rel for s in EXEMPT_DIRS) or rel in WRITE_PROTECTED:
            continue
        if p.suffix not in (".py", ".csv", ".md", ".json", ".txt"):
            continue
        if rel == "results/hits_all.csv":          # verbatim feature-table annotation
            continue
        targets.append((p, rel))

    changed = []
    for p, rel in sorted(targets, key=lambda x: x[1]):
        if p.name == "apply_naming_convention.py":
            continue
        before = p.read_text(encoding="utf-8", errors="replace")
        if rel == "data/sites_manifest.csv":
            rename_sites_manifest(p, rel)
        elif rel.endswith(".csv") and rename_csv_by_accession(p, rel):
            pass
        else:
            after = rename_text(before, rel)
            if after != before:
                p.write_text(after, encoding="utf-8")
        if p.read_text(encoding="utf-8", errors="replace") != before:
            changed.append(rel)

    print(f"Rewrote {len(changed)} files:")
    for c in changed:
        print(f"  {c}")
    unresolved = [l for l in log if l[2] == "UNRESOLVED"]
    defaulted = [l for l in log if "FILE-DEFAULT" in l[2]]
    print(f"\nPhoP disambiguation: {len(defaulted)} occurrences resolved by per-file default, "
          f"{len(unresolved)} UNRESOLVED")
    for l in defaulted:
        print(f"  [default] {l[0]}:{l[1]}  {l[3]}")
    for l in unresolved:
        print(f"  [UNRESOLVED] {l[0]}:{l[1]}  {l[3]}")
    return changed


if __name__ == "__main__":
    main()
