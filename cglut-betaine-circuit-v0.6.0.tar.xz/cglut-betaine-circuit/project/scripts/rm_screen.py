"""TASK 2/3: screen the 95-construct panel against the HOST restriction-modification system.

The panel has been screened against 35 COMMERCIAL CLONING enzymes. That is a
different set from the host's own restriction system, and a construct carrying a
host R-M site can be degraded on entry -- a failure that reads as a dead design.

Every motif comes from scripts/seqchecks.HOST_RM, which quotes REBASE v608
(cached at data/cache/rebase/link_orgref.txt). Nothing is written from memory.
"""
import csv, json, sys
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import (HOST_RM, HOST_RM_SOURCE, HOST_RM_EXCLUDED, host_rm_scan, iupac_regex,
                       IUPAC, revcomp, positive_control_check)

D, R = ROOT / "designs", ROOT / "results"
MANIFEST = "order_manifest_final_v4.csv"
COMPONENTS = "order_manifest_final_v4_components.csv"

CODON = {}
_t = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
for _i, (_a, _b, _c) in enumerate(product("TCAG", repeat=3)):
    CODON[_a+_b+_c] = _t[_i]
translate = lambda d: "".join(CODON[d[i:i+3]] for i in range(0, len(d)-2, 3))


def codon_freqs():
    tbl = json.loads((ROOT / "data" / "cache" / "codon" / "cglut_codon_usage.json").read_text())["table"]
    return {aa: {c: v["rel_freq"] for c, v in t.items()} for aa, t in tbl.items()}


def load():
    man = {r["construct_id"]: r for r in csv.DictReader(open(D / MANIFEST))}
    comp = defaultdict(list)
    for c in csv.DictReader(open(D / COMPONENTS)):
        comp[c["construct_id"]].append(c)
    for k in comp:
        comp[k].sort(key=lambda x: int(x["start"]))
    return man, comp


SOURCED_PREFIX = ("core:", "operator:opA", "operator:opB", "ctx:", "forecistron:", "SD2",
                  "TAATG_frag", "sensor:", "acceptor:", "henke_spacer:")
DESIGNED_PREFIX = ("designed:", "linker:", "stop:", "operator:scrambled")


def classify(labels):
    """SOURCED (not editable without abandoning the component) vs DESIGNED vs CODING."""
    kinds = set()
    for lab in labels:
        if lab.startswith(("sensor:", "acceptor:", "linker:", "stop:")):
            kinds.add("CODING")
        elif lab.startswith(SOURCED_PREFIX):
            kinds.add("SOURCED")
        elif lab.startswith(DESIGNED_PREFIX):
            kinds.add("DESIGNED")
        else:
            kinds.add("OTHER")
    if "CODING" in kinds:
        return "CODING"
    if "SOURCED" in kinds and "DESIGNED" in kinds:
        return "SOURCED+DESIGNED (spans a junction)"
    return kinds.pop() if len(kinds) == 1 else "+".join(sorted(kinds))


def motif_free(seq, lo, hi, pad=8):
    """Any host motif overlapping [lo,hi) in a padded window?"""
    a, b = max(0, lo - pad), min(len(seq), hi + pad)
    return [h for h in host_rm_scan(seq[a:b]) if a + h.start < hi and a + h.end > lo]


def synonymous_fix(dna, protein, freq, start, end, min_rel=0.10):
    """Exhaustive: can ANY combination of synonymous codons clear this site?"""
    lo_c, hi_c = start // 3, (end - 1) // 3
    codons = [dna[i:i+3] for i in range(0, len(dna), 3)]
    idxs = list(range(lo_c, min(hi_c, len(protein) - 1) + 1))
    if not idxs:
        return None
    aas = [protein[i] for i in idxs]
    opts = [sorted(freq[a], key=lambda c: -freq[a][c]) for a in aas]
    best = None
    for combo in product(*opts):
        trial = list(codons)
        for k, ci in enumerate(idxs):
            trial[ci] = combo[k]
        t = "".join(trial)
        if motif_free(t, start, end):
            continue
        if translate(t[:len(protein)*3]) != protein:
            continue
        nch = sum(1 for k, ci in enumerate(idxs) if combo[k] != codons[ci])
        if nch == 0:
            continue
        below = [(aas[k], combo[k], round(freq[aas[k]][combo[k]], 4))
                 for k in range(len(idxs)) if combo[k] != codons[idxs[k]]
                 and freq[aas[k]][combo[k]] < min_rel]
        key = (nch, len(below))
        if best is None or key < best[0]:
            best = (key, {"codons": idxs, "from": [codons[i] for i in idxs], "to": list(combo),
                          "n_codons_changed": nch, "below_floor": below})
    return best[1] if best else None


def main():
    out_sys, out_hits = R / "host_rm_systems.csv", R / "rm_screen_results.csv"
    for p in (out_sys, out_hits):
        if p.exists():
            sys.exit(f"REFUSING TO OVERWRITE {p}")
    positive_control_check()
    man, comp = load()
    freq = codon_freqs()
    kin = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v4.csv"))}

    print("=" * 78); print("HOST R-M SCREEN"); print("=" * 78)
    print(f"  manifest        : designs/{MANIFEST} ({len(man)} constructs)")
    print(f"  motifs screened : {HOST_RM}")
    print(f"  excluded        : {list(HOST_RM_EXCLUDED)}")
    for k, v in HOST_RM.items():
        n = 1
        for ch in v:
            n *= len(IUPAC[ch])
        print(f"    {k:12} {v:9} -> regex {iupac_regex(v):18} {n} concrete sequence(s); "
              f"revcomp of pattern = {revcomp(v.replace('S','C').replace('B','C'))}")

    hits = []
    for cid, r in man.items():
        seq = r["full_sequence"]
        bnds = [(c["component"], int(c["start"]), int(c["end"])) for c in comp[cid]]
        for h in host_rm_scan(seq):
            labs = tuple(l for l, a, b in bnds if a < h.end and h.start < b)
            hits.append({
                "construct_id": cid, "panel": r["panel"], "system": h.enzyme,
                "motif": h.site, "matched_sequence": seq[h.start:h.end],
                "start": h.start, "end": h.end, "strand": h.strand,
                "components": "|".join(labs), "spans_component_junction": len(labs) > 1,
                "region_class": classify(labs),
            })
    print(f"\n  TOTAL host R-M sites across all {len(man)} constructs, both strands: {len(hits)}")
    for k, n in Counter(h["system"] for h in hits).most_common():
        cs = len({h['construct_id'] for h in hits if h['system'] == k})
        print(f"    {k:12} {n:4} sites on {cs:3} constructs")
    print(f"  constructs with >=1 site : {len({h['construct_id'] for h in hits})} of {len(man)}")
    print(f"  constructs with 0 sites  : {len(man) - len({h['construct_id'] for h in hits})}")
    return man, comp, hits, freq, kin, out_sys, out_hits


if __name__ == "__main__":
    main()


def assess_and_write(man, comp, hits, freq, kin, out_sys, out_hits):
    # physical sites: unique (construct, start, system)
    phys = {(h["construct_id"], h["start"], h["system"]) for h in hits}
    print(f"\n  site INSTANCES {len(hits)} -> PHYSICAL sites {len(phys)}  "
          f"(GCSGC is its own reverse complement, so each CglI site is seen on both strands)")

    print("\n" + "=" * 78); print("TASK 3  FIXABILITY"); print("=" * 78)
    fixinfo = {}
    for h in hits:
        cid, key = h["construct_id"], (h["construct_id"], h["start"], h["system"])
        if key in fixinfo:
            continue
        if h["region_class"] == "CODING":
            dna = man[cid]["full_sequence"]; prot = kin[cid]["protein_seq"]
            fx = synonymous_fix(dna, prot, freq, h["start"], h["end"])
            fixinfo[key] = ({"fixable": bool(fx), "how": "synonymous substitution",
                             "n_codons": fx["n_codons_changed"] if fx else None,
                             "below_floor": bool(fx and fx["below_floor"]),
                             "detail": (f"codons {fx['codons']}: "
                                        f"{'/'.join(fx['from'])} -> {'/'.join(fx['to'])}") if fx else ""})
        elif h["region_class"] == "SOURCED":
            fixinfo[key] = ({"fixable": False, "how": "NOT EDITABLE - sourced sequence",
                             "n_codons": None, "below_floor": False,
                             "detail": "the choice is accepting the risk or abandoning the component"})
        else:
            fixinfo[key] = ({"fixable": None, "how": "designed non-coding - needs a design-constraint check",
                             "n_codons": None, "below_floor": False, "detail": ""})
    cod = [v for k, v in fixinfo.items() if v["how"].startswith("synonymous")]
    src = [v for k, v in fixinfo.items() if v["how"].startswith("NOT EDITABLE")]
    des = [v for k, v in fixinfo.items() if v["how"].startswith("designed")]
    print(f"  physical sites in CODING sequence  : {len(cod)}  -> fixable by synonymous change: "
          f"{sum(1 for v in cod if v['fixable'])}, needing a below-floor codon: "
          f"{sum(1 for v in cod if v['below_floor'])}")
    print(f"  physical sites in SOURCED sequence  : {len(src)}  -> fixable: 0 (structural)")
    print(f"  physical sites in DESIGNED non-coding: {len(des)}")
    print(f"    -> no site falls in a designed background, spacer or filler, so the substitution")
    print(f"       arm's GC-invariance constraint is never put at risk by this screen. [EVIDENCE]")

    # ---------------------------------------------------------------- CSVs
    rows = []
    for name, motif in HOST_RM.items():
        s = HOST_RM_SOURCE[name]
        nsite = len({(h["construct_id"], h["start"]) for h in hits if h["system"] == name})
        rows.append({
            "system": name, "screened": "YES", "recognition_sequence": motif,
            "concrete_sequences": ";".join(sorted({"".join(c) for c in product(*[IUPAC[x] for x in motif])})),
            "reverse_complement_pattern": revcomp(motif.replace("S", "C").replace("B", "C")),
            "type": "Type II-like (prototype TauI, GCSG^C)" if name == "CglI" else "not stated by the source",
            "activity": s["activity"], "status": s["status"],
            "microorganism": s["microorganism"], "rebase_source": s["rebase_source_strain"],
            "methylation_site": s["methylation"], "prototype": s["rebase_prototype"],
            "genome_loci_BX927147": {"CglI": "cg1996 cglIM (M), cg1997 cglIR (R), cg1998 cglIIR (N)"}.get(name, "[NOT FOUND]"),
            "genome_loci_NCgl": {"CglI": "NCgl1703 (M.CglI), NCgl1704 (R.CglI), NCgl1705 (N.CglI)"}.get(name, "[NOT FOUND]"),
            "physical_sites_in_panel": nsite,
            "constructs_affected": len({h["construct_id"] for h in hits if h["system"] == name}),
            "citation": s["citation"], "note": s["note"],
        })
    for name, why in HOST_RM_EXCLUDED.items():
        rows.append({"system": name, "screened": "NO", "recognition_sequence": "",
                     "concrete_sequences": "", "reverse_complement_pattern": "", "type": "",
                     "activity": "", "status": "excluded from the screen", "microorganism": "",
                     "rebase_source": "", "methylation_site": "", "prototype": "",
                     "genome_loci_BX927147": "", "genome_loci_NCgl": "",
                     "physical_sites_in_panel": "", "constructs_affected": "",
                     "citation": "REBASE v608", "note": why})
    rows.append({"system": "predicted Type IV REase (cg2664)", "screened": "NO",
                 "recognition_sequence": "n/a - targets METHYLATED DNA, not a sequence",
                 "concrete_sequences": "", "reverse_complement_pattern": "", "type": "Type IV",
                 "activity": "restriction of modified DNA", "status": "computationally predicted",
                 "microorganism": "Corynebacterium glutamicum ATCC 13032", "rebase_source": "",
                 "methylation_site": "", "prototype": "",
                 "genome_loci_BX927147": "cg2664 (2540887..2541972, + strand)",
                 "genome_loci_NCgl": "[NOT FOUND - not resolved here]",
                 "physical_sites_in_panel": "n/a", "constructs_affected": "n/a",
                 "citation": "BX927147.1 feature table, product 'Predicted type IV restriction "
                             "endonuclease' (cached data/cache/BX927147.ft.txt)",
                 "note": "SEQUENCE SCREENING DOES NOT ADDRESS THIS. Type IV enzymes cut DNA "
                         "because of its METHYLATION STATE, not its sequence. Addressed by the "
                         "methylation of the incoming plasmid, i.e. by the E. coli strain it is "
                         "prepared in. See Task 4."})
    with open(out_sys, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f"\n  wrote {out_sys.relative_to(ROOT)} ({len(rows)} rows)")

    hrows = []
    for h in sorted(hits, key=lambda x: (x["construct_id"], x["start"], x["system"])):
        f = fixinfo[(h["construct_id"], h["start"], h["system"])]
        hrows.append({**h, "fixable": f["fixable"], "fix_route": f["how"],
                      "fix_codons_changed": f["n_codons"], "fix_needs_below_floor_codon": f["below_floor"],
                      "fix_detail": f["detail"],
                      "n_sites_in_this_construct": sum(1 for x in hits if x["construct_id"] == h["construct_id"])})
    with open(out_hits, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(hrows[0].keys())); w.writeheader(); w.writerows(hrows)
    print(f"  wrote {out_hits.relative_to(ROOT)} ({len(hrows)} rows)")
    return fixinfo, phys
