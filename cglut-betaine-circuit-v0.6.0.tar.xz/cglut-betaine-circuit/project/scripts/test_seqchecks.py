"""Positive-control fixtures and unit tests for scripts/seqchecks.py.

Run: python3 scripts/test_seqchecks.py       (no pytest required)
     pytest scripts/test_seqchecks.py        (also works)

The point of this file is that a NULL RESULT IS ONLY MEANINGFUL FROM A SCANNER
THAT HAS BEEN SHOWN TO FIND SOMETHING. Every scanner therefore has at least one
fixture it must detect and one it must not fire on. The junction fixtures are
built so the feature exists ONLY across the join -- neither component contains
it -- because that is the defect class this repo has hit four times.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import seqchecks as S
from siga_consensus import EXT10_PWM

CONSENSUS = EXT10_PWM["consensus"].upper().replace("Y", "T").replace("N", "A")
FAILURES = []


def check(name):
    def deco(fn):
        try:
            fn()
            print(f"  PASS  {name}")
        except Exception as e:                                  # noqa: BLE001
            FAILURES.append((name, e))
            print(f"  FAIL  {name}: {e}")
        return fn
    return deco


# ------------------------------------------------------------------ catalogue
@check("catalogue holds exactly 35 enzymes with unique names")
def t_cat():
    assert len(S.CATALOGUE) == 35, len(S.CATALOGUE)
    assert len(set(S.CATALOGUE)) == 35


@check("every catalogue site is ACGT-only and at least 6 bp")
def t_cat_sites():
    for e, s in S.CATALOGUE.items():
        assert set(s) <= set("ACGT"), (e, s)
        assert len(s) >= 6, (e, s)


@check("Golden Gate is a NAMED SUBSET of the catalogue, not a separate list")
def t_gg_subset():
    assert set(S.GOLDEN_GATE) <= set(S.CATALOGUE)
    assert sorted(S.GOLDEN_GATE) == ["AarI", "BbsI", "BsaI", "BsmBI", "SapI"]
    # the site strings must come from the catalogue -- one definition only
    assert S.CATALOGUE["BsaI"] == "GGTCTC" and S.CATALOGUE["SapI"] == "GCTCTTC"


@check("the nine provenance-derived enzymes are all present")
def t_prov():
    required = {"NcoI", "NsiI", "SphI", "ScaI", "StuI", "EcoRV", "XhoI", "MluI", "BamHI"}
    assert required <= set(S.CATALOGUE), required - set(S.CATALOGUE)
    assert set(S.PROVENANCE_DERIVED) == required


@check("the enzymes that caused each historical miss are in the catalogue")
def t_historical():
    # HP-4 NcoI; the NsiI/SphI primer-tail pair; the plan-derived-list misses
    for e in ("NcoI", "NsiI", "SphI", "ScaI", "StuI", "EcoRV", "XhoI"):
        assert e in S.CATALOGUE, e


# ------------------------------------------------------------------ site_scan
@check("site_scan default screens all 35, not the Golden Gate subset")
def t_default_width():
    seq = "TT" + S.CATALOGUE["XhoI"] + "TT" + S.CATALOGUE["EcoRV"] + "TT"
    found = {h.enzyme for h in S.site_scan(seq)}
    assert {"XhoI", "EcoRV"} <= found, found
    assert S.site_scan(seq, enzymes=S.GOLDEN_GATE) == []


@check("site_scan reports minus-strand hits in forward coordinates")
def t_strand_coords():
    seq = "AAAA" + S.revcomp(S.CATALOGUE["SapI"]) + "AAAA"
    h = S.site_scan(seq, enzymes=["SapI"])
    assert len(h) == 1 and h[0].strand == "-" and h[0].start == 4, h
    assert seq[h[0].start:h[0].end] == S.revcomp(S.CATALOGUE["SapI"])


@check("site_scan finds every catalogue enzyme in its own fixture")
def t_every_enzyme():
    missed = [e for e, s in S.CATALOGUE.items()
              if not any(h.enzyme == e for h in S.site_scan("GG" + s + "GG", enzymes=[e]))]
    assert not missed, missed


@check("site_scan finds nothing in a sequence engineered to be site-free")
def t_true_null():
    assert S.site_scan("ACACACACACACACACACACACACAC") == []


@check("site_scan raises on an unknown enzyme instead of skipping it")
def t_unknown():
    try:
        S.site_scan("AAAA", enzymes=["Bogus"])
    except KeyError:
        return
    raise AssertionError("no KeyError raised")


@check("site_scan is case-insensitive on input")
def t_case():
    assert len(S.site_scan("aaa" + S.CATALOGUE["BsaI"].lower() + "aaa", enzymes=["BsaI"])) == 1


# ------------------------------------------------------------------ sigA_scan
@check("sigA_scan scores the exact consensus at 1.000 of max")
def t_siga_max():
    h = S.sigA_scan("TTTT" + CONSENSUS + "TTTT")
    assert any(x.score == 1.0 for x in h), h


@check("sigA_scan returns a FRACTION of max, never a raw bit score")
def t_siga_fraction():
    for x in S.sigA_scan("TTTT" + CONSENSUS + "TTTT"):
        assert 0.0 <= x.score <= 1.0, x


@check("sigA_scan threshold admits and excludes a window at its own score")
def t_siga_threshold():
    # a degraded copy of the consensus: its score must sit strictly below 1.000,
    # so a threshold set between the two must keep the consensus and drop the copy
    degraded = "C" + CONSENSUS[1:6] + "C" + CONSENSUS[7:]
    seq = "TTTT" + CONSENSUS + "TTTTTTTTTTTT" + degraded + "TTTT"
    lo = min(x.score for x in S.sigA_scan(seq, threshold=0.0))
    hi = max(x.score for x in S.sigA_scan(seq, threshold=0.0))
    assert hi == 1.0 and lo < hi, (lo, hi)
    mid = (lo + hi) / 2
    assert len(S.sigA_scan(seq, threshold=mid)) < len(S.sigA_scan(seq, threshold=lo))
    assert all(x.score >= mid for x in S.sigA_scan(seq, threshold=mid))
    assert S.sigA_scan(seq, threshold=1.01) == []


@check("sigA_scan is sense-strand only unless asked otherwise")
def t_siga_strand():
    anti = "TTTT" + S.revcomp(CONSENSUS) + "TTTT"
    assert not any(x.score == 1.0 for x in S.sigA_scan(anti))
    assert any(x.score == 1.0 and x.strand == "-" for x in S.sigA_scan(anti, both_strands=True))


@check("sigA_scan docstring carries the standing not-a-trained-PWM caveat")
def t_siga_caveat():
    d = S.sigA_scan.__doc__.lower()
    assert "not a pwm trained" in d or "reasoned approximation" in d, d


# ---------------------------------------------------------------- sd_atg_scan
@check("sd_atg_scan finds SD+ATG and reports both coordinates")
def t_sd():
    h = S.sd_atg_scan("CCGGAGGAAAAATGTT")
    assert h and h[0].detail.startswith("SD(GGAGG@2)"), h


@check("sd_atg_scan ignores an ATG that is too close or too far")
def t_sd_spacing():
    assert S.sd_atg_scan("GGAGGATGAAAAAAAA") == []                 # 0 nt gap: too close
    assert S.sd_atg_scan("GGAGG" + "T" * 20 + "ATG") == []          # 20 nt gap: too far


@check("sd_atg_scan excludes the design's own intended start")
def t_sd_known():
    seq = "CCGGAGGAAAAATGTT"
    pos = S.sd_atg_scan(seq)[0].end - 3
    assert S.sd_atg_scan(seq, known_starts=[pos]) == []


# -------------------------------------------------------------- basic_checks
@check("basic_checks fires on a run of 7 and not on a run of 6")
def t_homo():
    assert S.basic_checks("CC" + "T" * 7 + "CC")["n_homopolymers_gt6"] == 1
    assert S.basic_checks("CC" + "T" * 6 + "CC")["n_homopolymers_gt6"] == 0


@check("basic_checks GC and length are exact")
def t_basic():
    b = S.basic_checks("GGGGCCCCAAAATTTT")
    assert b["length_bp"] == 16 and b["GC_percent"] == 50.0, b


# ------------------------------------------------------------- junction_aware
@check("junction_aware finds an enzyme site that exists ONLY across the join")
def t_junc_site():
    a, b = "AAAAGGTC", "TCTTTTTT"          # BsaI only across a|b
    assert S.site_scan(a, enzymes=["BsaI"]) == [] and S.site_scan(b, enzymes=["BsaI"]) == []
    r = S.junction_aware(a + b, [("compA", a), ("compB", b)])
    hits = [h for h in r["sites"] if h.enzyme == "BsaI"]
    assert hits and all(h.spans_junction for h in hits), hits
    assert hits[0].components == ("compA", "compB"), hits[0].components


@check("junction_aware finds a SigA element that exists ONLY across the join")
def t_junc_siga():
    half = len(CONSENSUS) // 2
    a, b = "GGGG" + CONSENSUS[:half], CONSENSUS[half:] + "GGGG"
    assert not any(x.score == 1.0 for x in S.sigA_scan(a) + S.sigA_scan(b))
    r = S.junction_aware(a + b, [("left", a), ("right", b)])
    top = [x for x in r["sigA"] if x.score == 1.0]
    assert top and top[0].spans_junction, r["sigA"]


@check("junction_aware finds an SD+ATG that exists ONLY across the join")
def t_junc_sd():
    a, b = "CCGGAGGAA", "AAATGTT"
    assert S.sd_atg_scan(a) == [] and S.sd_atg_scan(b) == []
    r = S.junction_aware(a + b, [("l", a), ("r", b)])
    assert r["sd_atg"] and r["sd_atg"][0].spans_junction, r["sd_atg"]


@check("junction_aware does NOT mis-call a within-component hit as spanning")
def t_junc_within():
    a, b = "AA" + S.CATALOGUE["BsaI"] + "AA", "CCCCCC"
    r = S.junction_aware(a + b, [("compA", a), ("compB", b)])
    hits = [h for h in r["sites"] if h.enzyme == "BsaI"]
    assert hits and not any(h.spans_junction for h in hits), hits


@check("junction_aware raises when the map does not reproduce the construct")
def t_map_assert():
    for bad in ([("x", 0, 4)],                      # too short
                [("x", 0, 4), ("y", 5, 8)],         # gap
                [("x", 0, 5), ("y", 4, 8)],         # overlap
                [("y", 4, 8), ("x", 0, 4)],         # out of order
                []):                                # empty
        try:
            S.junction_aware("AAAACCCC", bad)
        except S.ComponentMapError:
            continue
        raise AssertionError(f"accepted a bad map: {bad}")


@check("junction_aware accepts (label, subsequence) maps and derives coordinates")
def t_map_forms():
    seq = "AAAACCCCGGGG"
    a = S.junction_aware(seq, [("x", "AAAA"), ("y", "CCCC"), ("z", "GGGG")])["boundaries"]
    b = S.junction_aware(seq, [("x", 0, 4), ("y", 4, 8), ("z", 8, 12)])["boundaries"]
    assert a == b == [("x", 0, 4), ("y", 4, 8), ("z", 8, 12)], (a, b)


@check("junction_aware boundaries tile the construct with no gap or overlap")
def t_map_tiles():
    seq = "AAAACCCCGGGGTTTT"
    bnds = S.junction_aware(seq, [("w", 0, 4), ("x", 4, 8), ("y", 8, 12), ("z", 12, 16)])["boundaries"]
    assert bnds[0][1] == 0 and bnds[-1][2] == len(seq)
    assert all(bnds[i][2] == bnds[i + 1][1] for i in range(len(bnds) - 1))


# ------------------------------------------------------------- host R-M subset
@check("HOST_RM holds only motifs with a cached REBASE provenance record")
def t_hostrm_prov():
    assert set(S.HOST_RM) == set(S.HOST_RM_SOURCE), set(S.HOST_RM) ^ set(S.HOST_RM_SOURCE)
    for k, v in S.HOST_RM_SOURCE.items():
        assert v["rebase_recognition"] == S.HOST_RM[k], (k, v["rebase_recognition"], S.HOST_RM[k])
        assert "REBASE" in v["citation"], k
        assert v["activity"] and v["status"], k


@check("every screened host motif comes from strain ATCC 13032")
def t_hostrm_strain():
    for k, v in S.HOST_RM_SOURCE.items():
        blob = v["microorganism"] + " " + v["rebase_source_strain"]
        assert "13032" in blob or "Binder" in blob, (k, blob)


@check("excluded host systems are recorded with a stated reason, not dropped silently")
def t_hostrm_excluded():
    assert set(S.HOST_RM_EXCLUDED) == {"CglAI", "CglAII", "Cgl165I"}
    for k, why in S.HOST_RM_EXCLUDED.items():
        assert len(why) > 40 and ("13032" in why or "NOT FOUND" in why), k
    assert not (set(S.HOST_RM_EXCLUDED) & set(S.HOST_RM))


@check("host R-M motifs are kept out of the 35-enzyme commercial catalogue")
def t_hostrm_disjoint():
    assert not (set(S.HOST_RM) & set(S.CATALOGUE))
    assert len(S.CATALOGUE) == 35


@check("iupac_regex expands degenerate codes correctly and rejects bad ones")
def t_iupac():
    assert S.iupac_regex("GCSGC") == "GC[CG]GC"
    assert S.iupac_regex("ACGABGG") == "ACGA[CGT]GG"
    assert S.iupac_regex("GGCGCA") == "GGCGCA"
    try:
        S.iupac_regex("ACGXT")
    except KeyError:
        return
    raise AssertionError("no KeyError for an unknown IUPAC code")


@check("host_rm_scan finds every resolution of every degenerate motif")
def t_hostrm_resolutions():
    import itertools
    for name, motif in S.HOST_RM.items():
        opts = [S.IUPAC[c] for c in motif]
        for combo in itertools.product(*opts):
            seq = "TT" + "".join(combo) + "TT"
            hits = [h for h in S.host_rm_scan(seq, motifs=[name], both_strands=False)]
            assert hits and hits[0].start == 2, (name, seq, hits)


@check("host_rm_scan reports minus-strand hits in forward coordinates")
def t_hostrm_strand():
    seq = "AAAA" + S.revcomp("ACGACGG") + "AAAA"
    h = S.host_rm_scan(seq, motifs=["Cgl13032II"])
    assert len(h) == 1 and h[0].strand == "-" and h[0].start == 4, h
    assert S.revcomp(seq[h[0].start:h[0].end]) == "ACGACGG"


@check("host_rm_scan counts overlapping sites separately")
def t_hostrm_overlap():
    assert len(S.host_rm_scan("GCCGCCGC", motifs=["CglI"], both_strands=False)) == 2
    assert len(S.host_rm_scan("GCGGCGGC", motifs=["CglI"], both_strands=False)) == 2


@check("host_rm_scan gives a true null on motif-free sequence")
def t_hostrm_null():
    assert not S.host_rm_scan("ATATATATATATATATATAT")


@check("GCSGC is its own reverse complement as a degenerate set")
def t_gcsgc_selfrc():
    assert S.revcomp("GCCGC") == "GCGGC" and S.revcomp("GCGGC") == "GCCGC"


# ------------------------------------------------- the module's own gatekeeper
@check("positive_control_check runs and reports every scanner it proved")
def t_pcc():
    log = S.positive_control_check(force=True)
    assert len(log) >= 15, len(log)
    for scanner in ("site_scan", "sigA_scan", "sd_atg_scan", "basic_checks", "junction_aware"):
        assert any(scanner in line for line in log), scanner


@check("positive_control_check raises if a scanner is broken")
def t_pcc_detects_breakage():
    real = S.site_scan
    try:
        S.site_scan = lambda *a, **k: []          # a scanner that finds nothing, ever
        try:
            S.positive_control_check(force=True)
        except AssertionError:
            return
        raise AssertionError("a permanently-empty site_scan was not detected")
    finally:
        S.site_scan = real
        S.positive_control_check(force=True)      # leave the cache in a truthful state


# -------------------------------------------------- no panel script owns a list
@check("no panel script defines its own enzyme recognition sequences")
def t_no_local_lists():
    import re
    root = Path(__file__).resolve().parent.parent
    offenders = []
    allowed = {"seqchecks.py", "test_seqchecks.py"}
    for p in sorted(list((root / "scripts").glob("*.py")) + list(root.glob("*.py"))):
        if p.name in allowed:
            continue
        txt = p.read_text()
        # an enzyme-name -> recognition-site mapping is the thing that must not recur.
        # Match on the catalogue's ACTUAL names: a shape heuristic like "...I+..." misses
        # EcoRV, the one name with no "I" in it.
        names = "|".join(sorted(S.CATALOGUE, key=len, reverse=True))
        hits = re.findall(r'"(' + names + r')"\s*:\s*\(?\s*"([ACGT]{6,})"', txt)
        if hits:
            offenders.append(f"{p.relative_to(root)} defines {len(hits)}: {sorted({h[0] for h in hits})}")
    assert not offenders, "\n      " + "\n      ".join(offenders)


if __name__ == "__main__":
    print("=" * 74)
    print("seqchecks unit tests and positive-control fixtures")
    print("=" * 74)
    total = len([k for k in dir() if k.startswith("t_")])
    print(f"\n  {total - len(FAILURES)} passed, {len(FAILURES)} failed")
    sys.exit(1 if FAILURES else 0)
