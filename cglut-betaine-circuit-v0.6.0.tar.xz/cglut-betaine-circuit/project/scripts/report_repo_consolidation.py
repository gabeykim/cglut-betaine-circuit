"""Generate REPORT_repo_consolidation.md.

EVERY table is computed here from the WRITTEN DATA FILES and from live calls into
the shared module. Nothing is transcribed from console output.
"""
import csv, json, re, subprocess, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
D = ROOT / "designs"
OUT = ROOT / "REPORT_repo_consolidation.md"
if OUT.exists():
    sys.exit(f"REFUSING TO OVERWRITE {OUT}")

import seqchecks as S
from seqchecks import CATALOGUE, GOLDEN_GATE, VECTOR_SITES, PROVENANCE_DERIVED, site_scan
from regression_seqchecks import analyse

BASE = Path(sys.argv[1]) if len(sys.argv) > 1 else None      # pre-refactor snapshot of designs/
L = []
w = L.append
I, F = int, float


def esc(x):
    return str(x).replace("|", "\\|")


def table(headers, rows):
    w("| " + " | ".join(esc(h) for h in headers) + " |")
    w("|" + "|".join("---" for _ in headers) + "|")
    for r in rows:
        w("| " + " | ".join(esc(x) for x in r) + " |")
    w("")


def read_fasta(p):
    o, k, b = {}, None, []
    for line in open(p):
        line = line.strip()
        if line.startswith(">"):
            if k:
                o[k] = "".join(b)
            k, b = line[1:].split()[0], []
        elif line:
            b.append(line)
    if k:
        o[k] = "".join(b)
    return o


# ------------------------------------------------------------------- inputs
v2fa, v3fa = read_fasta(D / "junctions_v2.fasta"), read_fasta(D / "junctions_v3.fasta")
r2 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v2.csv"))}
r3 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v3.csv"))}
m1 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final.csv"))}
m2 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v2.csv"))}
c1 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_checks.csv"))}
c2 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v2_checks.csv"))}
s2 = list(csv.DictReader(open(D / "order_manifest_final_v2_sites.csv")))
s1 = list(csv.DictReader(open(D / "order_manifest_final_sites.csv")))
mo2 = list(csv.DictReader(open(D / "order_manifest_final_v2_motifs.csv")))
sub2 = list(csv.DictReader(open(D / "order_submit_final_v2.csv")))
fa2n = sum(1 for line in open(D / "order_submit_final_v2.fasta") if line.startswith(">"))

# which files import the shared module, and what they used to own
OLD_SIZE = {"scripts/design_checks.py": 13, "scripts/design_translational_panel.py": 13,
            "scripts/build_order_manifest.py": 15, "scripts/design_backgrounds.py": 35,
            "scripts/check_manifest_v2.py": 35, "scripts/consolidate_final.py": 35,
            "scripts/junction_design.py": 5}
refactored = []
for p in sorted(list((ROOT / "scripts").glob("*.py")) + list(ROOT.glob("*.py"))):
    txt = p.read_text()
    if re.search(r"^(from seqchecks import|import seqchecks)", txt, re.M):
        refactored.append(str(p.relative_to(ROOT)))
still_own = []
for p in sorted(list((ROOT / "scripts").glob("*.py")) + list(ROOT.glob("*.py"))):
    if p.name in ("seqchecks.py", "test_seqchecks.py"):
        continue
    # match on the catalogue's ACTUAL names, never on a name-shape heuristic
    _names = "|".join(sorted(CATALOGUE, key=len, reverse=True))
    hits = re.findall(r'"(' + _names + r')"\s*:\s*\(?\s*"([ACGT]{6,})"', p.read_text())
    if hits:
        still_own.append((str(p.relative_to(ROOT)), sorted({h[0] for h in hits})))

tests = subprocess.run([sys.executable, str(ROOT / "scripts" / "test_seqchecks.py")],
                       capture_output=True, text=True)
n_pass = len(re.findall(r"^  PASS", tests.stdout, re.M))
n_fail = len(re.findall(r"^  FAIL", tests.stdout, re.M))
pcs = S.positive_control_check(force=True)
verd = analyse(BASE, D) if BASE else []

edited = [d for d in r3 if I(r3[d]["n_codon_edits"]) > 0]
ncoi_v2 = sorted(d for d, s in v2fa.items() if site_scan(s, enzymes=["NcoI"]))
ncoi_v3 = sorted(d for d, s in v3fa.items() if site_scan(s, enzymes=["NcoI"]))
gg_v3 = sum(len(site_scan(s, enzymes=GOLDEN_GATE)) for s in v3fa.values())
added_any, removed_any = defaultdict(list), defaultdict(list)
for d in v3fa:
    a = {h.key() for h in site_scan(v2fa[d])}
    b = {h.key() for h in site_scan(v3fa[d])}
    for x in sorted(b - a):
        added_any[d].append(x)
    for x in sorted(a - b):
        removed_any[d].append(x)

# ================================================================= LEAD
w("# Repo consolidation: one shared checking module, and the NcoI fix applied")
w("")
w("Built by `scripts/seqchecks.py` (the module), `scripts/apply_ncoi_fix.py` (the codon "
  "change) and `scripts/consolidate_v2.py` (the rebuilt manifest). This report is generated "
  "from the written data files by `scripts/report_repo_consolidation.py`.")
w("")
w("Tags: **[EVIDENCE]** computed here or stated by a citable source. **[INFERENCE]** reasoning "
  "from evidence, step named. **[NOT FOUND]** searched and absent.")
w("")
w("**No construct here is claimed to work.** Nothing below predicts expression, signalling, or "
  "assembly success.")
w("")
w("---")
w("")
w("## 0. LEAD")
w("")
w("### Did the refactor change any existing result?")
w("")
regressions = [v for v in verd if v["verdict"] == "REGRESSION"]
newfinds = [v for v in verd if v["verdict"] == "NEW FIND"]
unchanged = [v for v in verd if v["verdict"] == "UNCHANGED"]
if verd:
    w(f"**Yes, in {len(newfinds)} of {len(verd)} compared panel outputs — and every one of those "
      f"changes is a NEW FIND, not a regression. {len(regressions)} regressions.** [EVIDENCE]")
    w("")
    w("The test applied to each difference is strict and mechanical:")
    w("")
    w("1. the new site set must be a **superset** of the old — nothing may disappear;")
    w("2. every added site must name an enzyme **outside** that script's old list — a change for an "
      "enzyme already screened would be a bug, not a wider net;")
    w("3. every **sequence** must be byte-identical — refactoring the checks must not touch the designs.")
    w("")
    table(["panel output", "old list", "now", "sites added", "added enzymes", "sites removed",
           "added for an already-screened enzyme", "sequences identical", "verdict"],
          [[f"`{v['file']}`", f"{v['old_list_size']} enzymes" if v["old_list_size"] else "35 enzymes",
            f"{len(CATALOGUE)} enzymes", len(v["sites_added"]),
            ", ".join(f"`{e}`" for e in v["added_enzymes"]) or "—",
            len(v["sites_removed"]), ", ".join(v["added_inside_old_list"]) or "none",
            "yes" if v["seq_identical"] else "**NO**", v["verdict"]] for v in verd])
    allnew = sorted({e for v in verd for e in v["added_enzymes"]})
    w("")
    w("**One correction to this table, made before publishing it.** [EVIDENCE] The first version of "
      "`scripts/regression_seqchecks.py` recognised enzyme tokens with the pattern "
      "`[A-Za-z][A-Za-z0-9]*I+[a-zA-Z]*`, which requires an `I` in the name. `EcoRV` is the only "
      "one of the 35 catalogue names without one, so it was silently dropped and the table under-"
      "reported by 6 sites — and, worse, an `EcoRV` regression would have been invisible. The "
      "parser now builds its pattern from the catalogue's actual names. The same heuristic was "
      "removed from the architectural unit test, which had the same blind spot. This is the "
      "identical failure mode as the one being fixed, one level up: a check that guesses at its "
      "own vocabulary instead of reading it from the single source of truth.")
    w("")
    w(f"**Every added enzyme is one that the narrow lists could not see: "
      f"{', '.join('`'+e+'`' for e in allnew)}.** [EVIDENCE] All {len(allnew)} were already known "
      f"from provenance scanning to arrive inside *sourced* sequence — `ScaI` and `StuI` in the PsodA "
      f"amplicon, `EcoRV` in Ptuf, `XhoI` in fore-cistron HP-12, `NsiI`/`SphI` in the Psyn N105 "
      f"primer tail. The refactor did not discover new biology; it made the panels that had been "
      f"blind to those enzymes see what the combined check already saw.")
    w("")
    w(f"**No sequence changed anywhere in the refactor.** [EVIDENCE] "
      f"{sum(1 for v in verd if v['seq_identical'])} of {len(verd)} outputs have byte-identical "
      f"sequence columns; the differences are confined to flag, count and site-listing columns.")
else:
    w("**[NOT FOUND]** No pre-refactor snapshot was supplied, so the before/after comparison could "
      "not be run. Re-run with the snapshot directory as argv[1].")
w("")
w("Two further reproductions, outside the table because they compare whole files rather than "
  "site sets:")
w("")
w("- **`designs/junctions_v2.csv`, `junctions_v2.fasta` and `junctions_rename_map.csv` are "
  "reproduced byte-identically** after `junction_design.py` was refactored, and its stdout is "
  "identical line for line. [EVIDENCE] That is the load-bearing check: the codon optimiser's "
  "behaviour is unchanged, so the kinase panel was not silently redesigned.")
w("- **All eight `consolidate_final.py` outputs are reproduced byte-identically** after its own "
  "35-enzyme catalogue and its four local scanners were deleted in favour of the shared module. "
  "[EVIDENCE] Verified by writing to a scratch directory and diffing against the delivered files, "
  "so no delivered file was overwritten to prove it.")
w("")
w("### Are all 18 NcoI sites gone, and did anything new appear?")
w("")
_removed_enz = sorted({e for v in removed_any.values() for e, _p, _s in v})
w(f"**Yes. {len(ncoi_v2)} constructs carried NcoI in v2; {len(ncoi_v3)} carry it in v3.** "
  f"[EVIDENCE] {sum(len(v) for v in removed_any.values())} site-instances removed "
  f"({len(ncoi_v2)} constructs × 2 strands, NcoI being palindromic), and the only enzyme removed "
  f"anywhere is {', '.join('`'+e+'`' for e in _removed_enz)}.")
w("")
w(f"**No new site of any enzyme in the {len(CATALOGUE)}-enzyme catalogue was created, in any "
  f"construct, on either strand.** [EVIDENCE] Computed as a set difference per construct between "
  f"the v2 and v3 scans: {sum(len(v) for v in added_any.values())} additions across all 24.")
w("")
w(f"**Golden Gate remains at zero: {gg_v3} BsaI/BsmBI/BbsI/SapI/AarI sites across all 24 v3 "
  f"constructs on both strands.** [EVIDENCE] And across the whole rebuilt 93-construct set, "
  f"{len([x for x in s2 if x['enzyme'] in GOLDEN_GATE])}.")
w("")
w("---")
w("")
# ================================================================= TASK 1
w("## 1. Task 1 — the shared checking module")
w("")
w("### What was wrong")
w("")
w("The same check existed in seven places with five different enzyme lists. [EVIDENCE, from the "
  "pre-refactor sources]")
w("")
table(["script", "enzymes it screened", "what that could not see"],
      [["`scripts/junction_design.py`", "**5** (Golden Gate only)",
        "everything else — including the NcoI site that reached 18 of 24 kinase constructs"],
       ["`scripts/design_checks.py`", "13", "`NsiI`, `SphI`, `ScaI`, `StuI`, `EcoRV`, `XhoI`, …"],
       ["`scripts/design_translational_panel.py`", "13", "`XhoI` in fore-cistron HP-12, …"],
       ["`scripts/build_order_manifest.py`", "15 (enumerated from the assembly plan)",
        "`ScaI`, `StuI`, `EcoRV`, `XhoI` — all inside *sourced* sequence"],
       ["`scripts/design_backgrounds.py`", "35", "— (already full)"],
       ["`scripts/check_manifest_v2.py`", "35 catalogue, **narrowed to a derived 20** at scan time",
        "the 15 catalogue enzymes outside the derived list"],
       ["`scripts/consolidate_final.py`", "35", "— (already full)"]])
w("The failure is architectural, not arithmetical. HP-4 was excluded from the translational panel "
  "*for this exact site*, and the exclusion is still there in `design_translational_panel.py`'s "
  "`EXCLUDED` dict with NcoI named in its reason string. The knowledge existed; it just could not "
  "travel, because the next panel wrote its own check instead of importing the existing one.")
w("")
w("### What `scripts/seqchecks.py` provides")
w("")
table(["required item", "provided as", "notes"],
      [["1. the 35-enzyme catalogue", "`CATALOGUE` (module-level dict)",
        f"{len(CATALOGUE)} enzymes; `GOLDEN_GATE`, `VECTOR_SITES` and `PROVENANCE_DERIVED` are "
        f"NAMED SUBSETS holding enzyme **names**, so each recognition site is written down once"],
       ["2. `site_scan(sequence, enzymes=None, both_strands=True)`", "returns `Site` records",
        "`enzymes=None` means the **full catalogue**; minus-strand hits are reported in forward "
        "coordinates; an unknown enzyme name raises rather than being skipped"],
       ["3. `sigA_scan(sequence)`", "returns `MotifHit` records",
        "uses the repo's existing `siga_consensus.EXT10_PWM`; scores are a **fraction of matrix "
        "max**; the not-a-trained-PWM caveat is in the docstring and unit-tested for presence"],
       ["4. `sd_atg_scan(sequence)`", "returns `MotifHit` records",
        "SD core `GGAGG`/`AGGAG`/`GGAG` then an ATG 3–14 nt later; `known_starts` excludes the "
        "design's own initiator"],
       ["5. `basic_checks(sequence)`", "dict", "homopolymer runs > 6, GC percent, length"],
       ["6. `junction_aware(construct, component_map)`", "dict of classified hits",
        "runs all three scans on the whole construct and marks each hit "
        "contained-within-a-component or **spanning a junction**; raises `ComponentMapError` "
        "unless the map reproduces the construct base-for-base"],
       ["7. `positive_control_check()`", f"{len(pcs)} assertions, raises on failure",
        "proves every scanner FINDS a known positive before any null from it is trusted"]])
w(f"**`PROVENANCE_DERIVED` names the nine enzymes that only ever surfaced by scanning the "
  f"provenance of sourced components: {', '.join('`'+e+'`' for e in PROVENANCE_DERIVED)}.** "
  f"[EVIDENCE] They are kept as a named subset so the lesson is greppable rather than folklore.")
w("")
w("### The default is the full catalogue, and narrowing has to be said out loud")
w("")
w("`site_scan` screens all 35 unless a caller names fewer. Exactly one caller now narrows, and it "
  "says why at the call site:")
w("")
w("```python")
w("# scripts/junction_design.py")
w("# THE OPTIMISER'S CONSTRAINT SET IS DELIBERATELY NARROW, AND THAT NARROWING IS A")
w("# DECISION, NOT AN OVERSIGHT. `optimise`/`repair_all` avoid only the Golden Gate")
w("# sites because widening the constraint would re-derive every codon downstream of")
w("# the first change and therefore redesign every kinase construct, which is a")
w("# different act from checking them. The REPORTING path (`catalogue_hits`) screens")
w("# the full 35, so a site the optimiser does not avoid is still seen.")
w("```")
w("")
w("That split — **narrow constraint, wide check** — is the actual fix. The old code had a narrow "
  "constraint *and* a narrow check, so a site the optimiser did not avoid was also a site nobody "
  "looked for. [INFERENCE, reasoning named: `_bad_spans` and `forbidden_hits` were the same "
  "5-enzyme set, and `run_junction_design_v2.py` reported from `forbidden_hits`.]")
w("")
w("### Files refactored")
w("")
table(["file", "enzymes before", "enzymes after", "what was deleted from it"],
      [[f"`{f}`", OLD_SIZE.get(f, "—"), len(CATALOGUE),
        {"scripts/junction_design.py": "`GOLDEN_GATE` dict, `revcomp`, `forbidden_hits`, "
                                       "`homopolymers`, `gc_pct` bodies",
         "scripts/design_checks.py": "`ENZYME_SITES` dict, `find_sites` body",
         "scripts/design_translational_panel.py": "`ENZYME_SITES` dict, `enzyme_hits` and "
                                                  "`homopolymers` bodies",
         "scripts/build_order_manifest.py": "`ENZYMES` dict, `enzyme_hits` and `homopolymers` bodies",
         "scripts/design_backgrounds.py": "`ENZYMES` dict",
         "scripts/check_manifest_v2.py": "`CATALOGUE` and `GOLDEN_GATE` constants, `sites_in`, "
                                         "`spurious_promoters`, `spurious_initiation` bodies; "
                                         "the scan no longer narrows to the derived list",
         "scripts/consolidate_final.py": "`CATALOGUE`, `GOLDEN_GATE`, `VECTOR_SITES`, and the "
                                         "`enzyme_scan` / `siga_scan` / `sd_scan` / `homopolymers` "
                                         "/ `revcomp` bodies",
         "scripts/consolidate_v2.py": "— (new file, built on the shared module)",
         "scripts/apply_ncoi_fix.py": "— (new file)",
         "scripts/verify_ncoi_fix.py": "— (new file)",
         "scripts/regression_seqchecks.py": "— (new file)",
         "scripts/report_repo_consolidation.py": "— (new file)",
         }.get(f, "—")] for f in refactored])
w(f"**{len(refactored)} files import the shared module.** [EVIDENCE, computed by scanning for the "
  f"import] Of these, {len([f for f in refactored if f in OLD_SIZE])} previously owned an enzyme "
  f"list; the rest are new this session.")
w("")
w("### Scripts NOT refactored, and why")
w("")
table(["script", "reason"],
      [["`scripts/fetch_core_promoters.py`", "contains no enzyme list. The `GAATTCCATG` strings in "
        "it are **primer tails quoted from PMC7835838 Table 2** — data, not a screen. Changing them "
        "would corrupt provenance."],
       ["`scripts/design_promoter_panel.py`, `scripts/build_phasing_v2.py`",
        "define no enzyme list and run no scan; they build sequences from cached components. Both "
        "reproduce byte-identically after the refactor."],
       ["`run_junction_design.py` (v1), `run_junction_design_v2.py`",
        "carry no enzyme list of their own — they call into `junction_design.py`, which is "
        "refactored. `run_junction_design_v2.py` was re-run and reproduces all three of its "
        "outputs byte-identically."],
       ["the `scripts/fetch_*.py` and domain/PWM scripts",
        "no enzyme list and no sequence-motif screen; out of scope."]])
w(f"**No script could not be refactored.** [EVIDENCE] A unit test walks every `.py` in `scripts/` "
  f"and the repo root looking for an enzyme-name→recognition-site mapping and fails if it finds "
  f"one: {'it currently finds none' if not still_own else 'IT CURRENTLY FINDS: ' + str(still_own)}.")
w("")
w("### Tests")
w("")
w(f"`scripts/test_seqchecks.py`: **{n_pass} passed, {n_fail} failed.** [EVIDENCE] "
  f"`seqchecks.positive_control_check()` runs {len(pcs)} assertions and is called at the head of "
  f"every script that reports a zero.")
w("")
w("The fixtures that matter are the junction ones, because they are built so the feature exists "
  "**only across the join** and is absent from either component alone — the defect class this repo "
  "has hit four times:")
w("")
table(["fixture", "component A", "component B", "what only exists across the join"],
      [["enzyme site", "`AAAAGGTC`", "`TCTTTTTT`", "`BsaI` (`GGTCTC`)"],
       ["SigA extended −10", "`GGGG` + first half of the consensus",
        "second half + `GGGG`", "a 1.000-of-max extended −10"],
       ["SD + ATG", "`CCGGAGGAA`", "`AAATGTT`", "an SD followed by an ATG at 3–14 nt"]])
w("Each test asserts the component-level scan finds **nothing** and the junction-aware scan finds "
  "the hit and marks it `spans_junction`. There is also a negative control — a site wholly inside "
  "one component must **not** be called junction-spanning — and a self-sabotage test that replaces "
  "`site_scan` with a function returning `[]` and asserts `positive_control_check()` raises.")
w("")
w("---")
w("")
# ================================================================= TASK 2
w("## 2. Task 2 — the NcoI codon fix")
w("")
w("### What changed")
w("")
w(f"**{len(edited)} constructs, one synonymous codon each, one nucleotide each.** [EVIDENCE]")
w("")
nt_delta = {d: sum(1 for i in range(len(v2fa[d])) if v2fa[d][i] != v3fa[d][i]) for d in v3fa}
rows = []
for d in sorted(edited):
    e = r3[d]["codon_edits"]
    m = re.match(r"codon(\d+)\((\w)\)(\w+)->(\w+)@nt([\d,]+)", e)
    site = [h.start for h in site_scan(v2fa[d], enzymes=["NcoI"]) if h.strand == "+"][0]
    rows.append([f"`{d}`", site, f"codon {m.group(1)}", m.group(2), f"`{m.group(3)}`→`{m.group(4)}`",
                 m.group(5), nt_delta[d],
                 "yes" if r3[d]["protein_seq"] == r2[d]["protein_seq"] else "**NO**"])
table(["construct", "NcoI at (nt)", "codon", "residue", "change", "nt changed", "nt differing from v2",
       "protein identical"], rows)
w(f"Every edit is the documented `TCC`→`TCT` at the serine immediately 5′ of Met365 in `P0DM80` "
  f"numbering. [EVIDENCE] The methionine is a real residue and cannot move; the serine codon can. "
  f"`TCT` sits at "
  f"{json.loads((ROOT/'data'/'cache'/'codon'/'cglut_codon_usage.json').read_text())['table']['S']['TCT']['rel_freq']:.3f} "
  f"relative usage in the BX927147.1-derived codon table, above the optimiser's own 0.10 floor, so "
  f"no rare codon is introduced.")
w("")
w("The fix routine does not simply apply a hard-coded substitution. For each site it tries every "
  "synonymous codon at every position the site overlaps — the documented `TCC`→`TCT` first, then "
  "the rest by descending host usage — and accepts one only if it (a) removes the site, "
  "(b) leaves the protein **strictly** unchanged under back-translation, and (c) creates **no new "
  "site of any of the 35 catalogue enzymes anywhere in the construct**. [EVIDENCE: "
  "`scripts/apply_ncoi_fix.py`] The documented fix satisfied all three in all 18, so that is what "
  "was applied — but had it not, the script would have said so rather than forcing it.")
w("")
w("### Verification")
w("")
w("`scripts/verify_ncoi_fix.py` re-reads only the written v2 and v3 files and re-derives every "
  "claim from the sequences. [EVIDENCE]")
w("")
ver = subprocess.run([sys.executable, str(ROOT / "scripts" / "verify_ncoi_fix.py")],
                     capture_output=True, text=True)
vpass = re.findall(r"^  PASS  (.+)$", ver.stdout, re.M)
vfail = re.findall(r"^  FAIL  (.+)$", ver.stdout, re.M)
table(["check", "result"], [[c, "PASS"] for c in vpass] + [[c, "**FAIL**"] for c in vfail])
w(f"**{len(vpass)} passed, {len(vfail)} failed.**")
w("")
w("Four of those deserve to be spelled out, because they are the ones the task asks for by name:")
w("")
w(f"- **Zero NcoI remains.** {len(ncoi_v2)} carriers in v2 → {len(ncoi_v3)} in v3; "
  f"{sum(len(v) for v in removed_any.values())} site-instances removed, all NcoI. [EVIDENCE]")
w(f"- **No new site of any catalogue enzyme.** Set difference per construct, both strands, all 35 "
  f"enzymes: {sum(len(v) for v in added_any.values())} additions. [EVIDENCE]")
w(f"- **Golden Gate still zero on both strands**: {gg_v3} across the 24. [EVIDENCE]")
w(f"- **H-box histidine present at the expected position in all 24**, and at the *same* construct "
  f"position as in v2 — a synonymous change cannot move it, and this confirms it did not. "
  f"[EVIDENCE] "
  f"{sum(1 for d in r3 if r3[d]['hbox_residue'] == 'H')}/{len(r3)} carry `H`.")
w("")
w("### One comparison that had to be made carefully")
w("")
w("The junction-spanning SigA count **looks** different between `junctions_v2.csv` and the v3 "
  "check, and it is not. `junctions_v2.csv`'s own `spurious_sigA_at_junction` column was computed "
  "**sense-strand only**; the shared module scans both strands. Comparing one against the other "
  "would measure the change of method, not the effect of the codon edit. [EVIDENCE] Recomputing "
  "**both** sides with the identical shared-module scan gives an identical set: the single "
  "pre-existing antisense junction-spanning window in `JXN_MCPX_PHOQ_dhp_direct_m1` (0.722 of "
  "matrix max) is present in v2 and still present in v3, unchanged. The codon edit neither created "
  "nor removed a junction-spanning motif.")
w("")
w("---")
w("")

# ================================================================= TASK 3
w("## 3. Task 3 — the regenerated manifest")
w("")
w("### Count, verified by counting")
w("")
w(f"**{len(m2)} constructs.** [EVIDENCE] "
  f"`order_manifest_final_v2.csv` {len(m2)} rows · `order_manifest_final_v2_checks.csv` {len(c2)} "
  f"rows · `order_submit_final_v2.csv` {len(sub2)} rows · `order_submit_final_v2.fasta` {fa2n} "
  f"records · source panels: `order_manifest_v2.csv` "
  f"{len(list(csv.DictReader(open(D/'order_manifest_v2.csv'))))} + `junctions_v3.csv` {len(r3)} = "
  f"{len(list(csv.DictReader(open(D/'order_manifest_v2.csv')))) + len(r3)}. Expected 93 — "
  f"**{'MATCH' if len(m2) == 93 else 'MISMATCH'}**.")
w("")
rows = []
for p, n in sorted(Counter(r["panel"] for r in m2.values()).items()):
    ls = [I(r["length_bp"]) for r in m2.values() if r["panel"] == p]
    rows.append([f"`{p}`", n, f"{min(ls)}–{max(ls)}", sum(ls)])
rows.append(["**TOTAL**", f"**{len(m2)}**",
             f"**{min(I(r['length_bp']) for r in m2.values())}–{max(I(r['length_bp']) for r in m2.values())}**",
             f"**{sum(I(r['length_bp']) for r in m2.values())}**"])
table(["panel", "constructs", "length range (bp)", "total bp"], rows)

w("### What moved between the v1 and v2 consolidated manifests")
w("")
seqdiff = [k for k in m1 if m1[k]["full_sequence"] != m2[k]["full_sequence"]]
w(f"**{len(seqdiff)} of {len(m1)} sequences changed, all kinase, each by exactly one nucleotide.** "
  f"[EVIDENCE] Construct ids are identical between the two manifests, and total length is unchanged "
  f"at {sum(I(r['length_bp']) for r in m2.values())} bp — a synonymous substitution changes no length.")
w("")
chg = [c for c in c1[list(c1)[0]] if any(c1[k][c] != c2[k][c] for k in c1)]
rows = []
for c in chg:
    n = sum(1 for k in c1 if c1[k][c] != c2[k][c])
    if c == "GC_percent":
        d = [F(c1[k][c]) - F(c2[k][c]) for k in c1 if c1[k][c] != c2[k][c]]
        note = f"drops {min(d):.3f}–{max(d):.3f} points (one C→T)"
    elif c == "dG_full_kcal_per_mol":
        d = [F(c1[k][c]) - F(c2[k][c]) for k in c1 if c1[k][c] != c2[k][c]]
        note = f"changes {min(d):+.2f} to {max(d):+.2f} kcal/mol; the worst 60-nt window is unchanged in all 18"
    elif c == "vector_site_NcoI_NdeI":
        note = "was an NcoI listing, now `none` in all 18"
    elif c == "n_restriction_sites_35cat":
        note = "drops by 2 per construct (the palindrome on both strands)"
    elif c == "restriction_sites":
        note = "the NcoI tokens are gone; every other token is unchanged"
    else:
        note = ""
    rows.append([f"`{c}`", n, note])
table(["check column", "constructs affected", "what changed"], rows)
same = [c for c in c1[list(c1)[0]] if c not in chg]
w(f"**Every other check column is identical across all 93.** [EVIDENCE] That includes "
  f"`golden_gate_sites`, `homopolymer_gt6`, `siga_hits_ge_0.55_fwd`, `siga_junction_spanning_fwd`, "
  f"`sd_atg_hits`, `sd_atg_junction_spanning`, `gtracts`, `internal_repeat_20nt`, "
  f"`synthesis_difficulty`, `dG60_worst_local` and `under_vendor_min_125bp` — "
  f"{len(same)} columns unchanged.")
w("")
w(f"The site listing shrinks from {len(s1)} rows to {len(s2)} — exactly "
  f"{len(s1) - len(s2)} fewer, the 36 NcoI instances. [EVIDENCE] The motif, pair and component "
  f"files are unchanged in length "
  f"({len(mo2)} motif rows, "
  f"{len(list(csv.DictReader(open(D/'order_manifest_final_v2_pairs.csv'))))} pair rows, "
  f"{len(list(csv.DictReader(open(D/'order_manifest_final_v2_components.csv'))))} component rows).")
w("")
w("### Combined check across all 93, run through the shared module")
w("")
gg2 = [x for x in s2 if x["enzyme"] in GOLDEN_GATE]
nc2 = [x for x in s2 if x["enzyme"] == "NcoI"]
jsites = [x for x in s2 if x["spans_component_junction"] == "YES"]
sig2 = [x for x in mo2 if x["motif"] == "SigA_ext10"]
sd2 = [x for x in mo2 if x["motif"] == "SD+ATG"]
table(["check", "result across all 93"],
      [["Golden Gate sites (BsaI/BsmBI/BbsI/SapI/AarI), both strands", f"**{len(gg2)}**"],
       ["NcoI sites", f"**{len(nc2)}**  (was {len([x for x in s1 if x['enzyme']=='NcoI'])})"],
       [f"all {len(CATALOGUE)} catalogue enzymes, both strands",
        f"{len(s2)} sites on {len({x['construct_id'] for x in s2})} constructs"],
       ["sites spanning a component junction", f"{len(jsites)}"],
       ["identical sequences", f"{len(sub2) - len({r['full_sequence'] for r in sub2})}"],
       ["homopolymer runs > 6", f"{sum(1 for k in c2 if c2[k]['homopolymer_gt6'] != 'none')}"],
       ["SigA ext-10 windows ≥ 0.55 of max",
        f"{len(sig2)} ({sum(1 for x in sig2 if x['spans_component_junction']=='YES')} junction-spanning)"],
       ["spurious SD + ATG",
        f"{len(sd2)} ({sum(1 for x in sd2 if x['spans_component_junction']=='YES')} junction-spanning)"],
       ["constructs under 125 bp", f"{sum(1 for k in c2 if c2[k]['under_vendor_min_125bp'] == 'YES')}"],
       ["component maps reproducing their construct base-for-base", f"{len(m2)}/{len(m2)}"]])
w(f"Sites by enzyme, from `order_manifest_final_v2_sites.csv`:")
w("")
table(["enzyme", "sites", "constructs", "class"],
      [[f"`{e}`", n, len({x['construct_id'] for x in s2 if x['enzyme'] == e}),
        "BLOCKER (Golden Gate)" if e in GOLDEN_GATE else
        ("conditional (pECXT99A opening)" if e in VECTOR_SITES else "note")]
       for e, n in Counter(x["enzyme"] for x in s2).most_common()])
w("**The `CONDITIONAL_pECXT99A_OPENING_SITE` class is now empty.** [EVIDENCE] It held 18 "
  "constructs in the v1 manifest; the conditional dependency on an unchosen vector is discharged.")
w("")
w("---")
w("")
# ================================================================= CLOSING
w("## 4. Files written, and files changed in place")
w("")
w("### New files (nothing overwritten)")
w("")
table(["path", "contents"],
      [["`scripts/seqchecks.py`", f"the shared module: {len(CATALOGUE)}-enzyme catalogue, "
        f"`site_scan`, `sigA_scan`, `sd_atg_scan`, `basic_checks`, `junction_aware`, "
        f"`positive_control_check`"],
       ["`scripts/test_seqchecks.py`", f"{n_pass + n_fail} unit tests and positive-control fixtures"],
       ["`designs/junctions_v3.csv`", f"{len(r3)} rows — the NcoI-fixed kinase panel with edit "
        f"provenance and full-catalogue check columns"],
       ["`designs/junctions_v3.fasta`", f"{len(v3fa)} records"],
       ["`designs/order_manifest_final_v2.csv`", f"{len(m2)} rows"],
       ["`designs/order_manifest_final_v2_checks.csv`", f"{len(c2)} rows"],
       ["`designs/order_submit_final_v2.fasta`", f"{fa2n} records, id and sequence only"],
       ["`designs/order_submit_final_v2.csv`", f"{len(sub2)} rows, `construct_id` and "
        f"`full_sequence` only"],
       ["`REPORT_repo_consolidation.md`", "this report"],
       ["`designs/order_manifest_final_v2_sites.csv`", f"{len(s2)} rows, one per restriction site"],
       ["`designs/order_manifest_final_v2_motifs.csv`", f"{len(mo2)} rows, one per SigA / SD+ATG hit"],
       ["`designs/order_manifest_final_v2_pairs.csv`",
        f"{len(list(csv.DictReader(open(D/'order_manifest_final_v2_pairs.csv'))))} rows"],
       ["`designs/order_manifest_final_v2_components.csv`",
        f"{len(list(csv.DictReader(open(D/'order_manifest_final_v2_components.csv'))))} rows, the "
        f"verified component map"],
       ["`scripts/apply_ncoi_fix.py`, `scripts/verify_ncoi_fix.py`, "
        "`scripts/consolidate_v2.py`, `scripts/regression_seqchecks.py`, "
        "`scripts/report_repo_consolidation.py`", "the machinery for the above"]])
w("Every writer refuses to start if its target exists. [EVIDENCE] `junctions_v2.*`, "
  "`order_manifest_final*`, `order_submit_final*` and `REPORT_order_final.md` are untouched.")
w("")
w("### Pre-existing files regenerated in place by the mandated re-run")
w("")
w("The regression requirement is to re-run each panel's checks after refactoring. Re-running a "
  "panel script rewrites that panel's own outputs, so four files now carry the wider screen:")
w("")
if verd:
    table(["file", "what changed", "what did NOT change"],
          [[f"`designs/{v['file']}`",
            f"{len(v['sites_added'])} site listings added ({', '.join(v['added_enzymes'])}); "
            f"flag and count columns follow",
            "every sequence, every row key, every previously-reported site"]
           for v in verd if v["verdict"] == "NEW FIND"])
w("A pristine pre-refactor copy of `designs/`, `results/` and `data/cache/` was taken before any "
  "edit and is what the before/after comparison in §0 is computed against. [EVIDENCE] All eight "
  "panel scripts were confirmed **deterministic** first — each was run once before any refactoring "
  "and reproduced the repo byte-for-byte — so any later difference is attributable to the refactor "
  "and not to run-to-run variation.")
w("")
w("---")
w("")
w("## 5. What remains before the panel is order-ready")
w("")
w(f"Unchanged from the previous consolidation except that item 3 is now closed.")
w("")
table(["#", "step", "status"],
      [["1", "**Define the Golden Gate overhangs.** All 93 fragments need mutually unique 4-nt "
        "overhangs *across* panels. [NOT FOUND] A search of `scripts/`, `designs/`, `results/`, "
        "`*.py` and `*.md` for `overhang`, `fusion site` and `sticky` still returns zero hits.",
        "**OPEN — this is the gate**"],
       ["2", "**Re-run the enzyme scan after step 1.** Appending overhangs and their flanks can "
        "create a Type IIS site that does not exist today. Everything in §3 describes the fragments "
        "as they stand now. This is now a one-line call into the shared module rather than a "
        "rewrite.", "**OPEN — depends on 1**"],
       ["3", "**Settle the kinase panel's destination vector, or remove the NcoI dependency.**",
        "**CLOSED** — removed unconditionally, 18 constructs, one synonymous codon each"],
       ["4", "**Decide the purchase split.** "
        f"{sum(1 for k in c2 if c2[k]['under_vendor_min_125bp'] == 'YES')} constructs are under "
        f"125 bp and are probably cheaper as annealed oligo pairs than as gene fragments.",
        "OPEN — a quote question, not a design one"]])
w("A fifth item is now worth naming, because the refactor exposed it:")
w("")
w("**5. Decide whether the kinase codon optimiser's *constraint* set should be widened.** "
  "[INFERENCE, reasoning named] Today it avoids 5 enzymes while the check screens 35, so a site it "
  "does not avoid is caught after the fact and fixed by hand — which is what §2 just did. Adding "
  "`NcoI`/`NdeI`, or the whole catalogue, to `_bad_spans` would prevent the next one instead of "
  "catching it. It was **not** done here because widening the constraint re-derives every codon "
  "downstream of the first change and would redesign all 24 constructs, which is a different act "
  "from the targeted, auditable edit that was asked for. It is a design decision, and it is cheap "
  "to make now that there is one list to widen.")
w("")
w("---")
w("")
w("## 6. What none of this establishes")
w("")
w("- **The SigA matrix is still not a trained PWM.** Every SigA number here is a screening signal "
  "from a matrix built out of a textual consensus. A clean scan is evidence of no *consensus-like* "
  "element and nothing stronger. The caveat now lives in the shared module's docstring and is "
  "unit-tested for presence, so it travels with the function rather than with a report.")
w("- **A clean enzyme scan is a statement about 35 enzymes.** It is not a statement about any "
  "enzyme outside the catalogue. What the refactor guarantees is that all 93 constructs are "
  "screened against the *same* 35 — not that 35 is the right number.")
w("- **Folding energy predicts nothing about strength here** and is used only as a defect and cost "
  "screen. The 18 full-fragment MFE changes in §3 are a consequence of a one-nucleotide edit and "
  "carry no functional claim.")
w("- **A synonymous codon change is not functionally free in principle.** It cannot change the "
  "protein — that is verified by back-translation for all 24 — but codon choice can affect "
  "translation rate and co-translational folding. `TCT` was chosen because it is a documented, "
  "above-floor codon in this host's own table, not because the change is guaranteed to be inert. "
  "[INFERENCE, reasoning named]")
w("- **None of this is experimental validation.** Every sequence traces to an accession, a "
  "citation, or a named generating script; none of that is evidence that any construct expresses, "
  "signals, or assembles.")
w("")

OUT.write_text("\n".join(L) + "\n")
print(f"wrote {OUT.relative_to(ROOT)} ({len(L)} lines, {len(OUT.read_text())} chars)")
