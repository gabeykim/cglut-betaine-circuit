"""Task 2: map -35 and extended -10 elements in each core promoter against
the SigA consensus scoring matrix (scripts/siga_consensus.py).

For each promoter, scans every ungapped window for the best extended-10 hit
(the element the host leans on most heavily -- Patek & Nesvera 2011;
Pfeifer-Sancar et al. 2013), then searches a chemically plausible window
upstream of it for the best -35 hit, allowing spacer lengths from 13-25 bp
(E. coli-style -35/-10 spacers run ~15-19 bp; the search window is
deliberately wider than that canonical range since this host's promoters
are extended-10-dominant and -35 spacing is not independently established
here -- this breadth, and the fact that it is a search rather than an
assumed fixed spacer, is itself [INFERENCE], stated explicitly).

Confidence tiers (reasoned thresholds, not calibrated against a population of
true positives/negatives -- there isn't one available here):
  HIGH:   extended-10 score >= 70% of max AND -35 score >= 30% of max
  MEDIUM: extended-10 score >= 55% of max (any -35)
  LOW:    below that -- flagged, and per the task instruction, excluded from
          the operator-design panel in Task 3.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from siga_consensus import EXT10_PWM, MINUS35_PWM, best_hit, score_window, max_score

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

MINUS35_SEARCH_MIN = 13   # bp between end of -35 and start of extended -10, search range
MINUS35_SEARCH_MAX = 25

# The native promoter sequences fed into this mapper are now the EXACT
# experimentally-validated amplicons recovered in scripts/fetch_core_promoters.py
# (from the paper's own primers), not an arbitrary upstream window -- so no
# additional proximal-zone restriction is applied here; the whole given
# sequence (34-174 bp across the 5 promoters) is the biologically correct
# search space already. An earlier version of this script tried to compensate
# for a too-narrow/too-wide GUESSED window with a second guessed "proximal
# zone" parameter; that was unstable (it flipped PsodA's confidence tier
# depending on the zone size) and is why the amplicon-recovery approach in
# fetch_core_promoters.py replaced it instead of tuning this parameter
# further -- real evidence, not a better-tuned guess.
PROXIMAL_ZONE_BP = 10**9


def map_elements(seq: str, proximal_only: bool = True):
    seq = seq.upper()
    ext10_max = max_score(EXT10_PWM)
    m35_max = max_score(MINUS35_PWM)

    # extended -10: restrict the search to the proximal zone nearest the gene
    # (for short, already-minimal synthetic promoters, the whole sequence IS
    # the proximal zone, so this has no effect there)
    search_seq = seq[-PROXIMAL_ZONE_BP:] if proximal_only and len(seq) > PROXIMAL_ZONE_BP else seq
    zone_offset = len(seq) - len(search_seq)
    e_start_local, e_score = best_hit(search_seq, EXT10_PWM)
    e_start = e_start_local + zone_offset
    e_end = e_start + EXT10_PWM["width"]

    # -35: search only the plausible upstream window relative to the extended -10 hit
    m_best = None
    win_lo = max(0, e_start - MINUS35_SEARCH_MAX - MINUS35_PWM["width"])
    win_hi = max(0, e_start - MINUS35_SEARCH_MIN)
    for i in range(win_lo, win_hi):
        if i + MINUS35_PWM["width"] > len(seq):
            continue
        s = score_window(seq[i:i + MINUS35_PWM["width"]], MINUS35_PWM)
        if m_best is None or s > m_best[1]:
            m_best = (i, s)

    result = {
        "ext10_start0": e_start, "ext10_end0": e_end, "ext10_seq": seq[e_start:e_end],
        "ext10_score": round(e_score, 3), "ext10_max": round(ext10_max, 3),
        "ext10_frac": round(e_score / ext10_max, 3),
    }
    if m_best is not None:
        m_start, m_score = m_best
        result.update({
            "minus35_start0": m_start, "minus35_end0": m_start + MINUS35_PWM["width"],
            "minus35_seq": seq[m_start:m_start + MINUS35_PWM["width"]],
            "minus35_score": round(m_score, 3), "minus35_max": round(m35_max, 3),
            "minus35_frac": round(m_score / m35_max, 3),
            "spacer_bp": e_start - (m_start + MINUS35_PWM["width"]),
        })
    else:
        result.update({"minus35_start0": None, "minus35_frac": 0.0, "spacer_bp": None})

    if result["ext10_frac"] >= 0.70 and result.get("minus35_frac", 0) >= 0.30:
        confidence = "HIGH"
    elif result["ext10_frac"] >= 0.55:
        confidence = "MEDIUM"
    else:
        confidence = "LOW"
    result["confidence"] = confidence
    return result


def main():
    promoters = json.loads((DATA / "cache" / "core_promoters.json").read_text())
    mapped = {}
    for name, p in promoters.items():
        m = map_elements(p["sequence"])
        mapped[name] = m
        print(f"=== {name} ({p['strength_pct_ptrc']}% of Ptrc, {len(p['sequence'])} bp) ===")
        print(f"  extended-10: {m['ext10_seq']} @ [{m['ext10_start0']}:{m['ext10_end0']}]  "
              f"score={m['ext10_score']}/{m['ext10_max']} ({100*m['ext10_frac']:.0f}%)")
        if m["minus35_start0"] is not None:
            print(f"  -35:         {m['minus35_seq']} @ [{m['minus35_start0']}:{m['minus35_end0']}]  "
                  f"score={m['minus35_score']}/{m['minus35_max']} ({100*m['minus35_frac']:.0f}%)  "
                  f"spacer to ext-10 = {m['spacer_bp']} bp")
        else:
            print("  -35: no candidate found in search window")
        print(f"  confidence: {m['confidence']}")
        print()

    out = DATA / "cache" / "promoter_elements.json"
    out.write_text(json.dumps(mapped, indent=1))
    print(f"Wrote element map to {out}")

    excluded = [n for n, m in mapped.items() if m["confidence"] == "LOW"]
    if excluded:
        print(f"\nEXCLUDED (LOW confidence, elements not confidently assigned): {excluded}")
    else:
        print("\nAll promoters assigned at MEDIUM or HIGH confidence -- none excluded on element-mapping grounds.")


if __name__ == "__main__":
    main()
