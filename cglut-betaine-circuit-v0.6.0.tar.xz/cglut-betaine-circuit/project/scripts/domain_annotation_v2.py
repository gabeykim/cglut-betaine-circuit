"""Pfam domain annotation, TM prediction and H-box location for a set of
bacterial signalling proteins.  (v2 -- supersedes domain_annotation.py)

WHAT CHANGED FROM v1, AND WHY IT MATTERS
----------------------------------------
1. HMM scoring now uses Pfam's curated gathering thresholds (--cut_ga), not an
   arbitrary --domE 1e-3.  Every Pfam model ships a GA line that is the curator's
   own answer to "is this a real domain?".  v1 ignored it and reported three
   hits that Pfam itself rejects.  Sub-GA hits are still recorded, but in a
   separate column and never presented as domains.
2. TM prediction uses DeepTMHMM 1.0.57 (real predictor), not Kyte-Doolittle.
   v1's KD caller also emitted overlapping duplicate helices and loops with
   negative length; the KD code here is kept only as a third cross-check and
   merges overlapping segments.
3. The H-box column is derived independently per model from that model's own
   match-state emission probabilities, then cross-validated against an
   experimentally confirmed phosphohistidine.  v1 transferred a column index
   from HisKA onto HisKA_3, which is not a valid operation -- different models
   have different coordinate systems.

METHODS
  * Domains   : hmmscan (HMMER 3.4) against a pressed DB of the seven requested
                Pfam models.  hmmscan, not hmmsearch: the query set is proteins
                and the database is profiles.
  * TM        : DeepTMHMM 1.0.57 (Hallgren et al. 2022), run via pybiolib on
                BioLib cloud.  Cross-checked against UniProt curated topology
                and against Kyte-Doolittle (window 19) as a weak third opinion.
  * H-box     : per-model match-state column with the highest P(His), validated
                against E. coli EnvZ P0AEJ4 His243 and Salmonella PhoQ P0DM80
                His277 -- both UniProt "Phosphohistidine; by autocatalysis",
                evidence ECO:0000269 (experimental).
"""
import csv, gzip, json, math, re, ssl, subprocess, urllib.request
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA, RESULTS, CACHE = ROOT / "data", ROOT / "results", ROOT / "data" / "cache"
PFAM, FASTA, DTM = CACHE / "pfam", DATA / "fasta", CACHE / "deeptmhmm"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36"

MODELS = ["PF02743", "PF00672", "PF00512", "PF07568", "PF07730", "PF02518", "PF00072"]
MODEL_NAME = {"PF02743": "dCache_1", "PF00672": "HAMP", "PF00512": "HisKA",
              "PF07568": "HisKA_2", "PF07730": "HisKA_3", "PF02518": "HATPase_c",
              "PF00072": "Response_reg"}
# NOTE: the task called PF02743 "Cache_1"; Pfam's current name for PF02743 is
# dCache_1 (the double-Cache family).  Same accession, renamed family.
HISKA_FAMILY = {"HisKA", "HisKA_2", "HisKA_3"}

# requested -> (accession used, organism, protein name, resolution note)
TARGETS = [
    ("P14147", "P0DM80", "Salmonella enterica ser. Typhimurium LT2",
     "Virulence sensor histidine kinase PhoQ",
     "REQUESTED ACCESSION IS DEAD. UniProt REST reports P14147 entryType=Inactive, "
     "inactiveReasonType=DEMERGED, mergeDemergeTo=[E1WFA0, P0DM80]; its former ID was "
     "PHOQ_SALTY. P0DM80 (strain LT2) chosen over E1WFA0 (strain SL1344) so the entry "
     "stays strain-cognate with P0DM78 elsewhere in this set."),
    ("P0DM78", "P0DM78", "Salmonella enterica ser. Typhimurium LT2",
     "Virulence transcriptional regulatory protein PhoP", "active accession, used as given"),
    ("P0AEJ4", "P0AEJ4", "Escherichia coli K-12", "Sensor histidine kinase EnvZ",
     "active accession, used as given"),
    ("P0AA16", "P0AA16", "Escherichia coli K-12", "DNA-binding dual transcriptional regulator OmpR",
     "active accession, used as given"),
    ("PA4633", "Q9HVF8", "Pseudomonas aeruginosa PAO1", "Probable chemotaxis transducer",
     "locus tag, not a UniProt accession. UniProt entry Q9HVF8 carries GN=PA4633 directly "
     "(verified in the cached FASTA header)."),
    ("ECA_RS10935", "Q6D515", "Pectobacterium atrosepticum SCRI1043",
     "Methyl-accepting chemotaxis protein",
     "RefSeq locus tag. NCBI Gene 2883412 lists otheraliases='ECA_RS10935, ECA2226'; "
     "UniProt Q6D515 carries GN=ECA2226. WARNING: Q6D515 is N-terminally TRUNCATED by 46 "
     "residues relative to RefSeq WP_043878053.1 -- see the truncation analysis."),
    ("McpX (S. meliloti)", "Q92SH9", "Sinorhizobium (Rhizobium) meliloti 1021",
     "Chemoreceptor McpX",
     "name only, no accession supplied. Resolved by UniProt gene search "
     "gene:mcpX AND organism_id:266834 -> single hit Q92SH9 (gene names 'mcpX SMc01104')."),
]
# Full-length replacement for the truncated Pectobacterium entry.
REFSEQ_ECA = ("ECA_RS10935", "WP_043878053.1", "Pectobacterium atrosepticum SCRI1043",
              "Methyl-accepting chemotaxis protein (full-length RefSeq)",
              "RefSeq protein for locus ECA_RS10935, 657 aa. Q6D515 residue i maps to "
              "residue i+46 here; residues 2-611 of Q6D515 are identical to 48-657 here.")
ECA_OFFSET = 46

KD = {"A": 1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5, "Q": -3.5, "E": -3.5,
      "G": -0.4, "H": -3.2, "I": 4.5, "L": 3.8, "K": -3.9, "M": 1.9, "F": 2.8,
      "P": -1.6, "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2}
KD_WINDOW, KD_THRESHOLD, KD_MIN_LEN = 19, 1.6, 15
AA20 = "ACDEFGHIKLMNPQRSTVWY"

# UniProt curated topology (all ECO:0000255/0000256/0000305 -- inference, NOT experiment)
UNIPROT_TM = {
    "P0DM80": [(17, 37), (194, 214)], "P0AEJ4": [(16, 35), (159, 179)],
    "Q9HVF8": [(6, 31), (363, 384)], "Q6D515": [(271, 293)],
    "Q92SH9": [(12, 33), (318, 339)], "P0DM78": [], "P0AA16": [],
}
UNIPROT_TM_EVIDENCE = {"P0DM80": "ECO:0000255", "P0AEJ4": "ECO:0000305",
                       "Q9HVF8": "ECO:0000256", "Q6D515": "ECO:0000256",
                       "Q92SH9": "ECO:0000256", "P0DM78": "n/a", "P0AA16": "n/a"}
# InterPro's own Pfam boundaries, used as an independent boundary cross-check.
INTERPRO = {
    ("P0DM80", "HATPase_c"): (376, 477), ("P0DM78", "Response_reg"): (4, 113),
    ("P0AEJ4", "HisKA"): (234, 290), ("P0AEJ4", "HAMP"): (177, 226),
    ("P0AEJ4", "HATPase_c"): (334, 439), ("P0AA16", "Response_reg"): (7, 117),
    ("Q9HVF8", "HAMP"): (382, 431), ("Q6D515", "dCache_1"): (4, 266),
    ("Q92SH9", "HAMP"): [(339, 390), (429, 471)],
}
# Pfam families outside the requested seven that cover these proteins (InterPro).
NON_REQUESTED = {
    "P0DM80": [("PF08918", "PhoQ Sensor", 10, 189),
               ("PF26769", "Sensor protein PhoQ-like, HAMP domain", 218, 263)],
    "P0DM78": [("PF00486", "Trans_reg_C", 147, 221)],
    "P0AA16": [("PF00486", "Trans_reg_C", 157, 232)],
    "Q9HVF8": [("PF00015", "MCP signalling domain", 495, 678)],
    "Q6D515": [("PF00015", "MCP signalling domain", 411, 566)],
    "Q92SH9": [("PF00015", "MCP signalling domain", 534, 690),
               ("PF22673", "MCP-like first PDC sensor domain", 93, 215)],
}
HBOX_EXPERIMENTAL = {"P0AEJ4": 243, "P0DM80": 277}   # UniProt ECO:0000269


def ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def fetch(url, dest, binary=False):
    if dest.exists():
        return dest.read_bytes() if binary else dest.read_text()
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=90, context=ctx()) as r:
        blob = r.read()
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(blob)
    print(f"    fetched {dest.name}")
    return blob if binary else blob.decode()


def ensure_inputs():
    """Cache every FASTA and HMM. Returns {accession: (seq, header, retrieved_on)}."""
    seqs = {}
    for _r, acc, _o, _n, _note in TARGETS:
        p = FASTA / f"{acc}.fasta"
        txt = fetch(f"https://rest.uniprot.org/uniprotkb/{acc}.fasta", p)
        ls = txt.strip().split("\n")
        seqs[acc] = ("".join(ls[1:]).replace("*", ""), ls[0][1:],
                     date.fromtimestamp(p.stat().st_mtime).isoformat())
    p = FASTA / "WP_043878053.1.fasta"
    txt = fetch("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
                "?db=protein&id=WP_043878053.1&rettype=fasta&retmode=text", p)
    ls = txt.strip().split("\n")
    seqs["WP_043878053.1"] = ("".join(ls[1:]), ls[0][1:],
                              date.fromtimestamp(p.stat().st_mtime).isoformat())
    for pf in MODELS:
        h = PFAM / f"{pf}.hmm"
        if not h.exists():
            gz = fetch(f"https://www.ebi.ac.uk/interpro/wwwapi/entry/pfam/{pf}/?annotation=hmm",
                       PFAM / f"{pf}.hmm.gz", binary=True)
            h.write_bytes(gzip.decompress(gz))
    return seqs


def build_db(tag="domains7_v2"):
    db = PFAM / f"{tag}.hmm"
    db.write_text("".join((PFAM / f"{pf}.hmm").read_text() for pf in MODELS))
    subprocess.run(["hmmpress", "-f", str(db)], check=True, capture_output=True)
    return db


def ga_thresholds():
    """{model_name: (sequence_GA, domain_GA)} straight out of the cached HMM files."""
    out = {}
    for pf in MODELS:
        for ln in (PFAM / f"{pf}.hmm").read_text().split("\n"):
            if ln.startswith("GA "):
                a, b = ln.split()[1], ln.split()[2].rstrip(";")
                out[MODEL_NAME[pf]] = (float(a), float(b))
                break
    return out


def _domtbl(path):
    rows = []
    for line in open(path):
        if line.startswith("#"):
            continue
        f = line.split()
        rows.append({"model": f[0], "model_acc": f[1], "accession": f[3],
                     "seq_bitscore": float(f[7]), "dom_bitscore": float(f[13]),
                     "i_evalue": float(f[12]), "c_evalue": float(f[11]),
                     "hmm_from": int(f[15]), "hmm_to": int(f[16]),
                     "start": int(f[17]), "end": int(f[18]),
                     "env_from": int(f[19]), "env_to": int(f[20])})
    return rows


def run_hmmscan(db, seqs, accs, tag):
    """Two passes: --cut_ga (what Pfam itself would call a domain) and permissive."""
    qf = CACHE / f"queries_{tag}.fasta"
    with open(qf, "w") as fh:
        for a in accs:
            fh.write(f">{a}\n{seqs[a][0]}\n")
    ga_dom, ga_aln = CACHE / f"hits_ga_{tag}.domtblout", CACHE / f"hits_ga_{tag}.txt"
    pm_dom, pm_aln = CACHE / f"hits_perm_{tag}.domtblout", CACHE / f"hits_perm_{tag}.txt"
    subprocess.run(["hmmscan", "--cut_ga", "--domtblout", str(ga_dom), "-o", str(ga_aln),
                    str(db), str(qf)], check=True, capture_output=True)
    subprocess.run(["hmmscan", "-E", "10", "--domE", "10", "--domtblout", str(pm_dom),
                    "-o", str(pm_aln), str(db), str(qf)], check=True, capture_output=True)
    return _domtbl(ga_dom), _domtbl(pm_dom), ga_aln, pm_aln


def parse_alignments(aln_path):
    """(query, model, hmm_from, hmm_seq, ali_from, q_seq) per reported domain."""
    out, cur_q, cur_m = [], None, None
    lines = open(aln_path).read().split("\n")
    for i, ln in enumerate(lines):
        if ln.startswith("Query:"):
            cur_q = ln.split()[1]
        elif ln.startswith(">> "):
            cur_m = ln.split()[1]
        elif ln.strip().startswith("== domain"):
            hmm_line = q_line = None
            for b in lines[i:i + 12]:
                mm = re.match(r"\s+\S+\s+(\d+)\s+(\S+)\s+(\d+)\s*$", b)
                if not mm:
                    continue
                if hmm_line is None:
                    hmm_line = (int(mm.group(1)), mm.group(2))
                elif q_line is None and mm.group(2).upper() != mm.group(2).lower():
                    q_line = (int(mm.group(1)), mm.group(2))
            if hmm_line and q_line:
                out.append({"accession": cur_q, "model": cur_m, "hmm_from": hmm_line[0],
                            "hmm_seq": hmm_line[1], "ali_from": q_line[0], "q_seq": q_line[1]})
    return out


def hbox_columns():
    """Match-state column with the highest P(His) in each HisKA-family model.

    Derived from the model's own emission probabilities, so each model is scored
    in its OWN coordinate system -- a column index is not portable between models.
    """
    cols = {}
    for pf in ("PF00512", "PF07568", "PF07730"):
        lines = open(PFAM / f"{pf}.hmm").read().split("\n")
        i = next(k for k, l in enumerate(lines) if l.startswith("HMM "))
        rows, j = [], i + 1
        while j < len(lines):
            p = lines[j].split()
            if p and p[0].isdigit() and len(p) >= 21:
                rows.append((int(p[0]), [math.exp(-float(x)) if x != "*" else 0.0
                                         for x in p[1:21]]))
                j += 3
            else:
                j += 1
        hi = AA20.index("H")
        col, pr = max(rows, key=lambda r: r[1][hi])
        cols[MODEL_NAME[pf]] = (col, round(pr[hi], 3))
    return cols


def hmm_column_to_residue(a, col):
    """Which full-length residue sits at match-state column `col` of this alignment?"""
    h, q = a["hmm_seq"], a["q_seq"]
    hc, qp = a["hmm_from"] - 1, a["ali_from"] - 1
    for i in range(len(q)):
        if h[i] != ".":
            hc += 1
        if q[i] != "-":
            qp += 1
        if hc == col and h[i] != "." and q[i] != "-":
            return qp, q[i].upper()
    return None, None


def kyte_doolittle_tm(seq):
    """Weak third opinion. Overlapping segments are MERGED (v1 emitted duplicates)."""
    w = KD_WINDOW
    if len(seq) < w:
        return []
    prof = [sum(KD.get(c, 0.0) for c in seq[i:i + w]) / w for i in range(len(seq) - w + 1)]
    segs, cur = [], []
    for i, v in enumerate(prof):
        if v >= KD_THRESHOLD:
            cur.append(i)
        elif cur:
            segs.append(cur); cur = []
    if cur:
        segs.append(cur)
    hel = []
    for s in segs:
        st, en = s[0] + 1, s[-1] + w
        if en - st + 1 >= KD_MIN_LEN:
            hel.append({"start": st, "end": en, "peak_kd": round(max(prof[s[0]:s[-1] + 1]), 2)})
    merged = []
    for h in sorted(hel, key=lambda x: x["start"]):
        if merged and h["start"] <= merged[-1]["end"]:
            merged[-1]["end"] = max(merged[-1]["end"], h["end"])
            merged[-1]["peak_kd"] = max(merged[-1]["peak_kd"], h["peak_kd"])
        else:
            merged.append(dict(h))
    return merged


def parse_deeptmhmm(path):
    """{name: [(label, start, end), ...]} from a DeepTMHMM TMRs.gff3."""
    out = {}
    for ln in open(path):
        ln = ln.strip()
        if not ln or ln.startswith("#") or ln.startswith("//"):
            continue
        f = ln.split("\t")
        if len(f) >= 4:
            out.setdefault(f[0], []).append((f[1], int(f[2]), int(f[3])))
    return out
