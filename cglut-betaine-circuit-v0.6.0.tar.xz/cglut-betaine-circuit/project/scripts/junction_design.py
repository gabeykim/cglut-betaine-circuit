"""Fusion-junction design between a sensor N-terminal part and a signalling
C-terminal part, with heptad-register analysis and C. glutamicum codon output.

BOUNDARIES ARE READ, NOT RE-DERIVED.  Every residue number used to place a
junction comes from results/domain_boundaries_v2.csv or
results/tm_predictions_v2.csv.  The two exceptions are stated explicitly and
tagged as inference in the report:
  * PhoQ HAMP is taken as PF26769 218-263 (from results/REPORT_domains.md §7),
    because the generic PF00672 hit in the CSV (213-262) fails Pfam's
    gathering threshold and is LOW confidence.
  * PhoQ's DHp start is inferred from the experimentally confirmed H-box
    His277 -- NOT from its sub-threshold HisKA hit -- using the H-box offset
    measured in EnvZ (His243 in HisKA 234-290, i.e. 9 residues in).

ECA_RS10935 is represented by RefSeq WP_043878053.1 (657 aa).  The truncated
UniProt entry Q6D515 is never used.
"""
import csv, json, re, sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from seqchecks import (CATALOGUE, GOLDEN_GATE, site_scan, fmt_sites, revcomp, gc,
                       homopolymers as _homopolymers)

ROOT = Path(__file__).resolve().parent.parent
DATA, RESULTS, DESIGNS, CACHE = ROOT / "data", ROOT / "results", ROOT / "designs", ROOT / "data" / "cache"

# ----------------------------------------------------------------- constants
HOST_GC = 53.8                      # C. glutamicum genome average, per the brief
GC_TOL = 6.0                        # flag a construct outside HOST_GC +/- this
# Enzyme sites come from scripts/seqchecks.py -- this module defines none of its own.
#
# THE OPTIMISER'S CONSTRAINT SET IS DELIBERATELY NARROW, AND THAT NARROWING IS A
# DECISION, NOT AN OVERSIGHT. `optimise`/`repair_all` avoid only the Golden Gate
# sites because widening the constraint would re-derive every codon downstream of
# the first change and therefore redesign every kinase construct, which is a
# different act from checking them. The REPORTING path (`catalogue_hits`) screens
# the full 35, so a site the optimiser does not avoid is still seen. That split --
# narrow constraint, wide check -- is what was missing when 18 of 24 kinase
# constructs picked up the NcoI site HP-4 had already been excluded for.
_GG_SITES = tuple(CATALOGUE[e] for e in GOLDEN_GATE)

# ---------------------------------------------------------------------------
# THE OPTIMISER'S CONSTRAINT SET. Default = the FULL catalogue.
#
# It used to be the 5-enzyme Golden Gate set while every downstream check
# screened 35. That gap is what put an internal NcoI site into 18 of 24
# constructs: designed clean against a narrow list, found dirty by a wide one.
# The default is now wide. A caller wanting the historical narrow behaviour --
# only `run_junction_design_v2.py`, which exists to reproduce a frozen artifact
# byte-for-byte -- must name it explicitly.
CONSTRAINT_ENZYMES = tuple(CATALOGUE)


def _sites_of(enzymes):
    return tuple(CATALOGUE[e] for e in (CONSTRAINT_ENZYMES if enzymes is None else enzymes))


# FALLBACK POLICY, applied in this order and never silently.
# Feasibility analysis (scripts/optimiser_feasibility.py) shows no rung below 0
# is needed for the current panel; the ladder exists so that a future design
# which does need one cannot pass unnoticed.
#   0. synonymous codons at or above the usage floor (min_rel, default 0.10)
#   1. synonymous codons below the floor -- recorded as a floor violation
#   2. relax the homopolymer>6 rule        (a synthesis nuisance, not a blocker)
#   3. relax non-Golden-Gate, non-vector enzymes   (classified "note" in the
#      order report: unused by the selected route)
#   4. relax the vector opening sites NcoI/NdeI    (conditional blockers)
#   5. NEVER relax the Golden Gate set. If a Golden Gate site cannot be removed
#      synonymously the optimiser raises; the design must change at the protein
#      level. Silently emitting a Golden-Gate-dirty CDS is the one outcome this
#      pipeline must not produce.
FALLBACK_LADDER = ("floor", "homopolymer", "note_enzymes", "vector_sites")
RELAXATION_LOG = []
LINKER_C = "GSGSG"                  # strategy C flexible linker (5 residues)
HYDROPHOBIC = set("AVLIMFWYC")

# PhoQ HAMP from PF26769 (see module docstring); PhoQ DHp start from the H-box.
PHOQ_HAMP = (218, 263)
PHOQ_HBOX = 277
ENVZ_HBOX = 243


# ------------------------------------------------------------ boundary input
def load_boundaries():
    """{accession: {'domains': [...], 'tm': {feature: (start,end)}, 'regions': [...]}}"""
    out = defaultdict(lambda: {"domains": [], "tm": {}, "regions": []})
    for r in csv.DictReader(open(RESULTS / "domain_boundaries_v2.csv")):
        out[r["accession"]]["domains"].append(
            {"model": r["model"], "start": int(r["start"]), "end": int(r["end"]),
             "bit": float(r["bit_score"]), "ga": r["passes_pfam_GA"],
             "conf": r["confidence"]})
    for r in csv.DictReader(open(RESULTS / "tm_predictions_v2.csv")):
        if not r["start"]:
            continue
        s, e = int(r["start"]), int(r["end"])
        if r["feature"].startswith("TM"):
            out[r["accession"]]["tm"][r["feature"]] = (s, e, r["confidence"])
        out[r["accession"]]["regions"].append((r["feature"], s, e, r["side"], r["confidence"]))
    return out


def domain(bnd, acc, model):
    for d in bnd[acc]["domains"]:
        if d["model"] == model:
            return d
    return None


def load_protein(acc):
    p = DATA / "fasta" / f"{acc}.fasta"
    return "".join(p.read_text().strip().split("\n")[1:]).replace("*", "")


def element_at(bnd, acc, pos):
    """Which structural element does residue `pos` sit in? Read from the files."""
    hits = []
    for feat, s, e, side, _c in bnd[acc]["regions"]:
        if s <= pos <= e:
            hits.append(f"{feat}({side})" if side else feat)
    for d in bnd[acc]["domains"]:
        if d["start"] <= pos <= d["end"]:
            hits.append(f"{d['model']}[{d['ga']}/{d['conf']}]")
    return ";".join(hits) if hits else "unassigned"


# ------------------------------------------------------- heptad register
KD_SCALE = {"A": 1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5, "Q": -3.5, "E": -3.5,
            "G": -0.4, "H": -3.2, "I": 4.5, "L": 3.8, "K": -3.9, "M": 1.9, "F": 2.8,
            "P": -1.6, "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2}
# Determinacy tiers for a heptad phase call, set from the observed contrast of
# known windows in these very proteins: HAMP AS1 ~1.7 (strongly amphipathic),
# DHp alpha1 ~0.54-0.98, TM helix core ~0.40-0.68 (uniformly hydrophobic, so the
# seven phases barely differ and the register is not really determinable).
DET_WELL, DET_WEAK = 1.0, 0.5


def phase_score(seq, phase):
    """Mean Kyte-Doolittle hydrophobicity at a/d minus mean at b,c,e,f,g.

    A continuous scale rather than a binary hydrophobic/not call: with a binary
    call and a 21-residue window the statistic takes only a couple of distinct
    values, which is too coarse to rest a register verdict on.
    """
    ad = [KD_SCALE.get(c, 0.0) for i, c in enumerate(seq) if (i - phase) % 7 in (0, 3)]
    ot = [KD_SCALE.get(c, 0.0) for i, c in enumerate(seq) if (i - phase) % 7 not in (0, 3)]
    if not ad or not ot:
        return 0.0
    return sum(ad) / len(ad) - sum(ot) / len(ot)


def best_phase(seq):
    """Best heptad phase, its score, and the contrast to the runner-up phase.

    The contrast is the honest part: inside a transmembrane helix every position
    is hydrophobic, all seven phases score alike, and the register is genuinely
    indeterminate. Reporting contrast stops a verdict drawn from a degenerate
    window being presented as if it were well determined.
    """
    sc = sorted(((phase_score(seq, p), p) for p in range(7)), reverse=True)
    return sc[0][1], round(sc[0][0], 3), round(sc[0][0] - sc[1][0], 3)


def determinacy(contrast):
    if contrast >= DET_WELL:
        return "WELL_DETERMINED"
    if contrast >= DET_WEAK:
        return "WEAK"
    return "INDETERMINATE"


def register_analysis(sensor_seq, s_end, acc_seq, a_start, linker_len, win=21):
    """Is the a/d heptad phase continuous across the junction?

    Returns delta in -3..+3 (0 = in phase) plus the determinacy of each side.
    """
    up = sensor_seq[max(0, s_end - win):s_end]                 # residues ending at s_end
    dn = acc_seq[a_start - 1: a_start - 1 + win]               # residues starting at a_start
    if len(up) < 14 or len(dn) < 14:
        return None
    # phase indices are relative to the first residue of each window
    p_up, s_up, c_up = best_phase(up)
    p_dn, s_dn, c_dn = best_phase(dn)
    # convert to absolute residue numbering
    phi_s = (s_end - len(up) + 1 + p_up) % 7        # residue number congruent to an 'a'
    phi_a = (a_start + p_dn) % 7
    # construct position of acceptor residue j:  k = s_end + linker_len + (j - a_start + 1)
    delta = (s_end + linker_len + 1 - a_start - phi_s + phi_a) % 7
    signed = delta if delta <= 3 else delta - 7
    return {"delta": signed, "in_phase": signed == 0,
            "up_contrast": c_up, "dn_contrast": c_dn,
            "up_score": s_up, "dn_score": s_dn,
            "up_determinacy": determinacy(c_up), "dn_determinacy": determinacy(c_dn),
            "determinate": min(c_up, c_dn) >= DET_WELL}


def junction_ad_hydrophobicity(construct, jpos, phi, win=14):
    """Hydrophobic occupancy of a/d positions in a window spanning the junction."""
    lo, hi = max(0, jpos - win), min(len(construct), jpos + win)
    seg = construct[lo:hi]
    ad = [c for i, c in enumerate(seg, start=lo) if ((i + 1) - phi) % 7 in (0, 3)]
    return round(sum(c in HYDROPHOBIC for c in ad) / len(ad), 3) if ad else None


# --------------------------------------------------------- codon optimisation
def load_codon_table():
    d = json.load(open(CACHE / "codon" / "cglut_codon_usage.json"))
    return d, {aa: {c: v["rel_freq"] for c, v in t.items()} for aa, t in d["table"].items()}


def forbidden_hits(dna):
    """Golden Gate sites only -- the OPTIMISER'S constraint set (see _GG_SITES above).

    Deliberately narrow, and named so at every call site. For a real screen of a
    finished sequence use `catalogue_hits`, which is the full 35.
    """
    return fmt_sites(site_scan(dna, enzymes=GOLDEN_GATE))


def catalogue_hits(dna, enzymes=None):
    """Every site in the FULL 35-enzyme catalogue, both strands. The real screen."""
    return fmt_sites(site_scan(dna, enzymes=enzymes))


def homopolymers(dna, n=6):
    return [f"{h['base']}x{h['run']}@{h['start']}" for h in _homopolymers(dna, max_run=n)]


def gc_pct(dna):
    return round(gc(dna), 2) if dna else 0.0


def _bad_spans(dna, enzymes=None, homopolymers_too=True):
    """All constrained enzyme sites and >6 homopolymer runs, as (start, end) spans."""
    spans = []
    rc = revcomp(dna)
    n = len(dna)
    for site in _sites_of(enzymes):
        for m in re.finditer(site, dna):
            spans.append((m.start(), m.end()))
        for m in re.finditer(site, rc):
            spans.append((n - m.end(), n - m.start()))
    if homopolymers_too:
        for m in re.finditer(r"(A{7,}|C{7,}|G{7,}|T{7,})", dna):
            spans.append((m.start(), m.end()))
    return spans


def _tail_clean(tail, enzymes=None):
    """No constrained site or over-long run in this 3' window."""
    if re.search(r"(A{7,}|C{7,}|G{7,}|T{7,})", tail):
        return False
    rc = revcomp(tail)
    return not any(s in tail or s in rc for s in _sites_of(enzymes))


def optimise(protein, freq, min_rel=0.10, target=HOST_GC, enzymes=None):
    """Deterministic constrained greedy codon choice.

    For each residue, among synonymous codons above `min_rel` relative usage,
    prefer those that do not complete a Golden-Gate site or a >6 homopolymer in
    the 3' context, then pick the codon moving running GC toward the target,
    breaking ties by higher C. glutamicum usage. Deterministic and reproducible.
    A constraint-violating codon is taken ONLY if every synonymous option
    violates; `repair_all` then fixes it with a wider edit.
    """
    out = []
    for aa in protein:
        opts = freq.get(aa)
        if not opts:
            raise ValueError(f"no codons for residue {aa!r}")
        allowed = [c for c, f in opts.items() if f >= min_rel] or list(opts)
        cur = "".join(out)
        clean, dirty = [], []
        for c in allowed:
            g = gc_pct(cur + c)
            key = (abs(g - target), -opts[c], c)
            (clean if _tail_clean((cur + c)[-14:], enzymes) else dirty).append((key, c))
        pick = min(clean or dirty)[1]
        out.append(pick)
    return "".join(out)


def repair_all(dna, protein, freq, min_rel=0.10, max_rounds=400, enzymes=None, label=""):
    """Iteratively re-synonymise until no Golden-Gate site or long run remains.

    For each violating span, try every synonymous codon at every codon it
    overlaps (plus one codon of flank) and keep the first substitution that
    strictly reduces the violation count. Deterministic: options are tried in
    descending C. glutamicum usage.
    """
    codons = [dna[i:i + 3] for i in range(0, len(dna), 3)]
    for _ in range(max_rounds):
        cur = "".join(codons)
        spans = _bad_spans(cur, enzymes)
        if not spans:
            return cur, True
        lo, hi = spans[0]
        lo_c, hi_c = max(0, lo // 3 - 1), min(len(codons) - 1, hi // 3 + 1)
        best = None
        for ci in range(lo_c, hi_c + 1):
            aa = protein[ci]
            for alt in sorted((c for c, f in freq[aa].items()
                               if f >= min_rel and c != codons[ci]),
                              key=lambda c: -freq[aa][c]):
                trial = list(codons); trial[ci] = alt
                nviol = len(_bad_spans("".join(trial), enzymes))
                if nviol < len(spans):
                    best = trial; break
            if best:
                break
        if not best:                       # LADDER RUNG 1: allow rare codons, and record it
            for ci in range(lo_c, hi_c + 1):
                aa = protein[ci]
                for alt in sorted((c for c in freq[aa] if c != codons[ci]),
                                  key=lambda c: -freq[aa][c]):
                    trial = list(codons); trial[ci] = alt
                    if len(_bad_spans("".join(trial), enzymes)) < len(spans):
                        best = trial
                        RELAXATION_LOG.append({"label": label, "rung": "floor", "codon": ci,
                                               "residue": aa, "from": codons[ci], "to": alt,
                                               "rel_freq": round(freq[aa][alt], 4)})
                        break
                if best:
                    break
        if not best:
            return "".join(codons), False
        codons = best
    return "".join(codons), not _bad_spans("".join(codons), enzymes)


def repair(dna, protein, freq, offenders, min_rel=0.10, rounds=40, enzymes=None):
    """Re-synonymise codons overlapping a flagged span until it clears."""
    codons = [dna[i:i + 3] for i in range(0, len(dna), 3)]
    for _ in range(rounds):
        spans = offenders("".join(codons))
        if not spans:
            break
        changed = False
        for (lo, hi) in spans:
            for ci in range(lo // 3, min(len(codons), hi // 3 + 1)):
                aa = protein[ci]
                alts = [c for c, f in freq[aa].items()
                        if f >= min_rel and c != codons[ci]]
                alts.sort(key=lambda c: -freq[aa][c])
                for alt in alts:
                    trial = list(codons); trial[ci] = alt
                    t = "".join(trial)
                    if not offenders(t) or len(offenders(t)) < len(spans):
                        if not homopolymers(t) and not _bad_spans(t, enzymes):
                            codons = trial; changed = True; break
                if changed:
                    break
            if changed:
                break
        if not changed:
            break
    return "".join(codons)
