"""Task 2: remove the internal NcoI site from the kinase panel -> junctions_v3.

WHAT AND WHY. 18 of the 24 constructs in designs/junctions_v2.fasta carry an
internal NcoI site (CCATGG). All 18 are the same PhoQ Ser364-Met365 pair, which
the deterministic codon optimiser encodes identically everywhere it appears:

        ... TCC ATG GAC ...        Ser364 Met365 Asp366
              ^^ ^^^ ^             CCATGG

NcoI is the opening enzyme of pECXT99A, the vector the other 69 constructs use,
and it is the same site HP-4 was excluded from the translational panel for. The
kinase panel could not see it because its screen was the 5-enzyme Golden Gate
set. The destination vector for the kinase panel is still unchosen, so this is
a CONDITIONAL blocker -- but carrying a conditional dependency across sessions
costs more than one synonymous codon change now.

THE CHANGE. TCC -> TCT at the serine. The methionine is a real residue and
cannot move; the serine codon can. TCT sits at 17.4% relative usage in this
repo's BX927147.1-derived codon table, above the optimiser's own 0.10 floor, so
no rare codon is introduced.

WHAT THIS SCRIPT DOES NOT DO. It does not re-run the optimiser. Widening the
optimiser's constraint set would re-derive every codon downstream of the first
change and redesign all 24 constructs; this is a targeted, auditable edit whose
effect can be stated exactly. See scripts/junction_design.py for that split.

Writes designs/junctions_v3.csv and designs/junctions_v3.fasta. Never touches v2.
"""
import csv, json, re, sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import seqchecks as S
from seqchecks import CATALOGUE, GOLDEN_GATE, site_scan, sigA_scan, sd_atg_scan, junction_aware
import junction_design as J
from consolidate_final import translate, read_fasta

DESIGNS = ROOT / "designs"
OUT_CSV, OUT_FA = DESIGNS / "junctions_v3.csv", DESIGNS / "junctions_v3.fasta"
TARGET_ENZYME = "NcoI"
DOCUMENTED_FIX = ("TCC", "TCT")            # Ser, per the task and the repo's codon table
HBOX = {"P0DM80": 277, "P0AEJ4": 243}


def codon_freqs():
    tbl = json.loads((ROOT / "data" / "cache" / "codon" / "cglut_codon_usage.json").read_text())["table"]
    return {aa: {c: v["rel_freq"] for c, v in t.items()} for aa, t in tbl.items()}


def fix_one(dna, protein, freq, enzyme=TARGET_ENZYME):
    """Remove every `enzyme` site by synonymous substitution. Returns (dna, [edits])."""
    site = CATALOGUE[enzyme]
    edits = []
    for _ in range(20):
        hits = [h for h in site_scan(dna, enzymes=[enzyme]) if h.strand == "+"]
        if not hits:
            break
        h = hits[0]
        lo_c, hi_c = h.start // 3, (h.end - 1) // 3
        before_sites = {x.key() for x in site_scan(dna)}
        chosen = None
        # try the documented fix first, then any other synonymous codon by usage
        cands = []
        for ci in range(lo_c, hi_c + 1):
            cur, aa = dna[ci * 3:ci * 3 + 3], protein[ci]
            for alt, f in sorted(freq[aa].items(), key=lambda x: -x[1]):
                if alt == cur:
                    continue
                rank = 0 if (cur, alt) == DOCUMENTED_FIX else 1
                cands.append((rank, -f, ci, aa, cur, alt))
        for _rank, negf, ci, aa, cur, alt in sorted(cands):
            trial = dna[:ci * 3] + alt + dna[ci * 3 + 3:]
            if site in trial or S.revcomp(site) in trial:
                continue
            if translate(trial[:-3]) != protein:            # must be strictly synonymous
                continue
            new_sites = {x.key() for x in site_scan(trial)}
            if new_sites - before_sites:                     # must create nothing new, anywhere
                continue
            chosen = (ci, aa, cur, alt, -negf, trial)
            break
        if chosen is None:
            raise RuntimeError(f"no synonymous substitution removes {enzyme}@{h.start} cleanly")
        ci, aa, cur, alt, f, trial = chosen
        edits.append({"codon_index_1based": ci + 1, "residue": aa, "from": cur, "to": alt,
                      "rel_freq_of_replacement": round(f, 4), "site_start": h.start,
                      "nt_changed": [i for i in range(ci * 3, ci * 3 + 3) if dna[i] != trial[i]],
                      "documented_fix": (cur, alt) == DOCUMENTED_FIX})
        dna = trial
    return dna, edits


def main():
    for p in (OUT_CSV, OUT_FA):
        if p.exists():
            sys.exit(f"REFUSING TO OVERWRITE {p}")
    S.positive_control_check()
    print("=" * 78); print("TASK 2  NcoI CODON FIX  (junctions_v2 -> junctions_v3)"); print("=" * 78)
    print(f"  seqchecks positive controls: PASS  (catalogue {len(CATALOGUE)} enzymes)")

    rows = list(csv.DictReader(open(DESIGNS / "junctions_v2.csv")))
    fa = read_fasta(DESIGNS / "junctions_v2.fasta")
    assert len(rows) == len(fa) == 24, (len(rows), len(fa))
    freq = codon_freqs()
    prot_lib = {a: "".join((ROOT / "data" / "fasta" / f"{a}.fasta").read_text().strip().split("\n")[1:]).replace("*", "")
                for a in ("WP_043878053.1", "Q92SH9", "P0DM80", "P0AEJ4")}

    before_ncoi = sorted(d for d, s in fa.items() if site_scan(s, enzymes=[TARGET_ENZYME]))
    print(f"\n  constructs carrying {TARGET_ENZYME} in v2: {len(before_ncoi)} of {len(fa)}")

    out_rows, out_fa, edits_all, prot_bad = [], {}, {}, []
    for r in rows:
        did = r["design_id"]
        dna_v2, prot_v2 = fa[did], r["protein_seq"]
        assert translate(dna_v2[:-3]) == prot_v2, f"{did}: v2 DNA does not translate to its own protein_seq"
        dna_v3, edits = fix_one(dna_v2, prot_v2, freq)
        prot_v3 = translate(dna_v3[:-3])
        if prot_v3 != prot_v2:
            prot_bad.append(did)
        edits_all[did] = edits
        out_fa[did] = dna_v3
        out_rows.append((r, dna_v2, dna_v3, prot_v2, prot_v3, edits))

    print(f"  constructs edited: {sum(1 for _r,_a,_b,_c,_d,e in out_rows if e)}"
          f"   codon changes applied: {sum(len(e) for e in edits_all.values())}")
    print(f"  PROTEIN IDENTICAL before and after: {len(out_rows)-len(prot_bad)}/{len(out_rows)}"
          + (f"   FAILURES: {prot_bad}" if prot_bad else ""))
    if prot_bad:
        sys.exit("protein changed -- refusing to write")

    # ------------------------------------------------- FULL check on ALL 24
    print(f"\n  full shared-module check on ALL {len(out_rows)} revised constructs")
    checks = []
    for r, dna_v2, dna_v3, prot_v2, prot_v3, edits in out_rows:
        did = r["design_id"]
        s_end, llen = int(r["sensor_last_residue"]), int(r["linker_len"])
        a_start, jnt = int(r["acceptor_first_residue"]), int(r["junction_nt_pos"])
        sacc, aacc = r["sensor_accession"], r["acceptor_accession"]
        cmap = [(f"sensor:{sacc}[aa 1-{s_end}]", dna_v3[:s_end * 3])]
        if llen:
            cmap.append((f"linker:{r['linker']}", dna_v3[s_end * 3:jnt]))
        cmap.append((f"acceptor:{aacc}[aa {a_start}-{len(prot_lib[aacc])}]", dna_v3[jnt:len(dna_v3) - 3]))
        cmap.append(("stop:TAA", dna_v3[-3:]))
        ja = junction_aware(dna_v3, cmap, known_starts={0})       # raises if the map is wrong
        hb_native = HBOX[aacc]
        hb_pos = s_end + llen + (hb_native - a_start + 1) if a_start <= hb_native else None
        hb_res = prot_v3[hb_pos - 1] if hb_pos and hb_pos <= len(prot_v3) else None
        sites = ja["sites"]
        checks.append({
            "design_id": did, "panel": r["panel"], "strategy": r["strategy"],
            "register_offset": r["register_offset"],
            "dna_len": len(dna_v3), "protein_len": len(prot_v3),
            "gc_percent": round(S.gc(dna_v3), 2),
            "n_codon_edits": len(edits),
            "protein_identical_to_v2": "YES" if prot_v3 == prot_v2 else "NO",
            "NcoI_sites": len([h for h in sites if h.enzyme == "NcoI"]),
            "golden_gate_sites": ";".join(f"{h.enzyme}@{h.start}({h.strand})"
                                          for h in sites if h.enzyme in GOLDEN_GATE) or "none",
            "n_catalogue_sites": len(sites),
            "catalogue_sites": ";".join(f"{h.enzyme}@{h.start}({h.strand})" for h in sites) or "none",
            "sites_spanning_junction": ";".join(f"{h.enzyme}@{h.start}({h.strand})"
                                                for h in sites if h.spans_junction) or "none",
            "homopolymer_gt6": ";".join(f"{h['base']}x{h['run']}@{h['start']}"
                                        for h in ja["basic"]["homopolymers_gt6"]) or "none",
            "sigA_total": len(ja["sigA"]),
            "sigA_at_junction": ";".join(f"{h.start}({h.score})" for h in ja["sigA"] if h.spans_junction) or "none",
            "sd_atg_total": len(ja["sd_atg"]),
            "sd_atg_at_junction": ";".join(h.detail for h in ja["sd_atg"] if h.spans_junction) or "none",
            "hbox_native_residue": hb_native, "hbox_construct_position": hb_pos or "",
            "hbox_residue": hb_res or "",
        })
        r["_v3"] = dna_v3
        r["_checks"] = checks[-1]
        r["_edits"] = edits

    # -------------------------------------------------------------- write v3
    base_cols = [c for c in rows[0] if not c.startswith("_") and c != "protein_seq"]
    add_cols = ["revision", "revised_from", "n_codon_edits", "codon_edits",
                "protein_identical_to_v2", "NcoI_sites", "n_catalogue_sites", "catalogue_sites",
                "sites_spanning_junction", "sigA_total", "sigA_at_junction",
                "sd_atg_total", "sd_atg_at_junction"]
    with open(OUT_CSV, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=base_cols + add_cols + ["protein_seq"], extrasaction="ignore")
        w.writeheader()
        for r, dna_v2, dna_v3, prot_v2, prot_v3, edits in out_rows:
            c = r["_checks"]
            row = {k: r[k] for k in base_cols}
            row.update({
                "revision": "v3", "revised_from": r["design_id"],
                "n_codon_edits": len(edits),
                "codon_edits": ";".join(f"codon{e['codon_index_1based']}({e['residue']}){e['from']}->{e['to']}"
                                        f"@nt{','.join(map(str, e['nt_changed']))}" for e in edits) or "none",
                "protein_identical_to_v2": c["protein_identical_to_v2"],
                "NcoI_sites": c["NcoI_sites"], "n_catalogue_sites": c["n_catalogue_sites"],
                "catalogue_sites": c["catalogue_sites"],
                "sites_spanning_junction": c["sites_spanning_junction"],
                "sigA_total": c["sigA_total"], "sigA_at_junction": c["sigA_at_junction"],
                "sd_atg_total": c["sd_atg_total"], "sd_atg_at_junction": c["sd_atg_at_junction"],
                "gc_percent": c["gc_percent"],
                "golden_gate_sites": c["golden_gate_sites"],
                "homopolymer_gt6": c["homopolymer_gt6"],
                "spurious_sigA_ext10_total": c["sigA_total"],
                "spurious_sigA_at_junction": c["sigA_at_junction"],
                "spurious_SD_ATG_total": c["sd_atg_total"],
                "spurious_SD_at_junction": c["sd_atg_at_junction"],
                "hbox_construct_position": c["hbox_construct_position"],
                "hbox_residue": c["hbox_residue"],
                "protein_seq": prot_v3,
            })
            w.writerow(row)
    with open(OUT_FA, "w") as fh:
        for r, _a, dna_v3, _b, _c, _e in out_rows:
            c = r["_checks"]
            fh.write(f">{r['design_id']} revision=v3 panel={r['panel']} strategy={r['strategy']} "
                     f"register_offset={r['register_offset']} protein_aa={c['protein_len']} "
                     f"dna_nt={len(dna_v3)} GC={c['gc_percent']} codon_edits={c['n_codon_edits']}\n")
            for i in range(0, len(dna_v3), 60):
                fh.write(dna_v3[i:i + 60] + "\n")
    print(f"\n  wrote {OUT_CSV.relative_to(ROOT)} ({len(out_rows)} rows)")
    print(f"  wrote {OUT_FA.relative_to(ROOT)} ({len(out_fa)} records)")
    return out_rows, checks, edits_all, before_ncoi


if __name__ == "__main__":
    main()
