"""Task 3: scan a genome, both strands, every position, against a PWM.

Empirical null: score every window (both strands) of a dinucleotide-shuffled
copy of the SAME genome (cached; generated once per genome with a fixed seed
so reruns are deterministic and offline). Empirical p-value for a hit =
fraction of null-genome window scores >= the hit's score, pooling forward +
reverse null scores (a dinucleotide shuffle has no preferred strand, so
pooling both strands doubles the null sample size for free).

Reports raw (pre-merge) window counts, then applies non-maximum suppression
(overlapping windows within one PWM-width of each other, same strand,
collapse to their single highest-scoring position) so a single real binding
site is not counted as ~width independent hits.
"""
import argparse
import csv
from pathlib import Path

import numpy as np
from Bio import SeqIO

from dinuc_shuffle import shuffle_fasta
from pwm_lib import load_pwm_json, score_all_windows, revcomp, max_possible_score, min_possible_score

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"

# empirical-p thresholds defining the stringency tiers reported in Task 3
STRINGENCY_TIERS = [
    ("lenient", 5e-2),
    ("medium", 1e-3),
    ("strict", 1e-4),
]


def load_genome(fasta_path: Path):
    rec = next(SeqIO.parse(fasta_path, "fasta"))
    return rec.id, str(rec.seq).upper()


def strand_hits(seq: str, pwm: dict, strand: str, genome_len: int):
    """Returns list of (genome_start_1based, genome_end_1based, strand, score)."""
    scores = score_all_windows(seq, pwm)
    w = pwm["width"]
    hits = []
    if strand == "+":
        for j, s in enumerate(scores):
            if np.isfinite(s):
                hits.append((j + 1, j + w, "+", float(s)))
    else:
        # seq here is the revcomp genome; window at index k in revcomp maps to
        # original genome interval [L-w-k, L-k-1] (0-based) = 1-based [L-w-k+1, L-k]
        L = genome_len
        for k, s in enumerate(scores):
            if np.isfinite(s):
                start = L - w - k + 1
                end = L - k
                hits.append((start, end, "-", float(s)))
    return hits


def non_max_suppress(hits: list, width: int):
    """hits: list of (start, end, strand, score). Collapse overlapping same-strand
    windows (start positions within `width` bp of the last KEPT peak) to local maxima."""
    kept = {"+": [], "-": []}
    for strand in ("+", "-"):
        strand_sorted = sorted([h for h in hits if h[2] == strand], key=lambda h: h[0])
        i = 0
        n = len(strand_sorted)
        while i < n:
            j = i
            best = strand_sorted[i]
            # extend the run while consecutive windows overlap (start within `width` of run start)
            while j + 1 < n and strand_sorted[j + 1][0] - strand_sorted[i][0] < width:
                j += 1
                if strand_sorted[j][3] > best[3]:
                    best = strand_sorted[j]
            kept[strand].append(best)
            i = j + 1
    return kept["+"] + kept["-"]


def compute_empirical_p(observed_scores: np.ndarray, null_scores_sorted: np.ndarray) -> np.ndarray:
    n_null = len(null_scores_sorted)
    # rank = number of null scores >= observed  ==  n_null - searchsorted(observed, side='left')
    idx = np.searchsorted(null_scores_sorted, observed_scores, side="left")
    rank_ge = n_null - idx
    p = np.maximum(rank_ge, 1) / n_null  # floor at 1/n_null so p is never reported as exactly 0
    return p


def scan(genome_fasta: Path, pwm_json: Path, out_csv: Path, seed: int = 1337, label: str = ""):
    pwm = load_pwm_json(pwm_json)
    w = pwm["width"]

    genome_id, genome_seq = load_genome(genome_fasta)
    L = len(genome_seq)
    print(f"[{label}] genome {genome_id}, {L} bp, PWM width {w}")

    fwd_hits = strand_hits(genome_seq, pwm, "+", L)
    rc_seq = revcomp(genome_seq)
    rev_hits = strand_hits(rc_seq, pwm, "-", L)
    print(f"[{label}] raw window scores: {len(fwd_hits)} forward + {len(rev_hits)} reverse "
          f"= {len(fwd_hits)+len(rev_hits)} total")

    shuffled_path = DATA / "cache" / f"{genome_fasta.stem}_dinucshuffled_seed{seed}.fasta"
    shuffle_fasta(genome_fasta, shuffled_path, seed=seed)
    null_id, null_seq = load_genome(shuffled_path)
    null_fwd = score_all_windows(null_seq, pwm)
    null_rev = score_all_windows(revcomp(null_seq), pwm)
    null_all = np.concatenate([null_fwd[np.isfinite(null_fwd)], null_rev[np.isfinite(null_rev)]])
    null_sorted = np.sort(null_all)
    print(f"[{label}] empirical null pool: {len(null_sorted)} scores from dinucleotide-shuffled "
          f"{genome_fasta.name} (seed={seed})")

    all_hits = fwd_hits + rev_hits
    scores_arr = np.array([h[3] for h in all_hits])
    pvals = compute_empirical_p(scores_arr, null_sorted)

    loosest_p = STRINGENCY_TIERS[0][1]
    candidate = [(h[0], h[1], h[2], h[3], p) for h, p in zip(all_hits, pvals) if p <= loosest_p]
    print(f"[{label}] {len(candidate)} raw windows pass loosest tier (p<={loosest_p}) before merging")

    merged = non_max_suppress([(s, e, st, sc) for s, e, st, sc, p in candidate], width=w)
    merged_scores = np.array([m[3] for m in merged])
    merged_pvals = compute_empirical_p(merged_scores, null_sorted) if len(merged) else np.array([])

    rows = []
    for (start, end, strand, score), p in zip(merged, merged_pvals):
        rows.append({"genome": genome_id, "start": start, "end": end, "strand": strand,
                     "score": round(score, 4), "empirical_p": p})
    rows.sort(key=lambda r: r["empirical_p"])

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["genome", "start", "end", "strand", "score", "empirical_p"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"[{label}] {len(rows)} merged peaks (non-max-suppressed) written to {out_csv}")
    print(f"[{label}] max possible score={max_possible_score(pwm):.2f}, min={min_possible_score(pwm):.2f}")
    print(f"[{label}] hit counts by stringency tier:")
    for tname, thresh in STRINGENCY_TIERS:
        n = sum(1 for r in rows if r["empirical_p"] <= thresh)
        print(f"    {tname:8s} (empirical p <= {thresh:g}): {n} peaks")

    return rows, pwm


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--genome", required=True)
    ap.add_argument("--pwm", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--label", default="")
    args = ap.parse_args()
    scan(Path(args.genome), Path(args.pwm), Path(args.out), seed=args.seed, label=args.label)
