"""Task 3: design the hybrid promoter variant panel.

Construct grammar (5' -> 3'):
    [upstream context] [operator, 1 or 2 copies] [gap, bp] [-35 onward core promoter]

The "-35 onward core promoter" segment is held EXACTLY constant for every
variant built on a given core promoter (it is literally promoter_seq[minus35_start0:],
taken straight from the experimentally-validated amplicon in
data/cache/core_promoters.json) -- so operator position, copy number, and
upstream context are the only things that change within a core-promoter
family, isolating each axis cleanly. The extended -10 is inside this
constant segment and is therefore never touched by any variant, satisfying
the task's "keep the extended -10 unmodified in every variant" requirement
by construction, not by a per-variant check.

Operator sequences: two REAL, PMID-cited, confirmed Sal_PhoP sites
(from data/sites/phop_salmonella_sites.fasta, fetched in the earlier
follow-up analysis in this repo) are used -- never a PWM-derived synthetic
"ideal" sequence. Primary = the phoP autoregulatory site (highest-scoring
of the 9 confirmed sites against the Salmonella PWM, 94% of max possible
score); secondary = the mgtA site (91%), used for the sequence-identity
side of the panel.

Gap sweep: 0-10 bp (11 single-base steps = one full ~10.5 bp helical turn,
per the task's explicit instruction), between the operator's 3' end and the
-35's 5' start. [INFERENCE, reasoning named]: chosen based on (a) general
Class I/II bacterial activator positioning theory (activators typically
contact RNAP alpha-CTD or sigma region 4 from a site overlapping or
immediately upstream of -35) and (b) the actual distanceToPromoter values
in the confirmed Ec_PhoP site set cached from the earlier RegulonDB
fetch in this repo (mgrRp -44, mgtSp -35, ompTp -59.5, hdeAp -32 -- i.e. the
operator regularly sits close to, sometimes near-overlapping, the promoter
element, not far upstream). This is NOT calibrated against any confirmed
Sal_PhoP-driven C. glutamicum promoter, because none exists yet -- that absence
is the entire reason this panel is being built.
"""
import csv
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pwm_lib import revcomp
from annotate_hits import load_genes
from Bio import SeqIO

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DESIGNS = ROOT / "designs"

# 0..13 bp = 14 consecutive single-base positions = 13 bp end-to-end = 1.24 helical
# turns at 10.5 bp/turn. The original 0..10 sweep spanned only 10 bp = 0.952 turns
# (342.9 deg), stopping 17.1 deg short of closing the circle, so it sampled one
# near-complete period ONCE with no repeat -- which makes a periodic response
# statistically degenerate with monotonic decay-with-distance. Gaps 11/12/13 are the
# first three positions whose helical phase re-samples the faces of gaps 0/1/2, giving
# THREE independent same-face comparisons: one wrap point could be noise, three
# replicating the pattern is a result.
GAP_RANGE = list(range(0, 14))
TANDEM_SPACER_BP = 2  # [INFERENCE]: short, arbitrary, deliberately NOT data-grounded (see report)

# Psyn is SYNTHETIC: it has no genomic locus, so there is no "native" upstream
# context to retain the way PsodA/Ptuf have one. The closest sourced equivalent --
# and the only one that exists -- is the sequence immediately 5' of Psyn in the
# construct that was actually characterized at 286% of Ptrc: the 21 nt vector-
# homology tail of primer N105 (Psyn-fw2) in Henke, Krahn & Wendisch 2021,
# Microorganisms 9:204 (PMC7835838) Table 2. Transcribed from the cached raw HTML
# and verified to sit in a single unbroken <td> cell (this paper is known to contain
# at least one page-break artifact -- PH36 -- so the check is run, not assumed).
# N105 = ATGCATGCCGCTTCGCCTTCG + TTGACATTAATTTGAATCTGTGTTATAATGGTTC(= Psyn), and the
# Psyn core occurs exactly once in the primer, so the boundary is unambiguous.
PSYN_UPSTREAM_CONTEXT = "ATGCATGCCGCTTCGCCTTCG"

OPERATORS = {
    "opA_phoP":  "TTTATTAACTGTTTAT",   # Salmonella phoP autoregulatory site, 94% of PWM max
    "opB_mgtA":  "TTTATCGTTGGTTTAA",   # Salmonella mgtA site, 91% of PWM max
}

GENERIC_FILLER_SEED = "CG-glutamicum-hybrid-promoter-panel-filler"  # documented, reproducible generator


def make_generic_filler(length: int) -> str:
    """Deterministic, documented synthetic filler sequence (NOT a natural sequence,
    NOT claimed to be one) -- generated from a fixed seed string via repeated
    hashing so it is exactly reproducible from this source code alone, then
    checked downstream (Task 4) like every other variant for cryptic sites."""
    out = []
    counter = 0
    seed = GENERIC_FILLER_SEED
    while len("".join(out)) < length:
        h = hashlib.sha256(f"{seed}:{counter}".encode()).hexdigest()
        # map hex digits to bases (2 bits each via nibble mod 4)
        bases = "ACGT"
        out.append("".join(bases[int(c, 16) % 4] for c in h))
        counter += 1
    return "".join(out)[:length]


def scramble(seq: str, seed: int = 7) -> str:
    import random
    rng = random.Random(seed)
    chars = list(seq)
    rng.shuffle(chars)
    return "".join(chars)


def build_variant(core_name: str, core: dict, elem: dict, *, operator_seqs, gap_bp, upstream_mode,
                   native_upstream_extra: str, operator_labels=None):
    core_from_m35 = core["sequence"][elem["minus35_start0"]:]
    if upstream_mode == "replaced":
        upstream = make_generic_filler(30)
    elif upstream_mode == "retained":
        upstream = native_upstream_extra
    elif upstream_mode == "none":
        upstream = ""
    else:
        raise ValueError(upstream_mode)

    if len(operator_seqs) > 1:
        spacer = make_generic_filler(TANDEM_SPACER_BP)
        operator_block = spacer.join(operator_seqs)
    else:
        operator_block = operator_seqs[0] if operator_seqs else ""

    gap_seq = make_generic_filler(gap_bp) if gap_bp > 0 else ""
    seq = upstream + operator_block + gap_seq + core_from_m35

    return {
        "sequence": seq, "core": core_name, "n_operators": len(operator_seqs),
        "operator_names": "+".join(operator_labels) if operator_labels else "none",
        "gap_bp": gap_bp, "upstream_mode": upstream_mode,
        "core_length_used": len(core_from_m35), "upstream_length": len(upstream),
        "operator_block_length": len(operator_block),
    }


def main():
    DESIGNS.mkdir(exist_ok=True)
    core_promoters = json.loads((DATA / "cache" / "core_promoters.json").read_text())
    elements = json.loads((DATA / "cache" / "promoter_elements.json").read_text())
    genome = str(next(SeqIO.parse(DATA / "cache" / "BX927147.fasta", "fasta")).seq).upper()
    genes = load_genes(DATA / "cache" / "BX927147.ft.txt")
    by_tag = {g["locus_tag"]: g for g in genes}

    # native upstream extension beyond the amplicon's own 5' end, for the "retained" axis
    # (only meaningful for genome-derived promoters; fetched fresh from the cached genome,
    # immediately upstream of where the validated amplicon itself begins)
    native_ext = {}
    for name in ["PsodA", "Ptuf"]:
        tag = core_promoters[name]["locus_tag"]
        g = by_tag[tag]
        amplicon = core_promoters[name]["sequence"]
        if g["strand"] == "+":
            # amplicon's 5' end genomic position = translation_start - 1 - (len of region beyond amplicon start)
            # recover by re-finding the amplicon in the genome near the known TSS
            tss = g["tss"]
            window = genome[tss - 1 - 600:tss - 1 + 100]
            idx = window.find(amplicon[:30])
            assert idx != -1, f"could not relocate amplicon start for {name}"
            ext_start_local = idx - 40
            native_ext[name] = window[max(0, ext_start_local):idx]
        else:
            tss = g["tss"]
            window = revcomp(genome[tss - 100:tss + 600])
            idx = window.find(amplicon[:30])
            assert idx != -1, f"could not relocate amplicon start for {name}"
            ext_start_local = idx - 40
            native_ext[name] = window[max(0, ext_start_local):idx]
        print(f"native upstream extension for {name}: {len(native_ext[name])} bp -> {native_ext[name]}")

    variants = []  # list of dicts, filled progressively

    def add(name, core_name, meta, rationale):
        variants.append({"name": name, "core": core_name, **meta, "rationale": rationale})

    # ================= Psyn: full 11-position gap sweep (the primary, most-informative axis) =================
    psyn = core_promoters["Psyn"]
    psyn_elem = elements["Psyn"]
    for gap in GAP_RANGE:
        meta = build_variant("Psyn", psyn, psyn_elem, operator_seqs=[OPERATORS["opA_phoP"]],
                              gap_bp=gap, upstream_mode="replaced", native_upstream_extra="",
                              operator_labels=["opA_phoP"])
        wrap = {11: 0, 12: 1, 13: 2}.get(gap)
        wrap_txt = ("" if wrap is None else
                    f" WRAP-AROUND POINT: at 10.5 bp/turn this sits ~{360*gap/10.5 - 360:.0f} deg past a "
                    f"full turn, i.e. the same helical face as gap={wrap} but one turn further from the -35; "
                    f"the gap{gap:02d} vs gap{wrap:02d} pair is what separates face-of-helix periodicity from "
                    f"monotonic decay with distance.")
        add(f"Psyn_1x_opA_gap{gap:02d}_repl", "Psyn", meta,
            f"strong core (286% Ptrc), single operator (Sal_PhoP site), gap={gap}bp -- position sweep "
            f"point {gap} of 0-13 (14 consecutive positions = 13 bp = 1.24 helical turns).{wrap_txt}")

    # ================= Psyn: extra axes at the two most face-differentiated sweep positions =================
    # (gap=0 and gap=5, ~opposite faces of the helix; picked structurally, not from any performance
    # data -- none exists yet) -- copy number, upstream context, operator identity
    for gap in [0, 5]:
        meta2 = build_variant("Psyn", psyn, psyn_elem, operator_seqs=[OPERATORS["opA_phoP"], OPERATORS["opA_phoP"]],
                               gap_bp=gap, upstream_mode="replaced", native_upstream_extra="",
                               operator_labels=["opA_phoP", "opA_phoP"])
        add(f"Psyn_2xopA_gap{gap:02d}_repl", "Psyn", meta2,
            f"strong core, TWO tandem copies of the same operator, {TANDEM_SPACER_BP}bp inter-copy spacer, "
            f"gap={gap}bp to -35 -- tests whether a second box adds cooperative activation or just adds bulk")

        metaB = build_variant("Psyn", psyn, psyn_elem, operator_seqs=[OPERATORS["opB_mgtA"]],
                               gap_bp=gap, upstream_mode="replaced", native_upstream_extra="",
                               operator_labels=["opB_mgtA"])
        add(f"Psyn_1x_opB_gap{gap:02d}_repl", "Psyn", metaB,
            f"strong core, single operator using the SECOND real confirmed site (mgtA, not phoP) at the same "
            f"gap={gap}bp -- tests whether exact box identity (91% vs 94% of PWM max) matters at a fixed position")

    # ========== Psyn: retained upstream context, matched to existing replaced variants ==========
    # Huang et al. 2021 (Front Microbiol 12:718511) truncated P_NCgl1418 and found a 94 bp
    # construct with INTACT core -35 and -10 elements gave complete loss of function, with
    # ~26% of activity unaccounted for between 145 and 203 bp -- "unknown mechanisms may also
    # have an impact on the promoter." Every Psyn variant above uses 30 bp of generic filler
    # upstream. If the minimal constructs underperform for that same unidentified reason, the
    # panel cannot separate "the architecture does not work" from "we cut off something needed."
    # These two variants are the matched controls that make that separable on the PRIMARY core.
    for gap in [3, 5]:
        meta = build_variant("Psyn", psyn, psyn_elem, operator_seqs=[OPERATORS["opA_phoP"]],
                              gap_bp=gap, upstream_mode="retained",
                              native_upstream_extra=PSYN_UPSTREAM_CONTEXT,
                              operator_labels=["opA_phoP"])
        why = ("gap=3 is the panel's cross-core reference position, so this variant is directly "
               "comparable to PsodA_1x_opA_gap03_native and Ptuf_1x_opA_gap03_reta -- a retained-vs-"
               "replaced contrast on all three cores at one spacing"
               if gap == 3 else
               "gap=5 is one of the two designated most-face-differentiated positions and already "
               "carries the 2xopA and opB axes, so a retained/replaced contrast here tests whether "
               "upstream context INTERACTS with operator phasing rather than just shifting output")
        add(f"Psyn_1x_opA_gap{gap:02d}_reta", "Psyn", meta,
            f"strong core, single operator, gap={gap}bp, RETAINED upstream context "
            f"({len(PSYN_UPSTREAM_CONTEXT)} bp) -- matched 1:1 to Psyn_1x_opA_gap{gap:02d}_repl, which is "
            f"identical except that its upstream is 30 bp of generic filler. {why}. CAVEAT: Psyn is "
            f"synthetic and has no genomic locus, so this is not native genomic flanking sequence -- it "
            f"is the vector context of the construct in which Psyn's 286% Ptrc was measured "
            f"(PMC7835838 Table 2, primer N105). At 21 bp it is shorter than the 30 bp filler it "
            f"replaces and far shorter than the 50-100 bp scale of the Huang effect, so it tests the "
            f"validated construct's own immediate context, NOT the full truncation hypothesis.")

    # ================= PsodA: coarser validation sweep + context/copy axes =================
    psoda = core_promoters["PsodA"]
    psoda_elem = elements["PsodA"]
    for gap in [0, 3, 6, 10]:
        meta = build_variant("PsodA", psoda, psoda_elem, operator_seqs=[OPERATORS["opA_phoP"]],
                              gap_bp=gap, upstream_mode="replaced", native_upstream_extra="",
                              operator_labels=["opA_phoP"])
        add(f"PsodA_1x_opA_gap{gap:02d}_repl", "PsodA", meta,
            f"weak core (10.8% Ptrc), single operator, gap={gap}bp -- coarse 4-point cross-check of the "
            f"Psyn position sweep on a structurally different, independently-sourced core (does face-of-helix "
            f"periodicity replicate on a different promoter?)")

    meta = build_variant("PsodA", psoda, psoda_elem, operator_seqs=[OPERATORS["opA_phoP"]],
                          gap_bp=3, upstream_mode="retained", native_upstream_extra=native_ext["PsodA"],
                          operator_labels=["opA_phoP"])
    add("PsodA_1x_opA_gap03_native", "PsodA", meta,
        "weak core, single operator, gap=3bp, NATIVE upstream flanking sequence retained (not generic filler) "
        "-- tests whether PsodA's own native upstream context (unknown cis-elements, curvature) matters")

    meta = build_variant("PsodA", psoda, psoda_elem, operator_seqs=[OPERATORS["opA_phoP"], OPERATORS["opA_phoP"]],
                          gap_bp=3, upstream_mode="replaced", native_upstream_extra="",
                          operator_labels=["opA_phoP", "opA_phoP"])
    add("PsodA_2xopA_gap03_repl", "PsodA", meta,
        "weak core, two tandem operator copies, gap=3bp -- copy-number axis on the weak core")

    # ================= Ptuf: limited role (medium strength, but -35 assignment low-confidence) =================
    ptuf = core_promoters["Ptuf"]
    ptuf_elem = elements["Ptuf"]
    for gap, mode, ext in [(3, "replaced", ""), (3, "retained", native_ext["Ptuf"])]:
        meta = build_variant("Ptuf", ptuf, ptuf_elem, operator_seqs=[OPERATORS["opA_phoP"]],
                              gap_bp=gap, upstream_mode=mode, native_upstream_extra=ext,
                              operator_labels=["opA_phoP"])
        add(f"Ptuf_1x_opA_gap{gap:02d}_{mode[:4]}", "Ptuf", meta,
            f"medium core (~50% Ptrc, approx Ptrc-equivalent), single operator, gap={gap}bp, {mode} upstream "
            f"-- CAVEAT: this core's -35 could not be confidently assigned (extended-10 63% of max, but best "
            f"-35 candidate only 12% of max in the mechanistically plausible spacer window); gap is measured "
            f"from that low-confidence -35 position, so absolute spacing here is less trustworthy than for "
            f"Psyn/PsodA -- included only for strength-range breadth, not for the fine positional analysis")

    # ================= Negative controls =================
    for core_name, core, elem, strength in [("Psyn", psyn, psyn_elem, "strong"), ("PsodA", psoda, psoda_elem, "weak"),
                                             ("Ptuf", ptuf, ptuf_elem, "medium")]:
        meta = build_variant(core_name, core, elem, operator_seqs=[], gap_bp=0, upstream_mode="replaced",
                              native_upstream_extra="")
        add(f"{core_name}_noop_ctrl", core_name, meta,
            f"NEGATIVE CONTROL: {strength} core promoter, NO operator at all -- baseline uninduced/"
            f"unregulated expression level for this core; every operator-bearing variant on this core is "
            f"read relative to this")

    scrambled_op = scramble(OPERATORS["opA_phoP"])
    meta = build_variant("Psyn", psyn, psyn_elem, operator_seqs=[scrambled_op], gap_bp=3, upstream_mode="replaced",
                          native_upstream_extra="", operator_labels=["scrambled_opA"])
    add("Psyn_1x_scrambled_gap03_repl", "Psyn", meta,
        f"NEGATIVE CONTROL: strong core, gap=3bp -- SAME position as a real-operator variant, but the "
        f"operator sequence is a base-composition-matched SCRAMBLE of opA ({scrambled_op}) rather than the "
        f"real Sal_PhoP recognition sequence; isolates 'does inserting any 16bp sequence here perturb "
        f"transcription' from 'does the specific Sal_PhoP box matter'")
    meta = build_variant("PsodA", psoda, psoda_elem, operator_seqs=[scrambled_op], gap_bp=3, upstream_mode="replaced",
                          native_upstream_extra="", operator_labels=["scrambled_opA"])
    add("PsodA_1x_scrambled_gap03_repl", "PsodA", meta,
        f"NEGATIVE CONTROL: weak core, gap=3bp, scrambled operator ({scrambled_op}) -- same logic as above, "
        f"on the weak core")

    print(f"\n{len(variants)} variants designed.")

    # write intermediate JSON (checks/ranking scripts consume this)
    (DATA / "cache" / "panel_variants_raw.json").write_text(json.dumps(variants, indent=1))
    print("Wrote data/cache/panel_variants_raw.json")

    # write FASTA now (final naming); CSV is completed after Task 4 checks + Task 5 ranking
    with open(DESIGNS / "variants.fasta", "w") as fh:
        for v in variants:
            fh.write(f">{v['name']}\n{v['sequence']}\n")
    print(f"Wrote {DESIGNS / 'variants.fasta'}")


if __name__ == "__main__":
    main()
