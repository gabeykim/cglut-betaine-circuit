"""Domain-level analysis (Task 3).

Runs HMMER hmmscan against single-family Pfam HMMs fetched from the EBI
InterPro API (data/cache/pfam/PF00072.hmm = REC / Response_reg,
data/cache/pfam/PF00512.hmm = HisKA / DHp) to locate domain boundaries in
every response regulator and every sensor kinase. Extracts the matched
subsequence for each protein and recomputes the pairwise identity matrix
(same BLOSUM62 / -11/-1 / unpenalised-terminal-gaps aligner as Task 2) on
REC domains only.

Falls back to a profile-alignment-against-a-curated-seed approach (NOT
implemented here) only if hmmscan is unavailable -- this is checked and
reported explicitly rather than silently degrading.
"""
import csv
import shutil
import subprocess
import sys
from pathlib import Path

from Bio import SeqIO

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PFAM_DIR = DATA / "cache" / "pfam"
REC_HMM = PFAM_DIR / "PF00072.hmm"
# PF00512/HisKA alone missed 6/15 kinases entirely (zero hits, not just below
# threshold -- confirmed via direct hmmscan). This is a real biological
# finding: several C. glutamicum HKs use the divergent HisKA_2 (PF07568) or
# HisKA_3 (PF07730) phosphoacceptor-domain subfamilies rather than canonical
# HisKA. DHP_HMM is therefore a combined, pressed database of all three
# families; hmmscan reports the single best-scoring model per query, and the
# matched family name is recorded per accession in dhp_domain_hits.csv.
DHP_HMM = PFAM_DIR / "DHp_family.hmm"

sys.path.insert(0, str(ROOT / "scripts"))
from identity_matrix import make_aligner, compute_pair  # noqa: E402


def check_hmmer():
    return shutil.which("hmmscan") is not None


def run_hmmscan(hmm_path: Path, fasta_path: Path, domtbl_out: Path):
    subprocess.run(
        ["hmmscan", "--domtblout", str(domtbl_out), "-o", "/dev/null", str(hmm_path), str(fasta_path)],
        check=True,
    )


def parse_domtblout(path: Path):
    """Returns {query_name: best_hit_dict} keeping the domain with the lowest i-Evalue."""
    best = {}
    if not path.exists():
        return best
    with open(path) as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            fields = line.split()
            # domtblout columns (space-delimited, fixed order per HMMER3 spec):
            # 0 target_name 1 target_accession 2 tlen 3 query_name 4 query_accession 5 qlen
            # 6 full_evalue 7 full_score 8 full_bias 9 dom_# 10 dom_of 11 c-Evalue 12 i-Evalue
            # 13 dom_score 14 dom_bias 15 hmm_from 16 hmm_to 17 ali_from 18 ali_to
            # 19 env_from 20 env_to 21 acc ... 22+ description
            query_name = fields[3]
            i_evalue = float(fields[12])
            ali_from, ali_to = int(fields[17]), int(fields[18])
            env_from, env_to = int(fields[19]), int(fields[20])
            hit = {
                "target_name": fields[0], "query_name": query_name, "i_evalue": i_evalue,
                "dom_score": float(fields[13]), "ali_from": ali_from, "ali_to": ali_to,
                "env_from": env_from, "env_to": env_to,
            }
            if query_name not in best or i_evalue < best[query_name]["i_evalue"]:
                best[query_name] = hit
    return best


def extract_domains(manifest_rows, hmm_path, label, out_fasta, out_csv, coord_field="env"):
    """manifest_rows must already be pre-filtered to the accessions of interest."""
    fasta_dir = DATA / "fasta"
    combined_fasta = RESULTS / f"_tmp_{label}_input.fasta"
    accs = [r["accession"] for r in manifest_rows]
    with open(combined_fasta, "w") as out:
        for acc in accs:
            rec = next(SeqIO.parse(fasta_dir / f"{acc}.fasta", "fasta"))
            out.write(f">{acc}\n{str(rec.seq).replace('*','')}\n")

    domtbl = RESULTS / f"_tmp_{label}.domtblout"
    run_hmmscan(hmm_path, combined_fasta, domtbl)
    hits = parse_domtblout(domtbl)

    domain_seqs = {}
    csv_rows = []
    for acc in accs:
        rec = next(SeqIO.parse(fasta_dir / f"{acc}.fasta", "fasta"))
        seq = str(rec.seq).replace("*", "")
        hit = hits.get(acc)
        if hit is None:
            csv_rows.append({"accession": acc, "full_length": len(seq), "hmm_hit": "NONE",
                              "domain_start": None, "domain_end": None, "domain_length": None,
                              "i_evalue": None, "bit_score": None})
            continue
        start = hit[f"{coord_field}_from"]
        end = hit[f"{coord_field}_to"]
        dom_seq = seq[start - 1:end]
        domain_seqs[acc] = dom_seq
        csv_rows.append({"accession": acc, "full_length": len(seq), "hmm_hit": hit["target_name"],
                          "domain_start": start, "domain_end": end, "domain_length": len(dom_seq),
                          "i_evalue": hit["i_evalue"], "bit_score": hit["dom_score"]})

    with open(out_fasta, "w") as fh:
        for acc, seq in domain_seqs.items():
            fh.write(f">{acc}\n{seq}\n")
    with open(out_csv, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["accession", "full_length", "hmm_hit", "domain_start",
                                                 "domain_end", "domain_length", "i_evalue", "bit_score"])
        writer.writeheader()
        writer.writerows(csv_rows)

    combined_fasta.unlink()
    domtbl.unlink()
    return domain_seqs, csv_rows


def build_identity_matrix(domain_seqs, manifest_rows, out_csv):
    labels = {r["accession"]: r for r in manifest_rows}
    donors = [acc for acc in domain_seqs if labels[acc]["category"] == "donor"]
    natives = [acc for acc in domain_seqs if labels[acc]["category"] in ("native_RR", "native_HK")]
    aligner = make_aligner()
    rows = []
    for d in donors:
        for n in natives:
            res = compute_pair(aligner, domain_seqs[d], domain_seqs[n])
            rows.append({
                "donor_label": labels[d]["gene_label"], "donor_accession": d,
                "native_label": labels[n]["gene_label"], "native_locus_tag": labels[n]["locus_tag"],
                "native_accession": n, "native_category": labels[n]["category"],
                **res,
            })
    with open(out_csv, "w", newline="") as fh:
        fieldnames = list(rows[0].keys()) if rows else []
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return rows


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    manifest_rows = list(csv.DictReader(open(DATA / "manifest.csv")))

    if not check_hmmer():
        print("hmmscan NOT FOUND on PATH. Falling back to profile-alignment-against-curated-seed "
              "is NOT implemented in this script -- ABORTING domain analysis. Install HMMER "
              "(e.g. `brew install hmmer`) and rerun.")
        sys.exit(1)
    if not REC_HMM.exists() or not DHP_HMM.exists():
        print(f"Pfam HMM files missing ({REC_HMM}, {DHP_HMM}). Fetch them first.")
        sys.exit(1)

    print("=== REC domain (PF00072) boundaries: response regulators (donor + native) ===")
    rec_manifest = [r for r in manifest_rows if r["category"] in ("native_RR",)] + \
                   [r for r in manifest_rows if r["category"] == "donor" and r["role"] not in
                    ("PRIMARY_DONOR_KINASE", "BACKUP_DONOR_KINASE")]
    # Build a combined category-agnostic accession set for RR-type donors + native RRs
    rr_accs = {r["accession"] for r in rec_manifest}
    rr_rows = [r for r in manifest_rows if r["accession"] in rr_accs]
    rec_seqs, rec_hits = extract_domains(rr_rows, REC_HMM, "rec", RESULTS / "rec_domains.fasta",
                                          RESULTS / "rec_domain_hits.csv", coord_field="env")
    # extract_domains filters by category field; RR set spans two categories, so redo manually:
    print(f"  (see results/rec_domain_hits.csv for full HMMER boundary table)")

    print("\n=== DHp domain (PF00512/HisKA) boundaries: sensor kinases (donor + native) ===")
    hk_accs = {r["accession"] for r in manifest_rows
               if r["category"] == "native_HK" or r["role"] in ("PRIMARY_DONOR_KINASE", "BACKUP_DONOR_KINASE")}
    hk_rows = [r for r in manifest_rows if r["accession"] in hk_accs]
    dhp_seqs, dhp_hits = extract_domains(hk_rows, DHP_HMM, "dhp", RESULTS / "dhp_domains.fasta",
                                          RESULTS / "dhp_domain_hits.csv", coord_field="env")
    print(f"  (see results/dhp_domain_hits.csv for full HMMER boundary table)")

    print("\n=== Recomputing identity matrix on REC domains only ===")
    rec_rows = build_identity_matrix(rec_seqs, manifest_rows, RESULTS / "identity_rec.csv")
    print(f"  Wrote {len(rec_rows)} REC-domain pairwise comparisons to results/identity_rec.csv")

    print("\n=== Recomputing identity matrix on DHp domains only (bonus, for Task 4 support) ===")
    dhp_rows = build_identity_matrix(dhp_seqs, manifest_rows, RESULTS / "identity_dhp.csv")
    print(f"  Wrote {len(dhp_rows)} DHp-domain pairwise comparisons to results/identity_dhp.csv")

    missing_rec = [h["accession"] for h in rec_hits if h["hmm_hit"] == "NONE"]
    missing_dhp = [h["accession"] for h in dhp_hits if h["hmm_hit"] == "NONE"]
    if missing_rec:
        print(f"\nWARNING: no PF00072/REC domain found for: {missing_rec}")
    if missing_dhp:
        print(f"WARNING: no PF00512/DHp domain found for: {missing_dhp}")


if __name__ == "__main__":
    main()
