"""Independent verification of Task 2. Reads only the written v2 and v3 files."""
import csv, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import seqchecks as S
from seqchecks import CATALOGUE, GOLDEN_GATE, site_scan, sigA_scan, sd_atg_scan
D = ROOT / "designs"

CODON = {}
def _mk():
    from itertools import product
    t = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
    for i, (a, b, c) in enumerate(product("TCAG", repeat=3)):
        CODON[a+b+c] = t[i]
_mk()
tr = lambda d: "".join(CODON[d[i:i+3]] for i in range(0, len(d)-2, 3))

def read_fasta(p):
    o, k, b = {}, None, []
    for line in open(p):
        line = line.strip()
        if line.startswith(">"):
            if k: o[k] = "".join(b)
            k, b = line[1:].split()[0], []
        elif line: b.append(line)
    if k: o[k] = "".join(b)
    return o

v2, v3 = read_fasta(D / "junctions_v2.fasta"), read_fasta(D / "junctions_v3.fasta")
r2 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v2.csv"))}
r3 = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v3.csv"))}
ok, fail = [], []
def ck(n, c, d=""):
    """Detail is shown only on FAILURE -- a passing check that dumps its data is noise."""
    ok.append(n) if c else fail.append(f"{n} -- {d}")

S.positive_control_check(force=True)
ok.append(f"seqchecks positive controls pass ({len(CATALOGUE)}-enzyme catalogue)")

ck("v3 has 24 CSV rows and 24 FASTA records", len(r3) == 24 == len(v3), (len(r3), len(v3)))
ck("v3 ids match v2 ids exactly", set(v3) == set(v2))
ck("v2 files are untouched (still 18 NcoI carriers)",
   len([d for d, s in v2.items() if site_scan(s, enzymes=["NcoI"])]) == 18)

# --- 1. zero NcoI remains
ncoi3 = {d: site_scan(s, enzymes=["NcoI"]) for d, s in v3.items()}
ck("ZERO NcoI sites across all 24 v3 constructs, both strands",
   sum(len(v) for v in ncoi3.values()) == 0, {d: len(v) for d, v in ncoi3.items() if v})
# --- 2. Golden Gate still zero
gg = sum(len(site_scan(s, enzymes=GOLDEN_GATE)) for s in v3.values())
ck("ZERO Golden Gate sites across all 24 v3, both strands", gg == 0, gg)
# --- 3. protein identical
bad = [d for d in v3 if tr(v3[d][:-3]) != r2[d]["protein_seq"]]
ck("protein back-translates IDENTICAL to v2 for all 24", not bad, bad)
bad = [d for d in v3 if r3[d]["protein_seq"] != r2[d]["protein_seq"]]
ck("v3 CSV protein_seq equals v2 CSV protein_seq for all 24", not bad, bad)
# --- 4. no NEW site of ANY catalogue enzyme
added, removed = {}, {}
for d in v3:
    a = {h.key() for h in site_scan(v2[d])}
    b = {h.key() for h in site_scan(v3[d])}
    if b - a: added[d] = sorted(b - a)
    if a - b: removed[d] = sorted(a - b)
ck("no NEW site of any of the 35 catalogue enzymes was created", not added, added)
ck("the only sites removed are NcoI",
   all(e == "NcoI" for v in removed.values() for e, _p, _s in v), removed)
ck("exactly 36 NcoI site-instances removed (18 constructs x both strands)",
   sum(len(v) for v in removed.values()) == 36, sum(len(v) for v in removed.values()))
# --- 5. edit is exactly one synonymous codon, and only in the 18
edited = [d for d in r3 if int(r3[d]["n_codon_edits"]) > 0]
ck("exactly 18 constructs edited", len(edited) == 18, len(edited))
ck("every edited construct got exactly ONE codon change",
   all(int(r3[d]["n_codon_edits"]) == 1 for d in edited))
ck("every edit is the documented TCC->TCT",
   all("TCC->TCT" in r3[d]["codon_edits"] for d in edited),
   {d: r3[d]["codon_edits"] for d in edited if "TCC->TCT" not in r3[d]["codon_edits"]})
ck("the 6 unedited constructs are byte-identical to v2",
   all(v3[d] == v2[d] for d in r3 if int(r3[d]["n_codon_edits"]) == 0))
diffs = {d: sum(1 for i in range(len(v2[d])) if v2[d][i] != v3[d][i]) for d in edited}
ck("each edited construct differs from v2 by exactly ONE nucleotide",
   set(diffs.values()) == {1}, diffs)
ck("length unchanged for all 24", all(len(v2[d]) == len(v3[d]) for d in v3))

# --- 6. no new spurious SigA or SD, including junction-spanning
sig_bad, sd_bad = {}, {}
for d in v3:
    a = {h.key() for h in sigA_scan(v2[d], both_strands=True)}
    b = {h.key() for h in sigA_scan(v3[d], both_strands=True)}
    if b - a: sig_bad[d] = sorted(b - a)
    a = {h.key() for h in sd_atg_scan(v2[d], known_starts={0})}
    b = {h.key() for h in sd_atg_scan(v3[d], known_starts={0})}
    if b - a: sd_bad[d] = sorted(b - a)
ck("no NEW SigA ext-10 window (sense or antisense) anywhere", not sig_bad, sig_bad)
ck("no NEW SD+ATG anywhere", not sd_bad, sd_bad)
# Compare LIKE WITH LIKE. designs/junctions_v2.csv's own `spurious_sigA_at_junction`
# column was computed sense-strand-only, so comparing v3's both-strand column against
# it would measure the change of METHOD, not the effect of the codon edit. Both sides
# are therefore recomputed here with the identical shared-module scan.
def _junc_siga(dna, row):
    s_end, llen = int(row["sensor_last_residue"]), int(row["linker_len"])
    jnt = int(row["junction_nt_pos"])
    cmap = [("sensor", dna[:s_end * 3])]
    if llen: cmap.append(("linker", dna[s_end * 3:jnt]))
    cmap += [("acceptor", dna[jnt:len(dna) - 3]), ("stop", dna[-3:])]
    from seqchecks import junction_aware as _ja
    return {h.key() for h in _ja(dna, cmap)["sigA"] if h.spans_junction}
j2 = {d: _junc_siga(v2[d], r2[d]) for d in v2}
j3 = {d: _junc_siga(v3[d], r2[d]) for d in v3}
ck("junction-spanning SigA set is IDENTICAL v2 vs v3 (same scan both sides)",
   j2 == j3, {d: (sorted(j2[d]), sorted(j3[d])) for d in j2 if j2[d] != j3[d]})
ck("the one pre-existing junction-spanning SigA window is carried through unchanged",
   sum(len(v) for v in j3.values()) == sum(len(v) for v in j2.values()) == 1,
   (sum(len(v) for v in j2.values()), sum(len(v) for v in j3.values())))
ck("junction-spanning SD count is still zero",
   all(r3[d]["sd_atg_at_junction"] == "none" for d in r3))

# --- 7. H-box
ck("H-box histidine present at the expected position in all 24",
   all(r3[d]["hbox_residue"] == "H" for d in r3),
   {d: r3[d]["hbox_residue"] for d in r3 if r3[d]["hbox_residue"] != "H"})
ck("H-box construct position unchanged from v2 for all 24",
   all(r3[d]["hbox_construct_position"] == r2[d]["hbox_construct_position"] for d in r3))
# --- 8. homopolymers / GC
ck("no homopolymer run > 6 in any v3 construct",
   all(not S.basic_checks(s)["homopolymers_gt6"] for s in v3.values()))
gcs = [round(S.gc(s), 2) for s in v3.values()]
ck("GC stays inside the host band", max(abs(g - 53.84) for g in gcs) < 1.0,
   f"{min(gcs)}-{max(gcs)}%")

print("=" * 74); print("TASK 2 INDEPENDENT VERIFICATION"); print("=" * 74)
for x in ok: print(f"  PASS  {x}")
for x in fail: print(f"  FAIL  {x}")
print(f"\n  {len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
