"""FINAL consolidation: every construct in this repo -> one order-ready manifest,
with every check re-run across the COMBINED set of 93.

WHY THIS EXISTS. Four defects in this project were boundary defects: they lived
at a junction between two components and were invisible to component-level
checking (HP-4's NcoI; NsiI/SphI in a primer tail; a SigA element created at a
background/operator junction; a junction-created SigA hit in a kinase construct).
So every scan here runs on the WHOLE construct, and every hit is attributed to
either "inside one component" or "SPANS a component junction" using an explicit,
verified component map.

NOTHING IS WRITTEN FROM MEMORY. Every component sequence is read from a cached
record or a repo CSV; the component map is then verified by asserting that the
concatenation of the parts reproduces the stored full_sequence base-for-base.
No builder is re-run and no existing path is overwritten.
"""
import csv, json, re, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
DATA, DESIGNS, CACHE = ROOT / "data", ROOT / "designs", ROOT / "data" / "cache"

from siga_consensus import EXT10_PWM, score_window as siga_score, max_score as siga_max
from seqchecks import (CATALOGUE, GOLDEN_GATE, VECTOR_SITES, PROVENANCE_DERIVED,
                       site_scan, sigA_scan, sd_atg_scan, basic_checks, junction_aware,
                       positive_control_check, verify_component_map, ComponentMapError,
                       revcomp, gc as _gc, homopolymers as _homopolymers,
                       SIGA_THRESHOLD, SIGA_WIDTH, SIGA_MAX)
from design_promoter_panel import OPERATORS, scramble, PSYN_UPSTREAM_CONTEXT

HOST_GC = 53.84
GC_TOL_PTS = 15.0          # same band the previous manifests used
SIGA_THRESH = 0.55         # fraction of PWM max, repo convention
GAPS_BG_LEN = 46

# Enzyme sites and every scanner come from scripts/seqchecks.py -- this module defines
# none of its own. Before the shared module existed this file carried its own copy of
# the 35-enzyme catalogue and its own site/SigA/SD scanners, which is precisely the
# duplication that let the kinase panel screen 5 enzymes while this one screened 35.

def gc(s):
    return round(_gc(s), 2) if s else None


# ================================================================ PROVENANCE
# Every string below is a citation/accession, not a sequence. Sequences come
# from the cached records loaded in load_components().
P_CORE = ("Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838) Table 2 primers; "
          "amplicon recovered from BX927147.1")
P_OP = "PRODORIC MX000339 (confirmed Salmonella Sal_PhoP site)"
P_RETA = "PMC7835838 Table 2, vector-homology tail of primer N105 (Psyn-fw2)"
P_NATIVE = "BX927147.1, 40 bp immediately 5' of the validated amplicon"
P_FC = "Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1"
P_SD2 = "PMC10367133 body text, verbatim ('AAAGGAGGACAAC')"
P_TAATG = "PMC10367133 body text, TAATG coupling frame (fragment carries the 'TA')"
P_DESIGNED = ("DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; "
              "reproducible from that file alone")
P_SCRAM = "DESIGNED - composition-matched scramble of opA_phoP (scripts/design_promoter_panel.py)"
P_CODON = "codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA"
KIN_ACC = {
    "WP_043878053.1": "RefSeq WP_043878053.1, methyl-accepting chemotaxis protein, Pectobacterium atrosepticum (657 aa)",
    "Q92SH9": "UniProt Q92SH9 (McpX), Rhizobium meliloti 1021",
    "P0DM80": "UniProt P0DM80 (PhoQ), Salmonella Typhimurium LT2",
    "P0AEJ4": "UniProt P0AEJ4 (EnvZ), Escherichia coli K-12",
}


def load_components():
    """Every reusable component, read from cached records. label -> (seq, provenance, sourced?)"""
    bg = json.loads((CACHE / "designed_backgrounds.json").read_text())
    cp = json.loads((CACHE / "core_promoters.json").read_text())
    el = json.loads((CACHE / "promoter_elements.json").read_text())
    raw = {r["name"]: r for r in json.loads((CACHE / "panel_variants_raw.json").read_text())}
    src = json.loads((CACHE / "translational_sources.json").read_text())

    C = {}
    for k in ("Psyn", "PsodA", "Ptuf"):
        C[f"core:{k}"] = (cp[k]["sequence"][el[k]["minus35_start0"]:], f"core promoter {k}: {P_CORE}", True)
    for k, v in OPERATORS.items():
        C[f"operator:{k}"] = (v, f"operator {k}: {P_OP}", True)
    C["operator:scrambled_opA"] = (scramble(OPERATORS["opA_phoP"]), P_SCRAM, False)
    C["ctx:Psyn_N105_tail"] = (PSYN_UPSTREAM_CONTEXT, f"retained upstream context: {P_RETA}", True)
    C["ctx:PsodA_native40"] = (raw["PsodA_1x_opA_gap03_native"]["sequence"][:40],
                               f"retained native upstream context (PsodA): {P_NATIVE}", True)
    C["ctx:Ptuf_native40"] = (raw["Ptuf_1x_opA_gap03_reta"]["sequence"][:40],
                              f"retained native upstream context (Ptuf): {P_NATIVE}", True)
    for k in ("BG_A", "BG_B", "BG_C", "UP_A", "FILL_A", "FILL_B", "TSP_A"):
        C[f"designed:{k}"] = (bg[k], f"{k}: {P_DESIGNED}", False)
    for e in src["approach_B_source"]["fore_cistrons"]:
        C[f"forecistron:{e['id']}"] = (e["seq"], f"fore-cistron {e['id']} ({e['gene']}, {e['ncgl']}): {P_FC}", True)
    C["SD2"] = (src["approach_B_source"]["sd_motif"], f"SD2 motif: {P_SD2}", True)
    C["TAATG_frag"] = ("TA", f"TAATG coupling frame, 5' 2 nt: {P_TAATG}", True)
    # verify the two known homology tails are what the provenance says they are
    C["tail:Henke_fwd_Gibson"] = ("CTGTGCGGTATTTCACACCGCA", f"forward Gibson tail: {P_CORE}", True)
    C["tail:Henke_rev_Gibson"] = ("CCGGGTACCGAGCTCGAATTCCATG", f"reverse Gibson tail: {P_CORE}", True)
    C["tail:Psyn_N106_rev"] = ("GGCCAGTGAATTCGAGCTCGCTGCAGGTCGACTCTAGAGGATC", f"N106 reverse tail: {P_CORE}", True)
    return C, bg, cp, el, raw, src


# ==================================================== COMPONENT MAPS (non-kinase)
def build_nonkinase_parts(C, bg, t2rows):
    """name -> [(component_label, sequence), ...] mirroring scripts/build_phasing_v2.py.

    Layout rules are taken from that script's own docstring/code, not from memory;
    every map is then asserted against the stored full_sequence.
    """
    OP, OPB, SCR = C["operator:opA_phoP"][0], C["operator:opB_mgtA"][0], C["operator:scrambled_opA"][0]
    P, S, T = C["core:Psyn"][0], C["core:PsodA"][0], C["core:Ptuf"][0]
    BG = {"BG_A": bg["BG_A"], "BG_B": bg["BG_B"], "BG_C": bg["BG_C"]}
    UP_A, FILL_A, FILL_B, TSP = bg["UP_A"], bg["FILL_A"], bg["FILL_B"], bg["TSP_A"]
    CTX, NAT_S, NAT_T = C["ctx:Psyn_N105_tail"][0], C["ctx:PsodA_native40"][0], C["ctx:Ptuf_native40"][0]
    L = GAPS_BG_LEN

    def sub(tag, g, core, corename):
        b = BG[tag]
        lo = L - g - len(OP)
        parts = [(f"designed:{tag}[0:{lo}]", b[:lo]), ("operator:opA_phoP", OP)]
        if g:
            parts.append((f"designed:{tag}[{L-g}:{L}]", b[L - g:L]))
        parts.append((f"core:{corename}", core))
        return parts

    def ins(g, core, corename, up=("designed:UP_A", None), fill=("designed:FILL_A", None), op=("operator:opA_phoP", OP)):
        upl, ups = up[0], up[1] if up[1] is not None else UP_A
        fl, fs = fill[0], fill[1] if fill[1] is not None else FILL_A
        parts = [(upl, ups), op]
        if g:
            parts.append((f"{fl}[0:{g}]", fs[:g]))
        parts.append((f"core:{corename}", core))
        return parts

    M = {}
    for g in range(14):
        M[f"SUB_Psyn_opA_gap{g:02d}"] = sub("BG_A", g, P, "Psyn")
        M[f"INS_Psyn_opA_gap{g:02d}"] = ins(g, P, "Psyn")
    for g in (0, 3, 6, 10):
        M[f"INS_PsodA_opA_gap{g:02d}"] = ins(g, S, "PsodA")
    M["CTL_SUB_BGB_gap07"] = sub("BG_B", 7, P, "Psyn")
    M["CTL_SUB_BGC_gap07"] = sub("BG_C", 7, P, "Psyn")
    M["CTL_INS_FILLB_gap07"] = ins(7, P, "Psyn", fill=("designed:FILL_B", FILL_B))

    M["Psyn_noop_ctrl_v2"] = [("designed:UP_A", UP_A), ("core:Psyn", P)]
    M["PsodA_noop_ctrl_v2"] = [("designed:UP_A", UP_A), ("core:PsodA", S)]
    M["Ptuf_noop_ctrl_v2"] = [("designed:UP_A", UP_A), ("core:Ptuf", T)]
    M["Psyn_1x_scrambled_gap03_v2"] = ins(3, P, "Psyn", op=("operator:scrambled_opA", SCR))
    M["PsodA_1x_scrambled_gap03_v2"] = ins(3, S, "PsodA", op=("operator:scrambled_opA", SCR))
    for g in (0, 5):
        M[f"Psyn_1x_opB_gap{g:02d}_v2"] = ins(g, P, "Psyn", op=("operator:opB_mgtA", OPB))
        M[f"Psyn_2xopA_gap{g:02d}_v2"] = (
            [("designed:UP_A", UP_A), ("operator:opA_phoP#1", OP), ("designed:TSP_A", TSP),
             ("operator:opA_phoP#2", OP)]
            + ([(f"designed:FILL_A[0:{g}]", FILL_A[:g])] if g else []) + [("core:Psyn", P)])
    M["PsodA_2xopA_gap03_v2"] = [("designed:UP_A", UP_A), ("operator:opA_phoP#1", OP),
                                 ("designed:TSP_A", TSP), ("operator:opA_phoP#2", OP),
                                 ("designed:FILL_A[0:3]", FILL_A[:3]), ("core:PsodA", S)]
    for g in (3, 5):
        M[f"Psyn_1x_opA_gap{g:02d}_reta_v2"] = ins(g, P, "Psyn", up=("ctx:Psyn_N105_tail", CTX))
    M["PsodA_1x_opA_gap03_native_v2"] = ins(3, S, "PsodA", up=("ctx:PsodA_native40", NAT_S))
    M["Ptuf_1x_opA_gap03_repl_v2"] = ins(3, T, "Ptuf")
    M["Ptuf_1x_opA_gap03_reta_v2"] = ins(3, T, "Ptuf", up=("ctx:Ptuf_native40", NAT_T))
    return M


def t2_parts(C, t2row):
    """Fore-cistron(62) + SD2(13) + 'TA'(2) = 77 bp, per PMC10367133."""
    s = t2row["sequence"]
    if not s:
        return []
    fc, sd, ta = s[:62], s[62:75], s[75:]
    base = t2row["source_element"]
    m = re.match(r"HP-(\d+)", base)
    lab = f"forecistron:HP-{m.group(1)}" if m else "forecistron:?"
    ref = C.get(lab, (None,))[0]
    if ref is not None and fc != ref:
        d = [i for i in range(62) if fc[i] != ref[i]]
        lab += f"(MUT@{','.join(map(str, d))})"
    sdref = C["SD2"][0]
    sdlab = "SD2" if sd == sdref else f"SD2(MUT@{','.join(str(i) for i in range(13) if sd[i]!=sdref[i])})"
    return [(lab, fc), (sdlab, sd), ("TAATG_frag", ta)]


# ==================================================== COMPONENT MAP (kinase)
CODON = {}
_B = "TTCAG"
def _mk():
    from itertools import product
    tbl = ("FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG")
    for i, (a, b, c) in enumerate(product("TCAG", repeat=3)):
        CODON[a + b + c] = tbl[i]
_mk()


def translate(dna):
    return "".join(CODON[dna[i:i + 3]] for i in range(0, len(dna) - 2, 3))


def read_fasta(p):
    out, name, buf = {}, None, []
    for line in open(p):
        line = line.strip()
        if line.startswith(">"):
            if name:
                out[name] = "".join(buf)
            name, buf = line[1:].split()[0], []
        elif line:
            buf.append(line)
    if name:
        out[name] = "".join(buf)
    return out


def build_kinase_parts(jrow, dna, prot_lib):
    """sensor DNA | (linker DNA) | acceptor DNA | stop. Boundaries from the CSV's own
    junction_nt_pos / sensor_last_residue, then verified by back-translation."""
    sacc, aacc = jrow["sensor_accession"], jrow["acceptor_accession"]
    s_end, llen = int(jrow["sensor_last_residue"]), int(jrow["linker_len"])
    a_start, jnt = int(jrow["acceptor_first_residue"]), int(jrow["junction_nt_pos"])
    prot = jrow["protein_seq"]

    assert translate(dna[:-3]) == prot, f"{jrow['design_id']}: DNA does not translate to protein_seq"
    assert dna[-3:] == "TAA", f"{jrow['design_id']}: missing TAA stop"
    assert prot[:s_end] == prot_lib[sacc][:s_end], f"{jrow['design_id']}: sensor prefix mismatch"
    assert prot[s_end + llen:] == prot_lib[aacc][a_start - 1:], f"{jrow['design_id']}: acceptor suffix mismatch"
    assert jnt == (s_end + llen) * 3, f"{jrow['design_id']}: junction_nt_pos inconsistent"

    parts = [(f"sensor:{sacc}[aa 1-{s_end}]", dna[:s_end * 3])]
    if llen:
        parts.append((f"linker:{jrow['linker']}", dna[s_end * 3:jnt]))
    parts.append((f"acceptor:{aacc}[aa {a_start}-{len(prot_lib[aacc])}]", dna[jnt:len(dna) - 3]))
    parts.append(("stop:TAA", dna[-3:]))
    return parts


# ================================================================ SCANS
def boundaries_of(parts, construct=None):
    """[(label, start, end)] half-open, in construct coordinates.

    When `construct` is given the map is verified against it by
    seqchecks.verify_component_map, which raises unless the parts reproduce the
    sequence base-for-base. Every junction claim downstream rests on that.
    """
    out, p = [], 0
    for lab, s in parts:
        out.append((lab, p, p + len(s)))
        p += len(s)
    if construct is not None:
        verify_component_map(construct, out)
    return out


def attribute(lo, hi, bnds):
    """Which components does [lo,hi) touch? >1 == the span crosses a component junction."""
    touched = [lab for lab, a, b in bnds if a < hi and lo < b]
    return touched


def enzyme_scan(seq, bnds, enzymes=None):
    """seqchecks.site_scan, sorted by position and attributed to components."""
    out = []
    for h in sorted(site_scan(seq, enzymes=enzymes), key=lambda x: (x.start, x.enzyme)):
        comps = attribute(h.start, h.end, bnds)
        out.append({"enzyme": h.enzyme, "site": h.site, "start": h.start, "end": h.end,
                    "strand": h.strand, "components": comps, "spans_junction": len(comps) > 1})
    return out


SIGA_W = SIGA_WIDTH


def siga_scan(seq, bnds, thresh=SIGA_THRESH):
    """seqchecks.sigA_scan (sense strand), attributed to components.

    Carries sigA_scan's standing caveat: the matrix is a reasoned approximation
    from a textual consensus, not an empirically trained PWM.
    """
    out = []
    for h in sigA_scan(seq, threshold=thresh):
        comps = attribute(h.start, h.end, bnds)
        out.append({"start": h.start, "end": h.end, "frac_of_max": h.score,
                    "components": comps, "spans_junction": len(comps) > 1,
                    "window": h.detail})
    return out


def siga_best(seq):
    from seqchecks import sigA_best as _b
    return _b(seq)


def sd_scan(seq, bnds, known_starts=()):
    """seqchecks.sd_atg_scan, attributed to components."""
    out = []
    for h in sd_atg_scan(seq, known_starts=known_starts):
        comps = attribute(h.start, h.end, bnds)
        sd, sd_start, atg = re.match(r"SD\((\w+)@(\d+)\)\+ATG@(\d+)", h.detail).group(1, 2, 3)
        out.append({"sd": sd, "sd_start": int(sd_start), "atg_start": int(atg),
                    "spacing": int(atg) - (int(sd_start) + len(sd)), "components": comps,
                    "spans_junction": len(comps) > 1})
    return out


def homopolymers(seq, n=6):
    return _homopolymers(seq, max_run=n)


def gtracts(seq):
    """G-tracts / G-quadruplex-like motifs: vendors price these higher."""
    out = [f"G{len(m.group(0))}@{m.start()}" for m in re.finditer(r"G{4,}", seq)]
    out += [f"G4motif@{m.start()}" for m in re.finditer(r"(?=(G{3,}\w{1,7}G{3,}\w{1,7}G{3,}\w{1,7}G{3,}))", seq)]
    return out


def repeats20(seq, k=20):
    seen = defaultdict(list)
    for i in range(len(seq) - k + 1):
        seen[seq[i:i + k]].append(i)
    return {kk: v for kk, v in seen.items() if len(v) > 1}


def fold_mfe(seq):
    try:
        import RNA
        return round(RNA.fold(seq)[1], 2)
    except Exception:
        return None


def worst_local(seq, w=60, step=5):
    try:
        import RNA
    except Exception:
        return None
    if len(seq) <= w:
        return round(RNA.fold(seq)[1], 2)
    return round(min(RNA.fold(seq[i:i + w])[1] for i in range(0, len(seq) - w + 1, step)), 2)


def ungapped_identity(a, b):
    n = min(len(a), len(b))
    if n == 0:
        return 0.0
    return round(100 * sum(1 for i in range(n) if a[i] == b[i]) / max(len(a), len(b)), 2)


def max_shared_substring(a, b, lo=1):
    """Exact longest common substring length, binary search on k with hash sets."""
    hi = min(len(a), len(b))
    if hi == 0:
        return 0
    def shares(k):
        if k == 0:
            return True
        s = {hash(a[i:i + k]) for i in range(len(a) - k + 1)}
        return any(hash(b[i:i + k]) in s for i in range(len(b) - k + 1))
    if not shares(lo):
        return lo - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if shares(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


# ================================================================ MAIN
# Which kinase panel to consolidate, and how the outputs are named. Defaults reproduce
# the original v1 run exactly; scripts/consolidate_v2.py overrides them to consume the
# NcoI-fixed junctions_v3 and write the _v2 output set. Nothing is renamed in place.
SUFFIX = ""
KIN_CSV = "junctions_v2.csv"
KIN_FA = "junctions_v2.fasta"
NK_CSV = "order_manifest_v2.csv"

# --- hooks, all empty by default so every earlier run reproduces byte-identically ---
# cid -> replacement full_sequence (used when a tier-1 construct has been edited)
NK_SEQ_OVERRIDE = {}
# extra (label, seq) parts spliced between the promoter parts and the tier-2 element
# of every V2-CX-* construct built on Psyn
CX_INSERT_PARTS = []
# fully specified additional constructs: {construct_id, panel, tier, parts, rank_or_rationale, src}
EXTRA_CONSTRUCTS = []


def output_names(sfx=None):
    sfx = SUFFIX if sfx is None else sfx
    return {
        "manifest": f"order_manifest_final{sfx}.csv",
        "checks": f"order_manifest_final{sfx}_checks.csv",
        "sites": f"order_manifest_final{sfx}_sites.csv",
        "motifs": f"order_manifest_final{sfx}_motifs.csv",
        "pairs": f"order_manifest_final{sfx}_pairs.csv",
        "components": f"order_manifest_final{sfx}_components.csv",
        "fasta": f"order_submit_final{sfx}.fasta",
        "submit": f"order_submit_final{sfx}.csv",
    }


OUTPUTS = list(output_names("").values()) + ["REPORT_order_final.md"]


# Where the outputs go. Defaults to designs/; overridable so the refactor can be
# regression-tested (write to a scratch dir, diff against designs/) without ever
# overwriting a delivered file.
OUTDIR = DESIGNS


def guard_outputs():
    names = list(output_names().values()) + (["REPORT_order_final.md"] if not SUFFIX else [])
    clash = [o for o in names if (OUTDIR / o).exists()]
    if clash:
        sys.exit(f"REFUSING TO OVERWRITE: {clash}")


def selftest():
    """Positive controls. Every finder here must be shown to FIND something before a
    null result from it is trusted -- the repo's standing rule."""
    print("=" * 78); print("SELF-TEST (positive controls run before any null result is trusted)"); print("=" * 78)
    # enzyme finder: both strands, and a site deliberately straddling a component junction
    a, b = "AAAAGGTC", "TCTTTTTT"            # BsaI GGTCTC formed only across the a|b join
    seq = a + b
    bnds = [("compA", 0, len(a)), ("compB", len(a), len(seq))]
    hits = enzyme_scan(seq, bnds)
    got = {(h["enzyme"], h["strand"], h["spans_junction"]) for h in hits}
    assert ("BsaI", "+", True) in got, got
    # non-palindromic site on the minus strand only
    m = enzyme_scan("AAA" + revcomp("GGTCTC") + "AAA", [("x", 0, 12)])
    assert [(h["enzyme"], h["strand"]) for h in m] == [("BsaI", "-")], m
    # palindromic site is reported on both strands
    assert sorted(h["strand"] for h in enzyme_scan("AACCATGGAA", [("x", 0, 10)])) == ["+", "-"]
    # a site wholly inside one component must NOT be called junction-spanning
    inside = enzyme_scan("AAGGTCTCAA" + "GGGG", [("compA", 0, 10), ("compB", 10, 14)])
    assert all(not h["spans_junction"] for h in inside), inside
    # SigA scorer: the exact consensus must score 1.00 of max
    cons = EXT10_PWM["consensus"].upper().replace("Y", "T").replace("N", "A")
    assert round(siga_score(cons, EXT10_PWM) / SIGA_MAX, 3) == 1.0
    hs = siga_scan("GGGG" + cons + "GGGG", [("compA", 0, 8), ("compB", 8, 21)])
    assert hs and hs[0]["frac_of_max"] == 1.0 and hs[0]["spans_junction"] is True
    # SD+ATG finder
    sd = sd_scan("TTGGAGGTTTTATGCC", [("x", 0, 16)])
    assert sd and sd[0]["sd"] == "GGAGG" and sd[0]["atg_start"] == 11, sd
    # translate / revcomp / LCS
    assert translate("ATGTGGTAA") == "MW*"
    assert revcomp("ACGTn".upper().replace("N", "A")) == "TACGT"
    assert max_shared_substring("QQABCDEFGHQQ", "ZZABCDEFGHZZ", lo=1) == 8
    assert homopolymers("AAAAAAAGG") and not homopolymers("AAAAAAGG")
    print("  enzyme finder (+/- strand, junction-straddling, within-component)  PASS")
    print("  SigA ext-10 scorer (exact consensus = 1.00 of max, junction call)  PASS")
    print("  SD+ATG finder / translate / revcomp / LCS / homopolymer            PASS\n")


def main():
    guard_outputs()
    positive_control_check()
    selftest()
    C, bg, cp, el, raw, src = load_components()
    prov_of = {k: v[1] for k, v in C.items()}
    sourced = {k: v[2] for k, v in C.items()}

    # ------------------------------------------------------------ TASK 1: gather
    nk = list(csv.DictReader(open(DESIGNS / NK_CSV)))
    kin = list(csv.DictReader(open(DESIGNS / KIN_CSV)))
    kfa = read_fasta(DESIGNS / KIN_FA)
    t2 = {r["name"]: r for r in csv.DictReader(open(DESIGNS / "translational_variants.csv"))}
    t2fa = read_fasta(DESIGNS / "translational_variants.fasta")
    combo = list(csv.DictReader(open(DESIGNS / "combinatorial_design.csv")))
    subcsv = list(csv.DictReader(open(DESIGNS / "phasing_substitution.csv")))
    inscsv = list(csv.DictReader(open(DESIGNS / "phasing_insertion.csv")))
    ctlcsv = list(csv.DictReader(open(DESIGNS / "phasing_controls.csv")))

    print("=" * 78); print("TASK 1  COUNT VERIFICATION (rows / FASTA records, counted not assumed)"); print("=" * 78)
    counts = {
        f"{NK_CSV} rows": len(nk),
        "order_submit_v2.fasta records": len(read_fasta(DESIGNS / "order_submit_v2.fasta")),
        "phasing_substitution.csv rows": len(subcsv),
        "phasing_insertion.csv rows": len(inscsv),
        "phasing_controls.csv rows": len(ctlcsv),
        "combinatorial_design.csv rows (new_construct_required=yes)":
            sum(1 for c in combo if c["new_construct_required"] == "yes"),
        "translational_variants.csv rows": len(t2),
        "translational_variants.fasta records": len(t2fa),
        f"{KIN_CSV} rows": len(kin),
        f"{KIN_FA} records": len(kfa),
    }
    for k, v in counts.items():
        print(f"  {k:62} {v}")
    assert len(nk) == 69
    assert len(kin) == len(kfa) == 24
    assert {r["design_id"] for r in kin} == set(kfa)
    EXPECTED = 69 + 24 + len(EXTRA_CONSTRUCTS)
    print(f"\n  non-kinase {len(nk)} + kinase {len(kin)} + extra {len(EXTRA_CONSTRUCTS)} = "
          f"{len(nk)+len(kin)+len(EXTRA_CONSTRUCTS)}   EXPECTED {EXPECTED} -> "
          f"{'MATCH' if len(nk)+len(kin)+len(EXTRA_CONSTRUCTS) == EXPECTED else 'MISMATCH'}")
    if len(nk) + len(kin) + len(EXTRA_CONSTRUCTS) != EXPECTED:
        sys.exit("COUNT MISMATCH -- stopping before proceeding, as instructed.")

    # ------------------------------------------------------ build the 93 rows
    NKPARTS = build_nonkinase_parts(C, bg, t2)
    prot_lib = {a: "".join((DATA / "fasta" / f"{a}.fasta").read_text().strip().split("\n")[1:]).replace("*", "")
                for a in KIN_ACC}
    PANEL_MAP = {
        "phasing substitution arm": "substitution_phasing",
        "phasing insertion arm": "insertion_phasing",
        "swap controls": "phasing_swap_controls",
        "tier-1 non-phasing (rebuilt)": "tier1_nonphasing",
    }
    rows = []
    for r in nk:
        cid = r["construct_id"]
        full = NK_SEQ_OVERRIDE.get(cid, r["full_sequence"])
        if cid.startswith("V2-CX-"):
            base = cid.split("_", 1)[1].split("__")[0]
            ins = CX_INSERT_PARTS if base.startswith("SUB_Psyn") or base.startswith("INS_Psyn") else []
            parts = NKPARTS[base] + list(ins) + t2_parts(C, t2[r["translational_element"]])
            panel = "combinatorial_" + r["panel_of_origin"].split(", ")[1]
        else:
            parts = NKPARTS[cid.split("_", 1)[1]]
            panel = PANEL_MAP[r["panel_of_origin"]]
        rec = "".join(s for _, s in parts)
        assert rec == full, f"component map does not reproduce {cid}"
        # retained-context variants are their own reportable panel
        if "_reta_v2" in cid or "_native_v2" in cid:
            panel = "retained_context"
        rows.append({"construct_id": cid, "panel": panel, "tier": r["tier"], "kind": "DNA_fragment",
                     "full_sequence": full, "parts": parts,
                     "rank_or_rationale": r["rationale"], "src": r, "protein": None})
    for r in kin:
        dna = kfa[r["design_id"]]
        parts = build_kinase_parts(r, dna, prot_lib)
        rows.append({"construct_id": r["design_id"], "panel": "kinase_junction_" + r["panel"],
                     "tier": "sensor-kinase", "kind": "CDS",
                     "full_sequence": dna, "parts": parts,
                     "rank_or_rationale": (f"{r['strategy_contains']}; register_offset={r['register_offset']}; "
                                           f"heptad_delta={r['heptad_delta']} (in_phase={r['heptad_in_phase']}); "
                                           f"H-box His{r['hbox_native_residue']} -> construct pos "
                                           f"{r['hbox_construct_position']} ({r['hbox_residue']}); "
                                           f"triplet_recentred={r['triplet_recentred']}"),
                     "src": r, "protein": r["protein_seq"]})
    for e in EXTRA_CONSTRUCTS:
        rows.append({"construct_id": e["construct_id"], "panel": e["panel"], "tier": e["tier"],
                     "kind": e.get("kind", "DNA_fragment"),
                     "full_sequence": "".join(s for _, s in e["parts"]), "parts": e["parts"],
                     "rank_or_rationale": e["rank_or_rationale"], "src": e["src"],
                     "protein": None})
    assert len(rows) == EXPECTED, (len(rows), EXPECTED)
    ids = [r["construct_id"] for r in rows]
    assert len(set(ids)) == EXPECTED, "construct_id collision"

    # construct_id parseability check (kinase strategy names contain '_')
    for r in rows:
        cid = r["construct_id"]
        if cid.startswith("JXN_"):
            f = cid.split("_")
            sensor, acceptor, offset, strategy = f[1], f[2], f[-1], "_".join(f[3:-1])
            s = r["src"]
            assert strategy == s["strategy"] and offset in ("m1", "0", "p1"), cid
            assert {"m1": "-1", "0": "0", "p1": "1"}[offset] == s["register_offset"].lstrip("+"), cid
        elif cid.startswith("CAL-"):
            assert re.match(r"^CAL-\d{2}_", cid), cid
        else:
            assert re.match(r"^V2-(SUB|INS|CTL|OTH|CX)-\d{2}_", cid), cid
    print(f"  construct_id parse rule verified against the source columns for all {len(rows)}")
    return run_checks(rows, C, prov_of, sourced, cp, el, t2, counts)


def run_checks(rows, C, prov_of, sourced, cp, el, t2, counts):
    import time
    # ------------------------------------------------------------ TASK 2: enzymes
    print("\n" + "=" * 78)
    print("TASK 2  ENZYME LIST DERIVED FROM COMPONENT PROVENANCE (35-enzyme catalogue)")
    print("=" * 78)
    used = set()
    for r in rows:
        for lab, _ in r["parts"]:
            used.add(re.sub(r"\[.*|\#.*|\(MUT.*", "", lab))
    prov_enz = defaultdict(list)
    for lab, (seq, prov, is_src) in sorted(C.items()):
        base = re.sub(r"\[.*|\#.*", "", lab)
        if base not in used:
            continue
        hits = sorted({h["enzyme"] for h in enzyme_scan(seq, [(lab, 0, len(seq))])})
        if hits:
            print(f"  {lab:28} {'SOURCED' if is_src else 'designed':8} -> {', '.join(hits)}")
            for h in hits:
                prov_enz[h].append(lab)
    # kinase DNA is codon-optimised, not borrowed: its protein parents carry no DNA sites
    working = sorted(set(prov_enz) | set(VECTOR_SITES) | set(GOLDEN_GATE))
    print(f"\n  enzymes arriving WITH borrowed sequence : {sorted(prov_enz)}")
    print(f"  + pECXT99A opening sites                : {list(VECTOR_SITES)}")
    print(f"  + Golden Gate set (selected route)      : {list(GOLDEN_GATE)}")
    print(f"  WORKING LIST ({len(working)}): {working}")
    print(f"  ALL 93 ARE ALSO SCANNED AGAINST THE FULL {len(CATALOGUE)}-ENZYME CATALOGUE, both strands.")

    # ------------------------------------------------------------ per-construct
    site_rows, motif_rows, comp_rows, checks = [], [], [], []
    t0 = time.time()
    for r in rows:
        seq, cid, parts = r["full_sequence"], r["construct_id"], r["parts"]
        bnds = boundaries_of(parts)
        r["bnds"] = bnds
        for lab, a, b in bnds:
            base = re.sub(r"\[.*|\#.*|\(MUT.*", "", lab)
            comp_rows.append({"construct_id": cid, "component": lab, "start": a, "end": b,
                              "length_bp": b - a, "GC_percent": gc(seq[a:b]),
                              "sourced_or_designed": ("sourced" if sourced.get(base) else
                                                      ("sourced" if lab.startswith(("sensor:", "acceptor:")) else "designed")),
                              "provenance": component_provenance(lab, prov_of, r)})
        # --- enzymes (all 35, both strands)
        enz = enzyme_scan(seq, bnds)
        for h in enz:
            site_rows.append({"construct_id": cid, "panel": r["panel"], "enzyme": h["enzyme"],
                              "site": h["site"], "start": h["start"], "end": h["end"],
                              "strand": h["strand"],
                              "component_s": "|".join(h["components"]),
                              "spans_component_junction": "YES" if h["spans_junction"] else "no",
                              "in_provenance_list": "YES" if h["enzyme"] in prov_enz else "no",
                              "class": ("BLOCKER_GOLDEN_GATE" if h["enzyme"] in GOLDEN_GATE else
                                        "CONDITIONAL_pECXT99A_OPENING_SITE" if h["enzyme"] in VECTOR_SITES
                                        else "NOTE")})
        # --- SigA
        exclude = intended_core_window(r, cp, el, t2)
        for h in siga_scan(seq, bnds):
            in_ext10 = exclude and exclude["ext10"][0] <= h["start"] < exclude["ext10"][1]
            in_amp = exclude and exclude["amplicon"][0] <= h["start"] < exclude["amplicon"][1]
            motif_rows.append({"construct_id": cid, "panel": r["panel"], "motif": "SigA_ext10",
                               "start": h["start"], "end": h["end"], "strand": "+",
                               "score_frac_of_max": h["frac_of_max"], "detail": h["window"],
                               "component_s": "|".join(h["components"]),
                               "spans_component_junction": "YES" if h["spans_junction"] else "no",
                               "class": "INTENDED_CORE_MINUS10" if in_ext10 else
                                        ("WITHIN_SOURCED_CORE_AMPLICON" if in_amp else
                                         ("SPURIOUS_JUNCTION_CREATED" if h["spans_junction"] else
                                          "SPURIOUS_WITHIN_COMPONENT"))})
        for h in siga_scan(revcomp(seq), [(l, len(seq) - b, len(seq) - a) for l, a, b in reversed(bnds)]):
            motif_rows.append({"construct_id": cid, "panel": r["panel"], "motif": "SigA_ext10",
                               "start": len(seq) - h["end"], "end": len(seq) - h["start"], "strand": "-",
                               "score_frac_of_max": h["frac_of_max"], "detail": h["window"],
                               "component_s": "|".join(h["components"]),
                               "spans_component_junction": "YES" if h["spans_junction"] else "no",
                               "class": "ANTISENSE_" + ("JUNCTION_CREATED" if h["spans_junction"] else "WITHIN_COMPONENT")})
        # --- SD + ATG
        known = intended_starts(r, t2)
        for h in sd_scan(seq, bnds, known):
            motif_rows.append({"construct_id": cid, "panel": r["panel"], "motif": "SD+ATG",
                               "start": h["sd_start"], "end": h["atg_start"] + 3, "strand": "+",
                               "score_frac_of_max": "", "detail": f"SD({h['sd']})+ATG@{h['atg_start']} spacing={h['spacing']}",
                               "component_s": "|".join(h["components"]),
                               "spans_component_junction": "YES" if h["spans_junction"] else "no",
                               "class": "SPURIOUS_JUNCTION_CREATED" if h["spans_junction"] else "SPURIOUS_WITHIN_COMPONENT"})
        # --- other checks
        homo = homopolymers(seq)
        reps = repeats20(seq)
        mfe, wl = fold_mfe(seq), worst_local(seq)
        g = gc(seq)
        bi, bs = siga_best(seq)
        checks.append({
            "construct_id": cid, "panel": r["panel"], "tier": r["tier"], "kind": r["kind"],
            "length_bp": len(seq), "GC_percent": g,
            "GC_delta_vs_host": round(g - HOST_GC, 2),
            "gc_flag": "GC_OUT_OF_RANGE" if abs(g - HOST_GC) > GC_TOL_PTS else "",
            "n_restriction_sites_35cat": len(enz),
            "restriction_sites": ";".join(f"{h['enzyme']}@{h['start']}({h['strand']})" for h in enz) or "none",
            "golden_gate_sites": ";".join(f"{h['enzyme']}@{h['start']}({h['strand']})"
                                          for h in enz if h["enzyme"] in GOLDEN_GATE) or "none",
            "vector_site_NcoI_NdeI": ";".join(f"{h['enzyme']}@{h['start']}({h['strand']})"
                                              for h in enz if h["enzyme"] in VECTOR_SITES) or "none",
            "sites_spanning_component_junction": ";".join(
                f"{h['enzyme']}@{h['start']}({h['strand']})" for h in enz if h["spans_junction"]) or "none",
            "homopolymer_gt6": ";".join(f"{h['base']}x{h['run']}@{h['start']}" for h in homo) or "none",
            "gtracts": ";".join(gtracts(seq)) or "none",
            "internal_repeat_20nt": len(reps),
            "dG_full_kcal_per_mol": mfe, "dG60_worst_local": wl,
            "siga_best_frac_of_max": bs, "siga_best_start": bi,
            "siga_hits_ge_0.55_fwd": sum(1 for m in motif_rows if m["construct_id"] == cid
                                         and m["motif"] == "SigA_ext10" and m["strand"] == "+"),
            "siga_junction_spanning_fwd": sum(1 for m in motif_rows if m["construct_id"] == cid
                                              and m["motif"] == "SigA_ext10" and m["strand"] == "+"
                                              and m["spans_component_junction"] == "YES"),
            "sd_atg_hits": sum(1 for m in motif_rows if m["construct_id"] == cid and m["motif"] == "SD+ATG"),
            "sd_atg_junction_spanning": sum(1 for m in motif_rows if m["construct_id"] == cid
                                            and m["motif"] == "SD+ATG" and m["spans_component_junction"] == "YES"),
            "under_vendor_min_125bp": "YES" if len(seq) < 125 else "no",
        })
    print(f"\n  per-construct scans complete ({time.time()-t0:.0f}s, ViennaRNA included)")
    return cross_checks(rows, checks, site_rows, motif_rows, comp_rows, working, prov_enz,
                        C, prov_of, sourced, cp, el, t2, counts)


def component_provenance(lab, prov_of, r):
    base = re.sub(r"\[.*|\#.*|\(MUT.*", "", lab)
    if base in prov_of:
        p = prov_of[base]
        if "(MUT" in lab:
            p += f" | DESIGNED point mutation applied: {lab[lab.index('(MUT'):]}"
        return p
    if lab.startswith("sensor:") or lab.startswith("acceptor:"):
        acc = base.split(":")[1]
        return f"{KIN_ACC[acc]}; DNA {P_CODON}"
    if lab.startswith("linker:"):
        return f"DESIGNED flexible linker {lab.split(':')[1]}; DNA {P_CODON}"
    if lab.startswith("stop:"):
        return f"TAA stop codon (53.3% of BX927147.1 stops); DNA {P_CODON}"
    return "UNRESOLVED"


def intended_core_window(r, cp, el, t2):
    """Two windows: the MAPPED extended -10 (the element the panel intends to be a
    promoter) and the whole sourced core amplicon it sits in. A hit inside the
    amplicon but outside the mapped -10 is reported separately -- it is inside a
    sourced natural promoter fragment, so it is expected, but it is not the element
    the design placed there."""
    if r["kind"] == "CDS":
        return None
    for lab, a, b in boundaries_of(r["parts"]):
        if lab.startswith("core:"):
            k = lab.split(":")[1]
            off = int(el[k]["minus35_start0"])
            e0, e1 = int(el[k]["ext10_start0"]) - off, int(el[k]["ext10_end0"]) - off
            return {"amplicon": (a, b), "ext10": (a + e0, a + e1), "core": k}
    return None


def intended_starts(r, t2):
    if r["kind"] == "CDS":
        return {0}
    for lab, a, b in boundaries_of(r["parts"]):
        if lab.startswith("forecistron:"):
            return {a}
    return set()


# ================================================== TASKS 4/5: cross-construct
def series_key(r):
    """The axis a construct is swept along, used to decide whether a near-duplicate
    pair is an INTENDED matched pair or an accident."""
    cid, s = r["construct_id"], r["src"]
    if r["kind"] == "CDS":
        return ("kinase", s["sensor_accession"], s["acceptor_accession"], s["strategy"])
    if cid.startswith("V2-SUB-"):
        return ("sub", s["core_promoter"], s["operator_identity"], s["background_or_filler"])
    if cid.startswith("V2-INS-"):
        return ("ins", s["core_promoter"], s["operator_identity"], s["background_or_filler"])
    if cid.startswith("V2-CX-"):
        return ("cx", s["core_promoter"], s["operator_gap_bp"])
    return ("other", cid)


def cross_checks(rows, checks, site_rows, motif_rows, comp_rows, working, prov_enz,
                 C, prov_of, sourced, cp, el, t2, counts):
    byid = {r["construct_id"]: r for r in rows}
    seqs = {r["construct_id"]: r["full_sequence"] for r in rows}
    ids = list(seqs)
    pair_rows = []

    print("\n" + "=" * 78); print("TASK 4/5  CROSS-CONSTRUCT CHECKS OVER ALL 93"); print("=" * 78)

    # identical sequences
    dup = defaultdict(list)
    for cid, s in seqs.items():
        dup[s].append(cid)
    identical = [v for v in dup.values() if len(v) > 1]
    print(f"  identical DNA sequences : {len(identical)}")

    # substring containment
    contained = []
    for a in ids:
        for b in ids:
            if a != b and len(seqs[a]) < len(seqs[b]) and seqs[a] in seqs[b]:
                contained.append((a, b))
    print(f"  construct that is a substring of another : {len(contained)}")

    # 20-mer prefilter -> exact longest shared substring on candidate pairs
    K = 20
    idx = defaultdict(set)
    for cid, s in seqs.items():
        for i in range(len(s) - K + 1):
            idx[s[i:i + K]].add(cid)
    cand = set()
    for v in idx.values():
        if len(v) > 1:
            v = sorted(v)
            for i in range(len(v)):
                for j in range(i + 1, len(v)):
                    cand.add((v[i], v[j]))
    print(f"  pairs sharing a {K}-nt exact substring   : {len(cand)} of {len(ids)*(len(ids)-1)//2}")

    for a, b in sorted(cand):
        ra, rb = byid[a], byid[b]
        lcs = max_shared_substring(seqs[a], seqs[b], lo=K)
        pid = ungapped_identity(seqs[a], seqs[b]) if abs(len(seqs[a]) - len(seqs[b])) <= 0.10 * max(len(seqs[a]), len(seqs[b])) else ""
        same_panel = ra["panel"] == rb["panel"]
        same_series = series_key(ra) == series_key(rb)
        reason = intended_reason(ra, rb, same_series)
        pair_rows.append({
            "construct_a": a, "construct_b": b, "panel_a": ra["panel"], "panel_b": rb["panel"],
            "cross_panel": "no" if same_panel else "YES",
            "longest_shared_exact_substring_bp": lcs,
            "ungapped_identity_pct": pid,
            "a_is_substring_of_b": "YES" if seqs[a] in seqs[b] else "no",
            "b_is_substring_of_a": "YES" if seqs[b] in seqs[a] else "no",
            "intended_matched_pair": "YES" if reason else "NO",
            "relationship": reason or "not a declared matched pair",
        })

    hi_id = [p for p in pair_rows if p["ungapped_identity_pct"] != "" and p["ungapped_identity_pct"] >= 95]
    unintended = [p for p in hi_id if p["intended_matched_pair"] == "NO"]
    print(f"  pairs at >=95% ungapped identity        : {len(hi_id)} "
          f"({len(unintended)} NOT an intended matched pair)")
    xp = sorted([p for p in pair_rows if p["cross_panel"] == "YES"],
                key=lambda x: -x["longest_shared_exact_substring_bp"])
    print(f"  CROSS-PANEL pairs sharing >={K} nt        : {len(xp)}   "
          f"longest shared exact substring = {xp[0]['longest_shared_exact_substring_bp'] if xp else 0} bp")

    # protein-level uniqueness (kinase only)
    prots = {r["construct_id"]: r["protein"] for r in rows if r["protein"]}
    pdup = defaultdict(list)
    for cid, p in prots.items():
        pdup[p].append(cid)
    pident = [v for v in pdup.values() if len(v) > 1]
    ppairs = []
    pl = list(prots)
    for i in range(len(pl)):
        for j in range(i + 1, len(pl)):
            a, b = pl[i], pl[j]
            pi = ungapped_identity(prots[a], prots[b])
            if pi >= 95:
                ppairs.append((a, b, pi, series_key(byid[a]) == series_key(byid[b])))
    print(f"  PROTEIN: identical sets {len(pident)} | >=95% identity pairs {len(ppairs)} "
          f"({sum(1 for x in ppairs if not x[3])} outside a register triplet)")
    for a, b, pi, same in ppairs:
        why = intended_reason(byid[a], byid[b], same)
        pair_rows.append({"construct_a": a, "construct_b": b, "panel_a": byid[a]["panel"],
                          "panel_b": byid[b]["panel"],
                          "cross_panel": "no" if byid[a]["panel"] == byid[b]["panel"] else "YES",
                          "longest_shared_exact_substring_bp": "", "ungapped_identity_pct": pi,
                          "a_is_substring_of_b": "YES" if prots[a] in prots[b] else "no",
                          "b_is_substring_of_a": "YES" if prots[b] in prots[a] else "no",
                          "intended_matched_pair": "YES" if why else "NO",
                          "relationship": "PROTEIN-level: " + (why or "not a declared matched pair")})
    return finish(rows, checks, site_rows, motif_rows, comp_rows, pair_rows, working, prov_enz,
                  identical, contained, C, prov_of, sourced, cp, el, t2, counts)


def intended_reason(ra, rb, same_series):
    a, b = ra["construct_id"], rb["construct_id"]
    if ra["kind"] == "CDS" and rb["kind"] == "CDS":
        if same_series:
            return "register triplet: same sensor/acceptor/strategy at -1/0/+1"
        sa, sb = ra["src"], rb["src"]
        if (sa["sensor_accession"], sa["acceptor_accession"]) == (sb["sensor_accession"], sb["acceptor_accession"]):
            return "same sensor+acceptor, different junction strategy (deliberate strategy comparison)"
        return ""
    if same_series:
        return "same designed series, swept variable only (phasing gap / fore-cistron identity)"
    # declared swap controls
    for x, y in ((ra, rb), (rb, ra)):
        so = x["src"].get("background_or_filler", "")
        if x["construct_id"].startswith("V2-CTL-") and "->" in str(so):
            return f"declared swap control ({so}) vs its gap-matched reference"
    # combinatorial construct = its own promoter fragment + a fore-cistron element,
    # declared in designs/combinatorial_design.csv (promoter_variant column)
    for x, y in ((ra, rb), (rb, ra)):
        if x["construct_id"].startswith("V2-CX-") and not y["construct_id"].startswith("V2-CX-"):
            base = x["construct_id"].split("_", 1)[1].split("__")[0]
            if y["construct_id"].split("_", 1)[1] == base:
                return ("declared parent/derivative: the combinatorial construct IS this promoter "
                        "fragment plus a fore-cistron element (combinatorial_design.csv promoter_variant)")
    # combinatorial HP-7 disabling mutants vs the HP-7 parent
    if "HP07" in a and "HP07" in b:
        return "HP-7 parent vs its declared disabling/attenuating mutant (NEG / PARTIAL)"
    return ""


# ================================================================ TASK 6: output
def finish(rows, checks, site_rows, motif_rows, comp_rows, pair_rows, working, prov_enz,
           identical, contained, C, prov_of, sourced, cp, el, t2, counts):
    byid = {r["construct_id"]: r for r in rows}
    chk = {c["construct_id"]: c for c in checks}

    # ---- synthesis-difficulty + flags, computed from the check rows
    for c in checks:
        r = byid[c["construct_id"]]
        seq = r["full_sequence"]
        f = []
        if c["GC_percent"] < 35 or c["GC_percent"] > 65:
            f.append(f"EXTREME_GC({c['GC_percent']}%)")
        for m in re.finditer(r"(A{9,}|C{9,}|G{9,}|T{9,})", seq):
            f.append(f"LONG_HOMOPOLYMER({m.group(0)[0]}x{len(m.group(0))})")
        if c["internal_repeat_20nt"]:
            f.append(f"INTERNAL_REPEAT_20nt(x{c['internal_repeat_20nt']})")
        if c["dG60_worst_local"] is not None and c["dG60_worst_local"] <= -20.6:
            f.append(f"STRONG_LOCAL_HAIRPIN(dG60={c['dG60_worst_local']})")
        if c["gtracts"] != "none":
            f.append(f"G_TRACT({c['gtracts'].count(';')+1})")
        if len(seq) < 125:
            f.append(f"UNDER_VENDOR_MIN({len(seq)}bp)")
        c["synthesis_difficulty"] = ";".join(f) or "none"

    unint = {}
    for p in pair_rows:
        if p["intended_matched_pair"] == "NO" and p["ungapped_identity_pct"] != "" and p["ungapped_identity_pct"] >= 95:
            unint.setdefault(p["construct_a"], []).append(p["construct_b"])
            unint.setdefault(p["construct_b"], []).append(p["construct_a"])

    manifest = []
    for r in rows:
        c = chk[r["construct_id"]]
        seq = r["full_sequence"]
        prov = []
        for lab, a, b in r["bnds"]:
            prov.append(f"{lab} (construct nt {a}-{b}) = {component_provenance(lab, prov_of, r)}")
        flags = []
        if c["gc_flag"]:
            flags.append(c["gc_flag"])
        if c["golden_gate_sites"] != "none":
            flags.append("BLOCKER_GOLDEN_GATE:" + c["golden_gate_sites"])
        if c["vector_site_NcoI_NdeI"] != "none":
            flags.append("CONDITIONAL_BLOCKER_pECXT99A_SITE:" + c["vector_site_NcoI_NdeI"])
        if c["restriction_sites"] != "none":
            flags.append("RESTRICTION:" + c["restriction_sites"])
        if c["sites_spanning_component_junction"] != "none":
            flags.append("SITE_AT_COMPONENT_JUNCTION:" + c["sites_spanning_component_junction"])
        if c["homopolymer_gt6"] != "none":
            flags.append("HOMOPOLYMER:" + c["homopolymer_gt6"])
        sg = [m for m in motif_rows if m["construct_id"] == r["construct_id"]
              and m["motif"] == "SigA_ext10" and m["class"].startswith("SPURIOUS")]
        if sg:
            flags.append("SPURIOUS_SIGA:" + ";".join(f"{m['start']}({m['score_frac_of_max']})"
                                                     + ("@JUNCTION" if m["spans_component_junction"] == "YES" else "")
                                                     for m in sg))
        sdm = [m for m in motif_rows if m["construct_id"] == r["construct_id"] and m["motif"] == "SD+ATG"]
        if sdm:
            flags.append("SPURIOUS_INIT:" + ";".join(m["detail"]
                                                     + ("@JUNCTION" if m["spans_component_junction"] == "YES" else "")
                                                     for m in sdm))
        if c["synthesis_difficulty"] != "none":
            flags.append("SYNTH:" + c["synthesis_difficulty"])
        if r["construct_id"] in unint:
            flags.append("UNINTENDED_NEAR_DUPLICATE(vs " + ",".join(sorted(set(unint[r["construct_id"]]))) + ")")
        # design-level flags from the source panel. Only the kinase panel carries flags this
        # pass does not recompute (register break, H-box, recentring); the non-kinase panel's
        # flags are recomputed above, so carrying them too would just duplicate them.
        df = r["src"].get("flags", "")
        if r["kind"] == "CDS" and df and df != "none":
            flags.append("DESIGN:" + df.replace(" | ", ";"))
        manifest.append({
            "construct_id": r["construct_id"], "panel": r["panel"], "tier": r["tier"],
            "component_provenance": " || ".join(prov),
            "full_sequence": seq, "length_bp": len(seq), "GC_percent": c["GC_percent"],
            "flags": ";".join(flags) or "none",
            "rank_or_rationale": r["rank_or_rationale"],
        })

    def dump(name, data, cols=None):
        p = OUTDIR / name
        with open(p, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols or list(data[0].keys()), extrasaction="ignore")
            w.writeheader(); w.writerows(data)
        print(f"  wrote designs/{name}  ({len(data)} rows)")

    print("\n" + "=" * 78); print("TASK 6  ORDER-READY OUTPUT"); print("=" * 78)
    N = output_names()
    dump(N["manifest"], manifest)
    dump(N["checks"], checks)
    dump(N["sites"], site_rows or [{"construct_id": "", "panel": "", "enzyme": "",
         "site": "", "start": "", "end": "", "strand": "", "component_s": "",
         "spans_component_junction": "", "in_provenance_list": "", "class": ""}])
    dump(N["motifs"], motif_rows)
    dump(N["pairs"], pair_rows)
    dump(N["components"], comp_rows)
    with open(OUTDIR / N["fasta"], "w") as fh:
        for m in manifest:
            fh.write(f">{m['construct_id']}\n")
            s = m["full_sequence"]
            for i in range(0, len(s), 60):
                fh.write(s[i:i + 60] + "\n")
    print(f"  wrote designs/{N['fasta']}  ({len(manifest)} records)")
    with open(OUTDIR / N["submit"], "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(["construct_id", "full_sequence"])
        for m in manifest:
            w.writerow([m["construct_id"], m["full_sequence"]])
    print(f"  wrote designs/{N['submit']}  ({len(manifest)} rows)")

    # ---------------------------------------------------------------- summary
    print("\n" + "=" * 78); print("SUMMARY"); print("=" * 78)
    print(f"  constructs: {len(manifest)}   total bp: {sum(m['length_bp'] for m in manifest)}")
    for k, v in sorted(Counter(m["panel"] for m in manifest).items()):
        print(f"    {k:34} {v}")
    gg = [s for s in site_rows if s["enzyme"] in GOLDEN_GATE]
    print(f"\n  GOLDEN GATE sites across all {len(manifest)}, both strands: {len(gg)}  -> "
          f"{'CLEAN' if not gg else 'NOT CLEAN'}")
    print(f"  restriction sites (35 enzymes, both strands): {len(site_rows)} on "
          f"{len({s['construct_id'] for s in site_rows})} constructs")
    for k, v in Counter(s["enzyme"] for s in site_rows).most_common():
        cls = Counter(s["class"] for s in site_rows if s["enzyme"] == k)
        print(f"    {k:8} {v:4}  {dict(cls)}")
    print(f"  sites SPANNING a component junction: "
          f"{sum(1 for s in site_rows if s['spans_component_junction']=='YES')}")
    sig = [m for m in motif_rows if m["motif"] == "SigA_ext10"]
    print(f"\n  SigA ext-10 windows >= {SIGA_THRESH} of max: {len(sig)} total")
    for k, v in Counter(m["class"] for m in sig).most_common():
        print(f"    {k:34} {v}")
    print(f"    junction-spanning (fwd, spurious): "
          f"{sum(1 for m in sig if m['strand']=='+' and m['spans_component_junction']=='YES' and m['class'].startswith('SPURIOUS'))}")
    sdm = [m for m in motif_rows if m["motif"] == "SD+ATG"]
    print(f"  spurious SD+ATG: {len(sdm)} total, "
          f"{sum(1 for m in sdm if m['spans_component_junction']=='YES')} junction-spanning")
    print(f"\n  identical DNA: {len(identical)} | substring containment: {len(contained)}")
    print(f"  homopolymer>6: {sum(1 for c in checks if c['homopolymer_gt6']!='none')}")
    print(f"  GC out of +/-{GC_TOL_PTS} pts of {HOST_GC}%: {sum(1 for c in checks if c['gc_flag'])}")
    print(f"  under 125 bp: {sum(1 for c in checks if c['under_vendor_min_125bp']=='YES')}")
    sd = Counter(re.sub(r'\(.*', '', f) for c in checks for f in c["synthesis_difficulty"].split(';')
                 if f and f != "none")
    print(f"  synthesis flags: {dict(sd)}")
    deep(rows, checks, motif_rows, comp_rows, C, sourced, cp, el)
    return manifest, checks, site_rows, motif_rows, comp_rows, pair_rows, working, prov_enz, identical, contained


# ============================================ junction verification / distributions
COMPONENT_CLASS = [
    (r"^core:.*minus35$", "sourced core promoter: mapped -35 hexamer"),
    (r"^core:.*ext10$", "sourced core promoter: mapped extended -10"),
    (r"^core:", "sourced core promoter: rest of amplicon (spacer + downstream)"),
    (r"^operator:scrambled", "designed scramble control"),
    (r"^operator:", "sourced operator (PRODORIC Sal_PhoP site)"),
    (r"^ctx:", "sourced retained upstream context"),
    (r"^forecistron:", "sourced fore-cistron (leaderless BCD)"),
    (r"^SD2", "sourced SD2 motif"),
    (r"^TAATG_frag", "sourced TAATG coupling frame (5' 2 nt)"),
    (r"^designed:FILL", "designed gap filler"),
    (r"^designed:TSP", "designed inter-operator spacer"),
    (r"^designed:(BG|UP)", "designed background / upstream flank"),
    (r"^sensor:", "sourced sensor CDS (codon-optimised DNA)"),
    (r"^acceptor:", "sourced acceptor CDS (codon-optimised DNA)"),
    (r"^linker:", "designed peptide linker"),
    (r"^stop:", "stop codon"),
]


def classify_component(lab):
    for pat, name in COMPONENT_CLASS:
        if re.match(pat, lab):
            return name
    return "unclassified"


def deep(rows, checks, motif_rows, comp_rows, C, sourced, cp, el):
    byid = {r["construct_id"]: r for r in rows}
    print("\n" + "=" * 78); print("JUNCTION-CREATED MOTIFS: verified against each parent component ALONE")
    print("=" * 78)
    jm = [m for m in motif_rows if m["spans_component_junction"] == "YES"]
    if not jm:
        print("  none found")
    for m in jm:
        r = byid[m["construct_id"]]
        seq = r["full_sequence"]
        target = seq[int(m["start"]):int(m["end"])] if m["strand"] == "+" else m["detail"]
        parents = []
        for lab, a, b in r["bnds"]:
            if lab in m["component_s"].split("|"):
                sub = seq[a:b]
                best = max((siga_score(sub[i:i+SIGA_W], EXT10_PWM) / SIGA_MAX
                            for i in range(len(sub) - SIGA_W + 1)), default=None)
                bestr = max((siga_score(revcomp(sub)[i:i+SIGA_W], EXT10_PWM) / SIGA_MAX
                             for i in range(len(sub) - SIGA_W + 1)), default=None)
                parents.append((lab, None if best is None else round(best, 3),
                                None if bestr is None else round(bestr, 3)))
        print(f"  {m['construct_id']}  {m['motif']} {m['strand']}strand @{m['start']} = "
              f"{m['score_frac_of_max']} of max   window {m['detail']}")
        for lab, f, rv in parents:
            print(f"      parent component {lab:34} best fwd {f}  best rev {rv}")
        exceeds = all((f is None or float(m["score_frac_of_max"]) > f) and
                      (rv is None or float(m["score_frac_of_max"]) > rv) for _l, f, rv in parents)
        print("      -> the 13-mer itself spans the join, so it is present in NEITHER parent as a "
              "contiguous window (junction-created by construction)")
        print(f"      -> severity: {'NEW -- exceeds every parent best' if exceeds else 'NOT new -- a parent component alone already reaches this score'}")

    print("\n" + "=" * 78); print("AT DISTRIBUTION BY COMPONENT CLASS (all 93, computed from components)")
    print("=" * 78)
    agg = defaultdict(lambda: [0, 0, 0])       # class -> [bp, gc_bases, n_occurrences]
    for c in comp_rows:
        r = byid[c["construct_id"]]
        seq = r["full_sequence"][int(c["start"]):int(c["end"])]
        cls = classify_component(c["component"])
        agg[cls][0] += len(seq); agg[cls][1] += seq.count("G") + seq.count("C"); agg[cls][2] += 1
    # split the core amplicon into its mapped elements
    sub = defaultdict(lambda: [0, 0, 0])
    for c in comp_rows:
        if not c["component"].startswith("core:"):
            continue
        r = byid[c["construct_id"]]
        k = c["component"].split(":")[1]
        off = int(el[k]["minus35_start0"])
        s0 = int(c["start"])
        seq = r["full_sequence"][s0:int(c["end"])]
        m35 = (int(el[k]["minus35_start0"]) - off, int(el[k]["minus35_end0"]) - off)
        e10 = (int(el[k]["ext10_start0"]) - off, int(el[k]["ext10_end0"]) - off)
        for nm, (a, b) in (("-35 hexamer", m35), ("extended -10", e10)):
            t = seq[a:b]
            sub[nm][0] += len(t); sub[nm][1] += t.count("G") + t.count("C"); sub[nm][2] += 1
        rest = seq[:m35[0]] + seq[m35[1]:e10[0]] + seq[e10[1]:]
        sub["core amplicon, non-element (spacer + downstream)"][0] += len(rest)
        sub["core amplicon, non-element (spacer + downstream)"][1] += rest.count("G") + rest.count("C")
        sub["core amplicon, non-element (spacer + downstream)"][2] += 1
    print(f"  {'component class':58} {'occur':>6} {'total bp':>9} {'GC%':>7}")
    for k, (bp, g, n) in sorted(agg.items(), key=lambda x: -x[1][0]):
        print(f"  {k:58} {n:6} {bp:9} {100*g/bp:7.1f}")
    print(f"\n  core promoter amplicon, broken into its MAPPED elements:")
    for k, (bp, g, n) in sub.items():
        print(f"  {k:58} {n:6} {bp:9} {100*g/bp:7.1f}")

    print("\n" + "=" * 78); print("LENGTH DISTRIBUTION"); print("=" * 78)
    L = sorted(c["length_bp"] for c in checks)
    print(f"  min {L[0]}  median {L[len(L)//2]}  max {L[-1]}  total {sum(L)} bp")
    bins = [(0, 125), (125, 200), (200, 400), (400, 1000), (1000, 10**9)]
    for lo, hi in bins:
        n = sum(1 for x in L if lo <= x < hi)
        print(f"  {lo:>5} - {hi if hi < 10**9 else '  inf':>5} bp : {n:3}")
    u = [c for c in checks if c["under_vendor_min_125bp"] == "YES"]
    print(f"\n  UNDER 125 bp: {len(u)} of {len(checks)}")
    for k, v in sorted(Counter(c["panel"] for c in u).items()):
        print(f"    {k:34} {v}")

    print("\n" + "=" * 78); print("PROVENANCE: every component, resolved or not"); print("=" * 78)
    seen = {}
    for c in comp_rows:
        base = re.sub(r"\[.*|\#.*|\(MUT.*", "", c["component"])
        seen.setdefault(base, {"n": 0, "prov": c["provenance"], "kind": c["sourced_or_designed"]})
        seen[base]["n"] += 1
    unresolved = [k for k, v in seen.items() if v["prov"] == "UNRESOLVED"]
    for k, v in sorted(seen.items()):
        tag = "UNRESOLVED" if v["prov"] == "UNRESOLVED" else v["kind"].upper()
        print(f"  {k:32} x{v['n']:<4} {tag:9} {v['prov'][:96]}")
    print(f"\n  components with an UNRESOLVED provenance entry: {len(unresolved)} {unresolved}")

    src = json.loads((CACHE / "translational_sources.json").read_text())
    gaps = []
    for e in src["approach_B_source"]["fore_cistrons"]:
        if not e.get("genome_exact_match") and f"forecistron:{e['id']}" in seen:
            gaps.append(f"fore-cistron {e['id']}: published sequence is NOT an exact genome match -- "
                        f"{e.get('genome_note', '')}")
    for k in ("Psyn", "PsodA", "Ptuf"):
        if f"core:{k}" in seen and el[k]["confidence"] != "HIGH":
            gaps.append(f"core {k}: promoter-element assignment confidence {el[k]['confidence']} "
                        f"(-35 at {el[k]['minus35_frac']} of max, ext-10 at {el[k]['ext10_frac']} of max)")
    if any(x.startswith("sensor:") or x.startswith("acceptor:") for x in seen):
        gaps.append("kinase panel: NO destination vector is declared anywhere in the repo "
                    "(grep for 'pECXT99A' returns only the promoter/translational panels)")
    gaps.append("Golden Gate 4-nt overhangs: NOT DEFINED anywhere in the repo "
                "(grep 'overhang|fusion site|sticky' over scripts/, designs/, results/, *.py, *.md -> 0 hits)")
    print("\n  DECLARED PROVENANCE GAPS / CAVEATS carried into the order:")
    for g in gaps:
        print(f"    - {g}")

    print("\n" + "=" * 78); print("CRO ENVELOPE (48-96)"); print("=" * 78)
    n = len(checks)
    print(f"  final count {n}: {'FITS' if 48 <= n <= 96 else 'DOES NOT FIT'} the 48-96 envelope "
          f"({96 - n} slots of headroom)" if 48 <= n <= 96 else
          f"  final count {n}: DOES NOT FIT (over by {n - 96})")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        OUTDIR = Path(sys.argv[1]); OUTDIR.mkdir(parents=True, exist_ok=True)
    main()
