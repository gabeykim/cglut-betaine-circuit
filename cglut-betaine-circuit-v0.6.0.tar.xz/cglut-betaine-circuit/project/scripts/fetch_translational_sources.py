"""Tier-2 (translational layer) source acquisition, with provenance.

Two candidate approaches were evaluated (see designs/REPORT_translational.md
Task 1). This script fetches and caches the primary records for both, and
-- critically -- VERIFIES the Approach-B sequences against the cached
C. glutamicum genome rather than trusting the published table.

Sources
  A. Ding, Yuan, Zhang, Chen, Zhou & Deng 2020, Nucleic Acids Res
     48:10602-10613, PMID 32976557, PMC7544201. cRBS / CLM-RDR.
     Also queries the GitHub repo named in the paper (YuDengLAB/CLM-RDR)
     to record whether a TRAINED MODEL actually ships -- the paper's claim
     that the model is usable is checked, not assumed.
  B. Liu, Sun, Gao, Ledesma-Amaro, Fang, Yang & Bai 2023, ACS Synth Biol
     12:2157-2167, doi 10.1021/acssynbio.3c00246, PMC10367133. Leaderless
     bicistronic design (BCD) fore-cistrons, conducted IN C. glutamicum.

Nothing here is transcribed from memory: Table 1's 12 fore-cistrons are
parsed out of the fetched HTML table, then each 62-mer is located in the
cached BX927147.1 genome. Every base of every element is therefore backed
by a genome record, and the only permitted discrepancy is the start-codon
unification the paper itself documents (Table 1 footnote "Red base
represents mutation"; body text: "the start codons of all of these 12
fore-cistron sequences were unified into AUG").
"""
import html
import json
import re
import ssl
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
LIT = DATA / "cache" / "literature"

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120 Safari/537.36")

SOURCES = {
    "pmc7544201_ding2020_clmrdr.html":
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC7544201/",
    "pmc10367133_liu2023_leaderless_bcd.html":
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC10367133/",
}


def _ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def fetch(url: str, dest: Path) -> str:
    if dest.exists():
        print(f"  cached: {dest.name}")
        return dest.read_text(encoding="utf-8", errors="replace")
    print(f"  fetching: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=90, context=_ctx()) as r:
        text = r.read().decode("utf-8", errors="replace")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")
    return text


def parse_table1(html_text: str):
    """Table 1 of Liu 2023: number | gene ID | gene name | sequence."""
    tables = re.findall(r"<table.*?</table>", html_text, re.S)
    for tbl in tables:
        rows = []
        for tr in re.findall(r"<tr.*?</tr>", tbl, re.S):
            cs = [html.unescape(re.sub(r"<[^>]+>", "", c)).strip()
                  for c in re.findall(r"<t[dh].*?</t[dh]>", tr, re.S)]
            if cs:
                rows.append(cs)
        if rows and rows[0][0].lower().startswith("number"):
            out = []
            for r in rows[1:]:
                if len(r) >= 4 and re.fullmatch(r"[acgtACGT]+", r[3]):
                    out.append({"id": r[0], "ncgl": r[1], "gene": r[2],
                                "seq": r[3].upper()})
            return out
    return []


def verify_against_genome(entries):
    """Locate each 62-mer in BX927147.1; report every base-level discrepancy."""
    from Bio import SeqIO
    g = str(next(SeqIO.parse(DATA / "cache" / "BX927147.fasta", "fasta")).seq).upper()
    grc = g.translate(str.maketrans("ACGT", "TGCA"))[::-1]
    for e in entries:
        s = e["seq"]
        exact = (s in g) or (s in grc)
        tail = s[3:]                      # allow the documented start-codon change
        loc, strand = g.find(tail), "+"
        if loc < 0:
            loc, strand = grc.find(tail), "-"
        e["genome_exact_match"] = exact
        if loc < 0:
            e["genome_verified"] = False
            e["genome_note"] = "NOT FOUND in BX927147.1 on either strand"
            continue
        native = (g if strand == "+" else grc)[loc - 3: loc + len(tail)]
        diffs = [{"pos0": i, "genome": native[i], "published": s[i]}
                 for i in range(len(s)) if native[i] != s[i]]
        e["genome_verified"] = True
        e["genome_strand"] = strand
        e["genome_native_start_codon"] = native[:3]
        e["diffs_vs_genome"] = diffs
        e["genome_note"] = (
            "exact 62/62 match to BX927147.1"
            if not diffs else
            f"{len(diffs)} base differs: native start {native[:3]} -> published "
            f"{s[:3]} (documented start-codon unification to AUG)")
    return entries


def probe_clmrdr_repo():
    """Record whether github.com/YuDengLAB/CLM-RDR ships a TRAINED model."""
    import urllib.error
    out = {"repo": "https://github.com/YuDengLAB/CLM-RDR"}
    try:
        req = urllib.request.Request(
            "https://api.github.com/repos/YuDengLAB/CLM-RDR/git/trees/master?recursive=1",
            headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=60, context=_ctx()) as r:
            tree = json.load(r)
        blobs = [f["path"] for f in tree.get("tree", []) if f["type"] == "blob"]
        wexts = (".h5", ".ckpt", ".pb", ".pth", ".pkl", ".index", ".meta", ".hdf5", ".weights")
        out["n_files"] = len(blobs)
        out["files"] = sorted(blobs)
        out["trained_weight_files"] = [b for b in blobs if b.lower().endswith(wexts)]
        out["ships_trained_model"] = bool(out["trained_weight_files"])
    except Exception as exc:                                    # pragma: no cover
        out["error"] = f"{type(exc).__name__}: {exc}"
        out["ships_trained_model"] = None
    return out


def main():
    LIT.mkdir(parents=True, exist_ok=True)
    print("Fetching primary sources (cache-backed; reruns are offline):")
    pages = {name: fetch(url, LIT / name) for name, url in SOURCES.items()}

    liu = pages["pmc10367133_liu2023_leaderless_bcd.html"]
    entries = parse_table1(liu)
    if len(entries) != 12:
        sys.exit(f"ERROR: expected 12 fore-cistrons in Table 1, parsed {len(entries)}")
    verify_against_genome(entries)

    payload = {
        "approach_B_source": {
            "citation": ("Liu X, Sun Y, Gao Y, Ledesma-Amaro R, Fang H, Yang Y, Bai Z. "
                         "Leaderless Bicistronic Design for Precise and Reliable Control of "
                         "Gene Expression in Corynebacterium glutamicum. ACS Synth Biol. "
                         "2023;12(7):2157-2167."),
            "doi": "10.1021/acssynbio.3c00246",
            "pmcid": "PMC10367133",
            "host_organism": "Corynebacterium glutamicum",
            "promoter_used": "PH36 (synthetic, leaderless; 5'RACE-confirmed in the paper)",
            "table": "Table 1, Sequence Information of 12 Fore-Cistrons",
            "fore_cistron_length_bp": 62,
            "sd_motif": "AAAGGAGGACAAC",
            "sd_motif_note": ("quoted verbatim from the body text: 'Each fore-cistron sequence "
                              "includes a conserved SD sequence (AAAGGAGGACAAC) with a strong "
                              "affinity for C. glutamicum 16S rRNA'"),
            "coupling_frame": "TAATG",
            "coupling_note": ("body text: 'The stop codon (TAA) in the terminus of the SD motif "
                              "overlaps 1 bp with the start codon (ATG) of the EGFP to form the "
                              "widely used translation coupling frame TAATG.'"),
            "measured_range_fluorescence": [313, 3813],
            "measured_range_fold_over_monocistronic": [1.27, 15.44],
            "measured_range_note": ("body text, for the 12 BCDs of PH36. PER-ELEMENT values are "
                                    "in Figure 1B (an image) and are NOT text-extractable."),
            "ranked_representatives": {
                "note": ("body text: 'the ranking of expression intensity for the three BCDs "
                         "remained consistent across all three proteins, with HP-7 showing the "
                         "highest expression intensity, followed by HP-12 and then HP-6.'"),
                "high": "HP-7", "intermediate": "HP-12", "low": "HP-6",
            },
            "disabling_mutations": {
                "fore_cistron_start_AUG_to_AUC": ("'the mutation of the fore-cistron start codon in "
                                                  "all constructed leaderless BCDs resulted in a "
                                                  "significant reduction in both EGFP fluorescence "
                                                  "and transcriptional level'"),
                "fore_cistron_start_AUG_to_GUG": ("'the degree of reduction ... from the AUG to GUG "
                                                  "mutation was lower compared to other start codon "
                                                  "mutations ... although 5'-AUG is highly preferred, "
                                                  "it is not strictly required'"),
                "SD_mutation": ("'both fore-cistron start codon mutation and SD mutation resulted in "
                                "reduced expression intensity (Figures 4, S2, and S3)' -- the exact "
                                "SD mutant sequence is in the SI figures, NOT in the body text"),
            },
            "library_caution": ("the 55,901-fore-cistron library is a DIVERSITY CENSUS of fully "
                                "random 62-mers ('The 62 bp fore-cistron sequence was fully designed "
                                "with random bases (indicated with N) except for the start codon "
                                "ATG'); paired sequence+measurement data is the 12 characterized "
                                "fore-cistrons plus 42 sorted clones (Table S4)."),
            "fore_cistrons": entries,
        },
        "approach_A_source": {
            "citation": ("Ding N, Yuan Z, Zhang X, Chen J, Zhou S, Deng Y. Programmable "
                         "cross-ribosome-binding sites to fine-tune the dynamic range of "
                         "transcription factor-based biosensor. Nucleic Acids Res. "
                         "2020;48(18):10602-10613."),
            "pmid": "32976557", "pmcid": "PMC7544201",
            "training_host": "Escherichia coli BL21(DE3)",
            "training_host_evidence": ("'Escherichia coli BL21 (DE3) cells containing the plasmid "
                                       "libraries were cultured...'; cloning in E. coli JM109. The "
                                       "strings 'Corynebacterium' and 'glutamicum' appear ZERO times "
                                       "in the full text."),
            "training_system": "glucarate biosensor: CdaR activator + sfGFP reporter",
            "model_output": "5-class classification of biosensor DYNAMIC RANGE (not translation rate)",
            "subrange_avg_dynamic_range_fold": {"I": 13, "II": 29, "III": 53, "IV": 106, "V": 247},
            "cRBS_scaffold": {"RBSn_cdaR": "TAACCATGCATA-SDn-GACTT", "SDn": "NNGGAGNN",
                              "RBSm_sfgfp": "TCTTAATCATG-SDm-GGTTTC", "SDm": "NNNGANNN"},
            "model_input": ("a single 50-nt string = RBSm(25) ++ RBSn(25) in the fixed E. coli "
                            "scaffold above; only the two 8-nt SD windows (16 nt total) vary"),
            "reported_accuracy_in_E_coli": {"glucarate": 0.722, "arabinose": 0.611, "glycolate": 0.50},
            "repo": probe_clmrdr_repo(),
            "runtime_requirements": "Tensorflow-gpu==1.9.0, Python==3.5 (both end-of-life)",
        },
    }
    out = DATA / "cache" / "translational_sources.json"
    out.write_text(json.dumps(payload, indent=1))
    print(f"\nWrote {out.relative_to(ROOT)}")
    print("\nGenome verification of Liu 2023 Table 1 (12 fore-cistrons vs BX927147.1):")
    for e in entries:
        print(f"  {e['id']:6} {e['gene']:10} {e['genome_note']}")
    rp = payload["approach_A_source"]["repo"]
    print(f"\nCLM-RDR repo: {rp.get('n_files')} files, "
          f"ships_trained_model={rp.get('ships_trained_model')}, "
          f"weights={rp.get('trained_weight_files')}")


if __name__ == "__main__":
    main()
