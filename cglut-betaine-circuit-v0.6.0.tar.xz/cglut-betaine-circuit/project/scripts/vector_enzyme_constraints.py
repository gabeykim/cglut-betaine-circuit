"""Which enzymes must be avoided when choosing / opening the destination vector.

Every enzyme with at least one site anywhere in the ordered set is listed with
what carries it, whether that carrier is sourced or designed, and whether it
could be removed at all. An enzyme on this list cannot be used to linearise the
destination vector without cutting inside a fragment.
"""
import csv, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seqchecks import CATALOGUE, GOLDEN_GATE, VECTOR_SITES, positive_control_check

D = ROOT / "designs"
OUT = D / "vector_enzyme_constraints.csv"

CARRIER = {
    "ScaI":  ("core:PsodA", "sourced", "PsodA amplicon (Henke 2021 / BX927147.1)"),
    "StuI":  ("core:PsodA", "sourced", "PsodA amplicon (Henke 2021 / BX927147.1)"),
    "EcoRV": ("core:Ptuf", "sourced", "Ptuf amplicon (Henke 2021 / BX927147.1)"),
    "XhoI":  ("forecistron:HP-12", "sourced", "fore-cistron HP-12 (Liu 2023 Table 1)"),
    "BamHI": ("forecistron:HP-6", "sourced", "fore-cistron HP-6 (Liu 2023 Table 1)"),
    "NsiI":  ("ctx:Psyn_N105_tail", "sourced", "Psyn N105 primer tail (Henke 2021 Table 2)"),
    "SphI":  ("ctx:Psyn_N105_tail", "sourced", "Psyn N105 primer tail (Henke 2021 Table 2)"),
    "NcoI":  ("henke_spacer:HA07rc+HN49", "sourced", "Henke MCS spacer, at the Psyn|spacer junction"),
    "EcoRI": ("henke_spacer:HA07rc+HN49", "sourced", "Henke MCS spacer"),
    "KpnI":  ("henke_spacer:HA07rc+HN49", "sourced", "Henke MCS spacer"),
    "SacI":  ("henke_spacer:HA07rc+HN49", "sourced", "Henke MCS spacer"),
    "SmaI":  ("henke_spacer:HA07rc+HN49", "sourced", "Henke MCS spacer"),
}


def main():
    if OUT.exists():
        sys.exit(f"REFUSING TO OVERWRITE {OUT}")
    positive_control_check()
    sites = list(csv.DictReader(open(D / "order_manifest_final_v4_sites.csv")))
    man = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v4.csv"))}
    by = defaultdict(list)
    for s in sites:
        by[s["enzyme"]].append(s)
    rows = []
    for e in sorted(CATALOGUE):
        hits = by.get(e, [])
        carrier, kind, note = CARRIER.get(e, ("--", "--", ""))
        rows.append({
            "enzyme": e, "recognition_site": CATALOGUE[e],
            "sites_in_panel_both_strands": len(hits),
            "constructs_affected": len({h["construct_id"] for h in hits}),
            "panels_affected": ";".join(sorted({man[h["construct_id"]]["panel"] for h in hits})) or "",
            "carrying_component": carrier if hits else "",
            "component_is": kind if hits else "",
            "provenance_of_carrier": note if hits else "",
            "removable_by_codon_choice": "n/a - not a coding sequence" if hits else "",
            "usable_to_open_the_destination_vector":
                "NO" if hits else ("YES" if e not in GOLDEN_GATE else "NO - reserved for assembly"),
            "reason": ("cuts inside " + str(len({h["construct_id"] for h in hits})) + " ordered fragment(s)")
                      if hits else ("reserved: this is the selected Golden Gate assembly route"
                                    if e in GOLDEN_GATE else "no site anywhere in the ordered set"),
        })
    with open(OUT, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    blocked = [r for r in rows if r["sites_in_panel_both_strands"]]
    gg = [r for r in rows if r["enzyme"] in GOLDEN_GATE]
    free = [r for r in rows if not r["sites_in_panel_both_strands"] and r["enzyme"] not in GOLDEN_GATE]
    print("=" * 78); print("VECTOR ENZYME CONSTRAINTS"); print("=" * 78)
    print(f"  enzymes with sites in the ordered set (CANNOT open the vector): {len(blocked)}")
    for r in blocked:
        print(f"    {r['enzyme']:7} {r['sites_in_panel_both_strands']:>3} sites / "
              f"{r['constructs_affected']:>2} constructs   {r['carrying_component']}")
    print(f"\n  reserved for Golden Gate assembly: {[r['enzyme'] for r in gg]}")
    print(f"  free to use for vector opening   : {len(free)} of {len(CATALOGUE)}")
    print(f"    {[r['enzyme'] for r in free]}")
    print(f"\n  wrote {OUT.relative_to(ROOT)} ({len(rows)} rows)")
    return rows


if __name__ == "__main__":
    main()
