"""Generate designs/REPORT_order_final.md.

EVERY table is computed here FROM THE WRITTEN DATA FILES. Nothing is transcribed
from console output -- a previous report had 4 of 8 rows wrong that way while the
underlying CSV was correct.
"""
import csv, json, re, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
D = ROOT / "designs"
OUT = D / "REPORT_order_final.md"
from consolidate_final import (CATALOGUE, GOLDEN_GATE, VECTOR_SITES, HOST_GC, SIGA_THRESH,
                               classify_component, revcomp, EXT10_PWM, siga_score, SIGA_MAX, SIGA_W)

if OUT.exists():
    sys.exit(f"REFUSING TO OVERWRITE {OUT}")

man = list(csv.DictReader(open(D / "order_manifest_final.csv")))
chk = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_checks.csv"))}
sites = list(csv.DictReader(open(D / "order_manifest_final_sites.csv")))
mot = list(csv.DictReader(open(D / "order_manifest_final_motifs.csv")))
comp = list(csv.DictReader(open(D / "order_manifest_final_components.csv")))
pairs = list(csv.DictReader(open(D / "order_manifest_final_pairs.csv")))
submit = list(csv.DictReader(open(D / "order_submit_final.csv")))
el = json.loads((ROOT / "data" / "cache" / "promoter_elements.json").read_text())
src = json.loads((ROOT / "data" / "cache" / "translational_sources.json").read_text())

seq_of = {r["construct_id"]: r["full_sequence"] for r in man}
panel_of = {r["construct_id"]: r["panel"] for r in man}
is_kin = {c: p.startswith("kinase") for c, p in panel_of.items()}
F = lambda x: float(x)
I = lambda x: int(x)
L = []
w = L.append


def _pl(n):
    return f"{n} construct" + ("" if n == 1 else "s")


def esc(x):
    return str(x).replace("|", "\\|")


def table(headers, rows, align=None):
    w("| " + " | ".join(esc(h) for h in headers) + " |")
    w("|" + "|".join(align[i] if align else "---" for i in range(len(headers))) + "|")
    for r in rows:
        w("| " + " | ".join(esc(x) for x in r) + " |")
    w("")


# ---------------------------------------------------------------- derived facts
n_total = len(man)
gg_hits = [s for s in sites if s["enzyme"] in GOLDEN_GATE]
ncoi = sorted({s["construct_id"] for s in sites if s["enzyme"] == "NcoI"})
ndei = sorted({s["construct_id"] for s in sites if s["enzyme"] == "NdeI"})
junc_sites = [s for s in sites if s["spans_component_junction"] == "YES"]
sig = [m for m in mot if m["motif"] == "SigA_ext10"]
sd = [m for m in mot if m["motif"] == "SD+ATG"]
sig_junc = [m for m in sig if m["spans_component_junction"] == "YES"]
anti = [m for m in sig if m["class"].startswith("ANTISENSE")]
sd_junc = [m for m in sd if m["spans_component_junction"] == "YES"]
contain = [p for p in pairs if p["a_is_substring_of_b"] == "YES" or p["b_is_substring_of_a"] == "YES"]
hi = [p for p in pairs if p["ungapped_identity_pct"] not in ("",) and F(p["ungapped_identity_pct"]) >= 95]
hi_unint = [p for p in hi if p["intended_matched_pair"] == "NO"]
xp = sorted([p for p in pairs if p["cross_panel"] == "YES" and p["longest_shared_exact_substring_bp"] != ""],
            key=lambda p: -I(p["longest_shared_exact_substring_bp"]))
under125 = [c for c in chk.values() if c["under_vendor_min_125bp"] == "YES"]
gcout = [c for c in chk.values() if c["gc_flag"]]
homo = [c for c in chk.values() if c["homopolymer_gt6"] != "none"]

w("# Final order manifest: all 93 constructs, checked as one combined set")
w("")
w("Built by `scripts/consolidate_final.py`; this report generated from the written data files by "
  "`scripts/report_order_final.py`. No existing path was overwritten and no builder was re-run: "
  "the two source panels (`designs/order_manifest_v2.csv`, `designs/junctions_v2.csv` + `.fasta`) "
  "were read as-is and every sequence in the output is byte-identical to its source.")
w("")
w("Tags: **[EVIDENCE]** computed here or stated by a citable source. **[INFERENCE]** reasoning from "
  "evidence, step named. **[NOT FOUND]** searched and absent.")
w("")
w("**No construct here is claimed to work.** Nothing below is a prediction of expression, of "
  "signalling, or of assembly success.")
w("")
w("---")
w("")

# ================================================================= LEAD
w("## 0. LEAD — what the combined set found that the per-panel checks did not")
w("")
w(f"**No check that a per-panel pass actually ran, fails at the combined level.** Golden Gate is "
  f"clean across all {n_total} constructs on both strands ({len(gg_hits)} BsaI/BsmBI/BbsI/SapI/AarI "
  f"sites found), there are no identical sequences, no homopolymer run longer than 6, and no "
  f"junction-created SigA or SD element on the sense strand. Saying that explicitly rather than "
  f"leaving it implied by absence: **the four historical boundary defects have not recurred, and no "
  f"new one of that exact class was found.** [EVIDENCE, computed over all {n_total}]")
w("")
w("**Four things are true only at the combined level, and were invisible to every per-panel check.** "
  "Ranked by consequence:")
w("")
w(f"**1 — {len(ncoi)} of 24 kinase constructs carry an internal NcoI site, and NcoI is the other "
  f"panels' vector's own opening enzyme. This is the HP-4 defect, one panel over.** [EVIDENCE] The "
  f"kinase panel's own check screened exactly five enzymes (the Golden Gate set) — "
  f"`scripts/junction_design.py` defines `GOLDEN_GATE` and nothing else — so no per-panel pass ever "
  f"looked for NcoI in a kinase construct. Scanning the same 35-enzyme catalogue the promoter panels "
  f"use finds NcoI in every PhoQ-acceptor construct. It is **not** a Golden Gate blocker, and it is "
  f"**not** yet a confirmed blocker at all, because "
  f"**the kinase panel declares no destination vector anywhere in the repo** [NOT FOUND: `pECXT99A` "
  f"appears only in the promoter and translational panel files]. If the kinase constructs go into "
  f"pECXT99A — the vector the other 69 use, opened with NcoI/NdeI — those {len(ncoi)} are blocked. "
  f"The site sits in codon-optimised synthetic DNA, not in borrowed sequence, so it is removable by "
  f"re-synonymising one codon pair.")
w("")
w(f"**2 — {len([s for s in sites if is_kin[s['construct_id']]])} restriction sites across "
  f"{len({s['enzyme'] for s in sites if is_kin[s['construct_id']]})} enzymes sit in the kinase "
  f"constructs and had never been looked for.** [EVIDENCE] Same root cause as (1): the kinase panel "
  f"screened 5 of 35 enzymes. None of them interferes with Golden Gate.")
w("")
mx = xp[0] if xp else None
w(f"**3 — Constructs in different kinase sub-panels share up to "
  f"{mx['longest_shared_exact_substring_bp'] if mx else 0} bp of exact DNA.** [EVIDENCE] "
  f"`{mx['construct_a']}` and `{mx['construct_b']}` share a "
  f"{mx['longest_shared_exact_substring_bp']} bp identical run — the shared sensor, codon-optimised "
  f"deterministically to the same string in both. Cross-panel sequence sharing was never a per-panel "
  f"question. It does not cause Golden Gate misassembly (joins are set by overhangs), but it does "
  f"mean a sequencing read landing inside that run cannot be assigned to a construct.")
w("")
w(f"**4 — The Golden Gate overhangs do not exist yet.** [NOT FOUND] Golden Gate is named as the "
  f"selected route in every panel, but a search of `scripts/`, `designs/`, `results/`, `*.py` and "
  f"`*.md` for `overhang`, `fusion site` or `sticky` returns zero hits. This is a remaining design "
  f"step, not a check failure — but it is the step that decides whether (3) matters.")
w("")
w(f"Two further things changed only because this pass ran checks nobody had run before — a different "
  f"claim from 'a check failed', and labelled as such throughout. The **reverse strand** was scanned "
  f"for SigA elements for the first time (§3.2): it found {len(anti)} windows, all in kinase "
  f"constructs, and **one of them does span the sensor/acceptor junction** at "
  f"{[m['score_frac_of_max'] for m in anti if m['spans_component_junction']=='YES'][0]} of matrix max "
  f"— the follow-up parent-alone test in §3.2 shows it does not exceed what its own sensor component "
  f"already carried, so it is a note rather than a fifth boundary defect. And the kinase constructs "
  f"were put through the **synthesis-difficulty and folding** screen for the first time (§4.4–4.5): "
  f"all 24 carry a strong local hairpin, which is a cost signal, not a defect.")
w("")
w("---")
w("")

# ================================================================= TASK 1
w("## 1. Task 1 — consolidation and count")
w("")
w("Counted, not assumed: every number below is a row count or a FASTA record count taken at read time.")
w("")
rows = []
for p, n in sorted(Counter(r["panel"] for r in man).items()):
    ls = [len(seq_of[r["construct_id"]]) for r in man if r["panel"] == p]
    rows.append([f"`{p}`", n, f"{min(ls)}–{max(ls)}", sum(ls)])
rows.append(["**TOTAL**", f"**{n_total}**", f"**{min(len(s) for s in seq_of.values())}–"
             f"{max(len(s) for s in seq_of.values())}**", f"**{sum(len(s) for s in seq_of.values())}**"])
table(["panel", "constructs", "length range (bp)", "total bp"], rows)
w(f"**{n_total} constructs.** Reconciliation against the expected 93: "
  f"{sum(1 for r in man if not is_kin[r['construct_id']])} non-kinase (all 69 rows of "
  f"`order_manifest_v2.csv`, which equals the 69 records of `order_submit_v2.fasta`) + "
  f"{sum(1 for r in man if is_kin[r['construct_id']])} kinase (all 24 rows of `junctions_v2.csv`, "
  f"which equals the 24 records of `junctions_v2.fasta`, ids matching set-for-set) = "
  f"**{n_total}. MATCH.** [EVIDENCE]")
w("")
w("**The fore-cistron / translational panel is not a separate order line, and that is why the "
  "expected total is 93 rather than 104.** [EVIDENCE] `designs/translational_variants.csv` holds 12 "
  "rows but `designs/translational_variants.fasta` holds 11 records: the 12th, `T2_MCD_ctrl`, has an "
  "empty sequence because the monocistronic control *is* the promoter fragment with nothing appended. "
  "The other 11 are 77 bp elements, not constructs — each needs a promoter in front of it, and each "
  "appears inside the 19 combinatorial constructs as a component. The panel is therefore fully "
  "represented in the order, as components with their own provenance line, and is not double-counted.")
w("")
w("**Retained-context variants** are broken out as their own panel here "
  f"({sum(1 for r in man if r['panel']=='retained_context')} constructs) because the task names them "
  "as a panel; in `order_manifest_v2.csv` they sat inside `tier-1 non-phasing (rebuilt)`. No "
  "construct moved, only its label.")
w("")
w("### The component map is verified, not asserted")
w("")
w(f"Every one of the {n_total} constructs was decomposed into named components "
  f"(`designs/order_manifest_final_components.csv`, {len(comp)} rows) and **the concatenation of the "
  f"parts was asserted equal to the stored `full_sequence`, base for base, for all {n_total}.** "
  f"[EVIDENCE] For the kinase constructs the DNA was additionally back-translated and checked "
  f"against `protein_seq`, and the sensor prefix and acceptor suffix checked against the source "
  f"FASTA files. Without that, every 'spans a junction' claim below would be guesswork.")
w("")
w("### construct_id is parseable, including the kinase multi-word strategies")
w("")
w("`JXN_<sensor>_<acceptor>_<strategy>_<offset>` — the strategy field may itself contain `_` "
  "(`linker_retained`, `dhp_direct`), so the rule is: field 0 is `JXN`, fields 1–2 are sensor and "
  "acceptor, the **last** field is the register offset (`m1`/`0`/`p1`), and everything between is the "
  "strategy. That parse was run against all 24 and checked against the `strategy` and "
  "`register_offset` columns of `junctions_v2.csv`; all 24 agree. [EVIDENCE] Non-kinase ids match "
  "`^V2-(SUB|INS|CTL|OTH|CX)-\\d{2}_` and are unique. No id collides across the 93.")
w("")
w("---")
w("")

# ================================================================= TASK 2
w("## 2. Task 2 — enzyme check, enumerated from provenance")
w("")
w("The list is read off the **sourced components**, not off the assembly plan. That is the failure "
  "mode that produced the HP-4 NcoI collision, the NsiI/SphI collision, and the ScaI/StuI/EcoRV/XhoI "
  "misses: enzymes arrive *with* borrowed sequence, so the only safe list is the one the sequences "
  "themselves dictate. Every sourced component actually used in the 93 was scanned against the "
  "**35-enzyme catalogue** on both strands.")
w("")
prov_rows, kin_rows = [], []
seen_comp = {}
for c in comp:
    base = re.sub(r"\[.*|\#.*|\(MUT.*", "", c["component"])
    seen_comp.setdefault(base, (c["sourced_or_designed"], c["provenance"]))
for base, (kind, prov) in sorted(seen_comp.items()):
    hits = sorted({s["enzyme"] for s in sites
                   if base in re.sub(r"\[[^\]]*\]|\#\d|\(MUT[^)]*\)", "", s["component_s"]).split("|")
                   and s["spans_component_junction"] == "no"})
    if not hits or kind != "sourced":
        continue
    if base.startswith(("sensor:", "acceptor:")):
        kin_rows.append([f"`{base}`", ", ".join(f"`{h}`" for h in hits), prov.split(";")[0][:64]])
    else:
        prov_rows.append([f"`{base}`", ", ".join(f"**{h}**" for h in hits), prov.split(";")[0][:78]])

w("**Sourced DNA — sequence physically borrowed into the construct. Any enzyme site here arrived "
  "*with* the borrowed bases and cannot be removed without changing sourced sequence.**")
w("")
table(["sourced DNA component", "enzymes it brings", "provenance"], prov_rows)
borrowed = sorted({h.strip("*` ") for r in prov_rows for h in r[1].replace("**", "").split(", ")})
w(f"**Enzymes arriving with borrowed sequence: {', '.join('`'+e+'`' for e in borrowed)} "
  f"({len(borrowed)}).** [EVIDENCE, computed] Four of them — `ScaI`, `StuI`, `EcoRV`, `XhoI` — are "
  f"the ones a 15-enzyme list derived from the assembly plan missed, and all four are still here, "
  f"still inside sourced sequence, still invisible to any plan-derived list.")
w("")
w("**Sourced protein, synthetic DNA — the kinase constructs. These are the trap this table exists "
  "to avoid falling into.** Their sourced components are *proteins*; the DNA was written by the codon "
  "optimiser against the BX927147.1 CDS table. Sites in them are therefore **not borrowed** — they "
  "are artefacts of an optimiser that screened for exactly five enzymes "
  "(`scripts/junction_design.py` `_bad_spans` checks `GOLDEN_GATE` and homopolymers, nothing else). "
  "[INFERENCE, reasoning named] They are listed separately because that distinction decides whether "
  "a site can be removed: these can, by re-synonymising, without changing one amino acid.")
w("")
table(["protein-sourced segment", "enzymes in its synthetic DNA", "protein accession"], kin_rows)
working_n = len(set(borrowed) | set(VECTOR_SITES) | set(GOLDEN_GATE))
w(f"**Working list: {working_n} enzymes** = {len(borrowed)} arriving with borrowed sequence "
  f"∪ the pECXT99A opening sites (`NcoI`, `NdeI`) ∪ the Golden Gate set. But **all {n_total} "
  f"constructs were scanned against the full 35-enzyme catalogue on both strands regardless**, so "
  f"nothing below depends on that working list being complete — which is the point, since a "
  f"provenance-derived list is only as good as the provenance you thought to read.")
w("")
w("### 2.1 Golden Gate — the explicit confirmation")
w("")
w(f"**Zero BsaI, BsmBI, BbsI, SapI or AarI sites across all {n_total} constructs, on BOTH strands.** "
  f"[EVIDENCE, computed] The finder was positive-control tested before this null was trusted: it is "
  f"shown to find a BsaI site formed only across a component join, a non-palindromic site present "
  f"only on the minus strand, and to report a palindromic site on both strands, and *not* to call a "
  f"site wholly inside one component a junction-spanning one. Those assertions run at the top of "
  f"every execution of `scripts/consolidate_final.py`.")
w("")
w("### 2.2 Every site found, by enzyme")
w("")
rows = []
for e, n in Counter(s["enzyme"] for s in sites).most_common():
    es = [s for s in sites if s["enzyme"] == e]
    k = sum(1 for s in es if is_kin[s["construct_id"]])
    cs = sorted({s["construct_id"] for s in es})
    cls = "BLOCKER" if e in GOLDEN_GATE else ("CONDITIONAL" if e in VECTOR_SITES else "note")
    rows.append([f"`{e}`", CATALOGUE[e], n, len(cs), f"{len(cs)-len({s['construct_id'] for s in es if is_kin[s['construct_id']]})} / "
                 f"{len({s['construct_id'] for s in es if is_kin[s['construct_id']]})}", cls])
table(["enzyme", "site", "hits (both strands)", "constructs", "non-kinase / kinase", "class"], rows)
w(f"Palindromic sites are counted once per strand, so a single physical site contributes 2 hits. "
  f"Full detail — construct, position, strand, and the component the site sits in — is one row per "
  f"site in **`designs/order_manifest_final_sites.csv`** ({len(sites)} rows). "
  f"[EVIDENCE]")
w("")
w(f"**Not one of the {len(sites)} sites spans a component junction.** [EVIDENCE] Every site lies "
  f"wholly inside a single component; none was created by two components meeting. The junction-"
  f"straddling positive control passes, so this null is a real null.")
w("")
w("### 2.3 Blockers versus notes")
w("")
w("| class | count | which | why |")
w("|---|---|---|---|")
w(f"| **BLOCKER** — interferes with Golden Gate, the selected route | **0** | — | no Type IIS site of "
  f"the five exists in any of the {n_total} |")
w(f"| **CONDITIONAL BLOCKER** — interferes with the *other* route this repo declares | "
  f"**{len(ncoi)} constructs** | `NcoI` in {len(ncoi)} kinase constructs, every one PhoQ-acceptor; "
  f"`NdeI`: {'none found' if not ndei else str(len(ndei))+' constructs'} | pECXT99A is opened with "
  f"NcoI/NdeI and supplies the target ATG at that NcoI site. Blocked **only if** the kinase panel "
  f"uses that vector, which is nowhere stated |")
w(f"| **NOTE** | {len([s for s in sites if s['enzyme'] not in GOLDEN_GATE and s['enzyme'] not in VECTOR_SITES])} sites | "
  f"{', '.join('`'+e+'`' for e in sorted({s['enzyme'] for s in sites if s['enzyme'] not in GOLDEN_GATE and s['enzyme'] not in VECTOR_SITES}))} | "
  f"none is used by the selected assembly route or by the declared vector opening. They matter only "
  f"for downstream sub-cloning and diagnostic digests, and are recorded so a later route change is a "
  f"lookup rather than a rediscovery |")
w("")
w(f"The `NcoI`-carrying constructs, from the data: {', '.join('`'+c+'`' for c in ncoi)}. "
  f"[EVIDENCE] The six ENVZ-acceptor constructs are clean of it.")
w("")
w("#### The NcoI sites are one codon pair, and one synonymous change removes all of them")
w("")
import json as _json
from consolidate_final import translate as _tr
_kin = {r["design_id"]: r for r in csv.DictReader(open(D / "junctions_v2.csv"))}
_syn = {aa: {c: v["rel_freq"] for c, v in t.items()}
        for aa, t in _json.loads((ROOT / "data" / "cache" / "codon" / "cglut_codon_usage.json").read_text())["table"].items()}
_res = []
for _did in ncoi:
    _dna, _r = seq_of[_did], _kin[_did]
    _p = _r["protein_seq"]
    for _m in re.finditer("CCATGG", _dna):
        _s0 = _m.start(); _c0, _c1 = _s0 // 3, (_s0 + 5) // 3
        _ctx = [(i + 1, _dna[i*3:i*3+3], _p[i]) for i in range(_c0, _c1 + 1)]
        _fix = None
        for _i, _cod, _aa in _ctx:
            for _alt, _f in sorted(_syn[_aa].items(), key=lambda x: -x[1]):
                if _alt != _cod and "CCATGG" not in _dna[:(_i-1)*3] + _alt + _dna[_i*3:] \
                        and _tr((_dna[:(_i-1)*3] + _alt + _dna[_i*3:])[:-3]) == _p:
                    _fix = (_aa, _cod, _alt, round(_f, 3)); break
            if _fix:
                break
        _nat = int(_r["acceptor_first_residue"]) + (_ctx[1][0] - int(_r["junction_protein_pos"]) - 1)
        _res.append((_did, _s0, "".join(x[2] for x in _ctx), _ctx[1][0], _nat, _fix))
w(f"Every one of the {len(_res)} sites is the **same residue pair**: "
  f"`{_res[0][2]}` — PhoQ Ser{_res[0][4]-1}–Met{_res[0][4]} in `P0DM80` numbering, which the "
  f"deterministic optimiser encodes identically in every construct that contains it "
  f"(`{'/'.join(sorted({x[5][1] for x in _res}))} ATG GAC`). [EVIDENCE, computed] "
  f"The `ATG` is a real methionine and cannot move; the serine codon can.")
w("")
table(["construct", "NcoI at (nt)", "construct residue", "native P0DM80 residue", "one-codon synonymous fix",
       "C. glutamicum relative usage of the replacement"],
      [[f"`{d}`", s0, f"Met{cp}", f"Met{nat}", f"`{fx[1]}`→`{fx[2]}` (Ser)", fx[3]] for d, s0, aa, cp, nat, fx in _res])
w(f"**All {len(_res)} are removable by a single synonymous substitution, verified by back-translation: "
  f"`TCC`→`TCT` at the serine immediately 5′ of Met{_res[0][4]}, protein unchanged.** [EVIDENCE, "
  f"computed] `TCT` sits at {_res[0][5][3]} relative usage in the BX927147.1 codon table, above the "
  f"optimiser's own 0.10 floor, so the fix needs no rare codon and no relaxation of the optimiser's "
  f"constraints — only `NcoI` and `NdeI` added to its forbidden set.")
w("")
w("---")
w("")

# ================================================================= TASK 3
w("## 3. Task 3 — whole-construct scans, with junction attribution")
w("")
w("Every scan below ran on the **complete construct**, never on a component. Each hit is then "
  "attributed to the component(s) it overlaps, so a hit created where two components meet is "
  "separated from a hit that lives inside one of them. This is the class of defect the whole task "
  "exists to find.")
w("")
w("**Standing caveat on the SigA matrix, carried into every number in this section.** It is a "
  "reasoned approximation built from the *textual* IUPAC consensus of Patek & Nesvera 2011 and "
  "Pfeifer-Sancar et al. 2013, not a PWM trained on aligned, confirmed C. glutamicum promoters. "
  "Scores are reported as a fraction of the matrix maximum. A clean scan means *no consensus-like "
  "cryptic promoter*, not *no cryptic promoter*. [EVIDENCE: `scripts/siga_consensus.py` module "
  "docstring]")
w("")
w("### 3.1 SigA-like extended −10 elements")
w("")
rows = []
for cl, n in Counter(m["class"] for m in sig).most_common():
    ms = [m for m in sig if m["class"] == cl]
    fr = [F(m["score_frac_of_max"]) for m in ms]
    rows.append([f"`{cl}`", n, len({m["construct_id"] for m in ms}),
                 f"{min(fr):.3f}–{max(fr):.3f}",
                 ", ".join(sorted({("kinase" if is_kin[m["construct_id"]] else "non-kinase") for m in ms}))])
table(["class", "windows", "constructs", "score range (fraction of max)", "which set"], rows)
w(f"Threshold {SIGA_THRESH} of matrix max, window width {SIGA_W} nt. "
  f"`INTENDED_CORE_MINUS10` = the hit the design put there, checked against the **mapped** extended "
  f"−10 coordinates in `data/cache/promoter_elements.json` rather than against the whole amplicon. "
  f"Full detail in **`designs/order_manifest_final_motifs.csv`**.")
w("")
sg_sp = [m for m in sig if m["class"].startswith("SPURIOUS")]
w(f"**Sense strand: zero spurious SigA elements in any of the 69 non-kinase constructs** — the "
  f"construct-aware background redesign holds up in the combined set. [EVIDENCE] "
  f"The {len([m for m in sg_sp if is_kin[m['construct_id']]])} sense-strand spurious hits are all in "
  f"the 24 kinase constructs, all **inside a single component** (codon-optimised CDS), none at a "
  f"junction. The kinase panel already counted these — `junctions_v2.csv` carries a "
  f"`spurious_sigA_ext10_total` column — and flagged only the junction ones, so this is a "
  f"confirmation of the per-panel result, not a new finding.")
w("")
w("**A cryptic sense-strand promoter inside a coding sequence is a different risk from one in a "
  "promoter fragment** [INFERENCE, reasoning named]: it would initiate a truncated transcript of the "
  "same gene, not drive an unintended gene, and the kinase constructs are CDSs whose own promoter is "
  "supplied by whatever vector they land in. It is recorded as a note, not a blocker.")
w("")
w("### 3.2 Reverse strand — a scan no previous pass ran")
w("")
w(f"The repo's convention has been to scan the sense strand only, which is right for the question "
  f"'does a cryptic promoter drive the reporter'. It misses antisense promoters. Scanning the reverse "
  f"strand of all {n_total} for the first time finds **{len(anti)} windows at or above "
  f"{SIGA_THRESH} of max, all in kinase constructs**, of which "
  f"{len([m for m in anti if m['spans_component_junction']=='YES'])} spans the sensor/acceptor "
  f"junction. [EVIDENCE]")
w("")
rows = [[f"`{m['construct_id']}`", m["start"], m["strand"], m["score_frac_of_max"], f"`{m['detail']}`",
         m["spans_component_junction"], f"`{m['component_s']}`"] for m in anti]
table(["construct", "start", "strand", "fraction of max", "window", "spans junction", "component(s)"], rows)
w("")
# parent-alone verification, recomputed here from the component table
bnd_by = defaultdict(list)
for c in comp:
    bnd_by[c["construct_id"]].append((c["component"], I(c["start"]), I(c["end"])))
for m in [x for x in sig if x["spans_component_junction"] == "YES"]:
    s = seq_of[m["construct_id"]]
    par = []
    for lab, a, b in bnd_by[m["construct_id"]]:
        if lab in m["component_s"].split("|"):
            sub = s[a:b]
            bf = max((siga_score(sub[i:i+SIGA_W], EXT10_PWM)/SIGA_MAX for i in range(len(sub)-SIGA_W+1)), default=0)
            br = max((siga_score(revcomp(sub)[i:i+SIGA_W], EXT10_PWM)/SIGA_MAX for i in range(len(sub)-SIGA_W+1)), default=0)
            par.append((lab, round(bf, 3), round(br, 3)))
    w(f"**Parent-alone check for the one junction-spanning window** (`{m['construct_id']}`, "
      f"reverse strand @{m['start']}, {m['score_frac_of_max']} of max, window `{m['detail']}`):")
    w("")
    table(["parent component", "best sense score in that component alone", "best antisense score alone"],
          [[f"`{l}`", f, r] for l, f, r in par])
    exceeds = all(F(m["score_frac_of_max"]) > f and F(m["score_frac_of_max"]) > r for _l, f, r in par)
    w(f"**Verdict: junction-created by construction — the 13-mer straddles the join, so it exists in "
      f"neither parent as a contiguous window — but NOT a new severity level.** [EVIDENCE] "
      f"{'It exceeds every parent best.' if exceeds else 'The `' + par[0][0] + '` component *alone* already reaches ' + str(max(p[1] for p in par)) + ' of max on its own sense strand, so this construct was already carrying an element of exactly this strength inside a single component. The junction did not raise the ceiling.'} "
      f"Recorded as a note. This is the check that the four historical defects would have tripped, and "
      f"it is doing its job: it fired, and the follow-up test told us the hit is not the dangerous kind.")
    w("")

w("### 3.3 SD-like motifs and unintended start codons")
w("")
w(f"Scan: `GGAGG`/`AGGAG`/`GGAG` followed by an `ATG` 3–14 nt downstream, excluding each design's own "
  f"intended start (the fore-cistron AUG in a BCD construct, the initiator in a CDS). "
  f"**{len(sd)} hits across all {n_total}, {len(sd_junc)} of them spanning a component junction.** "
  f"[EVIDENCE]")
w("")
table(["construct", "detail", "spans junction", "component", "class"],
      [[f"`{m['construct_id']}`", m["detail"], m["spans_component_junction"],
        f"`{m['component_s']}`", m["class"]] for m in sd])
w(f"**Zero in the 69 non-kinase constructs; all {len(sd)} sit inside the codon-optimised "
  f"`P0DM80` acceptor segment of a kinase construct, none at a junction.** [EVIDENCE] Each is an "
  f"internal-initiation risk that would yield an N-terminally truncated kinase — a note, and "
  f"removable by re-synonymising, since the DNA is synthetic. The same six show in the kinase panel's "
  f"own `spurious_SD_ATG_total` column, so this too confirms rather than contradicts the per-panel "
  f"result.")
w("")
w("### 3.4 Junction-spanning summary — the answer to the question this task was built around")
w("")
table(["scan", "hits total", "hits inside one component", "hits SPANNING a component junction"],
      [["restriction sites (35 enzymes, both strands)", len(sites), len(sites) - len(junc_sites), len(junc_sites)],
       ["SigA extended −10, sense", len([m for m in sig if m["strand"] == "+"]),
        len([m for m in sig if m["strand"] == "+" and m["spans_component_junction"] == "no"]),
        len([m for m in sig if m["strand"] == "+" and m["spans_component_junction"] == "YES"])],
       ["SigA extended −10, antisense", len(anti),
        len([m for m in anti if m["spans_component_junction"] == "no"]),
        len([m for m in anti if m["spans_component_junction"] == "YES"])],
       ["SD-like + ATG", len(sd), len(sd) - len(sd_junc), len(sd_junc)]])
w(f"**One junction-spanning hit in total across every scan, and it is shown above not to exceed what "
  f"its own parent component already carried.** [EVIDENCE]")
w("")
w("---")
w("")

# ================================================================= TASK 4
w("## 4. Task 4 — remaining checks")
w("")
w("### 4.1 Uniqueness, DNA and protein")
w("")
ident = [p for p in pairs if p["longest_shared_exact_substring_bp"] != "" and
         p["a_is_substring_of_b"] == "YES" and p["b_is_substring_of_a"] == "YES"]
w(f"- **Identical sequences: 0.** No two of the {n_total} share a full sequence. [EVIDENCE]")
w(f"- **DNA pairs at ≥95% ungapped identity: "
  f"{len([p for p in hi if not p['relationship'].startswith('PROTEIN')])}.**")
w(f"- **Protein pairs at ≥95% ungapped identity (kinase only, {len([r for r in man if is_kin[r['construct_id']]])} "
  f"proteins): {len([p for p in hi if p['relationship'].startswith('PROTEIN')])}.** No two kinase "
  f"proteins are identical.")
w("")
rows = [[f"`{p['construct_a']}`", f"`{p['construct_b']}`", p["ungapped_identity_pct"],
         "DNA" if not p["relationship"].startswith("PROTEIN") else "protein",
         p["intended_matched_pair"], p["relationship"].replace("PROTEIN-level: ", "")] for p in
        sorted(hi, key=lambda p: -F(p["ungapped_identity_pct"]))]
table(["a", "b", "identity %", "level", "intended matched pair", "relationship"], rows)
w(f"**Every ≥95% pair is a declared matched pair. {len(hi_unint)} are unaccounted for.** [EVIDENCE] "
  f"The A-vs-C pairs at 99.18% (protein) and 99.08–99.24% (DNA) are the deliberate linker comparison "
  f"— strategy C is strategy A with five acceptor residues replaced by `GSGSG` at constant length, "
  f"which is exactly what `strategy_contains` says it is. The other 6 DNA pairs are all within the "
  f"HP-7 group: the fore-cistron parent against its own "
  f"declared disabling and attenuating mutants — the fore-cistron-identity sweep at gap 3.")
w("")
w("The register triplets are **not** near-duplicates at the DNA level despite being near-identical "
  "designs: the codon optimiser is a deterministic greedy walk from the 5′ end, so shifting the "
  "acceptor start by one residue re-derives every downstream codon. Within-triplet DNA identity runs "
  "around 71%. [EVIDENCE, from `order_manifest_final_pairs.csv`] That is worth knowing before anyone "
  "designs a diagnostic PCR expecting the triplet members to behave alike.")
w("")
w("### 4.2 Homopolymer runs longer than 6")
w("")
w(f"**{len(homo)} of {n_total} constructs carry a run longer than 6.** [EVIDENCE] The finder is "
  f"positive-control tested (it finds `A×7`, and does not fire on `A×6`) before this null is trusted.")
w("")
w("### 4.3 GC against the 53.8% host average")
w("")
gk = [F(chk[r["construct_id"]]["GC_percent"]) for r in man if is_kin[r["construct_id"]]]
gn = [F(chk[r["construct_id"]]["GC_percent"]) for r in man if not is_kin[r["construct_id"]]]
w(f"- Kinase constructs: **{min(gk):.2f}–{max(gk):.2f}% GC**, every one inside ±{max(abs(x-HOST_GC) for x in gk):.2f} "
  f"points of the {HOST_GC}% host average. Codon optimisation targets host GC explicitly, and it worked.")
w(f"- Non-kinase constructs: **{min(gn):.2f}–{max(gn):.2f}% GC**.")
w(f"- **{len(gcout)} constructs fall outside ±15 points of {HOST_GC}%. Every one is Psyn-cored, and "
  f"every one is *below* the host average, spanning {min(F(c['GC_percent']) for c in gcout):.2f}–"
  f"{max(F(c['GC_percent']) for c in gcout):.2f}%.** [EVIDENCE, computed]")
w("")
over = sorted([c for c in gcout if F(c["GC_percent"]) > 36.5], key=lambda c: -F(c["GC_percent"]))
w(f"The known Psyn band is 29.6–36.5%. The observed band is "
  f"{min(F(c['GC_percent']) for c in gcout):.2f}–{max(F(c['GC_percent']) for c in gcout):.2f}%, so "
  f"{len(over)} constructs sit just above the top of that band "
  f"({', '.join('`'+c['construct_id']+'` '+c['GC_percent']+'%' for c in over)}). "
  f"All {len(over)} are long-gap insertion-arm variants, where the rebuilt `FILL_A` filler (53.8% GC, "
  f"host-matched by design) adds up to 13 GC-rich bases to an AT-rich construct. "
  f"[INFERENCE, reasoning named] That is the corrected filler doing what it was rebuilt to do, "
  f"pulling composition *toward* the host — not a new bias. No construct fell below the band.")
w("")
w("#### Is the AT-richness in the core elements, or spread across spacers and flanks?")
w("")
agg = defaultdict(lambda: [0, 0, 0])
for c in comp:
    s = seq_of[c["construct_id"]][I(c["start"]):I(c["end"])]
    cl = classify_component(c["component"])
    agg[cl][0] += len(s); agg[cl][1] += s.count("G") + s.count("C"); agg[cl][2] += 1
table(["component class", "occurrences", "total bp", "GC%", "sourced or designed"],
      [[k, n, bp, f"{100*g/bp:.1f}", "designed" if k.startswith("designed") or k == "stop codon" else "sourced"]
       for k, (bp, g, n) in sorted(agg.items(), key=lambda x: -x[1][0])])
sub = defaultdict(lambda: [0, 0, 0])
for c in comp:
    if not c["component"].startswith("core:"):
        continue
    k = c["component"].split(":")[1]
    off = I(el[k]["minus35_start0"])
    s = seq_of[c["construct_id"]][I(c["start"]):I(c["end"])]
    m35 = (I(el[k]["minus35_start0"]) - off, I(el[k]["minus35_end0"]) - off)
    e10 = (I(el[k]["ext10_start0"]) - off, I(el[k]["ext10_end0"]) - off)
    for nm, (a, b) in (("mapped −35 hexamer", m35), ("mapped extended −10", e10)):
        t = s[a:b]
        sub[nm][0] += len(t); sub[nm][1] += t.count("G") + t.count("C"); sub[nm][2] += 1
    rest = s[:m35[0]] + s[m35[1]:e10[0]] + s[e10[1]:]
    sub["core amplicon, everything else (spacer + downstream)"][0] += len(rest)
    sub["core amplicon, everything else (spacer + downstream)"][1] += rest.count("G") + rest.count("C")
    sub["core amplicon, everything else (spacer + downstream)"][2] += 1
w("The sourced core amplicon, split into its **mapped** elements:")
w("")
table(["core promoter sub-element", "occurrences", "total bp", "GC%"],
      [[k, n, bp, f"{100*g/bp:.1f}"] for k, (bp, g, n) in sub.items()])
dz = agg["designed background / upstream flank"]; fz = agg["designed gap filler"]
w(f"**Verdict: the AT sits in the two sourced elements that are AT-rich by nature, and every designed "
  f"flank sits at host composition. This is expected concentration, not systematic design bias.** "
  f"[EVIDENCE, computed from the component table] The sourced operator runs "
  f"{100*agg['sourced operator (PRODORIC Sal_PhoP site)'][1]/agg['sourced operator (PRODORIC Sal_PhoP site)'][0]:.1f}% GC "
  f"and the core promoter's own mapped elements run {100*sub['mapped −35 hexamer'][1]/sub['mapped −35 hexamer'][0]:.1f}% "
  f"(−35) and {100*sub['mapped extended −10'][1]/sub['mapped extended −10'][0]:.1f}% (extended −10) — "
  f"extended −10 regions are AT-rich, which is what makes them extended −10 regions. Against that, "
  f"the **designed** backgrounds and upstream flanks run {100*dz[1]/dz[0]:.1f}% GC and the designed "
  f"gap filler {100*fz[1]/fz[0]:.1f}%, against a host average of {HOST_GC}%. Nothing designed drifts "
  f"AT-ward.")
w("")
w(f"One honest qualification: the rest of the core amplicon — spacer and downstream, "
  f"{100*sub['core amplicon, everything else (spacer + downstream)'][1]/sub['core amplicon, everything else (spacer + downstream)'][0]:.1f}% GC — "
  f"is also AT-rich and is *not* a mapped promoter element. It is still **sourced natural sequence** "
  f"(the real sodA/tuf promoter regions, and the published synthetic Psyn), so it is not design bias "
  f"either; it is simply what those fragments are. [INFERENCE, reasoning named]")
w("")
w("### 4.4 Secondary structure — DEFECT SCREEN ONLY")
w("")
w("**Folding energy is not used to rank anything here, and no dG below is a strength prediction.** "
  "It has already been shown to fail as a rank predictor in this host: HP-12 is the least structured "
  "tier-2 element and ranks only intermediate in measured strength. [EVIDENCE: "
  "`designs/REPORT_translational.md` §3] dG is reported to catch synthesis and cloning defects and "
  "for nothing else.")
w("")
w("Folded with ViennaRNA (python bindings, RNA 2.7.2). Two numbers per construct: whole-fragment MFE, "
  "which scales with length and therefore mostly reports length, and the worst 60-nt local window, "
  "which does not.")
w("")
rows = []
for nm, sel in (("non-kinase (69)", lambda c: not is_kin[c["construct_id"]]),
                ("kinase (24)", lambda c: is_kin[c["construct_id"]])):
    g = [c for c in chk.values() if sel(c)]
    d = [F(c["dG_full_kcal_per_mol"]) for c in g]
    l = [F(c["dG60_worst_local"]) for c in g]
    rows.append([nm, f"{min(d):.1f} … {max(d):.1f}", f"{min(l):.1f} … {max(l):.1f}",
                 sum(1 for x in l if x <= -20.6)])
table(["set", "whole-fragment MFE (kcal/mol)", "worst 60-nt window (kcal/mol)", "windows ≤ −20.6"], rows)
hair = sorted([c for c in chk.values() if F(c["dG60_worst_local"]) <= -20.6],
              key=lambda c: F(c["dG60_worst_local"]))
w(f"**{len(hair)} of {n_total} constructs carry a 60-nt window at or below −20.6 kcal/mol**, the bar "
  f"the tier-1 panel already used. [EVIDENCE] By panel: "
  f"{', '.join(f'{k} {v}' for k, v in sorted(Counter(panel_of[c['construct_id']] for c in hair).items()))}.")
w("")
w(f"**{len([c for c in hair if is_kin[c['construct_id']]])} of them are the kinase constructs — all "
  f"24 of them — and this is the first time the kinase panel has been through this screen at all.** "
  f"[EVIDENCE: `scripts/junction_design.py` computes Golden Gate sites, homopolymers and GC, and no "
  f"folding.] The five worst: "
  f"{', '.join('`'+c['construct_id']+'` '+c['dG60_worst_local'] for c in hair[:5])}. A 1.7 kb "
  f"codon-optimised CDS at host GC will fold; that is expected and is a synthesis-cost signal, not a "
  f"design fault. It is flagged so the vendor quote is not a surprise.")
w("")
w("### 4.5 Synthesis-difficulty flags")
w("")
sdc = Counter(re.sub(r"\(.*", "", f) for c in chk.values() for f in c["synthesis_difficulty"].split(";")
              if f and f != "none")
rows = []
for k, v in sdc.most_common():
    cs = [c for c in chk.values() if any(f.startswith(k) for f in c["synthesis_difficulty"].split(";"))]
    rows.append([f"`{k}`", v, f"{len([c for c in cs if not is_kin[c['construct_id']]])} / "
                 f"{len([c for c in cs if is_kin[c['construct_id']]])}",
                 ", ".join(f"{a} {b}" for a, b in sorted(Counter(panel_of[c["construct_id"]] for c in cs).items()))])
table(["flag", "constructs", "non-kinase / kinase", "panels"], rows)
w(f"`INTERNAL_REPEAT_20nt` fires on **0** constructs: no 20-mer occurs twice inside any single "
  f"construct. [EVIDENCE] `G_TRACT` counts runs of ≥4 G and G-quadruplex-like `G3N1-7 ×4` motifs. "
  f"These four flags are the ones vendors price on; none of them blocks anything.")
w("")
w("### 4.6 Length distribution and the vendor minimum")
w("")
Ls = sorted(len(s) for s in seq_of.values())
rows = []
for lo, hi_ in [(0, 125), (125, 200), (200, 400), (400, 1000), (1000, 10**9)]:
    n = sum(1 for x in Ls if lo <= x < hi_)
    rows.append([f"{lo} – {hi_ if hi_ < 10**9 else '∞'}", n, f"{100*n/len(Ls):.0f}%"])
table(["length (bp)", "constructs", "share"], rows)
w(f"min {Ls[0]} bp, median {Ls[len(Ls)//2]} bp, max {Ls[-1]} bp, total {sum(Ls)} bp.")
w("")
w(f"**{len(under125)} of {n_total} constructs fall below 125 bp.** [EVIDENCE] By panel: ")
w("")
table(["panel", "constructs under 125 bp", "length range"],
      [[f"`{k}`", v, f"{min(len(seq_of[c['construct_id']]) for c in under125 if panel_of[c['construct_id']]==k)}–"
        f"{max(len(seq_of[c['construct_id']]) for c in under125 if panel_of[c['construct_id']]==k)}"]
       for k, v in sorted(Counter(panel_of[c["construct_id"]] for c in under125).items())])
w(f"Common vendor minimum fragment lengths sit at or above 125 bp, so these {len(under125)} may be "
  f"excluded from a gene-fragment order outright. **All {len(under125)} are 64–{max(len(seq_of[c['construct_id']]) for c in under125)} bp, "
  f"which is squarely in annealed-oligo-pair territory and is very likely cheaper that way** — two "
  f"oligos, annealed, with the assembly overhangs built into the ends. [INFERENCE, reasoning named: "
  f"length alone; no vendor quote was obtained, so this is a routing recommendation, not a price "
  f"claim.] That splits the order into two purchase types, which is a decision for whoever places it.")
w("")
w("---")
w("")
# ================================================================= TASK 5
w("## 5. Task 5 — cross-panel interaction")
w("")
w("Checks that do not exist below the combined level.")
w("")
w("### 5.1 Do constructs from different panels share enough sequence to misassemble or to read ambiguously?")
w("")
w(f"Method: index every 20-mer across all {n_total} constructs to find candidate pairs, then compute "
  f"the **exact** longest common substring for each candidate by binary search. "
  f"{len([p for p in pairs if p['longest_shared_exact_substring_bp'] != ''])} of "
  f"{n_total*(n_total-1)//2} pairs share a 20-mer at all. [EVIDENCE]")
w("")
table(["a", "b", "panels", "longest exact shared run (bp)", "ungapped identity"],
      [[f"`{p['construct_a']}`", f"`{p['construct_b']}`",
        f"{p['panel_a']} ↔ {p['panel_b']}", p["longest_shared_exact_substring_bp"],
        p["ungapped_identity_pct"] or "—"] for p in xp[:10]])
w(f"…{len(xp)} cross-panel pairs in total; full list in `designs/order_manifest_final_pairs.csv`.")
w("")
kk = [p for p in xp if is_kin[p["construct_a"]] and is_kin[p["construct_b"]]]
nn = [p for p in xp if not is_kin[p["construct_a"]] and not is_kin[p["construct_b"]]]
mixp = [p for p in pairs if is_kin[p["construct_a"]] != is_kin[p["construct_b"]]]
w("| pair type | pairs sharing ≥20 nt | longest exact shared run |")
w("|---|---|---|")
w(f"| kinase ↔ kinase, different sub-panel | {len(kk)} | **{max(I(p['longest_shared_exact_substring_bp']) for p in kk)} bp** |")
w(f"| non-kinase ↔ non-kinase, different panel | {len(nn)} | {max(I(p['longest_shared_exact_substring_bp']) for p in nn)} bp |")
w(f"| kinase ↔ non-kinase | **{len(mixp)}** | — (no shared 20-mer exists between the two sets) |")
w("")
w(f"**The one that matters: `{kk[0]['construct_a']}` and `{kk[0]['construct_b']}` — different "
  f"sub-panels — share {kk[0]['longest_shared_exact_substring_bp']} bp of exactly identical DNA.** "
  f"[EVIDENCE] The cause is not a mistake: both use the same `WP_043878053.1` sensor, and the codon "
  f"optimiser is deterministic, so it emits the identical string for the identical protein prefix in "
  f"both panels. Consequences, separated:")
w("")
w("- **Golden Gate misassembly: no.** [INFERENCE, reasoning named] Joins in Golden Gate are defined "
  "by the 4-nt overhangs, not by internal homology. Shared interior sequence does not create a "
  "mis-join. This holds *provided* the overhangs are unique — see §5.2, which is exactly why that "
  "section is not a formality.")
w("- **Homologous recombination in the host: a real, unquantified risk if two such constructs ever "
  "share a cell.** [INFERENCE] A >1 kb perfect repeat is a strong recombination substrate. The panel "
  "design has one construct per strain, so this only bites if strains are ever pooled.")
w("- **Sequencing: yes, this is the live one.** [INFERENCE, reasoning named] A read landing entirely "
  "inside the shared run cannot be assigned to a construct. Verification must be anchored — Sanger "
  "from a vector primer, or a read that reaches the junction. For pooled NGS verification, the "
  "junction region is the only discriminating sequence and every read must span it.")
w("")
w("### 5.2 Do the Golden Gate overhangs collide across panels?")
w("")
w("**The overhangs are not defined anywhere in this repo, so there is nothing to collide yet.** "
  "[NOT FOUND] A case-insensitive search of `scripts/`, `designs/`, `results/`, `*.py` and `*.md` for "
  "`overhang`, `fusion site` and `sticky` returns zero hits, and no Type IIS site exists in any "
  "construct to imply one. **This is a remaining design step, not a check failure.**")
w("")
w("It is, however, the step that decides §5.1. Two constraints the eventual overhang set has to meet, "
  "which the combined view makes concrete: all 93 fragments must carry mutually unique 4-nt overhangs "
  "across panels, not just within a panel, and no chosen overhang may recreate a BsaI/BsmBI/BbsI/SapI/"
  "AarI site when it is appended — a fresh scan will be needed after they are chosen, because "
  "everything in §2 is a statement about the fragments as they stand today.")
w("")
w("### 5.3 Is any construct a subsequence of another?")
w("")
w(f"**Yes — {len(contain)} exact-containment relations, and all {len(contain)} are the same declared "
  f"parent/derivative relationship.** [EVIDENCE]")
w("")
rows = []
for p in contain:
    short, long = ((p["construct_a"], p["construct_b"]) if p["a_is_substring_of_b"] == "YES"
                   else (p["construct_b"], p["construct_a"]))
    rows.append([f"`{short}`", len(seq_of[short]), f"`{long}`", len(seq_of[long]),
                 f"{panel_of[short]} ↔ {panel_of[long]}"])
table(["contained construct", "bp", "container", "bp", "panels"], sorted(rows, key=lambda r: r[0]))
w("Every one is a promoter fragment sitting as the exact 5′ prefix of its own combinatorial "
  "derivative, which is how the combinatorial design is defined: the cross construct **is** the "
  "promoter fragment with a fore-cistron element appended, and `combinatorial_design.csv` names the "
  "parent in its `promoter_variant` column. [EVIDENCE] It is by design and it is not a defect — but "
  "it is worth stating rather than leaving implicit, because a prefix relationship means any primer "
  "or probe designed against the short construct also matches the long one, and no diagnostic that "
  "reads only the 5′ end can tell them apart.")
w("")
w("---")
w("")

# ================================================================= TASK 6
w("## 6. Task 6 — order-ready output, and the envelope")
w("")
w("| file | contents |")
w("|---|---|")
w(f"| `designs/order_manifest_final.csv` | {n_total} rows, one per construct: `construct_id`, `panel`, "
  f"`tier`, `component_provenance`, `full_sequence`, `length_bp`, `GC_percent`, `flags`, "
  f"`rank_or_rationale` |")
w(f"| `designs/order_manifest_final_checks.csv` | {len(chk)} rows, every check result per construct |")
w(f"| `designs/order_submit_final.fasta` | {n_total} records, **id and sequence only** |")
w(f"| `designs/order_submit_final.csv` | {len(submit)} rows, **`construct_id` and `full_sequence` only, "
  f"nothing else** |")
w(f"| `designs/order_manifest_final_sites.csv` | {len(sites)} rows, one per restriction site: construct, "
  f"enzyme, position, strand, component, class |")
w(f"| `designs/order_manifest_final_motifs.csv` | {len(mot)} rows, one per SigA / SD+ATG hit with its "
  f"junction attribution |")
w(f"| `designs/order_manifest_final_pairs.csv` | {len(pairs)} rows, one per sequence-relationship pair |")
w(f"| `designs/order_manifest_final_components.csv` | {len(comp)} rows, the verified component map |")
w("")
from verify_order_final import run as _verify
_vok, _vfail = _verify()
w("The two submission files carry **only** `construct_id` and `full_sequence`. No existing path was "
  "overwritten; `scripts/consolidate_final.py` refuses to start if any output already exists.")
w("")
w(f"**Round-trip verified independently: `scripts/verify_order_final.py` re-reads the source panel "
  f"files and the written outputs and runs {len(_vok)+len(_vfail)} checks against them — "
  f"{len(_vok)} pass, {len(_vfail)} fail.** [EVIDENCE] Among them: every sequence in "
  f"`order_submit_final.csv` and `order_submit_final.fasta` is byte-identical to its row in "
  f"`order_manifest_final.csv` **and** to its row in the source panel file; `length_bp` and "
  f"`GC_percent` recompute from the sequence; every sequence is ACGT-only; the component map tiles "
  f"every construct with no gap and no overlap; and no row carries an UNRESOLVED provenance entry.")
if _vfail:
    w("")
    w("**FAILING CHECKS:**")
    for f in _vfail:
        w(f"- {f}")
w("")
w("### Envelope")
w("")
w(f"**{n_total} constructs against a 48–96 CRO envelope: it fits, with {96-n_total} slots of "
  f"headroom.** [EVIDENCE]")
w("")
w(f"This resolves the open question in `REPORT_phasing.md` §5, which projected 69 + a sensor-kinase "
  f"panel of unknown size and warned that 69 + 30 = 99 would exceed 96. **The kinase panel came in at "
  f"24, so no cut is needed and none has been made.** The ranked cut order in that report (halve the "
  f"Psyn insertion series; drop the Ptuf arm; drop combinatorial block 3) remains available and "
  f"unused. Nothing was silently trimmed: the {n_total} here is every construct in every panel.")
w("")
w(f"The {len(under125)} sub-125 bp constructs are inside the {n_total} count. If the CRO prices a "
  f"gene-fragment order and an oligo-pair order as separate line items, the gene-fragment line is "
  f"{n_total - len(under125)} and the oligo line is {len(under125)}; both are well inside the "
  f"envelope either way.")
w("")
w("---")
w("")
# ================================================================= PROVENANCE
w("## 7. Provenance — every component, and every gap")
w("")
seen2 = {}
for c in comp:
    base = re.sub(r"\[.*|\#.*|\(MUT.*", "", c["component"])
    seen2.setdefault(base, {"n": 0, "kind": c["sourced_or_designed"], "prov": c["provenance"]})
    seen2[base]["n"] += 1
w(f"{len(seen2)} distinct components across the {n_total} constructs. "
  f"**{sum(1 for v in seen2.values() if v['prov'] == 'UNRESOLVED')} carry an unresolved provenance "
  f"entry.** [EVIDENCE] Every component resolves to either an accession/citation or an explicit "
  f"'DESIGNED, not sourced' statement naming the script that produced it.")
w("")
table(["component", "uses", "sourced / designed", "accession or citation"],
      [[f"`{k}`", v["n"], v["kind"], v["prov"]] for k, v in sorted(seen2.items())])
w("### Constructs with an unresolved provenance gap")
w("")
gapc = [r for r in man if "UNRESOLVED" in r["component_provenance"]]
w(f"**{len(gapc)}.** [EVIDENCE] No construct in the order contains a component whose origin is "
  f"unknown.")
w("")
w("### Caveats that travel with the order")
w("")
w("These are not unresolved provenance — each has a citation — but each is a known limitation of the "
  "cited source, and each is carried forward rather than dropped:")
w("")
rows = []
for e in src["approach_B_source"]["fore_cistrons"]:
    if not e.get("genome_exact_match") and f"forecistron:{e['id']}" in seen2:
        rows.append([f"fore-cistron `{e['id']}` ({e['gene']})",
                     f"published sequence is not an exact genome match — {e.get('genome_note','')}",
                     _pl(seen2[f"forecistron:{e['id']}"]["n"])])
for k in ("Psyn", "PsodA", "Ptuf"):
    if f"core:{k}" in seen2 and el[k]["confidence"] != "HIGH":
        rows.append([f"core `{k}`",
                     f"promoter-element assignment confidence {el[k]['confidence']}: −35 at "
                     f"{el[k]['minus35_frac']} of max, extended −10 at {el[k]['ext10_frac']} of max",
                     _pl(seen2[f"core:{k}"]["n"])])
rows.append(["kinase panel", "**no destination vector is declared anywhere in the repo** — this is "
             "what makes the NcoI finding conditional rather than settled",
             f"{sum(1 for r in man if is_kin[r['construct_id']])} constructs"])
rows.append(["Golden Gate overhangs", "**not defined anywhere in the repo** — remaining design step",
             f"all {n_total}"])
rows.append(["SigA matrix", "a reasoned approximation from a textual consensus, not an empirically "
             "trained PWM; a clean scan means 'no consensus-like cryptic promoter', not 'no cryptic "
             "promoter'", f"all {n_total}"])
rows.append(["Psyn", "synthetic promoter with no genomic locus, so no mapped TSS; every gap value is "
             "measured from a computationally assigned −35", f"{seen2['core:Psyn']['n']} constructs"])
table(["subject", "caveat", "reach"], rows)
w(f"`Ptuf`'s −35 sits at {el['Ptuf']['minus35_frac']} of matrix max, which is not an assignment worth "
  f"resting a gap value on — the tier-1 report reached the same conclusion and kept Ptuf in the panel "
  f"for strength-range breadth only, not as a phasing subject. That is unchanged here. [EVIDENCE]")
w("")
w("---")
w("")

# ================================================================= VERDICT
w("## 8. Blockers, notes, and whether this is order-ready")
w("")
w("### Blockers")
w("")
w(f"**None.** [EVIDENCE] Zero Golden Gate sites across all {n_total} on both strands; zero identical "
  f"sequences; zero homopolymer runs over 6; zero unaccounted-for near-duplicates; zero components "
  f"with unresolved provenance; zero junction-created motifs that exceed what their own parent "
  f"component already carried.")
w("")
w("### One conditional blocker, and it is the reason this task exists")
w("")
w(f"**`NcoI` in {len(ncoi)} of the 24 kinase constructs.** [EVIDENCE] Not a Golden Gate blocker. It "
  f"becomes a hard blocker the moment those constructs are targeted at pECXT99A, the vector the other "
  f"69 use, which is opened with NcoI/NdeI and supplies the target ATG at that very site. The kinase "
  f"panel's vector is undeclared, so this cannot be settled from the repo — it needs one decision "
  f"from whoever owns the cloning plan. **It is cheap to pre-empt: the sites are in synthetic, "
  f"codon-optimised DNA, so re-running the optimiser with `NcoI` and `NdeI` added to its forbidden "
  f"set removes all {len(ncoi)} without changing a single amino acid.** Doing that unconditionally is "
  f"the recommendation, because it costs nothing and closes the same hole HP-4 opened.")
w("")
w("### Notes")
w("")
nrows = [
    [f"{len([s for s in sites if s['enzyme'] not in GOLDEN_GATE and s['enzyme'] not in VECTOR_SITES])} restriction sites, "
     f"{len(sorted({s['enzyme'] for s in sites if s['enzyme'] not in GOLDEN_GATE and s['enzyme'] not in VECTOR_SITES}))} enzymes",
     "none is used by Golden Gate or by the declared vector opening; recorded so a route change is a lookup, not a rediscovery"],
    [f"{len([m for m in sig if m['class'].startswith('SPURIOUS')])} sense-strand SigA windows ≥{SIGA_THRESH} of max",
     "all inside a single kinase CDS component, none junction-created; a cryptic promoter inside a CDS truncates its own transcript rather than driving an unintended gene"],
    [f"{len(anti)} antisense SigA windows", "kinase only; the one at a junction is shown in §3.2 not to exceed its own parent component's best"],
    [f"{len(sd)} SD+ATG pairs", "all inside the codon-optimised P0DM80 acceptor; internal-initiation risk, removable by re-synonymising"],
    [f"{len(gcout)} GC outliers", f"all Psyn-cored, all below host, {min(F(c['GC_percent']) for c in gcout):.1f}–{max(F(c['GC_percent']) for c in gcout):.1f}%; the AT is in the sourced operator and core elements, not in designed flanks"],
    [f"{len(hair)} strong local hairpins", "24 of them are the kinase CDSs, screened here for the first time; a synthesis-cost signal, never a strength prediction"],
    [f"{len(under125)} constructs under 125 bp", "may fall below vendor minimum fragment length; likely cheaper as annealed oligo pairs"],
    [f"{len(contain)} containment relations", "each is a promoter fragment inside its own declared combinatorial derivative; affects primer/probe design, not assembly"],
    [f"up to {max(I(p['longest_shared_exact_substring_bp']) for p in kk)} bp shared between kinase sub-panels",
     "affects sequencing-read assignment and, if strains are ever pooled, recombination; not Golden Gate misassembly"],
]
table(["note", "why it does or does not matter"], nrows)

w("### Is the set order-ready?")
w("")
w(f"**Sequence-wise, yes: all {n_total} constructs pass every check with no blocker.** "
  f"**Process-wise, no — not yet, and for one reason that has nothing to do with the sequences.**")
w("")
w("Exactly what remains, in the order it has to happen:")
w("")
w("1. **Define the Golden Gate overhangs.** [NOT FOUND — they do not exist] All 93 fragments need "
   "mutually unique 4-nt overhangs *across* panels. Until they exist, no fragment can actually be "
   "ordered in an assembly-ready form, because the overhangs change the ends of every sequence in "
   "the submission files.")
w("2. **Re-run §2's enzyme scan after step 1.** Appending overhangs and their flanks can create a "
   "Type IIS site that does not exist today. Everything in §2 is a statement about the fragments as "
   "they stand now.")
w(f"3. **Settle the kinase panel's destination vector**, or simply strip `NcoI`/`NdeI` from the "
   f"kinase codon optimiser and regenerate those 24. The second option removes the question rather "
   f"than answering it, costs no amino-acid change, and is the recommendation.")
w(f"4. **Decide the purchase split.** {len(under125)} constructs at {Ls[0]}–"
  f"{max(len(seq_of[c['construct_id']]) for c in under125)} bp are probably annealed oligo pairs "
  f"rather than gene fragments; that is a quote question, not a design one.")
w("")
w("Steps 1 and 2 are the real gate. Steps 3 and 4 are decisions, not problems.")
w("")
w("---")
w("")
w("## 9. What none of this establishes")
w("")
w("- **The SigA matrix is not a trained PWM.** Every SigA number in this report is a screening "
  "signal from a matrix built out of a textual consensus. A clean scan is evidence of no "
  "*consensus-like* element, and nothing stronger.")
w("- **Folding energy predicts nothing about strength here**, and is used only as a defect and cost "
  "screen. HP-12 is the least-structured tier-2 element and only intermediate in measured strength.")
w("- **A clean enzyme scan is a statement about 35 enzymes**, chosen because the provenance of the "
  "sourced components pointed at them plus the routes this repo declares. It is not a statement "
  "about any enzyme outside that catalogue.")
w("- **Component-level provenance is not experimental validation.** Every sequence traces to an "
  "accession, a citation, or a named generating script. None of that is evidence that any construct "
  "expresses, signals, or assembles.")
w("- **The two-tier architecture has not been demonstrated in any bacterial host.** Nothing in this "
  "consolidation changes that.")
w("")

OUT.write_text("\n".join(L) + "\n")
print(f"wrote {OUT} ({len(L)} lines, {len(OUT.read_text())} chars)")
