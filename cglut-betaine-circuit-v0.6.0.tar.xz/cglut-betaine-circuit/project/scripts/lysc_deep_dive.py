"""Task 4 (follow-up): manual examination of the lysC hit. Verifies locus tag,
coordinates, strand, operon context, and intergenic placement directly against
the cached genome feature table (never assumed from memory), and pulls the
hit's score/p-value under both null models for direct side-by-side reporting.
Writes data/cache/lysc_facts.json, which results/lysc_analysis.md is written
from.
"""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from annotate_hits import load_genes

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"


def main():
    genes = load_genes(DATA / "cache" / "BX927147.ft.txt")
    by_tag = {g["locus_tag"]: g for g in genes}

    lysc = by_tag["cg0306"]
    assert lysc["gene"] == "lysC", f"cg0306 gene name is {lysc['gene']!r}, not lysC -- verify before trusting"

    neighbors = {tag: by_tag[tag] for tag in ["cg0303", "cg0304", "cg0305", "cg0306", "cg0307", "cg0308", "cg0309"]}

    hit_lo, hit_hi = 269204, 269220
    cg0305 = by_tag["cg0305"]
    overlaps_cg0305 = not (hit_hi < cg0305["cds_lo"] or hit_lo > cg0305["cds_hi"])
    overlaps_lysc = not (hit_hi < lysc["cds_lo"] or hit_lo > lysc["cds_hi"])
    gap_cg0305_lysc = lysc["cds_lo"] - cg0305["cds_hi"] - 1
    gap_lysc_asd = by_tag["cg0307"]["cds_lo"] - lysc["cds_hi"] - 1

    dist_to_translation_start = lysc["tss"] - hit_hi  # tss field is translation start here (no TSS data available)

    hc = list(csv.DictReader(open(RESULTS / "hits_high_concern.csv")))
    lysc_hit = next(r for r in hc if r["start"] == str(hit_lo) and r["end"] == str(hit_hi))

    facts = {
        "locus_tag": lysc["locus_tag"], "gene": lysc["gene"], "product": lysc["product"],
        "strand": lysc["strand"], "cds_lo": lysc["cds_lo"], "cds_hi": lysc["cds_hi"],
        "translation_start": lysc["tss"],
        "neighbors": {tag: g for tag, g in neighbors.items()},
        "hit_lo": hit_lo, "hit_hi": hit_hi,
        "overlaps_cg0305_cds": overlaps_cg0305, "overlaps_lysc_cds": overlaps_lysc,
        "gap_cg0305_to_lysc_bp": gap_cg0305_lysc, "gap_lysc_to_asd_bp": gap_lysc_asd,
        "distance_to_translation_start_bp": dist_to_translation_start,
        "score_wholegenome_null": lysc_hit["score"], "p_wholegenome_null": lysc_hit["empirical_p"],
        "score_intergenic_null": lysc_hit["score_intergenic_bg"], "p_intergenic_null": lysc_hit["empirical_p_intergenic_null"],
    }
    (DATA / "cache" / "lysc_facts.json").write_text(json.dumps(facts, indent=1))
    print(json.dumps(facts, indent=1))


if __name__ == "__main__":
    main()
