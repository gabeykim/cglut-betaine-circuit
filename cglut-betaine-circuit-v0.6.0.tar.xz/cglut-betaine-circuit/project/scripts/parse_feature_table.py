"""Parse NCBI eutils 'feature table' (rettype=ft) flat files into structured records.

Format (per NCBI FT spec):
    >Feature ref|ACCESSION|
    <start>\t<end>\t<feature_type>
    \t\t\t<qualifier>\t<value>
    \t\t\t<qualifier>\t<value>
    <start>\t<end>\t<feature_type>
    ...

Consecutive gene/CDS blocks sharing the same coordinates are merged into one record.
"""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class Feature:
    start: str
    end: str
    ftype: str
    qualifiers: dict = field(default_factory=dict)


def parse_ft(path: str) -> list[Feature]:
    features: list[Feature] = []
    current: Feature | None = None
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith(">Feature"):
                continue
            if line.startswith("\t\t\t"):
                # qualifier line: \t\t\tkey\tvalue  (value may be absent)
                parts = line.split("\t")
                # parts[0..2] are empty (three tabs), parts[3] is key, parts[4:] value
                rest = line.lstrip("\t")
                fields = rest.split("\t")
                key = fields[0]
                value = fields[1] if len(fields) > 1 else ""
                if current is not None:
                    if key in current.qualifiers:
                        # allow multiple (e.g. multiple db_xref) -> store as list
                        existing = current.qualifiers[key]
                        if isinstance(existing, list):
                            existing.append(value)
                        else:
                            current.qualifiers[key] = [existing, value]
                    else:
                        current.qualifiers[key] = value
                continue
            # feature line: start \t end \t type   (start/end may have no leading digit for continuation, but
            # for our purposes every top-level feature line has 3 tab-separated fields)
            fields = line.split("\t")
            if len(fields) >= 3 and fields[2]:
                current = Feature(start=fields[0], end=fields[1], ftype=fields[2])
                features.append(current)
    return features


def merge_gene_cds(features: list[Feature]) -> list[dict]:
    """Merge adjacent gene+CDS features sharing coordinates into single records keyed by locus_tag."""
    records: dict[str, dict] = {}
    order: list[str] = []
    pending_gene: Feature | None = None
    for feat in features:
        if feat.ftype == "gene":
            pending_gene = feat
            continue
        if feat.ftype == "CDS":
            locus_tag = None
            gene_name = None
            old_locus_tag = None
            if pending_gene is not None and pending_gene.start == feat.start and pending_gene.end == feat.end:
                locus_tag = pending_gene.qualifiers.get("locus_tag")
                gene_name = pending_gene.qualifiers.get("gene")
                old_locus_tag = pending_gene.qualifiers.get("old_locus_tag")
            if isinstance(locus_tag, list):
                locus_tag = locus_tag[0]
            if locus_tag is None:
                # fall back: CDS itself may carry locus_tag (rare in this format) or skip
                locus_tag = feat.qualifiers.get("locus_tag", f"UNKNOWN_{feat.start}_{feat.end}")
            protein_id = feat.qualifiers.get("protein_id")
            if isinstance(protein_id, list):
                protein_id = protein_id[0]
            product = feat.qualifiers.get("product")
            rec = {
                "locus_tag": locus_tag,
                "gene": gene_name,
                "old_locus_tag": old_locus_tag,
                "protein_id": protein_id,
                "product": product,
                "start": feat.start,
                "end": feat.end,
            }
            if locus_tag not in records:
                records[locus_tag] = rec
                order.append(locus_tag)
            pending_gene = None
    return [records[k] for k in order]


if __name__ == "__main__":
    import sys
    import json

    feats = parse_ft(sys.argv[1])
    merged = merge_gene_cds(feats)
    print(f"{len(feats)} raw features -> {len(merged)} gene/CDS records", file=sys.stderr)
    json.dump(merged, sys.stdout, indent=1)
