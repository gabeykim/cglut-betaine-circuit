"""Task 5: rank the panel by INFORMATIVENESS, not expected performance.

No variant is ranked on a guess about which will express best -- nobody has
ever shown an imported wild-type response regulator driving a hybrid
promoter in this host, so there is no performance prior to rank against.
Instead, rank = how much this construct teaches if characterized, and in
what order the panel should be read if only a subset comes back first.

Tiering:
  1 = load-bearing negative controls -- without these, no other result in
      the panel is interpretable at all.
  2 = the position-sweep BACKBONE -- a bisecting (not sequential) order
      within the sweep, so that even a partial readout of the highest-ranked
      subset already spans the full ~11 bp helical turn rather than covering
      only one end of it first.
  3 = cross-validation of the position effect on an independently-sourced
      core promoter (PsodA), and the copy-number / operator-identity /
      upstream-context axes at the two most face-differentiated positions.
  4 = the remaining secondary-axis and lower-priority negative-control
      variants (redundant with a tier-1/2/3 result once that result exists,
      but still add resolution).

Within a tier, sort key is a bisection index over the represented gap value
(so, e.g., gap=0 and gap=10 rank ahead of gap=1 and gap=9, which rank ahead
of gap=5 -- the sweep is read outside-in).
"""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DESIGNS = ROOT / "designs"


def bisection_order(values):
    """Given a sorted list of distinct values, return {value: rank} where
    rank 0 = first endpoint, 1 = other endpoint, 2 = midpoint, etc. -- a
    breadth-first bisection so an early truncation still spans the range."""
    vals = sorted(values)
    order = {}
    idx = 0

    def recurse(lo, hi):
        nonlocal idx
        if lo > hi:
            return
        mid = (lo + hi) // 2
        if vals[mid] not in order:
            order[vals[mid]] = idx
            idx += 1
        recurse(lo, mid - 1)
        recurse(mid + 1, hi)

    if not vals:
        return order
    order[vals[0]] = idx
    idx += 1
    if vals[-1] != vals[0]:
        order[vals[-1]] = idx
        idx += 1
    recurse(1, len(vals) - 2)
    return order


def main():
    variants = json.loads((DATA / "cache" / "panel_variants_raw.json").read_text())
    checks = list(csv.DictReader(open(DESIGNS / "design_checks.csv")))
    checks_by_name = {c["name"]: c for c in checks}
    names = [line[1:].strip() for line in open(DESIGNS / "variants.fasta") if line.startswith(">")]

    psyn_gaps = sorted({v["gap_bp"] for v, n in zip(variants, names)
                         if n.startswith("Psyn_1x_opA_gap") and n.endswith("_repl")})
    psyn_gap_order = bisection_order(psyn_gaps)

    rows = []
    for name, v in zip(names, variants):
        c = checks_by_name[name]
        n_ops = v["n_operators"]
        is_negctrl = "noop_ctrl" in name or "scrambled" in name

        if name in ("Psyn_noop_ctrl", "Psyn_1x_scrambled_gap03_repl"):
            tier, subrank = 1, 0 if "noop" in name else 1
        elif name.startswith("Psyn_1x_opA_gap") and name.endswith("_repl"):
            tier, subrank = 2, psyn_gap_order[v["gap_bp"]]
        elif name in ("PsodA_1x_opA_gap00_repl", "PsodA_1x_opA_gap10_repl",
                      "PsodA_1x_opA_gap03_repl", "PsodA_1x_opA_gap06_repl"):
            tier, subrank = 3, {"PsodA_1x_opA_gap00_repl": 0, "PsodA_1x_opA_gap10_repl": 1,
                                 "PsodA_1x_opA_gap03_repl": 2, "PsodA_1x_opA_gap06_repl": 3}[name]
        elif name in ("Psyn_2xopA_gap00_repl", "Psyn_1x_opB_gap00_repl",
                      "Psyn_2xopA_gap05_repl", "Psyn_1x_opB_gap05_repl"):
            tier, subrank = 3, 4
        elif name in ("Psyn_1x_opA_gap03_reta", "Psyn_1x_opA_gap05_reta"):
            # upstream-context axis on the PRIMARY core: this is the control that
            # distinguishes "the architecture does not work" from "we truncated
            # something that was needed", so it ranks with the cross-validation axes
            # rather than with the residual tier-4 variants.
            tier, subrank = 3, 5
        else:
            tier, subrank = 4, 0

        rows.append({
            "name": name, "core": v["core"], "n_operators": n_ops,
            "operator_names": v["operator_names"], "gap_bp": v["gap_bp"],
            "upstream_mode": v["upstream_mode"], "length_bp": len(v["sequence"]),
            "gc_pct": c["gc_pct"], "flags": c["flags"],
            "tier": tier, "subrank": subrank, "rationale": v["rationale"],
        })

    rows.sort(key=lambda r: (r["tier"], r["subrank"], r["name"]))
    for i, r in enumerate(rows, 1):
        r["rank"] = i

    out_path = DESIGNS / "variants.csv"
    fieldnames = ["rank", "name", "core", "n_operators", "operator_names", "gap_bp", "upstream_mode",
                  "length_bp", "gc_pct", "flags", "tier", "rationale"]
    with open(out_path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r[k] for k in fieldnames})
    print(f"Wrote {len(rows)} ranked rows to {out_path}")

    print("\nTier breakdown:")
    for t in (1, 2, 3, 4):
        n = sum(1 for r in rows if r["tier"] == t)
        print(f"  tier {t}: {n} variants")

    print("\nTop 12 by rank:")
    for r in rows[:12]:
        print(f"  {r['rank']:2d}. {r['name']}")


if __name__ == "__main__":
    main()
