"""Task 3: rebuild the consolidated 93-construct order manifest on junctions_v3.

Identical logic to scripts/consolidate_final.py -- same component maps, same
verified base-for-base reconstruction, same checks -- with two overrides:
the kinase panel is read from designs/junctions_v3.{csv,fasta} (the NcoI-fixed
set) and the outputs carry the _v2 suffix. Nothing existing is renamed or
overwritten.

Every scan runs through scripts/seqchecks.py, so the 69 non-kinase and the 24
kinase constructs are screened against the SAME 35-enzyme catalogue -- which is
the whole point of the refactor and the reason the NcoI collision is now visible
to the kinase panel at all.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import consolidate_final as CF
from seqchecks import positive_control_check

CF.SUFFIX = "_v2"
CF.KIN_CSV = "junctions_v3.csv"
CF.KIN_FA = "junctions_v3.fasta"

if __name__ == "__main__":
    if len(sys.argv) > 1:
        CF.OUTDIR = Path(sys.argv[1]); CF.OUTDIR.mkdir(parents=True, exist_ok=True)
    positive_control_check()
    CF.main()
