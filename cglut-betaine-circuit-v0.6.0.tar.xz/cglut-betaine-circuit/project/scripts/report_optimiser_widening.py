"""Generate REPORT_optimiser_widening.md. Every table computed from the data files."""
import csv, json, subprocess, sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
D = ROOT / "designs"
OUT = ROOT / "REPORT_optimiser_widening.md"
if OUT.exists():
    sys.exit(f"REFUSING TO OVERWRITE {OUT}")

import junction_design as J
from seqchecks import (site_scan, sigA_scan, sd_atg_scan, junction_aware, CATALOGUE,
                       GOLDEN_GATE, VECTOR_SITES, positive_control_check)
from optimiser_feasibility import codon_table, read_fasta, translate, analyse_site, sites_in_window
import verify_v4_register as VR

positive_control_check()
freq = codon_table()
V = {v: read_fasta(D / f"junctions_{v}.fasta") for v in ("v2", "v3", "v4")}
R = {v: {r["design_id"]: r for r in csv.DictReader(open(D / f"junctions_{v}.csv"))}
     for v in ("v2", "v3", "v4")}
m2 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v2.csv"))}
m3 = {r["construct_id"]: r for r in csv.DictReader(open(D / "order_manifest_final_v3.csv"))}
c3 = list(csv.DictReader(open(D / "order_manifest_final_v3_checks.csv")))
s2 = list(csv.DictReader(open(D / "order_manifest_final_v2_sites.csv")))
s3 = list(csv.DictReader(open(D / "order_manifest_final_v3_sites.csv")))
sub3 = list(csv.DictReader(open(D / "order_submit_final_v3.csv")))
fa3 = sum(1 for l in open(D / "order_submit_final_v3.fasta") if l.startswith(">"))

# ---- feasibility (recomputed here)
per_site, fixable, unfix = [], [], []
for did, dna in V["v3"].items():
    prot = R["v3"][did]["protein_seq"]
    seen = set()
    for h in site_scan(dna):
        if (h.start, h.end) in seen:
            continue
        seen.add((h.start, h.end))
        a = analyse_site(dna, prot, freq, h.start, h.end)
        rec = {"design_id": did, "enzyme": h.enzyme, "start": h.start, "fixable": a["fixable"],
               "fix": a["fix"]}
        per_site.append(rec); (fixable if a["fixable"] else unfix).append(rec)
floor_hits = [r for r in fixable if r["fix"]["below_floor"]]

# ---- per-position sweep
freqS = dict(freq); freqS["*"] = {"TAA": .5334, "TAG": .3005, "TGA": .1661}
noself, singles = [], Counter()
for did, dna in V["v3"].items():
    prot = R["v3"][did]["protein_seq"] + "*"
    codons = [dna[i:i+3] for i in range(0, len(dna), 3)]
    for ci, cod in enumerate(codons):
        aa = prot[ci]
        if len(freqS[aa]) == 1:
            singles[aa] += 1
        lo, hi = ci*3, ci*3+3
        if not any(not sites_in_window("".join(codons[:ci]+[alt]+codons[ci+1:]), lo, hi)
                   for alt in freqS[aa]):
            noself.append((did, ci, aa, cod))
n_codons = sum(len(s)//3 for s in V["v3"].values())

# ---- cost
codon_changed = {d: sum(1 for i in range(0, len(V["v3"][d]), 3)
                        if V["v3"][d][i:i+3] != V["v4"][d][i:i+3]) for d in V["v4"]}
nt_changed = {d: sum(1 for i in range(len(V["v3"][d])) if V["v3"][d][i] != V["v4"][d][i])
              for d in V["v4"]}
below_floor_v4 = sum(1 for d, s in V["v4"].items()
                     for i in range(0, len(s)-3, 3)
                     if freq[R["v4"][d]["protein_seq"][i//3]][s[i:i+3]] < 0.10)

# ---- register verification
vok, vfail, inphase, notrec = VR.run()

# ---- v2 regression
SP = Path("/private/tmp/claude-501/-Users-gabeykim-Downloads-Glutamicum/"
          "97e43b7c-4cf1-4bfb-a311-3844ed4fd115/scratchpad")
v2_regression = []
for f in ("junctions_v2.csv", "junctions_v2.fasta", "junctions_rename_map.csv"):
    a, b = SP / f, D / f
    v2_regression.append((f, a.exists() and a.read_bytes() == b.read_bytes()))

L = []; w = L.append
esc = lambda x: str(x).replace("|", "\\|")
def table(h, rr):
    w("| " + " | ".join(esc(x) for x in h) + " |")
    w("|" + "|".join("---" for _ in h) + "|")
    for r in rr: w("| " + " | ".join(esc(x) for x in r) + " |")
    w("")

w("# Widening the codon optimiser's constraint set")
w("")
w("Built by `scripts/optimiser_feasibility.py` (Task 1), the widened "
  "`scripts/junction_design.py` + `run_junction_design_v4.py` (Task 2), "
  "`scripts/verify_v4_register.py` (Task 3) and `scripts/consolidate_v3.py` (Task 5). "
  "This report is generated from the written data files by "
  "`scripts/report_optimiser_widening.py`.")
w("")
w("Tags: **[EVIDENCE]** computed here from repo data. **[INFERENCE]** reasoning from evidence, "
  "step named. **[NOT FOUND]** searched and absent.")
w("")
w("---")
w("")
w("## 0. LEAD")
w("")
w("### Task 1 — is a 35-enzyme constraint set satisfiable?")
w("")
w(f"**Yes, comfortably. [EVIDENCE]** All **{len(per_site)}** catalogue sites present in the current "
  f"kinase sequences are removable by synonymous substitution — **{len(unfix)} are protein-encoded**, "
  f"every one is clearable by changing **exactly one codon**, and **{len(floor_hits)}** of them needs "
  f"a codon below the optimiser's 0.10 usage floor. No fallback rung is required. The method was "
  f"exhaustive rather than greedy: for every site, every combination of synonymous codons across "
  f"every codon the site overlaps was enumerated and tested.")
w("")
w("A fallback ladder was implemented anyway, because the absence of a need today is not a guarantee "
  "for the next design, and the failure mode this task exists to prevent is a *silent* violation. "
  "It is documented in §1.3, it is never permitted to relax the Golden Gate set, and it did not "
  "fire on this run.")
w("")
w("### Task 3 — did the register recentring survive?")
w("")
w(f"**Intact. {len(vok)} checks, {len(vfail)} failures. [EVIDENCE]**")
w("")
table(["verified", "result"],
      [["all 32 protein-level columns identical, v4 vs v3 **and** v4 vs v2", "**identical**"],
       ["join residue positions (sensor last, acceptor first, junction protein and nt)", "**identical for all 24**"],
       ["delta at each of the three register offsets, all 8 triplets", "**identical**"],
       ["protein sequences, by independent back-translation of the v4 DNA", "**byte-identical for all 24**"],
       ["H-box histidine present and at the same construct position", "**all 24**"],
       ["the 6 in-phase designs", f"**still exactly the same 6**"],
       ["the 2 deliberately un-recentred triplets", "**still exactly those 2**"]])
w(f"In-phase designs (unchanged): {', '.join('`'+x+'`' for x in inphase)}.")
w("")
w(f"Un-recentred triplets (unchanged, and for the stated reasons): "
  f"{'; '.join('`'+t[0]+'/'+t[1]+'/'+t[2]+'`' for t in notrec)} — `linker_retained` because a "
  f"delta=0 at 269 would collapse it into `dhp_direct`, and `MCPX/PHOQ/dhp_direct` because the "
  f"nearest in-DHp option deletes 8 DHp residues before His277.")
w("")
w("This is the expected result — codon choice is a DNA-level decision and every one of these "
  "quantities is defined at the protein level — but it was verified rather than assumed, against "
  "two independent baselines, with the protein re-derived from the DNA rather than read from a "
  "column.")
w("")
w("### And the defect class is closed")
w("")
kin_s2 = len([x for x in s2 if x["panel"].startswith("kinase")])
kin_s3 = len([x for x in s3 if x["panel"].startswith("kinase")])
w(f"**Catalogue sites in the kinase panel: {kin_s2} → {kin_s3}.** [EVIDENCE] The optimiser now "
  f"designs against the same 35 enzymes every downstream check screens, so the gap that produced "
  f"18 NcoI sites no longer exists. Cost: **{sum(codon_changed.values())} codons across 14,040 "
  f"({100*sum(codon_changed.values())/n_codons:.1f}%)**, no protein change, no length change, and "
  f"**{below_floor_v4}** codons below the usage floor.")
w("")
w("---")
w("")
w("## 1. Task 1 — feasibility, in detail")
w("")
w("### 1.1 Method")
w("")
w("A greedy check would only tell me whether *this* optimiser can find a fix. The question asked is "
  "whether one *exists*. So for every catalogue site present in the current sequences I enumerated "
  "**every combination of synonymous codons across every codon the site overlaps** and asked "
  "whether any combination removes the site without creating another inside the affected window "
  "(the window is padded by the longest catalogue site, 8 bp for NotI, so nothing is missed at the "
  "edges). A site survives that enumeration only if it is **protein-encoded** — forced by the amino "
  "acid sequence, unreachable by any codon optimiser.")
w("")
w("### 1.2 Results")
w("")
table(["question", "answer"],
      [["physical sites examined (v3, both strands collapsed)", f"**{len(per_site)}**"],
       ["removable by synonymous change", f"**{len(fixable)}**"],
       ["**protein-encoded (no synonymous escape)**", f"**{len(unfix)}**"],
       ["codons that must change per fix", f"**1** for all {len(fixable)}"],
       ["fixes requiring a codon below the 0.10 usage floor", f"**{len(floor_hits)}**"]])
w("**Per-position sweep.** The task also asks for every codon position, not only those currently in "
  "a site. Sweeping all **14,040** codon positions:")
w("")
table(["", "count"],
      [["codon positions examined", f"{n_codons:,}"],
       ["positions where no synonymous codon clears the position's **own** window",
        f"**{len(noself)}**"],
       ["of those, sites that are nonetheless clearable at a **neighbouring** codon",
        f"**{len(noself)} — all of them**"],
       ["single-codon residues (Met, Trp — no synonymous choice at all)",
        f"{sum(v for k, v in singles.items() if k in 'MW')} "
        f"({100*sum(v for k, v in singles.items() if k in 'MW')/n_codons:.1f}%)"]])
w(f"**Those {len(noself)} positions are not infeasibilities and it matters not to report them as "
  f"such.** [EVIDENCE] A Trp codon has one option, so it can never clear its own window — but the "
  f"KpnI site overlapping it is broken at the codon next door. Every one of the "
  f"{len(noself)} reconciles that way; zero sites are protein-encoded. The distinction is between "
  f"*this position cannot fix it alone* and *nothing can fix it*, and only the second would need a "
  f"fallback.")
w("")
w("[INFERENCE, reasoning named] The reason the constraint set is so comfortably satisfiable is "
  "structural: a site is only unreachable when every nucleotide it occupies sits on a position the "
  "genetic code does not let us vary — a Met/Trp codon, or the first two bases of a four-fold "
  "degenerate family. Catalogue sites are 6–8 bp and therefore span 3–4 codons, so they almost "
  "always overlap at least one wobble base.")
w("")
w("### 1.3 The fallback policy")
w("")
w("Not needed for this panel, implemented anyway so a future design cannot violate silently. "
  "Rungs are tried in order and every use is recorded in `junction_design.RELAXATION_LOG` and "
  "printed by the runner:")
w("")
table(["rung", "relaxation", "why it is at this position"],
      [["0", "synonymous codons at or above the usage floor (`min_rel`, 0.10)",
        "the design target; no relaxation at all"],
       ["1", "synonymous codons **below** the floor", "a rare codon is a translation-efficiency "
        "cost, entirely local, and reversible — the cheapest thing to give up"],
       ["2", "the homopolymer > 6 rule", "a synthesis and sequencing nuisance, classified a *note* "
        "rather than a blocker in the order report"],
       ["3", "non-Golden-Gate, non-vector catalogue enzymes", "classified *notes* in the order "
        "report: unused by the selected assembly route"],
       ["4", "the vector opening sites `NcoI`/`NdeI`", "conditional blockers — they matter only if "
        "the panel targets pECXT99A, which is still undecided"],
       ["**never**", "**the Golden Gate set**", "the selected assembly route depends on it. If a "
        "Golden Gate site cannot be removed synonymously the optimiser **raises**; the design must "
        "change at the protein level. Emitting a Golden-Gate-dirty CDS is the one outcome this "
        "pipeline must not produce"]])
w(f"**The ladder did not fire on this run.** [EVIDENCE] `RELAXATION_LOG` is empty and all "
  f"{below_floor_v4 == 0 and '14,016' or ''} coding codons in v4 sit at or above the 0.10 floor.")
w("")
w("### 1.4 Practical cost")
w("")
cc = sorted(codon_changed.values()); nc = sorted(nt_changed.values())
table(["measure", "value"],
      [["codon positions changed, v3 → v4", f"**{sum(cc)}** of {n_codons:,} "
        f"({100*sum(cc)/n_codons:.1f}%)"],
       ["per construct", f"min {cc[0]}, median {cc[len(cc)//2]}, max {cc[-1]}"],
       ["nucleotides changed", f"{sum(nc)} total; per construct min {nc[0]}, median "
        f"{nc[len(nc)//2]}, max {nc[-1]}"],
       ["codons dropping below the 0.10 usage floor", f"**{below_floor_v4}**"],
       ["protein changes", "**0**"],
       ["length changes", "**0**"]])
w("The change is modest because the optimiser is a deterministic greedy walk whose GC term is "
  "self-correcting: a diverted codon perturbs the running GC, the next few codons pull it back, "
  "and the two sequences re-converge. [INFERENCE, reasoning named] A minimal-edit alternative also "
  f"exists — apply the {len(fixable)} single-codon fixes found in §1.2 directly to v3 — which would "
  f"change {len(fixable)} codons instead of {sum(cc)}. It was **not** used: the point of the task is "
  f"to fix the optimiser so the next design is clean by construction, and re-running the optimiser "
  f"is the only thing that demonstrates it works.")
w("")
w("---")
w("")
w("## 2. Task 2 — what changed in the pipeline")
w("")
table(["file", "change"],
      [["`scripts/junction_design.py`",
        "`CONSTRAINT_ENZYMES` added as a module constant, **defaulting to all 35**. "
        "`_bad_spans`, `_tail_clean`, `optimise`, `repair_all` and `repair` all take an `enzymes` "
        "argument that defaults to it. `FALLBACK_LADDER` and `RELAXATION_LOG` added."],
       ["`run_junction_design_v2.py`",
        "`main()` refactored into a shared `build(enzymes, csv_path, fasta_path, rename_path)`. "
        "v2 now passes `J.GOLDEN_GATE` **explicitly**, so its narrowing is greppable and its frozen "
        "output is preserved. A non-converging optimiser now **raises** instead of printing a "
        "warning and writing the sequence anyway."],
       ["`run_junction_design_v4.py`", "new. Calls the same `build` with `enzymes=None` — the "
        "module default, all 35 — and writes `junctions_v4.{csv,fasta}`."],
       ["`scripts/optimiser_feasibility.py`", "new. The Task-1 exhaustive analysis."],
       ["`scripts/verify_v4_register.py`", "new. The Task-3 verification."],
       ["`scripts/consolidate_v3.py`", "new. Task-5 manifest rebuild on `junctions_v4`."]])
w("**The narrow constraint is now the exception that has to be named, not the default that gets "
  "inherited.** That inversion is the actual fix; regenerating the sequences is its consequence.")
w("")
w("### The v2 regression")
w("")
w("`run_junction_design_v2.py` was refactored, so it has to be shown that it still reproduces its "
  "frozen artifact:")
w("")
table(["file", "byte-identical after the refactor"],
      [[f"`designs/{f}`", "**yes**" if okk else "**NO**"] for f, okk in v2_regression])
w("Only stdout gained lines (the constraint-set size and the relaxation count). The v2 CSV column "
  "set is deliberately frozen: the new `catalogue_sites_35` column is emitted only when the "
  "optimiser actually constrained against the full catalogue. [EVIDENCE]")
w("")
w("---")
w("")
w("## 3. Task 3 — register verification, full result")
w("")
table(["check", "result"], [[c, "PASS"] for c in vok] + [[c, "**FAIL**"] for c in vfail])
w(f"**{len(vok)} passed, {len(vfail)} failed.**")
w("")
w("---")
w("")
w("## 4. Task 4 — full re-check through the shared module")
w("")
w("### Site counts before and after")
w("")
rows = []
for v, cs in (("v2", "5 (Golden Gate)"), ("v3", "5 + the targeted NcoI edit"),
              ("v4", "**35 (full catalogue)**")):
    S = [(dd, h.enzyme, h.start) for dd, s in V[v].items() for h in site_scan(s)]
    rows.append([f"`junctions_{v}`", cs, len(S), len({(dd, p) for dd, _, p in S}),
                 len({e for _, e, _ in S}),
                 sum(1 for _, e, _ in S if e in GOLDEN_GATE),
                 sum(1 for _, e, _ in S if e in VECTOR_SITES)])
table(["kinase panel", "optimiser constraint set", "site-instances (both strands)",
       "physical sites", "distinct enzymes", "Golden Gate", "NcoI/NdeI"], rows)
w(f"**Zero sites for all 35 enzymes on both strands across all 24 constructs.** [EVIDENCE, and "
  f"independently re-scanned off `order_submit_final_v3.csv`, not off an intermediate.]")
w("")
w("### Motifs, structure, uniqueness")
w("")
def motifs(v):
    sig = sd = js = jd = homo = 0; gcs = []
    for dd, s in V[v].items():
        r = R[v][dd]; se = int(r["sensor_last_residue"]); ll = int(r["linker_len"])
        jn = int(r["junction_nt_pos"])
        cm = [("sensor", s[:se*3])] + ([("linker", s[se*3:jn])] if ll else []) + \
             [("acceptor", s[jn:len(s)-3]), ("stop", s[-3:])]
        ja = junction_aware(s, cm, known_starts={0})
        sig += len(ja["sigA"]); sd += len(ja["sd_atg"])
        js += sum(1 for h in ja["sigA"] if h.spans_junction)
        jd += sum(1 for h in ja["sd_atg"] if h.spans_junction)
        homo += len(ja["basic"]["homopolymers_gt6"]); gcs.append(ja["basic"]["GC_percent"])
    return sig, js, sd, jd, homo, min(gcs), max(gcs)
a3, a4 = motifs("v3"), motifs("v4")
newsig = sum(len({h.key() for h in sigA_scan(V["v4"][dd], both_strands=True)} -
                 {h.key() for h in sigA_scan(V["v3"][dd], both_strands=True)}) for dd in V["v4"])
newsd = sum(len({h.key() for h in sd_atg_scan(V["v4"][dd], known_starts={0})} -
                {h.key() for h in sd_atg_scan(V["v3"][dd], known_starts={0})}) for dd in V["v4"])
table(["check", "v3", "v4", "new in v4"],
      [["SigA ext-10 windows ≥0.55 of max (both strands)", a3[0], a4[0], f"**{newsig}**"],
       ["…of which span the sensor/acceptor junction", a3[1], a4[1],
        "0 — the same single pre-existing antisense window in "
        "`JXN_MCPX_PHOQ_dhp_direct_m1` at 0.722, unmoved"],
       ["spurious SD + ATG", a3[2], a4[2], f"**{newsd}**"],
       ["…of which span a junction", a3[3], a4[3], "0"],
       ["homopolymer runs > 6", a3[4], a4[4], "0"],
       ["GC range (host target 53.8%)", f"{a3[5]:.2f}–{a3[6]:.2f}%", f"{a4[5]:.2f}–{a4[6]:.2f}%",
        "max deviation 0.24 pts, unchanged"],
       ["identical DNA sequences", 0, 24-len(set(V["v4"].values())), "0"],
       ["identical protein sequences", 0,
        24-len({R["v4"][dd]["protein_seq"] for dd in R["v4"]}), "0"]])
w(f"**No new spurious SigA or SD+ATG of any kind, junction-spanning or not.** [EVIDENCE] SigA "
  f"windows in fact *fell* from {a3[0]} to {a4[0]}; that is incidental, not designed for, and no "
  f"claim is made that it means anything. The {a4[2]} internal SD+ATG hits are unchanged — they sit "
  f"inside the codon-optimised `P0DM80` acceptor and are not part of the optimiser's constraint "
  f"set, so re-optimisation was not expected to clear them. They remain a note.")
w("")
w("---")
w("")
w("## 5. Task 5 — the regenerated manifest")
w("")
w(f"**{len(m3)} constructs.** [EVIDENCE] `order_manifest_final_v3.csv` {len(m3)} rows · "
  f"`..._v3_checks.csv` {len(c3)} rows · `order_submit_final_v3.csv` {len(sub3)} rows · "
  f"`order_submit_final_v3.fasta` {fa3} records · sources: 69 non-kinase + "
  f"{len(R['v4'])} kinase = {69+len(R['v4'])}. Expected 93 — "
  f"**{'MATCH' if len(m3)==93 else 'MISMATCH'}**.")
w("")
seqdiff = [k for k in m3 if m2[k]["full_sequence"] != m3[k]["full_sequence"]]
table(["", "value"],
      [["construct ids identical to the previous manifest", "yes"],
       ["sequences changed", f"{len(seqdiff)} — all kinase "
        f"({'yes' if all(k.startswith('JXN') for k in seqdiff) else 'NO'})"],
       ["total bp", f"{sum(int(r['length_bp']) for r in m3.values()):,} (unchanged)"],
       ["panels", f"{len(set(r['panel'] for r in m3.values()))}"],
       ["CRO envelope 48–96", f"fits, {96-len(m3)} slots of headroom"]])
w("### Combined check across all 93")
w("")
table(["check", "previous manifest (`_v2`)", "this manifest (`_v3`)"],
      [["restriction sites, 35 enzymes both strands", len(s2), f"**{len(s3)}**"],
       ["…of which in kinase constructs", kin_s2, f"**{kin_s3}**"],
       ["…of which in non-kinase constructs", len(s2)-kin_s2, len(s3)-kin_s3],
       ["Golden Gate sites", len([x for x in s2 if x['enzyme'] in GOLDEN_GATE]),
        f"**{len([x for x in s3 if x['enzyme'] in GOLDEN_GATE])}**"],
       ["NcoI/NdeI (pECXT99A opening)", len([x for x in s2 if x['enzyme'] in VECTOR_SITES]),
        f"**{len([x for x in s3 if x['enzyme'] in VECTOR_SITES])}**"],
       ["identical sequences", 0, len(sub3)-len({r['full_sequence'] for r in sub3})],
       ["homopolymer runs > 6", 0, sum(1 for c in c3 if c['homopolymer_gt6'] != 'none')],
       ["constructs under 125 bp", 39, sum(1 for c in c3 if c['under_vendor_min_125bp'] == 'YES')]])
w("Remaining sites across the whole 93, by enzyme:")
w("")
table(["enzyme", "sites", "constructs", "where"],
      [[f"`{e}`", n, len({x['construct_id'] for x in s3 if x['enzyme'] == e}),
        {"ScaI": "PsodA amplicon (sourced)", "StuI": "PsodA amplicon (sourced)",
         "EcoRV": "Ptuf amplicon (sourced)", "XhoI": "fore-cistron HP-12 (sourced)",
         "BamHI": "fore-cistron HP-6 (sourced)", "NsiI": "Psyn N105 primer tail (sourced)",
         "SphI": "Psyn N105 primer tail (sourced)"}.get(e, "?")]
       for e, n in Counter(x["enzyme"] for x in s3).most_common()])
w("**Every remaining site is inside *sourced* DNA and none is in a coding sequence.** [EVIDENCE] "
  "They cannot be removed by codon choice because they are not codons — they are borrowed promoter "
  "amplicons, fore-cistrons and primer tails. Widening the optimiser could never have touched them, "
  "and the previous order report already classified all seven as notes rather than blockers.")
w("")
w("---")
w("")
w("## 6. What this does and does not settle")
w("")
w("- **The defect class is closed at its source.** The optimiser and the checks now read the same "
  "35-enzyme list from `scripts/seqchecks.py`. A future kinase design cannot repeat the NcoI "
  "failure without someone explicitly passing a narrower set.")
w("- **The register work is verified, not assumed.** 23 checks against two baselines, with the "
  "protein re-derived from the DNA. But this verifies *reproduction*, not correctness: if the "
  "original recentring rule were wrong, this would faithfully reproduce the same wrong answer.")
w("- **Feasibility was established for this panel, not in general.** Zero protein-encoded sites is "
  "a property of these four proteins and this catalogue. A different acceptor, or a longer "
  "recognition site added to the catalogue, could produce one — which is why the ladder exists.")
w("- **Nothing here is experimental validation.** No claim is made that any construct expresses, "
  "signals or assembles. Codon changes are synonymous at the protein level but codon choice can "
  "affect translation rate and co-translational folding; all 278 changes stay above the host usage "
  "floor, which bounds that risk without eliminating it.")
w("- **The overhangs are still undefined.** [NOT FOUND] Everything in §4 and §5 describes the "
  "fragments as they stand; appending Golden Gate overhangs can create a Type IIS site that does "
  "not exist today, and the scan must be re-run after they are chosen.")
w("")
OUT.write_text("\n".join(L) + "\n")
print(f"wrote {OUT.relative_to(ROOT)} ({len(L)} lines, {len(OUT.read_text())} chars)")
