"""Task 4: design checks for every variant.

  1. Assembly/cloning enzyme sites (BsaI, BsmBI, BbsI -- Golden-Gate-style
     Type IIS enzymes explicitly named in the task -- plus standard
     restriction sites, including NcoI/NdeI specifically because the source
     vector for this whole promoter set, pECXT99A (Henke et al. 2021,
     PMC7835838), is opened with exactly those two enzymes). Both strands
     checked (Type IIS sites are non-palindromic).
  2. SigA spurious-internal-promoter scan: the same consensus-derived
     extended-10/-35 scoring matrices from scripts/siga_consensus.py (Task 2)
     are used to scan the WHOLE variant sequence, and any hit outside the
     intended, constant core-promoter element is flagged.
  3. Secondary structure: the last 60 bp of each variant (the promoter's own
     downstream edge -- a proxy for "5' UTR region," see caveat in the
     report for short cores where this window barely extends past the
     extended -10) is folded with ViennaRNA; MFE (dG) reported.
  4. GC content vs. the host's genome-wide 53.8% (Kalinowski et al. 2003;
     already computed exactly from the cached genome in this repo).
  5. Homopolymer runs > 6 nt.
"""
import csv
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from siga_consensus import EXT10_PWM, MINUS35_PWM, score_window, max_score
from pwm_lib import revcomp
from seqchecks import site_scan, fmt_sites, positive_control_check

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DESIGNS = ROOT / "designs"

# Enzyme sites come from scripts/seqchecks.py -- this module defines none of its own.
# This screen was 13 enzymes; it is now the full 35, which is the point of the shared
# module: a check that lives in one place cannot drift panel by panel.

HOST_GC = 0.5384  # from data/cache/intergenic_null_summary.json genome_gc, this project's own earlier fetch
GC_TOLERANCE = 0.15  # +/- 15 points flagged as outside normal range (reasoned, not a hard biological cutoff)


def find_sites(seq: str):
    """Full 35-enzyme catalogue, both strands, coordinates on the + strand."""
    return fmt_sites(site_scan(seq))


def spurious_promoter_scan(seq: str, exclude_range):
    """Scan for extended-10 hits >=55% of max anywhere OUTSIDE exclude_range
    (the intended, constant core-promoter element)."""
    ext_max = max_score(EXT10_PWM)
    w = EXT10_PWM["width"]
    spurious = []
    for i in range(len(seq) - w + 1):
        if exclude_range[0] <= i < exclude_range[1]:
            continue
        s = score_window(seq[i:i + w], EXT10_PWM)
        if s / ext_max >= 0.55:
            spurious.append((i, seq[i:i + w], round(s / ext_max, 2)))
    return spurious


def homopolymer_check(seq: str, max_run: int = 6):
    runs = []
    i = 0
    while i < len(seq):
        j = i
        while j < len(seq) and seq[j] == seq[i]:
            j += 1
        if j - i > max_run:
            runs.append((seq[i], i, j - i))
        i = j
    return runs


def fold_dg(seq: str):
    try:
        import RNA
        struct, mfe = RNA.fold(seq)
        return mfe, struct, None
    except ImportError:
        return None, None, "ViennaRNA not available"


def main():
    variants = json.loads((DATA / "cache" / "panel_variants_raw.json").read_text())
    names = []
    with open(DESIGNS / "variants.fasta") as fh:
        for line in fh:
            if line.startswith(">"):
                names.append(line[1:].strip())
    assert len(names) == len(variants)

    rows = []
    for name, v in zip(names, variants):
        seq = v["sequence"]
        # the constant core-promoter element (from -35 through end of fragment) is at the tail of seq
        core_len = v["core_length_used"]
        exclude_range = (len(seq) - core_len, len(seq))

        sites = find_sites(seq)
        spurious = spurious_promoter_scan(seq, exclude_range)
        homopolymers = homopolymer_check(seq)
        gc = (seq.count("G") + seq.count("C")) / len(seq)
        gc_flag = abs(gc - HOST_GC) > GC_TOLERANCE

        fold_region = seq[-60:] if len(seq) >= 60 else seq
        mfe, struct, fold_err = fold_dg(fold_region)

        flags = []
        if sites:
            flags.append("ENZYME_SITE")
        if spurious:
            flags.append("SPURIOUS_PROMOTER")
        if homopolymers:
            flags.append("HOMOPOLYMER")
        if gc_flag:
            flags.append("GC_OUT_OF_RANGE")
        if mfe is not None and mfe <= -15.0:
            flags.append("STRONG_SECONDARY_STRUCTURE")

        rows.append({
            "name": name, "length": len(seq), "gc_pct": round(100 * gc, 1), "gc_flag": gc_flag,
            "enzyme_sites": ";".join(sites) if sites else "none",
            "n_enzyme_sites": len(sites),
            "spurious_promoter_hits": ";".join(f"{p}:{s}:{frac}" for p, s, frac in spurious) if spurious else "none",
            "n_spurious_promoter_hits": len(spurious),
            "homopolymer_runs": ";".join(f"{b}x{n}@{p}" for b, p, n in homopolymers) if homopolymers else "none",
            "fold_region_len": len(fold_region), "fold_dG_kcal_mol": mfe, "fold_structure": struct,
            "fold_error": fold_err,
            "flags": ";".join(flags) if flags else "none",
        })

    with open(DESIGNS / "design_checks.csv", "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to designs/design_checks.csv")

    n_flagged = sum(1 for r in rows if r["flags"] != "none")
    print(f"{n_flagged}/{len(rows)} variants have at least one flag")
    for r in rows:
        if r["flags"] != "none":
            print(f"  {r['name']}: {r['flags']}")

    if rows[0]["fold_error"]:
        print(f"\nWARNING: {rows[0]['fold_error']} -- secondary structure not assessed")


if __name__ == "__main__":
    main()
