"""Task 4: how much headroom does 'keep Sal_PhoP expression low' actually buy?

Compares the genomic lysC site against the operators actually designed into
the panel (designs/variants.fasta), in PWM score units and as an approximate
affinity ratio.

Method note (the comparison has to be like-for-like): the designed operators
are 16 bp real Sal_PhoP sites and were selected against the
Salmonella-derived PWM (data/cache/pwm_phop_salmonella.json), so the lysC
genomic region is scored with that SAME PWM, taking the best-scoring 16 bp
window in a +/-15 bp window around the called hit. Scoring only the narrow
17 bp E. coli-frame hit window would understate the lysC site by ~12 bp of
frame offset -- a trap this project already hit once and diagnosed (see
results/REPORT_followup.md Task 5). The E. coli-derived 17 bp PWM is also
reported as an independent second opinion.

Affinity-ratio conversion [ESTIMATE, assumptions named]: a log2-odds PWM
score is treated as proportional to binding free energy with independent
positions contributing additively, so a score difference of d bits
corresponds to a relative dissociation-constant ratio of about 2^d. This is
the standard first-order approximation; it ignores position interdependence,
DNA shape/flexibility, protein cooperativity, and everything about the
cellular context. It is an order-of-magnitude guide, not a measurement.
"""
import csv
import json
import sys
from pathlib import Path

from Bio import SeqIO

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pwm_lib import load_pwm_json, revcomp

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DESIGNS = ROOT / "designs"
RESULTS = ROOT / "results"

OPERATOR_LO, OPERATOR_HI = 269204, 269220
FLANK = 15

DESIGNED_OPERATORS = {
    "opA_phoP (panel primary)": "TTTATTAACTGTTTAT",
    "opB_mgtA (panel secondary)": "TTTATCGTTGGTTTAA",
}


def score(seq: str, pwm: dict) -> float:
    return sum(pwm["log_odds"][i].get(ch, -10.0) for i, ch in enumerate(seq.upper()))


def best_window(context: str, pwm: dict):
    w = pwm["width"]
    cands = [(i, score(context[i:i + w], pwm)) for i in range(len(context) - w + 1)]
    i, s = max(cands, key=lambda x: x[1])
    return context[i:i + w], s


def main():
    genome = str(next(SeqIO.parse(DATA / "cache" / "BX927147.fasta", "fasta")).seq).upper()
    pwm_sal = load_pwm_json(DATA / "cache" / "pwm_phop_salmonella.json")
    pwm_ec = load_pwm_json(DATA / "cache" / "pwm_phop.json")

    ctx = genome[OPERATOR_LO - 1 - FLANK: OPERATOR_HI + FLANK]
    results = {}

    for pwm_name, pwm in [("Salmonella PWM (16bp, 9 sites)", pwm_sal), ("E. coli PWM (17bp, 29 sites)", pwm_ec)]:
        max_possible = sum(max(r.values()) for r in pwm["log_odds"])
        lysc_seq, lysc_score = best_window(ctx, pwm)
        print(f"\n=== {pwm_name} ===")
        print(f"  max possible score: {max_possible:.3f}")
        print(f"  lysC genomic site (best {pwm['width']}bp window in +/-{FLANK}bp context):")
        print(f"    {lysc_seq}  score = {lysc_score:.3f}  ({100*lysc_score/max_possible:.0f}% of max)")

        entry = {"max_possible": max_possible, "lysc_seq": lysc_seq, "lysc_score": lysc_score,
                 "designed": {}}
        for label, opseq in DESIGNED_OPERATORS.items():
            if len(opseq) == pwm["width"]:
                s = score(opseq, pwm)
                used = opseq
            else:
                used, s = best_window(opseq, pwm) if len(opseq) > pwm["width"] else (opseq, None)
                if s is None:
                    # designed operator shorter than this PWM: embed in its own flanks is not possible;
                    # score the genomic-style comparison is skipped and reported honestly
                    print(f"  {label}: cannot score with this PWM (operator {len(opseq)}bp < PWM {pwm['width']}bp) "
                          f"-- skipped rather than padded with invented bases")
                    entry["designed"][label] = {"score": None,
                                                 "note": "operator shorter than PWM width; not scored"}
                    continue
            delta = s - lysc_score
            ratio = 2 ** delta
            print(f"  {label}: {used}  score = {s:.3f}  ({100*s/max_possible:.0f}% of max)")
            print(f"    gap vs lysC site: {delta:+.3f} bits  ->  approx {ratio:.1f}x tighter binding [ESTIMATE]")
            entry["designed"][label] = {"seq": used, "score": s, "delta_bits": delta, "affinity_ratio": ratio}
        results[pwm_name] = entry

    # where does lysC rank among all intergenic-null survivors? (context for "how special is it")
    rows = list(csv.DictReader(open(RESULTS / "hits_high_concern.csv")))
    survivors = [r for r in rows if r.get("passes_p1e-4_intergenic_null") == "True"]
    surv_sorted = sorted(survivors, key=lambda r: -float(r["score_intergenic_bg"]))
    lysc_rank = next((i + 1 for i, r in enumerate(surv_sorted)
                      if r["start"] == str(OPERATOR_LO) and r["end"] == str(OPERATOR_HI)), None)
    print(f"\n=== Context: lysC among the {len(survivors)} intergenic-null survivors ===")
    print(f"  rank by intergenic-background score: {lysc_rank} of {len(survivors)}")
    top = surv_sorted[0]
    print(f"  strongest survivor: {top.get('nearest_gene_name') or top['nearest_gene_locus_tag']} "
          f"score={top['score_intergenic_bg']}")

    # ---- what does that score gap actually buy? single-site occupancy model ----
    # [ESTIMATE, assumptions named]: independent single-site equilibrium binding,
    # theta = [P]/([P]+Kd), no cooperativity, no competition with other sites, and
    # Kd_lysC / Kd_design = the affinity ratio derived above. This says nothing about
    # absolute Sal_PhoP~P levels -- only about the RATIO of occupancies, which is the part
    # the "keep Sal_PhoP expression low" mitigation is trying to exploit.
    print("\n=== What the score gap buys: occupancy of the lysC site when the designed "
          "operator is occupied ===")
    occ_table = {}
    sal = results["Salmonella PWM (16bp, 9 sites)"]["designed"]
    for label, d in sal.items():
        if d.get("affinity_ratio") is None:
            continue
        ratio = d["affinity_ratio"]
        rows_out = []
        for theta_design in (0.5, 0.75, 0.9, 0.95):
            # [P]/Kd_design = theta/(1-theta); Kd_lysC = ratio * Kd_design
            p_over_kd_design = theta_design / (1 - theta_design)
            theta_lysc = p_over_kd_design / (p_over_kd_design + ratio)
            rows_out.append({"theta_design": theta_design, "theta_lysc": theta_lysc})
            print(f"  {label}: designed operator {100*theta_design:.0f}% occupied "
                  f"-> lysC site {100*theta_lysc:.0f}% occupied  (affinity ratio {ratio:.1f}x)")
        occ_table[label] = rows_out
    results["occupancy_model"] = occ_table

    results["lysc_rank_among_survivors"] = lysc_rank
    results["n_survivors"] = len(survivors)
    (DATA / "cache" / "lysc_leakiness.json").write_text(json.dumps(results, indent=1))
    print("\nWrote data/cache/lysc_leakiness.json")


if __name__ == "__main__":
    main()
