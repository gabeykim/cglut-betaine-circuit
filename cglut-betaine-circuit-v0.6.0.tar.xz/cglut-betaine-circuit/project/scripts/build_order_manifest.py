"""Task 3: consolidate every construct into one order manifest and re-run all
design checks ACROSS THE UNION.

Construct definitions were written in three separate sessions -- the tier-1
promoter panel, the tier-2 translational panel, and the combinatorial design --
and had never been checked as a combined set. Collisions only appear when panels
meet: the HP-4 internal NcoI site (NcoI being the tier-1 vector's own cloning
enzyme) is the known example, and it was invisible to either panel alone.

WHAT IS ORDERED. The tier-1 constructs already end immediately before the target
ATG, so they ARE the monocistronic column of the promoter x translation
factorial; only the non-MCD cells cost new constructs. The orderable set is
therefore 33 tier-1 fragments + 19 new combinatorial fragments = 52.

FRAGMENT BOUNDARY. Every ordered fragment ends immediately BEFORE the target
ATG, which the vector supplies (pECXT99A is opened with NcoI/NdeI; the Henke
reverse primer tail ends ...GAATTCCATG, the ATG being the vector's own).
For BCD constructs the fragment therefore ends in the "TA" of the TAATG
coupling frame, and the target's ATG completes both the fore-cistron stop and
the target start.
"""
import csv
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from siga_consensus import EXT10_PWM, score_window, max_score
from pwm_lib import revcomp
from seqchecks import (CATALOGUE, site_scan, fmt_sites, positive_control_check,
                       homopolymers as _homopolymers)

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DESIGNS = ROOT / "designs"
HOST_GC = 0.5384
GC_TOL = 0.15

# ---------------------------------------------------------------- enzymes
# Enumerated explicitly rather than assumed. Every enzyme used anywhere in the
# assembly strategy of ANY panel is checked against EVERY construct.
# Enzyme sites come from scripts/seqchecks.py -- this module defines none of its own.
# This screen was a 15-enzyme list enumerated from the assembly plan. It is now the
# full 35-enzyme catalogue: a plan-derived list cannot see an enzyme that arrived
# inside borrowed sequence, which is how ScaI, StuI, EcoRV and XhoI were missed.
ENZYME_WHY = {
    "BsaI": "Type IIS, named in every panel spec",
    "BsmBI": "Type IIS, named in every panel spec",
    "BbsI": "Type IIS, named in every panel spec",
    "NcoI": "vector pECXT99A opening site; also supplies the target ATG",
    "NdeI": "vector pECXT99A opening site",
    "KpnI": "in the Henke reverse homology tail",
    "SacI": "in the Henke reverse homology tail",
    "EcoRI": "in the Henke reverse homology tail",
    "NsiI": "in the Psyn N105 forward homology tail (retained-context variants)",
    "SphI": "in the Psyn N105 forward homology tail (retained-context variants)",
    "PstI": "in the Psyn N106 reverse homology tail",
    "SalI": "in the Psyn N106 reverse homology tail",
    "XbaI": "in the Psyn N106 reverse homology tail",
    "BamHI": "in the Psyn N106 reverse homology tail; also inside fore-cistron HP-6",
    "HindIII": "standard MCS enzyme, checked by the tier-1 panel",
}
ENZYMES = {e: (site, ENZYME_WHY.get(e, "screened as part of the shared catalogue"))
           for e, site in CATALOGUE.items()}


def enzyme_hits(seq):
    """Full 35-enzyme catalogue, both strands."""
    return fmt_sites(site_scan(seq))


def homopolymers(seq, n=6):
    return [f"{h['base']}x{h['run']}@{h['start']}" for h in _homopolymers(seq, max_run=n)]


def fold(seq):
    try:
        import RNA
        return round(RNA.fold(seq)[1], 2)
    except Exception:
        return None


def gc(seq):
    return 100 * (seq.count("G") + seq.count("C")) / len(seq) if seq else None


def spurious_promoters(seq, exclude):
    """SigA extended-10 hits >=55% of max outside the intended core-promoter window.

    CAVEAT carried into the report: the matrix in this repo is a reasoned
    approximation derived from a TEXTUAL consensus (Patek & Nesvera 2011), not a
    PWM trained on aligned confirmed C. glutamicum promoters. Hits are a
    screening signal, not a calibrated probability.
    """
    w, mx, out = EXT10_PWM["width"], max_score(EXT10_PWM), []
    for i in range(len(seq) - w + 1):
        if exclude and exclude[0] <= i < exclude[1]:
            continue
        s = score_window(seq[i:i+w], EXT10_PWM) / mx
        if s >= 0.55:
            out.append(f"ext10@{i}({s:.2f})")
    return out


def spurious_initiation(seq, known_starts):
    """SD-like motif followed by an ATG at initiation-plausible spacing (4-12 nt),
    excluding the intended start codons of the design."""
    out = []
    for m in re.finditer(r"GGAGG|AGGAG|GGAG", seq):
        for a in re.finditer(r"ATG", seq[m.end()+3:m.end()+15]):
            pos = m.end() + 3 + a.start()
            if pos in known_starts:
                continue
            out.append(f"SD({m.group(0)}@{m.start()})+ATG@{pos}")
    return out


def worst_local_hairpin(seq, w=60):
    """Most stable local structure in any w-nt window. Whole-fragment MFE scales with
    length, so it flags long constructs for being long; a fixed window does not."""
    try:
        import RNA
    except Exception:
        return None
    if len(seq) <= w:
        return round(RNA.fold(seq)[1], 2)
    return round(min(RNA.fold(seq[i:i+w])[1] for i in range(0, len(seq)-w+1, 5)), 2)


def synthesis_difficulty(seq, dg):
    """Vendor complexity flags -- these are priced higher or refused."""
    f = []
    g = gc(seq)
    if g is not None and (g < 35 or g > 65):
        f.append(f"EXTREME_GC({g:.1f}%)")
    for m in re.finditer(r"(A{9,}|C{9,}|G{9,}|T{9,})", seq):
        f.append(f"LONG_HOMOPOLYMER({m.group(0)[0]}x{len(m.group(0))})")
    # direct repeats >=20 nt occurring more than once
    seen = {}
    for i in range(len(seq) - 20 + 1):
        seen.setdefault(seq[i:i+20], []).append(i)
    reps = {k: v for k, v in seen.items() if len(v) > 1}
    if reps:
        f.append(f"INTERNAL_REPEAT_20nt(x{len(reps)})")
    local = worst_local_hairpin(seq)
    if local is not None and local <= -20.6:      # same bar the tier-1 panel already uses
        f.append(f"STRONG_LOCAL_HAIRPIN(dG60={local})")
    return f


def identity(a, b):
    """Ungapped identity over the overlap of two same-ish-length sequences."""
    n = min(len(a), len(b))
    if n == 0:
        return 0.0
    same = sum(1 for i in range(n) if a[i] == b[i])
    return 100 * same / max(len(a), len(b))


def main():
    # ---------------------------------------------------------- load panels
    t1_rows = list(csv.DictReader(open(DESIGNS / "variants.csv")))
    t1_seq = {}
    for line in open(DESIGNS / "variants.fasta"):
        if line.startswith(">"):
            k = line[1:].strip()
        else:
            t1_seq[k] = line.strip()
    raw = json.loads((DATA / "cache" / "panel_variants_raw.json").read_text())
    t1_meta = {r["name"]: r for r in raw}

    t2_rows = list(csv.DictReader(open(DESIGNS / "translational_variants.csv")))
    t2 = {r["name"]: r for r in t2_rows}
    combo = list(csv.DictReader(open(DESIGNS / "combinatorial_design.csv")))

    PROV_T1 = ("core promoter: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838), "
               "amplicon recovered from BX927147.1 by the paper's own primers | operator: confirmed "
               "Salmonella Sal_PhoP site, PRODORIC MX000339 | filler: deterministic synthetic "
               "(scripts/design_promoter_panel.py, documented seed, NOT a natural sequence)")
    PROV_RETA = (" | retained upstream context: 21 nt vector-homology tail of primer N105 (Psyn-fw2), "
                 "PMC7835838 Table 2, verified in a single unbroken <td> cell of the cached HTML")
    PROV_T2 = ("fore-cistron: Liu et al. 2023, ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1, "
               "each 62-mer verified base-for-base against BX927147.1 | SD2 AAAGGAGGACAAC and the "
               "TAATG coupling frame: same paper, body text verbatim")

    rows = []

    # ---------------------------------------------------------- tier 1
    for i, r in enumerate(sorted(t1_rows, key=lambda x: int(x["rank"])), 1):
        name = r["name"]
        seq = t1_seq[name]
        prov = PROV_T1 + (PROV_RETA if name.endswith("_reta") and r["core"] == "Psyn" else "")
        rows.append({
            "construct_id": f"T1-{i:02d}_{name}", "tier": "1", "panel_of_origin": "tier-1 promoter panel",
            "core_promoter": r["core"], "operator_identity": r["operator_names"],
            "operator_copy_number": r["n_operators"], "operator_gap_bp": r["gap_bp"],
            "upstream_mode": r["upstream_mode"], "translational_element": "none (direct ATG fusion = MCD)",
            "full_sequence": seq, "length_bp": len(seq), "GC_percent": round(gc(seq), 1),
            "provenance": prov, "rank_or_rationale": f"tier{r['tier']} rank{r['rank']}: {r['rationale']}",
            "_src_name": name, "_t2": None,
        })

    # ---------------------------------------------------------- combinatorial (new cells only)
    n = 0
    for c in combo:
        if c["new_construct_required"] != "yes":
            continue
        n += 1
        pname, tname = c["promoter_variant"], c["translational_variant"]
        pr = next(x for x in t1_rows if x["name"] == pname)
        pseq, eseq = t1_seq[pname], t2[tname]["sequence"]
        seq = pseq + eseq
        short = tname.replace("T2_BCD_", "").replace("T2_", "")
        prov = PROV_T1 + (PROV_RETA if pname.endswith("_reta") else "") + " || " + PROV_T2
        note = c["note"]
        rows.append({
            "construct_id": f"CX-{n:02d}_{pname}__{short}", "tier": "combinatorial",
            "panel_of_origin": f"combinatorial design, block {c['block']}",
            "core_promoter": pr["core"], "operator_identity": pr["operator_names"],
            "operator_copy_number": pr["n_operators"], "operator_gap_bp": pr["gap_bp"],
            "upstream_mode": pr["upstream_mode"], "translational_element": tname,
            "full_sequence": seq, "length_bp": len(seq), "GC_percent": round(gc(seq), 1),
            "provenance": prov,
            "rank_or_rationale": f"{c['block']}: {note[:240]}",
            "_src_name": pname, "_t2": tname,
        })

    # controls are already inside both panels; label them so the tier column is honest
    for r in rows:
        nm = r["construct_id"]
        if "noop_ctrl" in nm or "scrambled" in nm or "_NEG" in nm or "MCD_ctrl" in nm:
            r["tier"] = "control"

    print(f"{len(rows)} constructs consolidated "
          f"({sum(1 for r in rows if r['tier']=='1')} tier-1, "
          f"{sum(1 for r in rows if r['tier']=='combinatorial')} combinatorial, "
          f"{sum(1 for r in rows if r['tier']=='control')} controls)")
    # ================= 3b. CHECKS ACROSS THE COMBINED SET =================
    checks = []
    seqs = {r["construct_id"]: r["full_sequence"] for r in rows}

    # intended-start positions per construct (target ATG is vector-supplied, so the only
    # in-construct start is the BCD fore-cistron's own ATG at the element boundary)
    for r in rows:
        seq, cid = r["full_sequence"], r["construct_id"]
        known_starts = set()
        if r["_t2"] and t2[r["_t2"]]["sequence"]:
            known_starts.add(len(seq) - len(t2[r["_t2"]]["sequence"]))
        m = t1_meta.get(r["_src_name"], {})
        core_lo = len(t1_seq[r["_src_name"]]) - m.get("core_length_used", 0) if m else None
        exclude = (core_lo, core_lo + m.get("core_length_used", 0)) if core_lo is not None else None

        enz = enzyme_hits(seq)
        homo = homopolymers(seq)
        dg = fold(seq)
        sig = spurious_promoters(seq, exclude)
        init = spurious_initiation(seq, known_starts)
        g = gc(seq)
        gcflag = "GC_OUT_OF_RANGE" if abs(g/100 - HOST_GC) > GC_TOL else ""
        syn = synthesis_difficulty(seq, dg)
        checks.append({
            "construct_id": cid, "length_bp": len(seq), "GC_percent": round(g, 1),
            "gc_flag": gcflag,
            "restriction_sites": ";".join(enz) or "none",
            "n_restriction_sites": len(enz),
            "homopolymer_gt6": ";".join(homo) or "none",
            "dG_kcal_per_mol": dg,
            "spurious_sigA_ext10": ";".join(sig) or "none",
            "spurious_initiation": ";".join(init) or "none",
            "dG60_worst_local": worst_local_hairpin(seq),
            "synthesis_difficulty": ";".join(syn) or "none",
        })

    # ---- uniqueness / near-identity across the WHOLE set
    ids = list(seqs)
    dup = {}
    for cid, s in seqs.items():
        dup.setdefault(s, []).append(cid)
    identical = [v for v in dup.values() if len(v) > 1]
    near = []
    for i in range(len(ids)):
        for j in range(i+1, len(ids)):
            a, b = seqs[ids[i]], seqs[ids[j]]
            if abs(len(a) - len(b)) > 6:
                continue
            pid = identity(a, b)
            if pid >= 95:
                ra = next(r for r in rows if r["construct_id"] == ids[i])
                rb = next(r for r in rows if r["construct_id"] == ids[j])
                # A matched pair is one the design intends to compare directly: same
                # promoter variant, and tier-2 elements built on the SAME fore-cistron
                # background (HP-7 vs its own disabling mutants are matched by design).
                def bg(x):
                    m = re.search(r"HP\d+", x["translational_element"] or "")
                    return m.group(0) if m else (x["translational_element"] or "")
                intended = (ra["_src_name"] == rb["_src_name"] and bg(ra) == bg(rb))
                near.append((ids[i], ids[j], round(pid, 1), intended))
    by_id = {c["construct_id"]: c for c in checks}
    for a, b, pid, intended in near:
        if not intended:
            for x in (a, b):
                by_id[x]["synthesis_difficulty"] = (
                    (by_id[x]["synthesis_difficulty"].replace("none", "") + ";" if by_id[x]["synthesis_difficulty"] != "none" else "")
                    + f"UNINTENDED_NEAR_DUPLICATE(>=95% vs {b if x==a else a})").strip(";")

    # ---- AT-distribution: is the AT-richness in the core elements (expected) or the spacers?
    at_rows = []
    for r in rows:
        m = t1_meta.get(r["_src_name"])
        if not m or r["core_promoter"] != "Psyn":
            continue
        s = t1_seq[r["_src_name"]]
        up = m["upstream_length"]; ob = m["operator_block_length"]; gp = m["gap_bp"]
        seg = {"upstream": s[:up], "operator": s[up:up+ob], "gap_filler": s[up+ob:up+ob+gp],
               "core_from_-35": s[up+ob+gp:]}
        at_rows.append({k: (round(gc(v), 1) if v else None) for k, v in seg.items()})

    def avg(k):
        v = [a[k] for a in at_rows if a[k] is not None]
        return round(sum(v)/len(v), 1) if v else None

    print("\n" + "="*70)
    print("COMBINED-SET CHECK SUMMARY")
    print("="*70)
    nz = [c for c in checks if c["n_restriction_sites"]]
    print(f"restriction sites: {len(nz)}/{len(checks)} constructs carry >=1 site "
          f"({len(ENZYMES)} enzymes checked, both strands)")
    from collections import Counter
    ec = Counter(h.split('@')[0] for c in checks for h in c["restriction_sites"].split(';') if h != "none")
    for k, v in ec.most_common():
        print(f"    {k:8} {v} hits")
    print(f"identical sequence pairs: {len(identical)}")
    print(f">=95% identity pairs: {len(near)}  ({sum(1 for x in near if not x[3])} UNINTENDED)")
    for a, b, pid, it in near[:6]:
        print(f"    {pid}%  {'intended' if it else 'UNINTENDED'}  {a}  vs  {b}")
    print(f"spurious SigA ext-10 hits: {sum(1 for c in checks if c['spurious_sigA_ext10']!='none')} constructs")
    print(f"spurious initiation signals: {sum(1 for c in checks if c['spurious_initiation']!='none')} constructs")
    print(f"homopolymer >6: {sum(1 for c in checks if c['homopolymer_gt6']!='none')} constructs")
    print(f"GC out of range: {sum(1 for c in checks if c['gc_flag'])} constructs")
    dgs = [c["dG_kcal_per_mol"] for c in checks if c["dG_kcal_per_mol"] is not None]
    print(f"dG range: {min(dgs)} .. {max(dgs)} kcal/mol (DEFECT SCREEN ONLY, not a strength prediction)")
    print(f"synthesis-difficulty flags: {sum(1 for c in checks if c['synthesis_difficulty']!='none')} constructs")
    print(f"\nPsyn AT-distribution by segment (mean GC%): upstream={avg('upstream')} "
          f"operator={avg('operator')} gap_filler={avg('gap_filler')} core={avg('core_from_-35')}")
    from design_promoter_panel import make_generic_filler
    print("\ngap-filler composition across the sweep (all fillers are prefixes of ONE fixed string):")
    for n in (1, 2, 3, 5, 8, 10, 13):
        s = make_generic_filler(n)
        print(f"    gap={n:>2}: {s:<15} GC={gc(s):>5.1f}%")
    print(f"    upstream 'replaced' filler(30): GC={gc(make_generic_filler(30)):.1f}%")

    # ---------------------------------------------------------- write outputs
    mcols = ["construct_id", "tier", "panel_of_origin", "core_promoter", "operator_identity",
             "operator_copy_number", "operator_gap_bp", "upstream_mode", "translational_element",
             "full_sequence", "length_bp", "GC_percent", "provenance", "rank_or_rationale", "flags"]
    for r in rows:
        c = by_id[r["construct_id"]]
        fl = [x for x in (c["gc_flag"],
                          "" if c["restriction_sites"] == "none" else "RESTRICTION:" + c["restriction_sites"],
                          "" if c["homopolymer_gt6"] == "none" else "HOMOPOLYMER:" + c["homopolymer_gt6"],
                          "" if c["spurious_sigA_ext10"] == "none" else "SPURIOUS_SIGA:" + c["spurious_sigA_ext10"],
                          "" if c["spurious_initiation"] == "none" else "SPURIOUS_INIT:" + c["spurious_initiation"],
                          "" if c["synthesis_difficulty"] == "none" else "SYNTH:" + c["synthesis_difficulty"]) if x]
        r["flags"] = ";".join(fl) or "none"
    with open(DESIGNS / "order_manifest.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=mcols, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
    ccols = list(checks[0].keys())
    with open(DESIGNS / "order_manifest_checks.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=ccols)
        w.writeheader(); w.writerows(checks)
    with open(DESIGNS / "order_submit.fasta", "w") as fh:
        for r in rows:
            fh.write(f">{r['construct_id']}\n{r['full_sequence']}\n")
    with open(DESIGNS / "order_submit.csv", "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(["construct_id", "full_sequence"])
        for r in rows:
            w.writerow([r["construct_id"], r["full_sequence"]])
    print(f"\nWrote designs/order_manifest.csv ({len(rows)} rows)")
    print(f"Wrote designs/order_manifest_checks.csv ({len(checks)} rows)")
    print(f"Wrote designs/order_submit.fasta / .csv ({len(rows)} sequences, id+sequence only)")
    return rows, checks, near, at_rows


if __name__ == "__main__":
    main()
