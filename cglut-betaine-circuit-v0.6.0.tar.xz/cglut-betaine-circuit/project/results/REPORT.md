# PhoP operator motif scan of *C. glutamicum* ATCC 13032

Go/no-go check on the PhoP donor choice: does the native genome already contain a close match to the PhoP operator, such that inducing an engineered PhoP-responsive promoter would also switch on a native gene?

Pipeline run: 2026-08-22 (same session/repo as the earlier cross-talk identity analysis). Regenerate with `python3 run_scan_pipeline.py` (network touched only for files not already cached; a full rerun with everything cached completes in well under a minute).

Tags: **[EVIDENCE]** a citable source states it, cited inline. **[INFERENCE]** reasoning from evidence, reasoning step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent, with what was searched.

---

## 1. Positive control — PASS (report this first, as instructed)

The PhoP PWM (built below, §2) was used to scan the *E. coli* K-12 MG1655 genome (NC_000913.3) for the specific promoters the task named, plus every other confirmed PhoP site the PWM was built from.

**[EVIDENCE]** All three explicitly-required control loci are recovered, score in the extreme tail of the genome-wide empirical null, and classify correctly as HIGH_CONCERN (intergenic, within 400 bp upstream of the regulated gene's annotated start):

| Site | Position (NC_000913.3) | Strand | Score | Empirical p | Classification | Nearest gene | Distance |
|---|---|---|---|---|---|---|---|
| phoP autoregulatory site | 1,190,508-1,190,524 | − | 15.33 | 1.6×10⁻⁶ | HIGH_CONCERN | **phoP** (b1130) | 61 bp upstream |
| mgtA site (mgtAp1) | 4,467,321-4,467,337 | + | 14.43 | 5.1×10⁻⁶ | HIGH_CONCERN | **treR** (b4241)† | 75 bp upstream |
| slyB site (slyBp1/2) | 1,719,736-1,719,752 | + | 16.14 | 5.4×10⁻⁷ | HIGH_CONCERN | **slyB** (b1641) | 124 bp upstream |

†This exact site is annotated in RegulonDB as simultaneously regulating `mgtAp1` (via the *mgtL-mgtA* leader-attenuator, forward orientation) and `treRp3`/`treRp4` (*treR*, divergently transcribed on the reverse strand) — a documented bidirectional promoter [EVIDENCE: RegulonDB, citing PMID 12813061 and 12123454]. The classifier reports the single nearest gene in either direction (*treR*, 75 bp) rather than *mgtL* (94 bp, also upstream and also correct) purely because it is closer; both are real regulatory targets of this site, and the scan/classification code has no way to prefer one over the other without additional information. This is not an error — it is a case where the annotation itself is genuinely two-sided.

**Broader control** (not just the three named loci): the PWM was built from 29 confirmed PhoP sites (§2). Scanning those same 29 sites' genomic coordinates back out of the *E. coli* genome-wide scan: **26/29 (90%) are recovered at their exact annotated coordinate**; the 3 not recovered at the exact base pair were each collapsed by the overlap-merging step (§3) into an adjacent, overlapping, higher-scoring window representing the same physical regulatory region (verified individually; not a failure to detect, just a few-bp shift in the reported peak summit). **24/29 (83%) classify as concerning** (21 HIGH_CONCERN + 2 INSIDE_CDS_EXCEPTIONAL — e.g. the *mgrR* sRNA promoter, a well-documented case of a regulatory site embedded inside a neighboring ORF [EVIDENCE: PMID 19889087]). Full table: `results/positive_control.csv`.

**A bug the control caught**: the first version of the gene-annotation code computed a minus-strand gene's translation start using the wrong end of its coordinate pair (`min()` instead of the feature table's actual "start" field, which is always the translation start regardless of strand). This silently misclassified every minus-strand HIGH_CONCERN call — including the phoP autoregulatory site itself, which came back `INTERGENIC_LOW` with `purB` (the neighboring gene, wrong) as its nearest gene instead of `phoP`. The positive control caught this before any C. glutamicum result was trusted; see `scripts/annotate_hits.py` for the fix and the code comment documenting it. **This is exactly why the task orders the positive control before the main result — do not skip it.**

**Verdict: PASS.** Proceeding to the *C. glutamicum* scan.

---

## 2. Binding sites: what was assembled, and from where

**Source used: RegulonDB** (regulondb.ccg.unam.mx), queried live via its GraphQL API (`https://regulondb.ccg.unam.mx/graphql`), which returns curated, PMID-cited *E. coli* K-12 MG1655 transcription-factor binding sites with exact genomic coordinates, strand, and the DNase-footprint/EMSA/ChIP-confirmed core sequence (marked in uppercase within lowercase flanking context in the raw record).

**[NOT FOUND]** CollecTF (the other database explicitly named in the task, which additionally curates *Salmonella* sites) was attempted and is unreachable from this environment: both a direct HTTPS client and the fetch tool got `Could not resolve host` / `connection refused` against `collectf.umbc.edu` (its current domain, found via web search after the originally-expected `collectf.umassmed.edu` failed to resolve at all). PRODORIC and EcoCyc were reachable but not queried once RegulonDB alone yielded a large, well-cited confirmed-site set exceeding the task's minimum several times over; going further was not necessary to clear the stop condition. **Every site used in this analysis is therefore an *E. coli* K-12 MG1655 site, not a *Salmonella* site.** [INFERENCE, reasoning named]: this is a meaningful gap for a completeness bar, but a small one for this specific go/no-go question — the prior cross-talk analysis in this repo established that *Salmonella* PhoP (the actual donor, UniProt P0DM78) and *E. coli* PhoP (P23836) are 93.3% identical full-length, and the PhoP-box direct-repeat mechanism is conserved across gamma-proteobacteria [EVIDENCE: Kato, Tanabe & Utsumi 1999, *J Bacteriol* 181:5516-5520, PMC94065, which defines the "(T/G)GTTTA-5bp-(T/G)GTTTA" direct-repeat consensus verified directly against this paper's fetched full text]. Using the *E. coli*-confirmed set as a proxy for *Salmonella* PhoP specificity is a reasonable substitute, not a guess from scratch, but it is a substitution and is disclosed as one.

**Stop condition check**: not triggered. 36 unique, PMID-cited, experimentally confirmed *E. coli* PhoP sites were assembled (well above the "at least 10" bar), spanning 17 distinct primary-literature citations (DNase footprinting, EMSA, and ChIP-based studies from 1999-2023). Per-site PMIDs are in `data/sites_manifest.csv`.

**Core-motif length**: RegulonDB's curated core-site length distribution for PhoP was `{15bp:1, 16bp:1, 17bp:29, 18bp:3, 20bp:1, 23bp:1}` — a clean modal peak at **17 bp**, which is exactly the width predicted by Kato et al.'s "(T/G)GTTTA-5bp-(T/G)GTTTA" direct-repeat definition (6+5+6=17) [EVIDENCE, verified against fetched primary text, not assumed]. The **29 sites at the modal 17 bp width were used to build the PWM**; the 7 non-modal-length sites are real confirmed sites with genuinely different footprint/spacer widths (not duplicates or artifacts — individually inspected, see `data/sites_manifest.csv`) and are recorded but excluded from the fixed-width PWM alignment rather than forced into it.

**OmpR (backup donor)**: 45 unique confirmed sites, **all exactly 20 bp**, 31 distinct PMIDs, all used to build a backup-donor PWM (`results/pwm_ompr.txt`), held in reserve for mitigation (c) if needed (§6).

---

## 3. The PWM

Log-odds PWM, BLOSUM-style pseudocount (0.5), background = **observed *C. glutamicum* genome composition**, not uniform: A=0.2307, C=0.2701, G=0.2683, T=0.2308 (**GC = 53.84%**, computed directly from the cached BX927147.1 FASTA — matches [EVIDENCE: Kalinowski et al. 2003, *J Biotechnol* 104:5-25, "53.8% GC"] almost exactly, a good sanity check on the fetched sequence itself).

**Built from 29 sites** (comfortably above the ~8-site weak-determination floor the task flags).

**Total information content: 9.56 bits over 17 positions (0.56 bits/position average) — this is low**, and the scan is noisy as a direct consequence (§4). The per-position IC profile is not flat, though: positions 3-6 (≈1.0, 0.9, 0.7, 0.8 bits) and 14-17 (≈1.3, 1.0, 0.16, 1.1 bits) carry almost all the signal — exactly the two `GTTTA`-like hexamer repeats — while positions 7-11 (the predicted 5 bp spacer) carry almost none (0.03-0.11 bits each). **This internal structure was not built in by hand — it fell straight out of aligning 29 independently-sourced sites** and independently reproduces the direct-repeat architecture Kato et al. described from footprinting, which is a meaningful validation of both the site set and the alignment, separate from the positive-control validation in §1.

**[INFERENCE]**: the motif's two hexamer repeats are T/A-rich (best-scoring consensus: `TGTTTATGATCTGTTTA`) against a GC-rich (53.8%) host background. A GC-mismatched host background makes an AT-rich motif rarer by chance than it would be in an AT-rich or neutral genome — this is one reason the *C. glutamicum* hit counts below come in somewhat below a naive genome-size-only extrapolation from the *E. coli* scan (§4).

Full matrix with per-position IC: `results/pwm.txt`.

---

## 4. The scan

Both strands, every position, both genomes (script: `scripts/scan_genome.py`, vectorized with NumPy; forward/reverse coordinate mapping unit-tested before use on real data — see script docstring). Overlapping windows within one PWM-width of each other on the same strand are merged to their single highest-scoring position (non-maximum suppression) so one real site is not double- or triple-counted as several independent "hits."

**Empirical null**: a dinucleotide-shuffled copy of the *same* genome (Altschul-Erikson 1985 algorithm — exact dinucleotide, mononucleotide, and first/last-symbol preservation verified by a self-test asserting identical dinucleotide count dictionaries between original and shuffled sequence, plus a 20-trial stress test across varied lengths and skewed compositions; see `scripts/dinuc_shuffle.py`). One shuffle per genome, fixed seed (1337) for reproducibility — but that one shuffled genome is scanned at *every* position on *both* strands, giving a null pool of **6,565,384 scores for *C. glutamicum*** and 9,283,272 for *E. coli*, so empirical p-values are well resolved down to ~10⁻⁷ from a single shuffle, without needing to repeat it.

**Hit counts by stringency, *C. glutamicum* (sensitivity/specificity tradeoff, as requested)**:

| Tier | Empirical p ≤ | Total merged peaks | ... classified HIGH_CONCERN |
|---|---|---|---|
| lenient | 0.05 | 149,001 | 17,399 |
| medium | 0.001 | 7,096 | 1,925 |
| strict | 0.0001 | 895 | **304** |
| (context) | 10⁻⁵ | — | 57 |
| (context) | 10⁻⁶ | — | 9 |

**[INFERENCE, reasoning named]**: HIGH_CONCERN counts look large in absolute terms even at the strict tier, but a large fraction of that is base rate, not motif signal: **33.2% of the entire *C. glutamicum* genome falls within 400 bp upstream of some annotated gene start** [ESTIMATE, computed directly from the cached feature table: 1,090,379 of 3,282,708 bp], purely because bacterial genomes are gene-dense with short intergenic regions. Observed HIGH_CONCERN fraction at the strict tier is 304/895 = 34% — almost exactly the base rate. This does not mean the 304 hits are meaningless; it means "HIGH_CONCERN" alone is a positional label, not a significance claim, and the empirical p-value (not the classification) is what should drive prioritization within that set — which is why §5 below is organized by p-value, not by raw HIGH_CONCERN membership.

---

## 5. HIGH CONCERN hits in *C. glutamicum* — what they sit next to

**304 HIGH_CONCERN hits** at the pre-registered strict tier (empirical p ≤ 10⁻⁴); full list with score, position, strand, nearest locus tag, and product in `results/hits_high_concern.csv`. Below is every hit at **p ≤ 10⁻⁶ — the same order of statistical extremeness as the confirmed, functionally real *E. coli* sites in §1** (whose scores ranged p = 5.4×10⁻⁷ to 1.7×10⁻⁶) — treated here as the top-priority subset within the 304:

| Position | Strand | Score | Empirical p | Distance | Locus tag | Gene | Product |
|---|---|---|---|---|---|---|---|
| 1,898,810-1,898,826 | + | 17.36 | 1.5×10⁻⁷ | 107 bp | cg2008 | — | putative membrane protein |
| 343,501-343,517 | − | 16.89 | 1.5×10⁻⁷ | 120 bp | cg0397 | — | probable 5′-nucleotidase precursor |
| 1,193,527-1,193,543 | − | 17.34 | 1.5×10⁻⁷ | 323 bp | cg1292 | — | flavin-containing monooxygenase 3 |
| 1,232,813-1,232,829 | − | 16.48 | 1.5×10⁻⁷ | 12 bp | cg1326 | — | hypothetical protein |
| 1,800,394-1,800,410 | − | 16.68 | 1.5×10⁻⁷ | 165 bp | cg1911 | — | putative secreted protein |
| 269,204-269,220 | + | 15.35 | 3.0×10⁻⁷ | 151 bp | **cg0306** | **lysC** | **aspartokinase (α/β subunits)** |
| 2,683,275-2,683,291 | + | 15.30 | 3.0×10⁻⁷ | 232 bp | cg2824 | — | SAM-dependent methyltransferase |
| 1,781,932-1,781,948 | − | 14.97 | 7.6×10⁻⁷ | 346 bp | cg1891 | — | hypothetical protein |
| 2,397,813-2,397,829 | − | 15.11 | 7.6×10⁻⁷ | 27 bp | cg2518 | — | putative secreted protein |

**cg0306/*lysC* is the single most consequential name on this list.** Aspartokinase is the first, feedback-inhibited, committed step of the aspartate-derived amino-acid pathway (lysine, threonine, methionine, isoleucine) — in almost every industrial *C. glutamicum* production strain, *lysC* carries deregulating point mutations specifically because its expression/activity is a primary lever on amino-acid titer. A PhoP-responsive element with this much statistical support sitting 151 bp upstream of it is not proof of function, but it is exactly the kind of hit that would matter if it turned out to be real, and it warrants inclusion in whatever experimental check (EMSA/reporter fusion) is run on this list.

At the wider p ≤ 10⁻⁵ tier (57 hits total, `results/hits_all.csv`), two more thematically notable names recur: **cg2833/*cysK*** (O-acetylserine sulfhydrylase, cysteine biosynthesis; twice, on both strands near the same locus) and **cg2846/*pstS*** (phosphate ABC-transporter substrate-binding protein — phosphate transport is the textbook PhoP/PhoQ physiological role in enterobacteria, though in *C. glutamicum* phosphate signaling runs through an unrelated native two-component system per the earlier cross-talk analysis in this repo, so this is a thematic coincidence, not evidence of a real regulatory link). The remaining hits in the 57- and 304-hit tiers are mostly annotated "hypothetical protein" / "putative membrane protein" / "conserved hypothetical protein" — unsurprising, since roughly that fraction of any bacterial genome (*C. glutamicum* included) remains functionally uncharacterized; their absence of a known function does not make a nearby motif match less concerning, only harder to interpret.

---

## 6. Verdict

**The PhoP operator is not clean in this host at the sequence-motif level.** The scan recovers, in *C. glutamicum*, hits statistically as extreme as the confirmed functional *E. coli* PhoP sites used to validate the method (§1, §5) — most prominently a p=3×10⁻⁷ hit 151 bp upstream of *lysC*, a gene of direct industrial relevance to this host. This is **a triage signal, not a verdict**: a 17 bp, 9.56-bit motif match upstream of a gene means that genomic region should be checked experimentally before the engineered PhoP-responsive promoter is treated as insulated from native regulation — it does not mean *lysC* (or any other hit) *will* be pleiotropically activated. Whether any specific hit is functional depends on chromatin/nucleoid context, competing regulators, and PhoP concentration/activation state in this host, none of which this sequence-only scan can assess.

**Given that qualification, the donor choice does need revisiting, or at minimum the engineered construct does.** A ">0 statistically-extreme HIGH_CONCERN hits, including one next to a strain-defining gene" result is exactly the outcome the task frames as a go/no-go trigger, not a pass.

---

## 7. Mitigations, in the required order (response regulator modification is out of scope and not recommended below)

**(a) Reposition or re-space the operator in the engineered promoter.** The cleanest first move: none of the 304 HIGH_CONCERN native hits are inside the engineered construct itself — they are pre-existing genomic matches the PhoP protein would also see. Re-siting the engineered PhoP box relative to the promoter's −10/−35 elements, or adjusting its spacing, does not change genomic cross-talk risk (the native sites are fixed, wherever they are) but is listed first per the requested order; it is most useful in combination with (b) below if the goal is also to fine-tune engineered-promoter output strength independent of the cross-talk question.

**(b) Use a different PhoP box variant with lower genomic similarity.** The site set assembled in §2 already spans real biological variation — 7 confirmed sites at non-modal spacer widths (15-23 bp instead of 17 bp; `data/sites_manifest.csv`), several with visibly weaker match to the T/A-rich consensus (e.g. the *hdeA*/*gadW* sites in §1's broader control, which scored far more weakly and did not classify as concerning). Selecting an engineered operator sequence from the weaker/divergent end of the confirmed-site spectrum, rather than the strongest consensus-matching sites, would directly lower its resemblance to whatever native sequence pattern drives the *C. glutamicum* hits, at a likely tradeoff of somewhat weaker engineered-promoter response and should be re-scanned against this same PWM/pipeline before committing.

**(c) Fall back to the EnvZ/OmpR donor and rescan.** A backup-donor PWM was already built as part of this analysis (`results/pwm_ompr.txt`, 45 confirmed *E. coli* OmpR sites, all 20 bp, total IC 6.60 bits) and is ready to scan with the same pipeline (`python3 scripts/scan_genome.py --genome data/cache/BX927147.fasta --pwm data/cache/pwm_ompr.json --out ... `) if (a)/(b) are judged insufficient. Note the OmpR motif's total IC (6.60 bits) is even lower than PhoP's (9.56 bits), which on its own would predict a *noisier*, not cleaner, scan — this fallback is not automatically better on sequence grounds alone and should be run and evaluated on its own positive control before being treated as a solution rather than a different set of tradeoffs.

**Response regulator modification is excluded from this mitigation list, per instruction, and is not recommended here for any reason.**

---

## 8. Reproducing this analysis

```
pip install -r requirements.txt
python3 run_scan_pipeline.py             # first run: fetches + caches everything not already cached
python3 run_scan_pipeline.py --skip-fetch   # later runs: fully offline
```
The script prints the positive-control PASS/FAIL check and will not proceed to the *C. glutamicum* scan if it fails.
