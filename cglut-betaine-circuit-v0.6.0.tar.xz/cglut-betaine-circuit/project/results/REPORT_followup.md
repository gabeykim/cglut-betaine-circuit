# Follow-up analysis: is the 304-hit Sal_PhoP operator scan a real signal or a compositional artifact?

Regenerate with `python3 run_followup.py` (fully offline; all inputs reused from the cached genome, feature table, and RegulonDB/PRODORIC data already in this repo — nothing was re-fetched that was already cached). Tags: **[EVIDENCE]** a citable source states it, cited inline. **[INFERENCE]** reasoning from evidence, reasoning step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent, with what was searched.

---

## Headline finding (read this first)

**Most of the original 304 was compositional artifact. A small residual signal survives, and it is concentrated almost entirely in the hits already flagged as most extreme — including lysC.** Rebuilding the null from intergenic composition (52.7% AT, vs. 46.2% AT genome-wide — Sal_PhoP boxes are AT-rich, and intergenic DNA in this 53.8%-GC organism is enriched for exactly the composition the motif already prefers) drops the HIGH_CONCERN count from **304 to 82** at the same p≤10⁻⁴ threshold. Analytically, **~54 hits** would be expected by chance alone under this corrected null; by direct simulation, **~64**. Both are close enough to the 82 observed that **the bulk of the original list cannot be called a real signal with confidence** — this is a Poisson excess of roughly 1.3-1.5×, nominally detectable (p=0.0002 to 0.017 depending on which chance-estimate is trusted, itself a single-shuffle Monte Carlo estimate with its own sampling noise) but nowhere near the dramatic, confident-looking "304 hits" the original report led with. **The correct verdict for the bulk of the list, per the reasoning Task 3 asked to apply, is "this motif lacks the resolving power to answer the question" — not "the operator is not clean."** The earlier blanket verdict is retracted below.

The exception: **the 9 hits already singled out as "as extreme as the confirmed *E. coli* sites" all survive the correction (9/9), and 54 of the top 57 (95%) survive**, while only 28 of the remaining 247 weaker hits (11%) do. The residual excess above chance is not spread evenly across the original 304 — it is almost entirely the same small set already flagged as most extreme. **lysC is in that set**, remains significant by an order of magnitude of headroom under the corrected null (p=3.96×10⁻⁶ vs. the 10⁻⁴ threshold), and is independently corroborated by a second PWM built from actual *Salmonella*-specific Sal_PhoP sites (§Task 5) — obtained in this follow-up after the original report incorrectly had to substitute *E. coli* sites for lack of access. **This specific candidate has not been explained away and is the one result from this whole exercise that should drive an experimental decision.**

---

## Task 1 — the Sal_PhoP numbers the earlier report never surfaced

`results/identity_rec.csv` and `results/identity_full.csv` were computed by the earlier cross-talk analysis but the operator-scan report only discussed the Ec_OmpR (backup-donor) comparison. Surfacing the Sal_PhoP (primary-donor) numbers directly:

**Closest native *C. glutamicum* RR to *Salmonella* Sal_PhoP (P0DM78), REC-domain basis**: **"Cg_PhoR(CgtR3)" / Cg_CgtR3 (cg2888)**, at **40.54%** identity on *both* denominators (45 identities / 111 aligned columns after trimming = 45 identities / 111 = length of the shorter sequence, both 111 aa) [EVIDENCE: `results/identity_rec.csv`].

**Closest native RR to *E. coli* Ec_PhoP (P23836), REC-domain basis**: a three-way tie at **40.54%** aligned-column / ~40.5-40.9% shorter-seq — Cg_MprA(CgtR2) (cg0996), Cg_CgtR5 (cg2947), and Cg_CopR(CgtR9) (cg3285) — with Cg_PhoR(CgtR3)/Cg_CgtR3 close behind at 38.74%.

**Full ranked list, REC-domain identity to *Salmonella* Sal_PhoP** (the primary donor):

| Rank | Native RR | Locus | REC identity (aligned-col / shorter-seq) |
|---|---|---|---|
| 1 | Cg_PhoR(CgtR3) / Cg_CgtR3 | cg2888 | 40.54% / 40.54% |
| 2 | Cg_CopR(CgtR9) | cg3285 | 40.18% / 40.91% |
| 3 | Cg_MprA(CgtR2) | cg0996 | 39.64% / 39.64% |
| 4 | Cg_CgtR5 | cg2947 | 38.74% / 39.09% |
| 5 | Cg_RegX3(CgtR4) | cg0484 | 36.94% / 37.27% |
| 6 | Cg_MtrA | cg0862 | 36.04% / 36.36% |
| 7 | Cg_CgtR1 | cg0330 | 35.14% / 35.14% |
| 8 | Cg_ChrA(CgtR8) | cg2200 | 26.89% / 28.83% |
| 9 | Cg_CitB | cg0090 | 26.55% / 27.78% |
| 10 | Cg_CgtR7 | cg0709 | 26.13% / 26.13% |
| 11 | Cg_HrrA(CgtR11) | cg3247 | 23.81% / 27.03% |
| 12 | Cg_CgtR6 | cg3061 | 22.12% / 22.52% |
| 13 | Cg_CgtR10 | cg1084 | 19.83% / 20.72% |

**Does the Sal_PhoP ranking differ from the Ec_OmpR ranking, and how?** [EVIDENCE, from `results/identity_rec.csv`] Substantially at the top: Ec_OmpR's #1 is **Cg_MtrA** (48.65%), which ranks only **6th** against Sal_PhoP (36.04%). Sal_PhoP's #1, **Cg_PhoR(CgtR3)/Cg_CgtR3** (40.54%), ranks 7th against Ec_OmpR (36.94%). Cg_CopR(CgtR9) and Cg_MprA(CgtR2) are the two RRs that rank highly against *both* donors (top-3 in each list). **[INFERENCE]** — reasoning: this divergence matters because Cg_MtrA is the best-characterized, most consequential native Ec_OmpR-family regulator in this organism (essential, well-studied), so a ranking exercise anchored on the wrong donor could deprioritize the wrong RR — this is exactly why the primary donor (Sal_PhoP), not just the backup (Ec_OmpR), needed its own ranked list reported, as this task asked for.

---

## Task 2 — rescoring against an intergenic null

### Intergenic regions: extraction and composition

No GFF3 was ever fetched for this repo; the cached feature table (`BX927147.ft.txt`, from the original cross-talk analysis) carries equivalent gene-coordinate data and was reused directly (script: `scripts/intergenic_null.py`). Intergenic = genome positions outside the union of all annotated CDS intervals. BX927147.1 is circular, but its first gene (dnaA) starts at position 1 — verified directly, not assumed — so the region after the last gene is an ordinary 76 bp terminal segment, not a true wraparound, and no special circular handling was needed.

- **2,509 merged CDS intervals** (from 3,058 individual gene/CDS records — 481 adjacent-gene pairs overlap, common in bacterial genomes, handled by interval merging) → **2,509 intergenic segments**.
- **Total intergenic: 414,950 bp = 12.64% of the 3,282,708 bp genome** [ESTIMATE, computed directly].
- **Observed intergenic composition**: A=0.2638, C=0.2385, G=0.2341, T=0.2636 (**GC=47.26%**), vs. whole-genome A=0.2307, C=0.2701, G=0.2683, T=0.2308 (GC=53.84%).
- **AT enrichment**: intergenic sequence is **52.74% AT vs. 46.16% AT genome-wide — a 6.58-percentage-point enrichment** [ESTIMATE]. This confirms the concern stated in the task: the whole-genome background used in the original scan systematically understated how common AT-rich sequence actually is in the specific compartment (intergenic DNA) where every HIGH_CONCERN hit, by definition, lives.

### Rebuilt background, rebuilt PWM

The Ec_PhoP PWM was rebuilt from the same 29 confirmed *E. coli* sites, against the intergenic background instead of whole-genome: **total IC drops from 9.56 to 8.28 bits** (`results/pwm_intergenic.txt`) — a weaker-looking motif, exactly as expected, because part of the original 9.56 bits was measuring "AT-rich relative to a GC-heavy whole genome," which is a smaller distinction once the background itself is already AT-enriched.

### Empirical null: per-segment dinucleotide shuffling

Each of the 2,509 intergenic segments was **independently** dinucleotide-shuffled (Altschul-Erikson; same verified algorithm as the original scan) and scored on both strands — shuffling segments independently, rather than concatenating them first, avoids inventing spurious dinucleotide transitions at segment junctions, and (importantly) lets every null window be mapped back to its exact position within the real segment it came from. That mapping is what makes the "expected by chance" calculation below exact rather than approximate: a null window's HIGH_CONCERN-eligibility (intergenic + within 400 bp upstream of a real gene) is computed with the *same* edge-based distance rule the original classifier uses, applied to the segment's real genomic coordinates — shuffling changes the sequence, not the segment's length or position.

Resulting null pool: **756,962 scores**, of which **535,264** (both strands) fall in HIGH_CONCERN-eligible genomic territory — this is the *exact* count of real (position, strand) window pairs in the genome that could possibly be classified HIGH_CONCERN, not an estimate.

### Corrected count

**82 of the original 304 HIGH_CONCERN hits (27%) also pass p≤10⁻⁴ under the intergenic null.** Full rescoring (new score, new empirical p, pass/fail flag) for every one of the 304 is in `results/intergenic_null.csv`, and the same three columns (`score_intergenic_bg`, `empirical_p_intergenic_null`, `passes_p1e-4_intergenic_null`) have been **added** to `results/hits_high_concern.csv` — the original whole-genome-null columns are untouched.

### Expected by chance

| Method | Expected HIGH_CONCERN hits at p≤10⁻⁴ | Basis |
|---|---|---|
| Analytical | **53.5** | 535,264 HC-eligible windows × 10⁻⁴ |
| Simulation | **64.0** | fraction of HC-eligible *null* windows exceeding the threshold score (10.23), scaled to the real HC-eligible window count |

**Observed 82 vs. expected 53.5-64.0**: a Poisson tail test (P(X≥82 \| λ)) gives **p=0.0002** against the analytical expectation and **p=0.017** against the (noisier, single-shuffle) simulation estimate [ESTIMATE, `scipy.stats.poisson.sf`]. This is a real, if modest, aggregate excess — not zero — but it is a 1.3-1.5× effect, not the dramatic-looking 304-vs-a-handful-of-known-sites framing the original report implied.

### What happened to the 9 "as extreme as confirmed sites" hits

**All 9 survive**, every one comfortably beyond the corrected p≤10⁻⁴ threshold:

| Gene/locus | Old score (whole-genome PWM) | Old p | New score (intergenic PWM) | New p | Survives? |
|---|---|---|---|---|---|
| cg2008 | 17.36 | 1.5×10⁻⁷ | 14.85 | 1.3×10⁻⁶ | Yes |
| cg0397 | 16.89 | 1.5×10⁻⁷ | 15.15 | 1.3×10⁻⁶ | Yes |
| cg1292 | 17.34 | 1.5×10⁻⁷ | 15.18 | 1.3×10⁻⁶ | Yes |
| cg1326 | 16.48 | 1.5×10⁻⁷ | 14.38 | 1.3×10⁻⁶ | Yes |
| cg1911 | 16.68 | 1.5×10⁻⁷ | 15.31 | 1.3×10⁻⁶ | Yes |
| **lysC (cg0306)** | **15.35** | **3.1×10⁻⁷** | **13.63** | **4.0×10⁻⁶** | **Yes** |
| cg2824 | 15.30 | 3.1×10⁻⁷ | 13.19 | 4.0×10⁻⁶ | Yes |
| cg1891 | 14.97 | 7.6×10⁻⁷ | 12.09 | 1.1×10⁻⁵ | Yes |
| cg2518 | 15.11 | 7.6×10⁻⁷ | 12.98 | 5.3×10⁻⁶ | Yes |

More broadly, **54/57 (95%) of the old p≤10⁻⁵ tier survive**, versus only **28/247 (11%) of the weaker hits** in the original 304. The residual signal after correction is not spread across the list — it is almost exactly the same small set that was already the strongest evidence.

---

## Task 3 — does this motif have the resolving power to answer the question?

**Standard information-theoretic benchmark**: a motif needs roughly **log₂(2L) bits** of information to expect fewer than one chance occurrence across a genome of length L scanned on both strands. For *C. glutamicum* (L=3,282,708 bp): **log₂(2×3,282,708) = 22.65 bits** [ESTIMATE].

**The Sal_PhoP PWM has 9.56 bits** (whole-genome background) or **8.28 bits** (intergenic background, the more appropriate comparison here). Either way, that is **13.1-14.4 bits short of what genome-scale specificity requires** — a shortfall of **2¹³·¹ ≈ 8,700-fold (whole-genome) to 2¹⁴·⁴ ≈ 21,100-fold (intergenic)** too many expected chance matches, by this standard benchmark [ESTIMATE, `log2(2×3282708) - IC`, both bases shown].

**Is the observed count distinguishable from noise?** For the bulk of the 304 (the great majority, per Task 2): **no, not confidently** — 82 observed against 53.5-64.0 expected is a small, borderline-significant excess that is fully consistent with "this motif is close to its resolution floor for a 3.3 Mb genome," exactly as the 13-14 bit shortfall predicts. For the extreme tail (9 hits, lysC included): **yes** — that subset clears both null models by 1-2 further orders of magnitude beyond the already-strict p≤10⁻⁴ line, survives a background-model change that eliminated 73% of the rest of the list, and (for lysC specifically) is corroborated by an independently-built PWM from a different source organism. A 9.56-13-bit motif genuinely cannot resolve *most* of a 3.3 Mb genome — but it can still surface a small number of individually well-supported candidates at its most extreme tail, the same way a weak GWAS signal can still contain one or two individually genome-wide-significant loci even when the bulk of nominal hits are noise.

**Correct verdict, stated plainly, per the distinction the task asked to make**: **"This motif cannot resolve most of what it flagged"** is the right characterization for the bulk of the original 304 — not "the operator is not clean." That stronger claim is not supported by evidence of this quality at this scale and is retracted for the bulk of the list (§ Revised verdict, below). It is *not* retracted for the small extreme-tail subset, where the evidence is of a qualitatively different (and adequate) strength.

**What would actually resolve this**, per the task's own framing:
1. **Published *Salmonella* Sal_PhoP ChIP-seq or ChIP-chip data** — would directly test whether Sal_PhoP occupies the lysC-*asd* intergenic region in vivo, sidestepping the whole sequence-motif resolving-power problem entirely. [NOT FOUND in this search — the literature located (Task 5, below) is DNase footprinting/EMSA at individually chosen promoters, not a genome-wide ChIP dataset; a targeted search for one was not separately conducted in this follow-up and would be a reasonable next step.]
2. **A higher-IC motif from more/better sites** — 9 Salmonella sites and 29 *E. coli* sites are both well below the count needed to tightly constrain a 16-17 bp motif; more confirmed sites (or a motif discovery pass over ChIP-seq peaks, which typically yields far more instances than one-off footprinting studies) would narrow the PWM and could plausibly add several bits.
3. **Direct experimental testing in the host** — EMSA with purified Sal_PhoP (Salmonella, the actual donor) against the cg0305-lysC intergenic fragment, or a reporter-fusion assay in *C. glutamicum* itself, is the only way to get a real answer for lysC specifically rather than a probability statement about a low-resolution motif.

---

## Task 4 — lysC: full deep dive

See **`results/lysc_analysis.md`** for the complete analysis (locus verification, operon context, intergenic confirmation, the translation-start-vs-TSS distinction, and both null-model scores side by side). Summary:

- **Locus verified**: cg0306, 269,371-270,636, **+ strand**, product "aspartokinase LysC alpha and beta subunits" — confirmed directly against the genome record, not assumed.
- **Operon context**: not obviously monocistronic — only **23 bp** separates lysC's stop from *asd*'s (aspartate-semialdehyde dehydrogenase, the next enzyme in the same pathway) start, consistent with (but not independently proven to be) a *lysC-asd* operon. No specific native transcriptional regulator of this exact promoter was found in a literature search.
- **Genuinely intergenic, confirmed**: the hit (269,204-269,220) sits in the 242 bp gap between cg0305 and lysC, overlapping neither CDS.
- **The 151 bp figure is measured from the translation start, not the TSS** — the two were not distinguished in the original report. The specific lysC TSS was [NOT FOUND] despite a genuine multi-source search (Pfeifer-Sancar 2013 primary text fetched directly and searched — no lysC-specific mention, only genome-wide statistics; that paper's supplementary tables blocked by a PMC bot-detection proof-of-work challenge; Albersmeier et al. 2017 blocked by an Elsevier bot-detection challenge; CoryneRegNet database defunct/unreachable). Genome-wide statistics from Pfeifer-Sancar 2013 bound the estimate: 33% of *C. glutamicum* genes are leaderless (TSS = translation start exactly), so **151 bp is a firm upper bound on distance-to-TSS, not necessarily the value itself** — the true distance is most likely somewhat less, given the genome-wide UTR-length distribution skews short.
- **Activator-spacing assessment** (reported separately from the number, per instruction): plausible-to-borderline. The confirmed *E. coli* Ec_PhoP sites used to build the PWM in this project cluster in the −30 to −60 bp range relative to the promoter (verified against the cached RegulonDB data: mgrRp −44, mgtSp −35, ompTp −59.5, hdeAp −32); 151 bp from the translation start is beyond that if lysC is leaderless, but squarely within it if lysC carries even a modest 5′-UTR. Not resolvable further without the actual TSS.
- **Score and significance survive the intergenic-null correction** (§Task 2): p=3.05×10⁻⁷ → p=3.96×10⁻⁶, both far inside the significant range.
- **Independently corroborated by the Salmonella-specific PWM** (§Task 5): scores 17.19/20.21 — the strongest match among the 9 most-extreme hits under that motif.

---

## Task 5 — retrying Salmonella-specific binding sites

**CollecTF**: retried at both its old domain (`collectf.umbc.edu`, still DNS-unreachable — confirmed by two independent tools) and its rebuilt `collectf.org` (live, HTTP 200, but a pure client-side React SPA; its JS bundle exposes only curator/auth API routes, no public search/browse API was discoverable). Genuinely inaccessible from this environment on both attempts.

**PRODORIC**: retried and **succeeded**. `prodoric.de` has a documented OpenAPI spec (`/api/openapi.json`); its `/prodonet/{organism_accession}` endpoint returns *Salmonella enterica*'s (accession AL513382.1) full regulatory network, which includes matrix **MX000339 — a curated Sal_PhoP binding-site collection**.

**9 confirmed Sal_PhoP sites obtained** [EVIDENCE, PRODORIC MX000339, cached at `data/cache/prodoric/`], each with DNase footprinting / EMSA / site-directed mutagenesis / expression-assay evidence, from four Groisman-lab-associated primary papers (resolved via CrossRef, matching exactly the literature source the task named):

| Operon | Site | Citation |
|---|---|---|
| pagC-ugtL | TAAATTCTCTCTAAAC | Perez, Latifi & Groisman 2008, *J Biol Chem* 283:26066-26076 |
| phoP | TTTATTAACTGTTTAT | Lejona, Aguirre, Cabeza, Vescovi & Soncini 2003, *J Bacteriol* 185:6287-6294 |
| mgtA | TTTATCGTTGGTTTAA | Lejona et al. 2003 |
| slyB | TTTAAGATTGGTTAAT | Lejona et al. 2003 |
| pcgL | TTAACCATCTGTTTAA | Lejona et al. 2003 |
| pmrD | TTGCCGTTTTGTTTAT | Lejona et al. 2003 |
| ssrB | TTAAAAGGCTGTTTAG | Bijlsma & Groisman 2005, *Mol Microbiol* 57:85-96 |
| iraP (×2) | TTTTTTGATGGTTTAT / TACGGATATGGTTTAA | Tu, Latifi, Bougdour, Gottesman & Groisman 2006, *PNAS* 103:13503-13508 |

Note: 9 sites is one short of the "at least 10" bar the original analysis targeted for *E. coli*; reported honestly rather than padded, but every site here carries multiple independent lines of experimental evidence per site (footprinting *and* EMSA *and* mutagenesis for several), arguably higher per-site confidence than a single-method-confirmed set.

**Second PWM built** (`results/pwm_salmonella.txt`, `scripts/salmonella_pwm.py`): 9 sites, 16 bp, **total IC = 10.15 bits** — slightly *higher* than the *E. coli* PWM (9.56 bits) despite far fewer training sites, consistent with these particular sites being drawn from tightly-characterized, high-confidence Groisman-lab promoters rather than a broader, noisier genome-wide RegulonDB collection.

**Position-by-position comparison**: best ungapped alignment between the two consensus sequences (`TGTTTATGATCTGTTTA` vs. `TTTATTATTTGTTTAT`) agrees at **13/15 positions (86.7%)** — both are the same `GTTTA`-direct-repeat architecture with a ~5 bp spacer. **The motifs do not differ materially**, consistent with the ~93% Sal_PhoP protein identity established in the earlier cross-talk analysis. Per the task's own branching instruction, this means a full genome rescan with the Salmonella PWM is not required.

**Confirmatory spot-check performed anyway** (lower cost than a full rescan, directly relevant to Task 4): the 9 most-extreme *C. glutamicum* hits were scored against the Salmonella PWM using a wide flanking search window. (A first attempt using only the narrow 17 bp *E. coli*-frame window gave misleadingly poor scores for every hit — traced to a ~12 bp systematic framing offset between how RegulonDB trims its "core" sites and where the PRODORIC-derived matrix expects its window, confirmed by showing the same narrow-window approach also scores most of the genuine *E. coli* training sites poorly against the Salmonella PWM, which a correct cross-species comparison should not do given how similar the two consensus sequences are once properly aligned.) With adequate flanking context, **all 9 score strongly positive** (9.0 to 17.2, out of a possible 20.2) — including **lysC at 17.19, the strongest of the 9** — directly addressing the concern that the whole scan was only ever a proxy for the primary donor: for the one hit that matters most, it is now a direct(ish) measurement, not just an inference from 93% protein identity.

**If CollecTF had remained the only recourse and PRODORIC had also failed**: this would have meant the scan was a proxy for the primary donor, not a direct measurement of it, quantified as: the substitution rests on 93.3% full-length Sal_PhoP protein identity between *Salmonella* and *E. coli* (established in the cross-talk analysis) but zero direct evidence that the *Salmonella*-specific DNA-recognition preferences match — a meaningfully weaker evidentiary chain than what was actually obtained here.

---

## Revised verdict

**The earlier verdict — "the Sal_PhoP operator is not clean in this host... the donor choice does need revisiting" — is partially retracted.** It was based on the whole-genome-null 304-hit count and (implicitly) treated that count as a coherent body of evidence. It was not: 73% of it (222/304) does not survive a properly-matched intergenic null and is statistically indistinguishable from what a 9.56-13-bit motif would flag by chance alone in this genome. **For the bulk of the original hit list, the correct conclusion is that the motif lacks the resolving power to answer the cross-talk question — not that the operator is unclean.** Revising this on better analysis is the right outcome, not a failure of the earlier work.

**What is not retracted**: the small extreme-tail subset (9 hits, 82 broader survivors concentrated around that same tail) clears every check applied to it — two independently-built null models (whole-genome, intergenic), two independently-sourced PWMs (*E. coli*-derived, *Salmonella*-derived), and, for lysC specifically, a direct operon/intergenic verification. This subset is not explained by compositional artifact. **lysC in particular remains the single highest-priority candidate for experimental follow-up identified anywhere in this project**, and the donor-choice question should be treated as open pending that experimental test (EMSA with purified *Salmonella* Sal_PhoP, or a reporter-fusion assay in the host, against the cg0305-lysC intergenic fragment) — not closed in either direction on sequence-motif evidence alone. The mitigation ordering from the original report (reposition/re-space the engineered operator; use a lower-genomic-similarity Sal_PhoP box variant; fall back to Ec_EnvZ/Ec_OmpR; response-regulator modification excluded) still applies if the lysC site is confirmed functional, but nothing in this follow-up changes that ordering or reopens the excluded option.

---

## Reproducing this analysis

```bash
pip install -r requirements.txt
python3 run_followup.py
```
Fully offline: every input (genome FASTA, feature table, RegulonDB Sal_PhoP/Ec_OmpR sites, PWMs, and the original scan's hit lists) was already cached by the earlier two analyses in this repo, plus the newly-fetched PRODORIC Sal_PhoP matrix (cached at `data/cache/prodoric/`). No genome or site data was re-fetched.