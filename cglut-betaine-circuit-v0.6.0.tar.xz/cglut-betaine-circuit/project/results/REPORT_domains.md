# Pfam domain annotation, transmembrane topology and H-box location
### Seven bacterial signalling proteins — boundaries, confidence, and what could not be resolved

Run date **2026-08-23**. Pipeline: `run_domain_annotation_v2.py`.
Outputs: `results/domain_boundaries_v2.csv`, `results/tm_predictions_v2.csv`, `data/domains_manifest_v2.csv`.

Every claim below is tagged **[EVIDENCE]** (a tool output or citable source states it),
**[INFERENCE]** (reasoning from evidence, with the step named), or **[NOT FOUND]**
(searched and absent, with what was searched).

---

## 0. Read this first — what could not be assigned confidently

Six things. All of them affect boundary numbers that downstream work would consume.

### 0.1 Salmonella PhoQ (requested `P14147`) has NO HisKA and NO HAMP domain that Pfam would accept

**[EVIDENCE]** `hmmscan --cut_ga` against PF00512/HisKA returns **nothing** for P0DM80. The hit exists
but scores **26.2 bits against a gathering threshold of 26.9** — it fails by **0.7 bits**. The HAMP hit
scores 21.9 (domain) but its *sequence* score of 22.4 fails the HAMP sequence GA of 25.0.

**[EVIDENCE]** InterPro's own Pfam annotation of P0DM80 lists `PF02518` (HATPase_c, 376-477),
`PF08918` (PhoQ_Sensor, 10-189) and `PF26769` (HAMP_PhoQ, 218-263) — **and no HisKA of any kind.**
Pfam itself does not assign a HisKA family to PhoQ.

**[EVIDENCE]** Yet PhoQ *is* a histidine kinase and its phosphoacceptor is real: UniProt P0DM80
annotates His277 as "Phosphohistidine; by autocatalysis" with evidence `ECO:0000269` — experimental.

**[INFERENCE]** (step: comparing a below-threshold model hit against a curated experimental
annotation) PhoQ carries a genuine but highly divergent DHp domain that the generic HisKA model
cannot detect at Pfam's own confidence bar. **The PhoQ HisKA boundary 270-327 in the CSV is LOW
confidence and must not be treated as a Pfam domain call.** The H-box position derived from it is
nevertheless correct, because it was validated against the experimental annotation independently
(§5).

### 0.2 `ECA_RS10935`: the UniProt entry is N-terminally truncated by 46 residues — every coordinate is offset

**[EVIDENCE]** UniProt `Q6D515` is 611 aa. RefSeq `WP_043878053.1`, the protein for locus
`ECA_RS10935`, is **657 aa**. Residues 2-611 of Q6D515 are byte-identical to residues 48-657 of the
RefSeq protein. The RefSeq protein carries an extra N-terminal
`MAKQLIQKKTMSTRAQVLLTGAFTIALGFAVTIGVLSWQSSSEQKSL`.

**[INFERENCE]** (step: exact substring alignment of the two sequences) **Q6D515 residue *i* maps to
RefSeq residue *i* + 46.** Anything computed on Q6D515 is offset by 46 relative to the gene model.

**[EVIDENCE]** The consequences are measurable, not cosmetic:
- Q6D515's Cache domain aligns to HMM columns **11-218** (the model's first 10 columns have nothing
  to align to). On the full-length protein it aligns to columns **2-218**, scores **higher**
  (54.6 vs 51.3 bits) and covers **41-312**.
- DeepTMHMM predicts **1** TM helix for Q6D515 and **2** for the full-length protein. The missing
  helix is TM1 (18-38), which lies entirely inside the truncated-away segment.
- Q6D515's topology is therefore nonsense as annotated: DeepTMHMM places its whole 271-residue Cache
  domain "outside" (periplasmic) with no membrane anchor and no signal peptide preceding it.

**Both are reported.** `Q6D515` rows are kept because that is the accession UniProt serves, and
`WP_043878053.1` rows are added as the biologically correct full-length annotation. **Use the
`WP_043878053.1` rows.**

### 0.3 PA4633 carries a HisKA-family hit with NO identifiable H-box histidine

This is the negative result requested in Task 3, stated in the lead rather than a footnote.

**[EVIDENCE]** `Q9HVF8` (PA4633) produces a PF07730/HisKA_3 hit at **580-620**. Its H-box histidine
is **[NOT FOUND]**: the alignment covers HisKA_3 match-state columns **27-67**, and the H-box column
of HisKA_3 is column **10** (P(His) = 0.898, derived from the model's own emission probabilities).
The alignment does not reach the H-box column at all, so no residue can be assigned.

**[EVIDENCE]** The hit is noise regardless: its domain score is 10.6 against a gathering threshold of
24.0, and its **whole-sequence score is negative (-2.0)**.

**[EVIDENCE]** The same region is covered far better by `PF00015` (MCPsignal) at 495-678 scoring
**153.9 bits** — 14× the HisKA_3 score.

**[INFERENCE]** (step: comparing competing model scores over one region) PA4633 is a methyl-accepting
chemotaxis protein, not a histidine kinase. It has no H-box because it has no kinase domain. The
HisKA_3 row is retained in the CSV flagged LOW so the absence is visible, not silently dropped.

### 0.4 `PF02743` (Cache_1 / dCache_1) is absent from PA4633 and McpX

**[NOT FOUND]** Searched: `hmmscan` against PF02743.26 at gathering threshold *and* permissively at
`-E 10 --domE 10`. Neither `Q9HVF8` nor `Q92SH9` produces any PF02743 hit at any threshold.

**[EVIDENCE]** InterPro confirms: neither protein carries a PF02743 annotation.

**[EVIDENCE]** McpX's periplasmic sensor is a different Pfam family — `PF22673` (MCP-like_PDC_1) at
**93-215**, scoring 52.0 bits. PA4633's periplasmic sensor region (32-360) matches **none** of the
twelve Pfam models scanned.

**[INFERENCE]** (step: the requested model list does not contain the family that actually covers the
region) Absence of Cache_1 in these two proteins is a real property of the model set, not a pipeline
failure. Note also that **Pfam's current name for PF02743 is `dCache_1`, not `Cache_1`** — same
accession, renamed family.

### 0.5 Boundaries flagged MEDIUM or LOW — the complete list

| Type | Protein | Feature | Boundary | Confidence | Why |
|---|---|---|---|---|---|
| Domain | P0DM80 (PhoQ) | HisKA | 270-327 | **LOW** | 26.2 bits < GA 26.9 — Pfam rejects it |
| Domain | P0DM80 (PhoQ) | HAMP | 213-262 | **LOW** | seq score 22.4 < seq-GA 25.0 |
| Domain | Q9HVF8 (PA4633) | HisKA_3 | 580-620 | **LOW** | 10.6 bits < GA 24.0; seq score **-2.0** |
| Domain | Q92SH9 (McpX) | HAMP | 339-390 | **MEDIUM** | passes GA but weak, i-E 1.1e-07 |
| Domain | Q92SH9 (McpX) | HAMP | 429-471 | **MEDIUM** | passes GA but weak, i-E 1.2e-07 |
| TM | WP_043878053.1 | TM1 | 18-38 | **MEDIUM** | DeepTMHMM only; no UniProt helix to cross-check (Kyte-Doolittle within 3 aa) |

### 0.6 Two TM boundaries sit exactly on the MEDIUM cutoff

**[EVIDENCE]** `Q9HVF8` TM1 (DeepTMHMM 11-31 vs UniProt 6-31) and TM2 (361-379 vs 363-384) each
disagree by **exactly 5 residues**. The rubric says MEDIUM at *more than* 5, so both compute as HIGH.
They are flagged here because they are borderline and because the UniProt side is `ECO:0000256`
(automatic annotation — the weakest evidence tier). Treat the N-terminus of TM1 and the C-terminus of
TM2 as ±5.

---

## 1. Tools and versions — stated plainly

| Purpose | Tool | Version | Notes |
|---|---|---|---|
| Domain search | **`hmmscan`** | HMMER 3.4 (Aug 2023) | `hmmscan`, not `hmmsearch` — queries are proteins, database is profiles |
| Domain thresholds | Pfam curated **GA** | per-model | `--cut_ga`; every model's own gathering threshold |
| TM prediction | **DeepTMHMM 1.0.57** | `DTU/DeepTMHMM:1.0.57` | **A real TM predictor was available and used.** Run via `pybiolib` 1.4.363 on BioLib cloud |
| TM cross-check 1 | UniProt curated topology | — | `ECO:0000255/0000256/0000305` — all *inference*, none experimental |
| TM cross-check 2 | Kyte-Doolittle | window 19 | weakest method; used only as a third opinion |
| Boundary cross-check | InterPro Pfam API | accessed 2026-08-23 | independent of the local scan |

**On DeepTMHMM:** it is not installable locally any more — `pybiolib` refuses `machine="local"`
("Running applications locally with machine='local' is no longer supported"). It ran on BioLib's
cloud instead. The sequences submitted are public UniProt/RefSeq entries. **No fallback to
hydrophobicity analysis was needed**; Kyte-Doolittle appears only as a cross-check column.

---

## 2. Accession resolution

**[EVIDENCE]** Full provenance in `data/domains_manifest_v2.csv` (accession → organism → protein name
→ retrieval date → source URL → resolution note).

| Requested | Used | Protein | How resolved |
|---|---|---|---|
| `P14147` | **P0DM80** | PhoQ, *S.* Typhimurium LT2 | **Requested accession is dead.** UniProt REST returns `entryType: Inactive`, `inactiveReasonType: DEMERGED`, `mergeDemergeTo: [E1WFA0, P0DM80]`, former ID `PHOQ_SALTY`. LT2 chosen over SL1344 (E1WFA0) to stay strain-cognate with P0DM78 |
| `P0DM78` | P0DM78 | PhoP | active, used as given |
| `P0AEJ4` | P0AEJ4 | EnvZ | active, used as given |
| `P0AA16` | P0AA16 | OmpR | active, used as given |
| `PA4633` | **Q9HVF8** | Probable chemotaxis transducer | Locus tag. UniProt entry Q9HVF8 carries `GN=PA4633` in the FASTA header itself |
| `ECA_RS10935` | **Q6D515** + **WP_043878053.1** | MCP | NCBI Gene 2883412 lists `otheraliases: ECA_RS10935, ECA2226`; UniProt Q6D515 carries `GN=ECA2226`. See §0.2 — **use the RefSeq entry** |
| `McpX`, *S. meliloti* | **Q92SH9** | Chemoreceptor McpX | Resolved from the name. UniProt query `gene:mcpX AND organism_id:266834` returns exactly one entry: Q92SH9, gene names `mcpX SMc01104`, 788 aa |

**No accession failed to resolve.** One (`P14147`) was dead and required substitution; one
(`ECA_RS10935`) resolved to a truncated entry and required a second, better source.

---

## 3. Task 1 — domain annotation

`results/domain_boundaries_v2.csv`, one row per domain hit, **descending bit score within each
protein**. `hmmscan`, HMMER 3.4, `--cut_ga`.

### 3.1 Domains that pass Pfam's gathering threshold

| Protein | Model | Acc | Start | End | Len | Bit | i-E | Conf |
|---|---|---|---:|---:|---:|---:|---|---|
| P0AA16 OmpR | Response_reg | PF00072.31 | 7 | 117 | 111 | 107.2 | 1.8e-34 | HIGH |
| P0DM78 PhoP | Response_reg | PF00072.31 | 4 | 113 | 110 | 89.6 | 5.6e-29 | HIGH |
| P0AEJ4 EnvZ | HATPase_c | PF02518.32 | 334 | 439 | 106 | 86.5 | 5.9e-28 | HIGH |
| P0AEJ4 EnvZ | HisKA | PF00512.32 | 234 | 290 | 57 | 46.5 | 1.1e-15 | HIGH |
| P0AEJ4 EnvZ | HAMP | PF00672.31 | 177 | 226 | 50 | 32.6 | 2.9e-11 | HIGH |
| P0DM80 PhoQ | HATPase_c | PF02518.32 | 376 | 477 | 102 | 61.3 | 4.0e-20 | HIGH |
| **WP_043878053.1** | dCache_1 | PF02743.26 | 41 | 312 | 272 | 54.6 | 6.9e-18 | HIGH |
| Q6D515 *(truncated)* | dCache_1 | PF02743.26 | 4 | 266 | 263 | 51.3 | 7.0e-17 | HIGH |
| Q9HVF8 PA4633 | HAMP | PF00672.31 | 382 | 431 | 50 | 40.4 | 1.1e-13 | HIGH |
| Q92SH9 McpX | HAMP | PF00672.31 | 339 | 390 | 52 | 21.1 | 1.1e-07 | **MEDIUM** |
| Q92SH9 McpX | HAMP | PF00672.31 | 429 | 471 | 43 | 21.0 | 1.2e-07 | **MEDIUM** |

**[EVIDENCE]** Every one of these boundaries was cross-checked against InterPro's independent Pfam
annotation and **all agree exactly, to the residue** (P0AEJ4 HisKA 234-290, HAMP 177-226, HATPase_c
334-439; P0DM80 HATPase_c 376-477; P0DM78 4-113; P0AA16 7-117; Q9HVF8 HAMP 382-431; Q92SH9 HAMP
339-390 and 429-471; Q6D515 dCache_1 4-266).

### 3.2 Hits reported but rejected by Pfam's own threshold

| Protein | Model | Start | End | Bit | GA | Seq score | Verdict |
|---|---|---:|---:|---:|---:|---:|---|
| P0DM80 PhoQ | HisKA | 270 | 327 | 26.2 | 26.9 | 26.2 | fails by 0.7 bits |
| P0DM80 PhoQ | HAMP | 213 | 262 | 21.9 | 15.0 dom / 25.0 seq | 22.4 | fails sequence GA |
| Q9HVF8 PA4633 | HisKA_3 | 580 | 620 | 10.6 | 24.0 | **-2.0** | noise |

### 3.3 Proteins with no hit to an expected model — called out explicitly

- **P0DM80 (PhoQ) — MISSING `HisKA` and `HAMP`.** Expected for a sensor histidine kinase; neither
  passes GA. See §0.1. **[NOT FOUND]** (searched: PF00512, PF07568, PF07730, PF00672 at GA and at
  `-E 10`).
- **Q9HVF8 (PA4633) — MISSING `dCache_1`.** **[NOT FOUND]** (searched: PF02743 at GA and `-E 10`).
  Its sensor region matches none of the twelve models scanned.
- **Q92SH9 (McpX) — MISSING `dCache_1`.** **[NOT FOUND]** (same search). Its sensor is PF22673
  (MCP-like_PDC_1, 93-215, 52.0 bits) instead.
- **P0DM78, P0AA16, P0AEJ4, Q6D515/WP_043878053.1** — nothing expected is missing.
- **`PF07568` (HisKA_2) matched no protein in this set at any threshold.** **[NOT FOUND]**.

---

## 4. Task 2 — transmembrane prediction

**Tool: DeepTMHMM 1.0.57.** `results/tm_predictions_v2.csv`. Topology labels are DeepTMHMM's own
(`inside` = cytoplasmic, `outside` = periplasmic).

| Protein | # TM | Helices | Topology |
|---|---:|---|---|
| P0DM80 PhoQ | 2 | **17-38**, **195-215** | cyto 1-16 → **TM1** → peri 39-194 → **TM2** → cyto 216-487 |
| P0DM78 PhoP | **0** | — | cytoplasmic 1-224 (soluble) |
| P0AEJ4 EnvZ | 2 | **15-35**, **160-178** | cyto 1-14 → **TM1** → peri 36-159 → **TM2** → cyto 179-450 |
| P0AA16 OmpR | **0** | — | cytoplasmic 1-239 (soluble) |
| Q9HVF8 PA4633 | 2 | **11-31**, **361-379** | cyto 1-10 → **TM1** → peri 32-360 → **TM2** → cyto 380-712 |
| Q6D515 *(truncated)* | **1** | **272-292** | peri 1-271 → **TM1** → cyto 293-611 — **artefactual, see §0.2** |
| **WP_043878053.1** | 2 | **18-38**, **318-338** | cyto 1-17 → **TM1** → peri 39-317 → **TM2** → cyto 339-657 |
| Q92SH9 McpX | 2 | **13-33**, **318-338** | cyto 1-12 → **TM1** → peri 34-317 → **TM2** → cyto 339-788 |

**On per-helix confidence:** **[NOT FOUND]** — DeepTMHMM's `TMRs.gff3` and `.3line` outputs do not
carry a per-helix posterior probability, only per-residue topology labels. Since no numeric
per-helix confidence is emitted, confidence here is assigned by **cross-method agreement** instead,
which is stated per helix in the CSV (`max_delta_vs_uniprot_aa`, `max_delta_vs_kd_aa`). Claiming a
posterior the tool did not report would be fabrication.

**[EVIDENCE]** Agreement with UniProt's curated topology is excellent: 7 of 9 cross-checkable helices
agree within **1 residue**; the remaining two (Q9HVF8) within 5.

**[EVIDENCE]** No signal peptide was predicted for any of the eight sequences (no `S` labels in the
DeepTMHMM output).

**[INFERENCE]** (step: both soluble proteins are response regulators, which act in the cytoplasm)
PhoP and OmpR having zero TM helices is the expected result, not a failure.

---

## 5. Task 3 — the conserved H-box histidine

**Method — stated as required.** Two independent steps, so the answer does not rest on either alone:

1. **[EVIDENCE]** For each HisKA-family model, the H-box match-state column was derived from the
   model's **own emission probabilities** — the column where P(His) is maximal:
   `HisKA` col **11** (P = 0.794), `HisKA_2` col **4** (P = 0.843), `HisKA_3` col **10** (P = 0.898).
   Each model is read in its own coordinate system; a column index is **not** portable between
   models.
2. **[EVIDENCE]** That column was validated against **experimentally confirmed phosphohistidines**:

| Reference | H-box column → residue | UniProt annotation | Evidence | Agreement |
|---|---|---|---|---|
| *E. coli* **EnvZ** `P0AEJ4` | HisKA col 11 → **H243** | Phosphohistidine; by autocatalysis | `ECO:0000269` (experimental) | **AGREE** |
| *Salmonella* **PhoQ** `P0DM80` | HisKA col 11 → **H277** | Phosphohistidine; by autocatalysis | `ECO:0000269` (experimental) | **AGREE** |

Both named references reproduce their known histidine exactly. The method is calibrated, not assumed.

### Results

| Protein | Model | H-box | Confidence | Note |
|---|---|---|---|---|
| **P0AEJ4** EnvZ | HisKA (passes GA) | **His243** | **HIGH** | matches experimental annotation |
| **P0DM80** PhoQ | HisKA (**fails GA**) | **His277** | **HIGH** *(residue)* / LOW *(domain boundary)* | matches experimental annotation; see below |
| **Q9HVF8** PA4633 | HisKA_3 (**fails GA**) | **NONE — [NOT FOUND]** | — | **negative result, see §0.3** |

**[INFERENCE]** (step: separating the residue call from the domain call) P0DM80's H-box **residue**
is HIGH confidence even though its HisKA **domain boundary** is LOW, because the residue is
independently confirmed by an experimental UniProt annotation, whereas the boundary rests only on a
sub-threshold HMM hit. These two numbers have different reliability and are reported separately
rather than averaged into one.

**No protein carrying a *GA-passing* HisKA-family hit lacks an H-box histidine.** The one protein
lacking it — PA4633 — carries only a sub-threshold hit with a negative sequence score.

---

## 6. Task 4 — boundary confidence

Rubric as specified: **HIGH** = strong hit, i-E < 1e-10, boundaries agree across methods;
**MEDIUM** = present but weak, or methods disagree by > 5 residues; **LOW** = inferred, or the only
support is a single weak hit.

Applied mechanically in `run_domain_annotation_v2.py`; every row carries `confidence` and
`confidence_reason`. Counts: **domains** 9 HIGH, 2 MEDIUM, 3 LOW. **TM helices** 10 HIGH, 1 MEDIUM.

**The complete MEDIUM/LOW list is in §0.5**, and the two borderline-HIGH TM boundaries in §0.6. They
are in the summary, not only in the tables, as required.

---

## 7. Where two Pfam models compete for the same region

**[EVIDENCE]** Within the **seven requested models**, no two models overlap on any protein — there is
no competition to adjudicate. To answer the question properly the scan was repeated with five
additional Pfam families that InterPro assigns to these proteins (`PF26769`, `PF08918`, `PF00015`,
`PF22673`, `PF00486`). Three genuine competitions appear. **Both models are reported in each case**,
with the higher scorer named:

| Protein | Region | Model A | Model B | **Higher** |
|---|---|---|---|---|
| P0DM80 PhoQ | ~213-263 | `PF00672` HAMP — 21.9 bits, **fails GA** | `PF26769` HAMP_PhoQ — 34.3 bits, 218-263, **passes GA** | **PF26769 HAMP_PhoQ** |
| Q6D515 / WP_043878053.1 | N-terminal sensor | `PF02743` dCache_1 — **51.3** / **54.6** bits | `PF22673` MCP-like_PDC_1 — 37.8 / 37.6 bits | **PF02743 dCache_1** |
| Q9HVF8 PA4633 | ~580-620 | `PF07730` HisKA_3 — 10.6 bits, fails GA | `PF00015` MCPsignal — 153.9 bits, 495-678 | **PF00015 MCPsignal** |

**[INFERENCE]** (step: the winning model in each case is the one Pfam actually assigns in InterPro)
PhoQ's HAMP region is real but belongs to a PhoQ-specific HAMP family, which is *why* the generic
HAMP model falls below threshold — the competition explains the apparent absence in §0.1.

---

## 8. Reproducibility

```bash
pip install -r requirements_domains.txt
brew install hmmer                      # HMMER 3.4; hmmscan/hmmpress on PATH

python3 run_domain_annotation_v2.py                 # offline, from cached data
python3 run_domain_annotation_v2.py --refresh-tm    # also re-runs DeepTMHMM (network)
```

The default run touches the network **only** if a cached input is missing. All FASTAs
(`data/fasta/`), all HMMs (`data/cache/pfam/`) and the DeepTMHMM output
(`data/cache/deeptmhmm/`) are cached in-repo. See `README_domains.md` for what was fetched and when.

---

## 9. Correction to the earlier run in this repo

An earlier pipeline (`run_domain_annotation.py`, `results/domain_boundaries.csv`,
`results/tm_predictions.csv`, 2026-08-23 15:59) covered the same task. **Those files were left
untouched** per the no-overwrite instruction; v2 writes to `*_v2.csv`. Three defects in it are worth
recording, because its numbers are still on disk:

1. **[EVIDENCE]** It scored with `--domE 1e-3`, bypassing Pfam's gathering thresholds, and so
   reported three domains that Pfam rejects (§3.2) — including a HisKA_3 "domain" whose sequence
   score is negative — with confidences of MEDIUM rather than LOW.
2. **[EVIDENCE]** Its Kyte-Doolittle TM caller emitted **overlapping duplicate helices**
   (e.g. P0AEJ4 "TM2" 160-179 and "TM3" 163-182) and **loops of negative length**
   (e.g. `loop2,219,202,-16`). v2's output tiles every protein with no gaps, no overlaps and no
   negative lengths.
3. **[EVIDENCE]** It transferred the H-box column index **from HisKA onto HisKA_3**, which are
   different models with different coordinate systems. v2 derives the column separately per model.

It also reported no TM predictor was available. **DeepTMHMM was in fact installable and was used
here.**
