# Host restriction-modification screen: 95 constructs vs C. glutamicum ATCC 13032

Run by `scripts/rm_screen.py` against the host R-M subset added to `scripts/seqchecks.py`. This report is generated from `results/host_rm_systems.csv` and `results/rm_screen_results.csv` by `scripts/report_rm_screen.py`.

Tags: **[EVIDENCE]** from a fetched, cached source or computed here. **[INFERENCE]** reasoning from evidence, step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent.

**No recognition sequence in this report was written from memory.** Every motif is quoted from REBASE version 608, downloaded and cached at `data/cache/rebase/link_orgref.txt` (http://rebase.neb.com/rebase/link_orgref, build dated Jul 31 2026). Supporting literature is cached at `data/cache/literature/rm/pubmed_rm_records.xml`.

---

## 0. LEAD

### Which systems were sourced, and which could not be

| system | recognition sequence | sourced? | screened? | why |
|---|---|---|---|---|
| **CglI** | `GCSGC` | **yes** — REBASE v608, source strain **ATCC 13032**, prototype `TauI` | **yes** | the host's characterised restriction system; documented transformation barrier |
| **Cgl13032I** | `GGCGCA` | **yes** — REBASE v608, **ATCC 13032**, m6A at position 6 | **yes** | motif sourced; cognate restriction activity **[NOT FOUND]** |
| **Cgl13032II** | `ACGABGG` | **yes** — REBASE v608, **ATCC 13032**, m6A at position 4 | **yes** | motif sourced; cognate restriction activity **[NOT FOUND]** |
| CglAI | `GCATGC` (SphI) | yes, but for a **different strain** | **no** | REBASE source is strain `NEB 968`, not ATCC 13032 — screening it would be a false constraint |
| CglAII | `GTCGAC` (SalI) | yes, but for a **different strain** | **no** | REBASE source strain `NEB 968`, not ATCC 13032 |
| Cgl165I | **[NOT FOUND]** | **no** — REBASE records the recognition sequence literally as `?` | **no** | excluded rather than guessed; strain 165 in any case |
| predicted Type IV REase (`cg2664`) | n/a — targets **methylated DNA**, not a sequence | gene sourced from the genome record | **cannot be** | sequence screening does not address Type IV at all — see §4 |

### Total constructs affected

**28 of 95 constructs carry at least one host R-M site**; 67 are clean. [EVIDENCE] That is **50 physical sites** (60 strand-instances — `GCSGC` is its own reverse complement, so every CglI site is seen on both strands).

| system | physical sites | constructs affected |
|---|---|---|
| `Cgl13032II` | 39 | 19 |
| `CglI` | 10 | 9 |
| `Cgl13032I` | 1 | 1 |
| **total** | **50** | **28** |

### Is anything unfixable?

**Yes — 6 sites, in 6 constructs, and all of them are CglI.** [EVIDENCE] They sit inside **sourced** sequence: a native promoter amplicon, a published primer tail, and a published fore-cistron. They cannot be edited without abandoning the component. Every one of the other **44 sites is in coding sequence and every one is fixable by a single synonymous substitution**, none needing a codon below the optimiser's usage floor.

**But the more important answer is that sequence editing is not the main lever here.** [EVIDENCE, §4] Pre-methylating the plasmid with the host's own M.CglI methyltransferase — by preparing it in an *E. coli* strain expressing `cglIM` — raised C. glutamicum ATCC 13032 transformation efficiency from 1.8×10² to 5.2×10⁶ cfu/µg in the published work, roughly **4 orders of magnitude**. That protects *every* CglI site at once, including the 6 structural ones. This is a CRO protocol question, not a design fix.

---

## 1. Task 1 — the host R-M systems

### Genes, resolved against BOTH genome records

The repo has been bitten twice by assuming `cg` and `NCgl` numbering are interchangeable, so both were parsed and reconciled by coordinate and length rather than by number. [EVIDENCE]

| BX927147.1 (`cg`) | gene | coordinates | product (annotation) | NC_003450 (`NCgl`) | role per Šikšnys/NAR 2014 |
|---|---|---|---|---|---|
| `cg1996` | cglIM | 1879784..1880875 (+), 1092 nt | MODIFICATION METHYLASE | `NCgl1703` (1878312..1879403, 1092 nt) — DNA cytosine methyltransferase | **M.CglI** |
| `cg1997` | cglIR | 1880884..1881960 (+), 1077 nt | TYPE II RESTRICTION ENDONUCLEASE | `NCgl1704` (1879412..1880488, 1077 nt) — restriction endonuclease, PLD domain | **R.CglI** |
| `cg1998` | cglIIR | 1881962..1883860 (+) | RESTRICTION ENDONUCLEASE CGLIIR PROTEIN | `NCgl1705` (1880529..1882388) — Z1 domain protein | **N.CglI** |
| `cg2664` | — | 2540887..2541972 (+) | **Predicted type IV restriction endonuclease** | [NOT FOUND — not resolved here] | — |

**The `cg` and `NCgl` coordinates differ by ~1,470 bp and the numbers differ by 293.** [EVIDENCE] The mapping was established by matching CDS lengths exactly (1092/1092 and 1077/1077) and by an independent cross-check: Schäfer et al. 1997 report `cglIM` as 1092 nucleotides encoding 363 amino acids, and `cg1996` is exactly 1092 nt = 363 aa + stop.

**One naming trap worth stating plainly.** [INFERENCE, reasoning named] The BX927147.1 annotation calls `cg1998` "cglIIR / RESTRICTION ENDONUCLEASE CGLIIR", which reads as a second, separate enzyme *CglII*. It is not. By coordinate and length it is `NCgl1705`, which the 2014 *Nucleic Acids Research* work on this system identifies as **N.CglI** — the auxiliary N-protein of the single CglI system, which the paper shows is *required together with* R.CglI for cleavage. There is **one** restriction system here (M + R + N), not two. REBASE agrees: it lists `CglI` and no `CglII`.

### Systems, types and recognition sequences

| system | type | recognition | activity | characterised or predicted | source |
|---|---|---|---|---|---|
| `CglI` | Type II-like (prototype TauI, GCSG^C) | `GCSGC` | restriction endonuclease + cognate methyltransferase | characterised | REBASE v608 (Roberts, R.J.), record CglI; ref therein Ikeda, M. & Nakagawa, S. |
| `Cgl13032I` | not stated by the source | `GGCGCA` | methyltransferase specificity; cognate restriction activity NOT STATED | specificity recorded in REBASE from unpublished observations | REBASE v608, record Cgl13032I; ref Morgan, R.D., unpublished observations |
| `Cgl13032II` | not stated by the source | `ACGABGG` | methyltransferase specificity; cognate restriction activity NOT STATED | specificity recorded in REBASE from unpublished observations | REBASE v608, record Cgl13032II; ref Binder, S., Schendzielorz, G., Staebler, N |
| `CglAI` | — | — | — | excluded from the screen | REBASE v608 |
| `CglAII` | — | — | — | excluded from the screen | REBASE v608 |
| `Cgl165I` | — | — | — | excluded from the screen | REBASE v608 |
| `predicted Type IV REase (cg2664)` | Type IV | `n/a - targets METHYLATED DNA, not a sequence` | restriction of modified DNA | computationally predicted | BX927147.1 feature table, product 'Predicted type IV restriction endonuclease' |

**Distinctions maintained, as required:**

- **CglI is a restriction activity with a cognate methyltransferase.** Its REBASE prototype is `TauI`, a characterised, commercially available Type II REase cutting `GCSG^C`. The 2014 NAR work notes CglI "does not readily conform to the classical Types" and proposes it as a sub-class with characteristics of **both Type I and Type II**. It is screenable by sequence either way, because its recognition site is a short, contiguous, non-bipartite motif. [EVIDENCE]
- **`Cgl13032I` and `Cgl13032II` are recorded in REBASE as methyltransferase specificities.** Both have a methylation site given, no prototype, no commercial availability, and unpublished-observation provenance — REBASE's signature for a methylome-detected MTase. **Whether either has a cognate restriction enzyme is [NOT FOUND].** [INFERENCE, reasoning named] A methyltransferase without a cognate REase protects DNA rather than cutting it, so these two are screened and reported but **graded as an unresolved hazard class, not as confirmed hazards**.
- **No Type I system was found** with a bipartite recognition sequence for this strain. [NOT FOUND] `cg0844` is annotated "Type II restriction enzyme, methylase subunit" and `cg1028` "PUTATIVE RESTRICTION-MODIFICATION SYSTEM: METHYLASE", but REBASE assigns them no recognition sequence, so nothing about them is screenable and nothing is guessed.
- **The Type IV system is reported separately in §4 and is not sequence-screenable at all.**

### A tension between sources, reported rather than resolved

Jang, Chambers & Britz 1996 (FEMS Microbiol Lett 136:309-15) analysed nucleotides in C. glutamicum DNA and **"failed to detect significant levels of methylated adenosine, but methylated cytidine was readily detected"**. [EVIDENCE] Both `Cgl13032I` and `Cgl13032II` are recorded by REBASE as **m6A** specificities. Those statements sit awkwardly together. [INFERENCE] They are not a flat contradiction — a bulk HPLC assay from 1996 could miss a low-abundance motif that later single-molecule methylome sequencing detects — but the m6A systems' status is genuinely less settled than CglI's, which is consistent with grading them separately above.

---

## 2. Task 2 — the screen

All 95 constructs from `designs/order_manifest_final_v4.csv`, both strands, using `seqchecks.host_rm_scan`. Degenerate codes are expanded by `iupac_regex`; overlapping occurrences are counted separately because two overlapping sites are two substrates. Independently cross-checked with a plain regex count outside the module: **exact agreement on all three motifs.** [EVIDENCE]

| system | motif | concrete sequences | site-instances | physical sites | constructs |
|---|---|---|---|---|---|
| `CglI` | `GCSGC` | `GCCGC`, `GCGGC` | 20 | 10 | 9 |
| `Cgl13032I` | `GGCGCA` | `GGCGCA` | 1 | 1 | 1 |
| `Cgl13032II` | `ACGABGG` | `ACGACGG`, `ACGAGGG`, `ACGATGG` | 39 | 39 | 19 |

### Where the sites are

| region class | physical sites | meaning |
|---|---|---|
| **CODING** | 44 | inside a codon-containing region (the kinase CDSs) — editable by synonymous substitution |
| **SOURCED** | 6 | inside a native promoter amplicon, primer tail or fore-cistron — **not editable without abandoning the component** |
| **DESIGNED non-coding** | 0 | backgrounds, spacers, fillers |

**No site falls in a designed non-coding region.** [EVIDENCE] That matters because the substitution phasing arm holds GC exactly invariant by construction, and editing a background would break it. The screen never puts that constraint at risk.

### By panel

| panel | site-instances | constructs affected |
|---|---|---|
| `kinase_junction_core_second_sensor` | 24 | 6 |
| `kinase_junction_core_primary` | 14 | 12 |
| `kinase_junction_alt_backbone` | 10 | 4 |
| `retained_context` | 6 | 3 |
| `tier1_nonphasing` | 4 | 2 |
| `combinatorial_2_tuning_curve` | 2 | 1 |

### Constructs carrying multiple sites — risk compounds

| construct | physical sites | systems |
|---|---|---|
| `JXN_MCPX_PHOQ_A_0` | 4 | Cgl13032II×4 |
| `JXN_MCPX_PHOQ_A_m1` | 4 | Cgl13032II×4 |
| `JXN_MCPX_PHOQ_A_p1` | 4 | Cgl13032II×4 |
| `JXN_MCPX_PHOQ_dhp_direct_0` | 4 | Cgl13032II×4 |
| `JXN_MCPX_PHOQ_dhp_direct_m1` | 4 | Cgl13032II×4 |
| `JXN_MCPX_PHOQ_dhp_direct_p1` | 4 | Cgl13032II×4 |
| `JXN_ECA_ENVZ_A_0` | 3 | Cgl13032I×1, CglI×2 |
| `JXN_ECA_PHOQ_A_p1` | 2 | Cgl13032II×2 |
| `JXN_ECA_PHOQ_C_p1` | 2 | Cgl13032II×2 |

9 constructs carry more than one site; 19 carry exactly one. **`JXN_ECA_ENVZ_A_0` is the worst case at 3 sites.** [EVIDENCE] Full per-site detail — construct, system, motif, matched sequence, position, strand, component and fixability — is one row per strand-instance in `results/rm_screen_results.csv` (60 rows).

### An observation that changes how the numbers should be read

| motif | host genome obs/exp | this panel obs/exp | kinase CDS obs/exp | non-kinase obs/exp |
|---|---|---|---|---|
| `GCSGC` (CglI) | 0.90 | **0.08** | **0.03** | 1.06 |
| `GGCGCA` (Cgl13032I) | 1.36 | 0.04 | 0.04 | 0.00 |
| `ACGABGG` (Cgl13032II) | 0.99 | **2.06** | **2.24** | 0.00 |

[EVIDENCE, computed against BX927147.1 with per-sequence base composition] The host genome sits at roughly the expected frequency for all three motifs — it does not avoid its own sites, which is what one expects of a genome protected by its own methyltransferase. The panel is a different story, and the difference is confined to the **codon-optimised kinase CDSs**: CglI sites are depleted ~30-fold there and Cgl13032II sites are enriched ~2.2-fold. [INFERENCE, reasoning named] The codon optimiser targets host GC with a greedy walk that pulls running GC back toward 53.8% whenever it drifts, which disfavours the GC-rich `GCSGC` (4–5 of 5 bases G or C) and incidentally favours the AT-richer `ACGABGG`. **This was not designed for and is not a safety margin anyone chose** — it is a side effect, and it is reported so that nobody later mistakes it for a deliberate feature.

---

## 3. Task 3 — fixability

### Coding sites

For each of the **44** sites in coding sequence, every combination of synonymous codons across every codon the site overlaps was enumerated exhaustively — the same approach used for the kinase enzyme screen — and tested for whether it clears the motif without creating another in a padded window. This reports whether a fix **exists**, not whether a greedy pass happens to find one. [EVIDENCE]

|  | count |
|---|---|
| sites in coding sequence | 44 |
| **fixable by synonymous substitution** | **44** (100%) |
| needing more than one codon changed | 0 |
| needing a codon below the 0.10 usage floor | 0 |
| **protein-encoded (no synonymous escape)** | **0** |

All of them clear with a single synonymous codon change and none requires a rare codon. [EVIDENCE] These sites are therefore a **cost**, not a constraint: removing them is a re-run of the optimiser with the three host motifs added to its forbidden set, which the optimiser already supports — its constraint set is a parameter, and widening it is the pattern adopted in this repo after the same class of error recurred.

### Sourced sites — structural

| construct | system | matched | position | component | provenance of that component |
|---|---|---|---|---|---|
| `V2-CX-10_SUB_Psyn_opA_gap03__HP01_groES` | CglI | `GCCGC` | 102 | `forecistron:HP-1` | fore-cistron HP-1 (groES), Liu 2023 Table 1 |
| `V2-OTH-07_Psyn_1x_opA_gap03_reta_v2` | CglI | `GCCGC` | 6 | `ctx:Psyn_N105_tail` | Psyn N105 primer tail, Henke 2021 Table 2 |
| `V2-OTH-08_Psyn_1x_opA_gap05_reta_v2` | CglI | `GCCGC` | 6 | `ctx:Psyn_N105_tail` | Psyn N105 primer tail, Henke 2021 Table 2 |
| `V2-OTH-13_Ptuf_1x_opA_gap03_repl_v2` | CglI | `GCGGC` | 65 | `core:Ptuf` | Ptuf amplicon, Henke 2021 / BX927147.1 |
| `V2-OTH-14_Ptuf_1x_opA_gap03_reta_v2` | CglI | `GCGGC` | 75 | `core:Ptuf` | Ptuf amplicon, Henke 2021 / BX927147.1 |
| `V2-OTH-15_Ptuf_noop_ctrl_v2` | CglI | `GCGGC` | 46 | `core:Ptuf` | Ptuf amplicon, Henke 2021 / BX927147.1 |

**6 sites in 6 constructs, all CglI, all structural.** [EVIDENCE] The choice at each is accepting the risk or abandoning the component — not editing. Concretely:

- **`core:Ptuf` (3 constructs)** — the Ptuf amplicon is a native C. glutamicum promoter recovered from BX927147.1. Editing it would make it no longer Ptuf. Note the panel already carries a standing caveat on Ptuf: its −35 could not be confidently assigned (12% of matrix max), and it is retained for strength-range breadth, not as a phasing subject.
- **`ctx:Psyn_N105_tail` (2 constructs)** — the retained-context variants exist precisely to test whether retaining the published upstream context matters. Editing that context defeats the variant's purpose.
- **`forecistron:HP-1` (1 construct)** — a published 62-mer whose measured strength is the reason it is in the panel. Editing it invalidates the published value it anchors.

### Designed non-coding sites

**None.** [EVIDENCE] No host R-M site falls in a designed background, filler, spacer or linker, so no design constraint — including the substitution arm's exact GC invariance — has to be traded off against this screen.

---

## 4. Task 4 — the methylation question

**Sequence screening does not address any of this.** Type IV enzymes cut DNA because of its *methylation state*, not its sequence, so no amount of motif screening protects against them.

### Does ATCC 13032 have methylation-dependent restriction activity?

**A Type IV restriction endonuclease is annotated in the genome: `cg2664`, 2540887..2541972 (+ strand), product "Predicted type IV restriction endonuclease".** [EVIDENCE, BX927147.1 feature table, cached] It is **computationally predicted**, not characterised, and REBASE assigns it no recognition specificity — as expected, since Type IV enzymes do not have one in the screenable sense. Its substrate preference is **[NOT FOUND]**.

### Does Dam+/Dcm+ versus Dam−/Dcm− plasmid preparation matter?

| question | answer | evidence |
|---|---|---|
| Is the CglI system a transformation barrier for **ATCC 13032**? | **Yes, severely.** | *"The cglIR-cgIIR restriction system is a major barrier to introduction of foreign DNA into Corynebacterium glutamicum cells"* — Li, Zhang, Guo & Xu (2016) *J Microbiol Methods* 131:156-160, PMID 27793586 [EVIDENCE] |
| Does pre-methylating with the host's own M.CglI help? | **Yes, by ~4 orders of magnitude.** | Same paper: pAU4 from *E. coli* TG1 gave 1.80±0.21×10² cfu/µg into C. glutamicum ATCC 13032; from *E. coli* AU1 (chromosomally integrated `cglIM`) it reached 5.22±0.33×10⁶ cfu/µg [EVIDENCE] |
| Independently replicated? | **Yes, at smaller magnitude.** | Expressing `cglIM` in *E. coli* *"conferred the C. glutamicum-specific methylation pattern to co-resident shuttle plasmids and led to a 260-fold increase in the transformation rate of C. glutamicum"* — Schäfer, Tauch, Droste, Pühler & Kalinowski (1997) *Gene* 203:95-101, PMID 9426239 [EVIDENCE] |
| Is a **Dam−/Dcm−** *E. coli* host specifically documented to help **ATCC 13032**? | **[NOT FOUND] for this strain.** | The frequently cited ~10³-fold dam⁻dcm⁻ result is reported for *C. glutamicum* ATCC 31831 and *B. flavum* MJ233C — **different strains**. Transferring it to ATCC 13032 would be an unsourced extrapolation, so it is not made here |
| Is ATCC 13032's own DNA Dam-methylated? | **No.** | *"enzymes which require methylation at adenosine in GATC sequences failed to cut"* and *"failed to detect significant levels of methylated adenosine"* — Jang, Chambers & Britz (1996) *FEMS Microbiol Lett* 136:309-15, PMID 8867385 [EVIDENCE] |

[INFERENCE, reasoning named] Because the host's own DNA carries m5C but little or no m6A, and because a Type IV enzyme is predicted, Dam methylation added by a standard *E. coli* cloning host is a *foreign* mark on the incoming plasmid. That is the configuration in which a methyl-dependent restriction system would act. **This is a hypothesis consistent with the sources, not something any of them demonstrates for ATCC 13032.**

For scale, if the plasmid is prepared in a Dam+/Dcm+ host the inserts alone would carry **744 GATC** and **534 CCWGG** strand-instances across 30 of the 95 constructs, with 64 constructs carrying neither. [EVIDENCE, computed] The vector backbone will add more.

### Draft question for the CRO

> *We plan to transform C. glutamicum ATCC 13032 and understand the CglI (cglIM/cglIR/cglIIR) system is a major barrier — the literature reports ~260-fold to ~10⁴-fold gains in transformation efficiency when the plasmid is pre-methylated by M.CglI, e.g. by passaging through an E. coli strain expressing cglIM. Could you tell us which E. coli background you prepare plasmid in for this host, whether it is Dam−/Dcm− and/or CglI-methylating, and whether you have seen a Dam/Dcm effect on transformation efficiency into ATCC 13032 specifically? We have screened our inserts against the sequence-recognised systems, but a predicted Type IV (methylation-dependent) endonuclease is annotated in this strain at cg2664, and that one cannot be addressed by sequence design — only by the methylation state of the DNA we send you.*

---

## 5. Task 5 — verdict

### How many constructs are affected, and how severely

| hazard class | physical sites | constructs | severity |
|---|---|---|---|
| **CglI** — characterised restriction system, documented transformation barrier | 10 | 9 | **real**; but abolished for every site at once by M.CglI pre-methylation (§4) |
| `Cgl13032I` / `Cgl13032II` — MTase specificities, cognate REase **[NOT FOUND]** | 40 | 20 | **unresolved**; if MTase-only these are protective, not destructive, and the count is irrelevant |
| **total** | 50 | 28 |  |

**28 of 95 constructs carry at least one site; 67 are clean.** But the two numbers should not be added together as if they were the same kind of risk. If `Cgl13032I/II` turn out to be methyltransferase-only — which is what their REBASE records suggest and what the task's own rule says to assume absent a cognate endonuclease — then the panel's real exposure is the **10 CglI sites in 9 constructs**, not 50 in 28.

### Fixable versus structural

|  | sites | route |
|---|---|---|
| fixable by synonymous substitution | 44 | re-run the codon optimiser with the three host motifs added to its constraint set |
| structural (sourced sequence) | 6 | accept the risk, or abandon the component — no third option |
| in designed non-coding regions | 0 | n/a — none exist |

### Can the panel proceed?

**Yes, as designed — provided the methylation question in §4 is settled with the CRO.** [INFERENCE, reasoning named] The reasoning:

1. **Nothing here is a redesign trigger.** No component has to be reconsidered. The 6 structural sites sit in three components whose value is exactly that they are the published, unedited originals; editing them would destroy the thing being tested.
2. **The coding sites are optional housekeeping.** All 44 clear with one synonymous codon each, at no cost in codon usage. Worth doing on the next optimiser run; not worth blocking on.
3. **Pre-methylation dominates everything else.** A ~10⁴-fold effect from M.CglI methylation swamps the difference between 10 CglI sites and 0. Removing sites from the coding regions while leaving the plasmid unmethylated would be optimising the small term.
4. **The one thing that could still bite is not addressable by design.** The predicted Type IV endonuclease at `cg2664` responds to methylation state, and the answer lies in which *E. coli* background the CRO uses.

**Recommended order of operations:** ask the CRO the §4 question first, because their answer determines whether the coding-site cleanup is worth doing at all. If they already prepare CglI-methylated plasmid, the 44 coding sites are close to irrelevant. If they prepare in a standard Dam+/Dcm+ host with no CglI methylation, then removing the 44 is cheap insurance and the 6 structural sites become a stated, accepted risk on 6 constructs.

### What sequence screening cannot resolve

| issue | why screening cannot settle it | who settles it |
|---|---|---|
| predicted Type IV endonuclease `cg2664` | targets methylation state, not a sequence — there is no motif to screen | CRO: which *E. coli* background prepares the plasmid |
| Dam/Dcm effect on ATCC 13032 specifically | **[NOT FOUND]** — published dam⁻dcm⁻ results are for other C. glutamicum strains | CRO experience, or a small pilot |
| whether `Cgl13032I`/`Cgl13032II` have cognate restriction enzymes | REBASE records the specificities from unpublished observations and does not say | REBASE curators / NEB, or the CRO's documented list |
| `Cgl165I` recognition sequence | REBASE records it literally as `?` — **[NOT FOUND]**; excluded rather than guessed. It is a different strain in any case | not applicable to this host |
| `cg0844`, `cg1028`, `cg2633` annotated R-M genes | annotated as restriction/modification proteins but with **no recognition sequence in REBASE** — nothing screenable, and nothing guessed | would need experimental determination |

**The CRO's own documented motif list is worth asking for regardless.** They raised this unprompted, which suggests they have one. If it differs from REBASE v608, the difference is worth knowing before the order is placed.

---

## 6. What this screen does not establish

- **A clean screen is a statement about three motifs**, the ones that could be sourced for this strain. Four further R-M genes are annotated in the genome with no recognition sequence in REBASE; they are unscreened because they are unscreenable, not because they are absent.
- **`Cgl13032I` and `Cgl13032II` rest on unpublished observations** recorded in REBASE. That is a citable source and it is cached, but it is weaker than a characterised system, and their hazard status is genuinely open.
- **The obs/exp depletion of CglI sites in the kinase CDSs is an accident of codon optimisation**, not a designed safety margin. It should not be relied on, and a future re-optimisation could remove it without anyone noticing unless the host motifs are in the constraint set.
- **Nothing here is experimental.** No construct has been transformed into anything. The transformation-efficiency numbers quoted are from the literature, for other plasmids.
- **Sequence screening cannot make a construct safe from a Type IV system.** That is the whole point of §4, and it is the part of this screen that has to leave the repo and become a question.

