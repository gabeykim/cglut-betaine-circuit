# Manual examination: the *lysC* HIGH_CONCERN hit

This gene gets individual attention regardless of what the global statistics in `results/REPORT_followup.md` say — aspartokinase is the committed, first step of the aspartate-derived amino acid pathway (lysine, threonine, methionine, isoleucine) and the gene the commercial thesis of a lysine-production host runs through. All facts below are pulled directly from `data/cache/BX927147.ft.txt` (the cached genome feature table) via `scripts/lysc_deep_dive.py`, never assumed from memory. Tags: [EVIDENCE] / [INFERENCE] / [ESTIMATE] / [NOT FOUND].

## Locus identity [EVIDENCE, verified against the genome record]

- **Locus tag: cg0306.** Gene name `lysC`, product "ASPARTOKINASE LYSC ALPHA and beta SUBUNITs".
- **Coordinates: 269,371-270,636**, **strand +**. Translation start = 269,371 (the feature table's "start" field, which is always the translation start regardless of strand — see the earlier operator-scan analysis for the bug this convention caught elsewhere in this project).

This was verified by direct lookup against the cached BX927147.1 feature table, not assumed from the earlier scan's classification output (which had already reported `cg0306`/`lysC` correctly, but is re-derived here independently as a check).

## Operon context [EVIDENCE, verified against the genome record]

Immediate neighborhood, from the feature table:

| Locus tag | Gene | Strand | Coordinates | Product | Gap to next |
|---|---|---|---|---|---|
| cg0304 | — | − | 268,256-268,948 | membrane protein | (divergent, opposite strand from lysC) |
| cg0305 | — | + | 269,030-269,128 | hypothetical protein | **242 bp** to lysC |
| **cg0306** | **lysC** | **+** | **269,371-270,636** | **aspartokinase** | **23 bp** to asd |
| cg0307 | asd | + | 270,660-271,694 | aspartate-semialdehyde dehydrogenase | 286 bp to cg0308 |
| cg0308 | — | + | 271,980-273,197 | putative membrane protein | |

**lysC is not obviously monocistronic.** It sits only 23 bp from the start of `asd` (aspartate-semialdehyde dehydrogenase) — the *second* enzyme in the same pathway (aspartate → aspartyl-phosphate via LysC, → aspartate-semialdehyde via Asd) — which is a tight enough spacing to strongly suggest co-transcription in a *lysC-asd* operon [INFERENCE: 23 bp is far too short to fit a separate promoter and 5′-UTR for asd; the classic bacterial pattern of adjacent genes in the same pathway with <50 bp spacing and no divergent promoter signature between them is operon co-transcription]. `cg0308` is a further 286 bp downstream of `asd` with no described functional link to the pathway — plausibly a separate transcription unit, but this feature-table-only analysis cannot determine operon boundaries definitively (that requires transcript-level evidence: a mapped TSS for lysC and/or a mapped terminator after asd or cg0308 — see below). Upstream, `cg0305` (hypothetical protein, same strand) is separated from lysC by 242 bp, and `cg0304` is on the opposite strand entirely (divergent), consistent with an independent promoter region sitting between cg0305 and lysC rather than an operon spanning cg0305 into lysC.

**No specific native transcriptional regulator of lysC was found in a literature search** [NOT FOUND: searched "Corynebacterium glutamicum lysC promoter regulation transcription factor"]. McbR (TetR-family, sulfur-regulon repressor) was the only regulator surfacing in that search, and its DNA target (`TAGAC-N6-GTCTA`, an inverted repeat) is structurally unrelated to Sal_PhoP's `GTTTA`-direct-repeat motif and is not reported to include lysC among its ~45 target genes. lysC's dominant, well-documented control in the literature is **post-translational** (allosteric feedback inhibition by Lys+Thr, the basis for the classic desensitizing point mutations used industrially), not a characterized transcriptional circuit at this promoter [INFERENCE: the absence of a well-known competing transcriptional regulator at this exact site is not evidence for the Sal_PhoP-like match being real, but it does mean there is no established alternative explanation this finding needs to be weighed against].

## Confirmed genuinely intergenic [EVIDENCE, verified against the genome record]

Hit interval: **269,204-269,220** (17 bp, + strand). Checked directly against both flanking CDS intervals:
- cg0305 CDS: 269,030-269,128 → hit does **not** overlap (hit starts 76 bp after cg0305 ends).
- lysC CDS: 269,371-270,636 → hit does **not** overlap (hit ends 151 bp before lysC starts).

The hit sits entirely within the 242 bp intergenic gap between cg0305 and lysC. Confirmed genuinely intergenic, not inside a CDS.

## What "151 bp upstream" is measured from — and what would change it

**151 bp is measured from the translational start (the ATG at 269,371)**, because that is what the feature table annotates and what `scripts/annotate_hits.py` uses throughout this project. It is **not** necessarily the distance from the transcriptional start site (TSS) — those differ by the length of the 5′-UTR, and for an activator, distance-to-TSS is the biologically relevant number, not distance-to-ATG.

**[NOT FOUND, with what was searched]**: an experimentally mapped TSS specific to lysC. Searched:
- Pfeifer-Sancar, Mentz, Rückert & Kalinowski 2013, *BMC Genomics* 14:888 (PMC3890552) — fetched and searched directly (not summarized): the paper mapped >2,000 TSSs genome-wide by RNAseq, but the body text contains no gene-by-gene TSS table and no mention of `lysC`, `cg0306`, or "aspartokinase" anywhere; the per-gene data lives only in Additional file 1 (Table S2/S3), a supplementary PDF. That PDF was unreachable: PMC's supplementary-file endpoint now sits behind a proof-of-work JavaScript bot challenge (`cloudpmc-viewer`) that a plain HTTP client cannot solve, and the Springer/BMC mirror (`static-content.springer.com`) returned 403 without a resolvable internal article ID.
- Albersmeier, Pfeifer-Sancar, Rückert & Kalinowski 2017, *J Biotechnol* (PMID 28412515, DOI 10.1016/j.jbiotec.2017.04.008) — confirmed this is the correct paper via PubMed (the task's attribution to "Busche" does not match the actual byline; noted for the record). Hosted on ScienceDirect/Elsevier, which returned a "Client Challenge" bot-detection page to both a direct HTTP client and the fetch tool — inaccessible from this environment.
- CoryneRegNet (the database that has historically integrated this kind of regulatory/TSS data for *C. glutamicum*) — the known URL (`coryneregnet.cebitec.uni-bielefeld.de`) returns a "service moved" notice pointing to `www.coryneregnet.de`, which does not resolve (unreachable) from this environment.

**What was found instead — genome-wide statistics, used to bound the estimate** [EVIDENCE, directly quoted from the fetched Pfeifer-Sancar 2013 full text]: of 2,147 TSSs assigned to annotated protein-coding genes, **~33% (707/2,147) are leaderless** (5′-UTR length = 0, i.e. TSS = translation start exactly), with the AUG/GUG start codon immediately transcribed; among the remainder, UTR length "decreased exponentially with increasing length" with a secondary accumulation at 26-40 nt (278 genes), and 531/2,147 (24.7%) have UTRs longer than 100 nt.

**[ESTIMATE, bounded, not a point value]**: if lysC is one of the ~33% leaderless genes, distance-to-TSS = distance-to-translation-start = **151 bp exactly** (unchanged). If lysC instead carries a UTR anywhere near the genome-wide modal range (roughly 10-40 nt), distance-to-TSS would be **≈110-140 bp**. Only if lysC sits in the minority long-UTR tail (>100 nt, ~25% of genes) would distance-to-TSS drop well below 100 bp or even become negative (TSS downstream of the hit, inside the transcribed-but-untranslated leader). Without the specific value, **151 bp is a firm upper bound on the true distance-to-TSS, not the distance-to-TSS itself** — and the true value is more likely to be somewhat less than 151 bp than more, given the genome-wide distribution is skewed toward short UTRs.

## Is this spacing plausible for a transcriptional activator?

Reported **separately** from the number, per instruction:

- **The number**: 151 bp from the translational start (firm, verified); true distance-to-TSS is [NOT FOUND] but bounded between roughly 0 and 151 bp, most probably in the ~110-151 bp range given the genome-wide UTR distribution (§ above).
- **The assessment** [INFERENCE, reasoning named]: Ec_PhoP activates most of its targets, and characterized enterobacterial Ec_PhoP activator sites typically sit within roughly 100 bp of the TSS, often overlapping or immediately adjacent to the −35 element (this is the general pattern described in the task and consistent with the RegulonDB *E. coli* site set used to build the PWM in this project: `distanceToPromoter` values recorded in that dataset — e.g. mgrRp −44, mgtSp −35, ompTp −59.5, hdeAp −32 — cluster tightly in the −30 to −60 range relative to the promoter). A distance of 151 bp from the *translation* start is at the outer edge of, or somewhat beyond, that typical window if lysC turns out to be leaderless; it is squarely within the typical window if lysC carries even a modest 5′-UTR. **Verdict: plausible-to-borderline, not implausible, and not confirmable at the precision this question deserves without the actual TSS.** This is exactly the kind of ambiguity that argues for resolving the real TSS (or testing the site directly) before treating this hit as either dismissed or confirmed.

## Score and significance under both null models

| Null model | Score | Empirical p | Passes p≤1e-4? |
|---|---|---|---|
| Whole-genome background (original scan) | 15.35 | 3.05×10⁻⁷ | Yes |
| **Intergenic background (follow-up correction, see REPORT_followup.md)** | **13.63** | **3.96×10⁻⁶** | **Yes** |

**The lysC hit survives the intergenic-null correction that eliminated 222 of the original 304 HIGH_CONCERN hits** (§Task 2 in `results/REPORT_followup.md`). Its significance drops by roughly an order of magnitude (as expected — the intergenic null is a more conservative, better-matched background) but remains extremely strong: 1 in ~250,000 by chance under the corrected null, comfortably inside the "as extreme as a confirmed real Sal_PhoP site" tier established by the positive control.

**Independent cross-species corroboration** [EVIDENCE, from `scripts/salmonella_pwm.py`]: scored against a *second*, independently-built PWM derived from 9 confirmed *Salmonella*-specific Sal_PhoP sites (PRODORIC MX000339 — see `results/REPORT_followup.md` §Task 5), the same genomic window scores **17.19 out of a possible 20.21** — the *strongest* match among the 9 most-extreme hits under that motif, stronger even than its relative standing under the *E. coli* motif. This hit is not an artifact of substituting *E. coli* sites for the primary *Salmonella* donor; it is corroborated by a motif built from the primary donor species itself.

## Bottom line

Real locus (cg0306/lysC, verified), genuinely intergenic (verified), likely part of a *lysC-asd* operon (inferred from spacing, not independently confirmed), no known competing native regulator at this exact site (literature search came up empty), significant under both the original and the corrected intergenic null (survives the correction that eliminated ~73% of the original hit list), and corroborated by an independently-built Salmonella-specific PWM. The one open question — exact spacing to the true TSS rather than the translation start — could not be resolved from this environment despite a genuine multi-source search effort, and is the single most important remaining fact needed before treating this hit as confirmed or dismissed. **This is the strongest candidate in the entire hit list for direct experimental follow-up (EMSA with purified Sal_PhoP, or a reporter-fusion assay) before finalizing the Sal_PhoP donor decision.**
