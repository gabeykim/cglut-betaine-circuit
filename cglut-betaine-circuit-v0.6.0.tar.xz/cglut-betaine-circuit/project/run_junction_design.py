#!/usr/bin/env python3
"""Entry point: design fusion junctions and emit C. glutamicum-optimised DNA.

    python3 run_junction_design.py

Runs fully offline from cached data. Writes:
    designs/junctions.csv
    designs/junctions.fasta
Boundaries are READ from results/domain_boundaries_v2.csv and
results/tm_predictions_v2.csv -- never re-derived.
"""
import csv, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import junction_design as J
from siga_consensus import EXT10_PWM, score_window, max_score

STOP = "TAA"          # 53.3% of C. glutamicum CDS stops (genome-derived)
EXT10_THRESH = 0.55   # same threshold the earlier design pass used

# sensor short-name -> accession
SENSORS = {"ECA": "WP_043878053.1", "MCPX": "Q92SH9"}
ACCEPTORS = {"PHOQ": "P0DM80", "ENVZ": "P0AEJ4"}
OFFSETS = [(-1, "m1"), (0, "0"), (+1, "p1")]


def strategy_points(bnd, sensor, acceptor):
    """Nominal (s_end, a_start, linker) per strategy. All numbers from the files."""
    s_tm2 = bnd[sensor]["tm"]["TM2"]
    a_tm2 = bnd[acceptor]["tm"]["TM2"]
    s_mid = (s_tm2[0] + s_tm2[1]) // 2
    a_mid = (a_tm2[0] + a_tm2[1]) // 2
    if acceptor == "P0DM80":
        hamp_end = J.PHOQ_HAMP[1]                     # PF26769 218-263
        dhp_start = J.PHOQ_HBOX - 9                   # H-box anchored, see module doc
        hamp_src = "PF26769 218-263 (REPORT_domains.md §7)"
        dhp_src = f"inferred: His{J.PHOQ_HBOX} - 9 (EnvZ H-box offset)"
    else:
        h = J.domain(bnd, acceptor, "HAMP"); hamp_end = h["end"]
        d = J.domain(bnd, acceptor, "HisKA"); dhp_start = d["start"]
        hamp_src = f"PF00672 {h['start']}-{h['end']} ({h['ga']}/{h['conf']})"
        dhp_src = f"PF00512 start {d['start']} ({d['ga']}/{d['conf']})"
    return {
        "A": dict(s_end=s_mid, a_start=a_mid + 1, linker="",
                  desc="within TM2", s_src=f"midpoint of sensor TM2 {s_tm2[0]}-{s_tm2[1]}",
                  a_src=f"midpoint of acceptor TM2 {a_tm2[0]}-{a_tm2[1]}"),
        "B": dict(s_end=s_tm2[1], a_start=hamp_end + 1, linker="",
                  desc="immediately after the HAMP region",
                  s_src=f"sensor TM2 end {s_tm2[1]}", a_src=f"1 past acceptor HAMP end; {hamp_src}"),
        "C": dict(s_end=s_mid, a_start=a_mid + 1, linker=J.LINKER_C,
                  desc="within TM2 + 5-residue flexible linker",
                  s_src=f"midpoint of sensor TM2 {s_tm2[0]}-{s_tm2[1]}",
                  a_src=f"midpoint of acceptor TM2 {a_tm2[0]}-{a_tm2[1]}"),
        "D": dict(s_end=s_tm2[1], a_start=dhp_start, linker="",
                  desc="HAMP omitted; sensor TM2 joined directly to DHp",
                  s_src=f"sensor TM2 end {s_tm2[1]}", a_src=dhp_src),
    }


def spurious_ext10(dna):
    w, mx = EXT10_PWM["width"], max_score(EXT10_PWM)
    out = []
    for i in range(len(dna) - w + 1):
        s = score_window(dna[i:i + w], EXT10_PWM) / mx
        if s >= EXT10_THRESH:
            out.append((i, i + w, round(s, 3)))
    return out


def spurious_sd(dna):
    out = []
    for m in re.finditer(r"GGAGG|AGGAG|GGAG", dna):
        for a in re.finditer(r"ATG", dna[m.end() + 3:m.end() + 15]):
            pos = m.end() + 3 + a.start()
            if pos == 0:
                continue
            out.append((m.start(), pos + 3, f"SD({m.group(0)})@{m.start()}+ATG@{pos}"))
    return out


def main():
    bnd = J.load_boundaries()
    prot = {a: J.load_protein(a) for a in set(SENSORS.values()) | set(ACCEPTORS.values())}
    meta, freq = J.load_codon_table()
    print(f"codon table: {meta['n_cds_used']} CDS, {meta['n_codons']} codons, "
          f"CDS GC {meta['cds_gc_percent']}%")

    panel = ([("core_primary", "ECA", "PHOQ", s) for s in "ABCD"]
             + [("core_second_sensor", "MCPX", "PHOQ", s) for s in "AD"]
             + [("alt_backbone", "ECA", "ENVZ", s) for s in "AD"])

    rows, fasta = [], []
    for panel_name, sname, aname, strat in panel:
        sensor, acceptor = SENSORS[sname], ACCEPTORS[aname]
        pts = strategy_points(bnd, sensor, acceptor)[strat]
        for off, tag in OFFSETS:
            s_end = pts["s_end"]
            a_start = pts["a_start"] + off          # register scan: acceptor slides
            link = pts["linker"]
            sseq, aseq = prot[sensor], prot[acceptor]
            protein = sseq[:s_end] + link + aseq[a_start - 1:]

            reg = J.register_analysis(sseq, s_end, aseq, a_start, len(link))
            jpos = s_end + len(link)                # last residue before acceptor
            phi = (s_end - 21 + 1 + J.best_phase(sseq[max(0, s_end - 21):s_end])[0]) % 7
            ad_frac = J.junction_ad_hydrophobicity(protein, jpos, phi)

            jnt = jpos * 3
            def junc_offenders(d, _j=jnt):
                bad = []
                for a, b, _s in spurious_ext10(d):
                    if a <= _j + 13 and b >= _j - 13:
                        bad.append((a, b))
                for a, b, _l in spurious_sd(d):
                    if a <= _j + 15 and b >= _j - 15:
                        bad.append((a, b))
                return bad
            dna = J.optimise(protein, freq)
            # Alternate global (enzyme/homopolymer) and junction (regulatory)
            # repair until both are clean -- fixing one can create the other.
            clean = False
            for _ in range(12):
                dna, clean = J.repair_all(dna, protein, freq)
                if not junc_offenders(dna):
                    break
                dna = J.repair(dna, protein, freq, junc_offenders)
            dna, clean = J.repair_all(dna, protein, freq)
            if not clean:
                print(f"  WARNING: {sname}/{aname}/{strat}{tag} could not be fully cleaned")
            dna_full = dna + STOP

            ext10 = spurious_ext10(dna_full)
            sd = spurious_sd(dna_full)
            j_ext10 = [f"{a}({s})" for a, b, s in ext10 if a <= jnt + 13 and b >= jnt - 13]
            j_sd = [l for a, b, l in sd if a <= jnt + 15 and b >= jnt - 15]
            enz = J.forbidden_hits(dna_full)
            homo = J.homopolymers(dna_full)
            gc = J.gc_pct(dna_full)

            flags = []
            if enz: flags.append("ENZYME:" + ",".join(enz))
            if homo: flags.append("HOMOPOLYMER:" + ",".join(homo))
            if abs(gc - J.HOST_GC) > J.GC_TOL: flags.append(f"GC_OUTLIER:{gc}")
            if j_ext10: flags.append("JUNCTION_SIGA:" + ",".join(j_ext10))
            if j_sd: flags.append("JUNCTION_SD:" + ";".join(j_sd))
            if reg and not reg["in_phase"]: flags.append(f"REGISTER_BREAK:{reg['delta']:+d}")
            if reg and not reg["determinate"]:
                flags.append(f"REGISTER_PHASE_{min([reg['up_determinacy'],reg['dn_determinacy']],key=lambda x:['INDETERMINATE','WEAK','WELL_DETERMINED'].index(x))}")

            name = f"JXN_{sname}_{aname}_{strat}{tag}"
            rows.append({
                "design_id": name, "panel": panel_name, "strategy": strat,
                "strategy_desc": pts["desc"], "register_offset": off,
                "sensor_accession": sensor, "sensor_last_residue": s_end,
                "sensor_element": J.element_at(bnd, sensor, s_end),
                "sensor_boundary_source": pts["s_src"],
                "acceptor_accession": acceptor, "acceptor_first_residue": a_start,
                "acceptor_element": J.element_at(bnd, acceptor, a_start),
                "acceptor_boundary_source": pts["a_src"],
                "linker": link or "none", "linker_len": len(link),
                "protein_len": len(protein), "dna_len": len(dna_full),
                "junction_protein_pos": jpos, "junction_nt_pos": jnt,
                "heptad_delta": "" if not reg else reg["delta"],
                "heptad_in_phase": "" if not reg else ("YES" if reg["in_phase"] else "NO"),
                "heptad_determinate": "" if not reg else ("YES" if reg["determinate"] else "NO"),
                "up_contrast": "" if not reg else reg["up_contrast"],
                "dn_contrast": "" if not reg else reg["dn_contrast"],
                "up_determinacy": "" if not reg else reg["up_determinacy"],
                "dn_determinacy": "" if not reg else reg["dn_determinacy"],
                "junction_ad_hydrophobic_frac": ad_frac,
                "gc_percent": gc,
                "golden_gate_sites": ",".join(enz) or "none",
                "homopolymer_gt6": ",".join(homo) or "none",
                "spurious_sigA_ext10_total": len(ext10),
                "spurious_sigA_at_junction": ",".join(j_ext10) or "none",
                "spurious_SD_ATG_total": len(sd),
                "spurious_SD_at_junction": ";".join(j_sd) or "none",
                "flags": " | ".join(flags) or "none",
                "protein_seq": protein,
            })
            fasta.append((name, panel_name, strat, off, len(protein), gc, dna_full))

    # ---------------------------------------------------------- uniqueness
    dnas = [f[-1] for f in fasta]
    prots = [r["protein_seq"] for r in rows]
    dup_dna = len(dnas) - len(set(dnas))
    dup_prot = len(prots) - len(set(prots))

    J.DESIGNS.mkdir(exist_ok=True)
    cols = [c for c in rows[0] if c != "protein_seq"] + ["protein_seq"]
    with open(J.DESIGNS / "junctions.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
    with open(J.DESIGNS / "junctions.fasta", "w") as fh:
        for name, panel_name, strat, off, plen, gc, dna in fasta:
            fh.write(f">{name} panel={panel_name} strategy={strat} register_offset={off:+d} "
                     f"protein_aa={plen} dna_nt={len(dna)} GC={gc}\n")
            for i in range(0, len(dna), 60):
                fh.write(dna[i:i + 60] + "\n")

    print(f"\nWrote designs/junctions.csv   ({len(rows)} designs)")
    print(f"Wrote designs/junctions.fasta ({len(fasta)} DNA sequences)")

    def head(t): print("\n" + "=" * 76 + f"\n{t}\n" + "=" * 76)
    head("DESIGN COUNT")
    from collections import Counter
    for p, n in Counter(r["panel"] for r in rows).items():
        print(f"  {p:20} {n}")
    print(f"  {'TOTAL':20} {len(rows)}")

    head("HEPTAD REGISTER")
    for r in rows:
        mark = "IN PHASE" if r["heptad_in_phase"] == "YES" else f"BREAK {r['heptad_delta']:+d}"
        print(f"  {r['design_id']:24} {mark:12} up={r['up_determinacy']:15} dn={r['dn_determinacy']:15} "
              f"contrast {r['up_contrast']}/{r['dn_contrast']}")

    head("BASIC CHECKS")
    print(f"  Golden Gate sites (BsaI/BsmBI/BbsI/SapI/AarI): "
          f"{sum(1 for r in rows if r['golden_gate_sites']!='none')} constructs with hits")
    print(f"  homopolymer runs > 6                        : "
          f"{sum(1 for r in rows if r['homopolymer_gt6']!='none')} constructs")
    print(f"  GC outliers (>{J.GC_TOL} pts from {J.HOST_GC}%)          : "
          f"{sum(1 for r in rows if 'GC_OUTLIER' in r['flags'])} constructs")
    print(f"  GC range                                    : "
          f"{min(r['gc_percent'] for r in rows)} - {max(r['gc_percent'] for r in rows)}%")
    print(f"  duplicate DNA sequences                     : {dup_dna}")
    print(f"  duplicate protein sequences                 : {dup_prot}")
    print(f"  spurious SigA ext-10 AT A JUNCTION          : "
          f"{sum(1 for r in rows if r['spurious_sigA_at_junction']!='none')} constructs")
    print(f"  spurious SD+ATG AT A JUNCTION               : "
          f"{sum(1 for r in rows if r['spurious_SD_at_junction']!='none')} constructs")

    head("FLAGGED DESIGNS")
    for r in rows:
        if r["flags"] != "none":
            print(f"  {r['design_id']:24} {r['flags']}")
    return rows


if __name__ == "__main__":
    main()
