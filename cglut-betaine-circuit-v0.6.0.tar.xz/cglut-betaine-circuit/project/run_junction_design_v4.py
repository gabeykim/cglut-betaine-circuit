#!/usr/bin/env python3
"""v4 of the kinase junction panel: re-optimised against the FULL 35-enzyme catalogue.

Nothing about the DESIGN changes. The triplets, the register recentring rule,
the strategies, the H-box guard and the junction-motif repair are all the same
code paths v2 used -- this run differs only in what the codon optimiser is
allowed to emit. `run_junction_design_v2.py::build` is the shared driver; v2
calls it with the 5-enzyme Golden Gate set to reproduce its frozen artifact,
and this script calls it with `enzymes=None`, which means the module default in
scripts/junction_design.py: all 35.

Feasibility was established before running this (scripts/optimiser_feasibility.py):
all 200 catalogue sites present in v3 are removable by a single synonymous
codon, none of them requiring a codon below the 0.10 usage floor, and no site is
protein-encoded. The fallback ladder should therefore never fire; if it does,
it is logged in junction_design.RELAXATION_LOG and reported below rather than
being applied silently.

    python3 run_junction_design_v4.py

Writes designs/junctions_v4.csv and designs/junctions_v4.fasta.
Never touches v1, v2 or v3.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import junction_design as J
from seqchecks import positive_control_check
from run_junction_design_v2 import build

CSV = J.DESIGNS / "junctions_v4.csv"
FA = J.DESIGNS / "junctions_v4.fasta"

if __name__ == "__main__":
    for p in (CSV, FA):
        if p.exists():
            sys.exit(f"REFUSING TO OVERWRITE {p}")
    positive_control_check()
    print("=" * 78)
    print("v4: RE-OPTIMISING THE KINASE PANEL AGAINST THE FULL 35-ENZYME CATALOGUE")
    print("=" * 78)
    print(f"  optimiser constraint set : {len(J.CONSTRAINT_ENZYMES)} enzymes (module default)")
    print(f"  fallback ladder          : {' -> '.join(J.FALLBACK_LADDER)}  "
          f"(Golden Gate never relaxed)")
    rows = build(None, CSV, FA, None, tag_note="  (full catalogue -- the widened default)")
    if J.RELAXATION_LOG:
        print("\n  FALLBACK LADDER FIRED -- these are recorded, not silent:")
        for r in J.RELAXATION_LOG:
            print(f"    {r}")
    else:
        print("\n  fallback ladder never fired: every constraint satisfied at rung 0 "
              "(synonymous codons at or above the usage floor)")
