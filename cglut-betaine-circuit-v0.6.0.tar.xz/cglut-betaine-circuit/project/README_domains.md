# Pfam domain annotation of bacterial signalling proteins (v2)

Domain boundaries, transmembrane topology and H-box histidine positions for seven requested
bacterial signalling proteins.

**Read `results/REPORT_domains.md` first** — it leads with the six findings that could not be
assigned confidently, which is where the risk to downstream work is.

> This is a separate analysis from the three already documented in `README.md` (cross-talk triage,
> operator-motif genome scan, follow-up). It shares `data/fasta/` and `data/cache/pfam/` with them.

---

## Headline results

- **Salmonella PhoQ has no Pfam-acceptable HisKA or HAMP domain.** The HisKA hit fails Pfam's
  gathering threshold by 0.7 bits; InterPro assigns PhoQ no HisKA at all. Its H-box (His277) is
  nonetheless experimentally confirmed.
- **The UniProt entry for `ECA_RS10935` (Q6D515) is N-terminally truncated by 46 residues** relative
  to RefSeq `WP_043878053.1`. Every coordinate is offset by 46 and TM1 is missing entirely. Both are
  annotated; **use the RefSeq rows**.
- **PA4633 carries a HisKA-family hit with no identifiable H-box histidine** — a real negative. The
  hit is noise (sequence bit score −2.0).
- **`PF02743` is absent from PA4633 and McpX** at any threshold; McpX's sensor is `PF22673` instead.
- **DeepTMHMM 1.0.57 was available and used** — no fallback to hydrophobicity was needed.

---

## What was fetched, when, from where

Retrieved **2026-08-22** (four UniProt entries, five HMMs) and **2026-08-23** (three UniProt entries,
two HMMs, the RefSeq protein, all DeepTMHMM output, five extra HMMs for the competing-model check).

| What | Count | Source |
|---|---:|---|
| UniProt FASTA | 7 | `https://rest.uniprot.org/uniprotkb/<ACC>.fasta` |
| RefSeq FASTA | 1 | NCBI E-utilities `efetch`, `db=protein&id=WP_043878053.1` |
| Pfam HMMs (requested) | 7 | `https://www.ebi.ac.uk/interpro/wwwapi/entry/pfam/<PF>/?annotation=hmm` |
| Pfam HMMs (competing-model check) | 5 | same endpoint — PF26769, PF08918, PF00015, PF22673, PF00486 |
| DeepTMHMM topology | 8 seqs | `DTU/DeepTMHMM:1.0.57` via `pybiolib` 1.4.363, BioLib cloud |
| InterPro boundary cross-check | 7 | `https://www.ebi.ac.uk/interpro/api/entry/pfam/protein/uniprot/<ACC>/` |
| Accession/topology metadata | — | UniProt REST JSON (`ft_mod_res`, `ft_transmem`, `ft_topo_dom`); NCBI Gene 2883412 |

Per-accession provenance — accession → organism → protein name → retrieval date → source URL →
resolution note — is in **`data/domains_manifest_v2.csv`**.

### Accessions that needed resolving

| Requested | Used | How |
|---|---|---|
| `P14147` | `P0DM80` | dead accession — UniProt reports `Inactive` / `DEMERGED` → `[E1WFA0, P0DM80]`; LT2 chosen for strain consistency with P0DM78 |
| `PA4633` | `Q9HVF8` | locus tag; the UniProt entry carries `GN=PA4633` |
| `ECA_RS10935` | `Q6D515` **and** `WP_043878053.1` | NCBI Gene 2883412 aliases `ECA_RS10935, ECA2226`; UniProt entry is truncated, RefSeq added |
| `McpX` (name only) | `Q92SH9` | UniProt query `gene:mcpX AND organism_id:266834` → one hit, `mcpX SMc01104` |

---

## Layout

```
run_domain_annotation_v2.py            entry point — runs offline from cached data
scripts/domain_annotation_v2.py        fetch/scan/topology/H-box library
requirements_domains.txt               Python deps (HMMER installed separately)

data/fasta/<ACC>.fasta                 cached sequences, never hand-written
data/fasta/WP_043878053.1.fasta        full-length RefSeq protein for ECA_RS10935
data/cache/pfam/<PF>.hmm               cached Pfam HMMs
data/cache/deeptmhmm/                  DeepTMHMM output + PROVENANCE.txt
data/domains_manifest_v2.csv           accession -> organism -> name -> date -> URL

results/domain_boundaries_v2.csv       one row per domain hit
results/tm_predictions_v2.csv          one row per TM helix and per topological region
results/REPORT_domains.md              findings
```

## Reproduce

```bash
pip install -r requirements_domains.txt
brew install hmmer                                  # HMMER 3.4 on PATH

python3 run_domain_annotation_v2.py                 # offline against cached data
python3 run_domain_annotation_v2.py --refresh-tm    # re-run DeepTMHMM (needs network)
```

The default run makes **no network calls** while the caches are populated. `pybiolib` is needed only
for `--refresh-tm`.

## Methods in one line each

- **Domains** — `hmmscan` (HMMER 3.4) with `--cut_ga`, i.e. Pfam's own curated per-model gathering
  thresholds. `hmmscan` not `hmmsearch`: queries are proteins, the database is profiles. A permissive
  pass (`-E 10`) runs alongside so sub-threshold hits are *visible and labelled*, never silently
  promoted to domains.
- **TM** — DeepTMHMM 1.0.57, cross-checked against UniProt curated topology and Kyte-Doolittle
  (window 19). Note UniProt's TM annotations here are `ECO:0000255/0000256/0000305` — inference, not
  experiment; there is no experimental topology for any of these proteins.
- **H-box** — the match-state column with maximal P(His) taken from each model's own emission
  probabilities, then validated against two experimentally confirmed phosphohistidines
  (EnvZ `P0AEJ4` His243 and PhoQ `P0DM80` His277, both UniProt `ECO:0000269`). Both reproduce exactly.

## Relationship to the earlier run

`run_domain_annotation.py` and `results/{domain_boundaries,tm_predictions}.csv` are an earlier pass at
this task. **They were not overwritten.** Three defects in them are documented in
`results/REPORT_domains.md` §9: gathering thresholds bypassed, overlapping/negative-length TM
regions, and an invalid H-box column transfer between two different Pfam models.
