#!/usr/bin/env python3
"""Single entry point for the Ec_PhoP operator-motif genome scan.

Runs, in order, from cached data (network only touched by step 0, and only
for files not already cached):
  0. scripts/fetch_scan_data.py    -- fetch/cache genomes + RegulonDB sites
  1. scripts/prepare_sites.py      -- extract confirmed sites -> aligned FASTA + manifest
  2. scripts/build_pwm.py          -- log-odds PWM vs observed C. glutamicum background
  3. scan E. coli (positive control) with the PWM, both strands, empirical null
  4. classify + assemble results/positive_control.csv
  5. scan C. glutamicum with the SAME PWM, both strands, empirical null
  6. classify -> results/hits_all.csv, results/hits_high_concern.csv

Per the task: if the positive control fails, this script prints a clear
FAIL and stops before running the C. glutamicum scan.

Usage:
    python3 run_scan_pipeline.py             # run everything
    python3 run_scan_pipeline.py --skip-fetch  # reuse existing cache, skip network step
"""
import argparse
import csv
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "scripts"
DATA = ROOT / "data"
RESULTS = ROOT / "results"

sys.path.insert(0, str(SCRIPTS))


def run(script: str, extra_args=None):
    cmd = [sys.executable, str(SCRIPTS / script)] + (extra_args or [])
    print(f"\n{'='*70}\n>>> {' '.join(cmd)}\n{'='*70}")
    subprocess.run(cmd, check=True, cwd=ROOT)


def check_positive_control(pc_csv: Path, min_high_concern_fraction: float = 0.5) -> bool:
    rows = list(csv.DictReader(open(pc_csv)))
    n = len(rows)
    concerning = sum(1 for r in rows if r["classification"] in ("HIGH_CONCERN", "INSIDE_CDS_EXCEPTIONAL"))
    recovered = sum(1 for r in rows if r["recovered_at_exact_coord"] == "True")
    frac = concerning / n if n else 0
    print(f"\nPositive control: {recovered}/{n} known Ec_PhoP sites recovered at their exact genomic "
          f"coordinate; {concerning}/{n} ({frac:.0%}) classify as concerning (HIGH_CONCERN or "
          f"INSIDE_CDS_EXCEPTIONAL).")
    passed = frac >= min_high_concern_fraction
    print("Positive control: " + ("PASS" if passed else "FAIL"))
    return passed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-fetch", action="store_true")
    args = ap.parse_args()

    if not args.skip_fetch:
        run("fetch_scan_data.py")
    else:
        print("Skipping fetch step; reusing existing data/cache/ as-is.")

    run("prepare_sites.py")
    run("build_pwm.py")

    print("\n" + "=" * 70)
    print("POSITIVE CONTROL: scanning E. coli K-12 MG1655 with the Ec_PhoP PWM")
    print("=" * 70)
    run("scan_genome.py", ["--genome", "data/cache/NC_000913.fasta", "--pwm", "data/cache/pwm_phop.json",
                            "--out", "data/cache/scan_ecoli_phop_raw.csv", "--seed", "1337", "--label", "ecoli_phop"])
    run("annotate_hits.py", ["--hits", "data/cache/scan_ecoli_phop_raw.csv", "--ft", "data/cache/NC_000913.ft.txt",
                              "--out", "data/cache/positive_control_all_classified.csv", "--max-p", "1.0"])

    # assemble results/positive_control.csv from the known PWM-training sites
    sites = list(csv.DictReader(open(DATA / "sites_manifest.csv")))
    phop_sites = [s for s in sites if s["tf"] == "Ec_PhoP" and s["included_in_pwm"] == "True"]
    cls_rows = list(csv.DictReader(open(DATA / "cache" / "positive_control_all_classified.csv")))
    by_coord = {(int(h["start"]), h["strand"]): h for h in cls_rows}
    raw = list(csv.DictReader(open(DATA / "cache" / "scan_ecoli_phop_raw.csv")))
    raw_by_coord = {(int(r["start"]), r["strand"]): r for r in raw}
    strand_map = {"forward": "+", "reverse": "-"}
    out_rows = []
    for s in phop_sites:
        left, strand = int(s["left"]), strand_map[s["strand"]]
        hit = raw_by_coord.get((left, strand))
        cls_row = by_coord.get((left, strand))
        out_rows.append({
            "promoter": s["promoter"], "position": left, "strand": strand,
            "core_sequence": s["core"], "pmids": s["pmids"],
            "recovered_at_exact_coord": hit is not None,
            "score": hit["score"] if hit else "", "empirical_p": hit["empirical_p"] if hit else "",
            "classification": cls_row["classification"] if cls_row else "not recovered at exact coordinate",
            "nearest_gene": (cls_row.get("nearest_gene_name") or cls_row.get("nearest_gene_locus_tag")) if cls_row else "",
            "distance_bp": cls_row.get("distance_bp", "") if cls_row else "",
        })
    pc_path = RESULTS / "positive_control.csv"
    with open(pc_path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(out_rows[0].keys()))
        writer.writeheader()
        writer.writerows(out_rows)
    print(f"\nWrote {len(out_rows)} rows to {pc_path}")

    if not check_positive_control(pc_path):
        print("\n" + "!" * 70)
        print("POSITIVE CONTROL FAILED. Per the task instructions, stopping here rather than")
        print("reporting the C. glutamicum scan -- a PWM that cannot recover its own known")
        print("training sites as significant, correctly classified hits cannot be trusted for")
        print("a genome it has no ground truth for. Fix the PWM/scan/classification pipeline")
        print("before proceeding.")
        print("!" * 70)
        sys.exit(1)

    print("\n" + "=" * 70)
    print("MAIN SCAN: C. glutamicum ATCC 13032 (BX927147.1)")
    print("=" * 70)
    run("scan_genome.py", ["--genome", "data/cache/BX927147.fasta", "--pwm", "data/cache/pwm_phop.json",
                            "--out", "data/cache/scan_cglut_phop_raw.csv", "--seed", "1337", "--label", "cglut_phop"])
    run("annotate_hits.py", ["--hits", "data/cache/scan_cglut_phop_raw.csv", "--ft", "data/cache/BX927147.ft.txt",
                              "--out", "results/hits_all.csv", "--max-p", "5e-2"])

    all_rows = list(csv.DictReader(open(RESULTS / "hits_all.csv")))
    hc = [r for r in all_rows if r["classification"] == "HIGH_CONCERN" and float(r["empirical_p"]) <= 1e-4]
    hc.sort(key=lambda r: float(r["empirical_p"]))
    hc_path = RESULTS / "hits_high_concern.csv"
    with open(hc_path, "w", newline="") as fh:
        if hc:
            writer = csv.DictWriter(fh, fieldnames=list(hc[0].keys()))
            writer.writeheader()
            writer.writerows(hc)
        else:
            fh.write(",".join(all_rows[0].keys()) + "\n" if all_rows else "")
    print(f"\n{len(hc)} HIGH_CONCERN hits (empirical p<=1e-4) written to {hc_path}")

    print("\n" + "=" * 70)
    print("Pipeline complete. Outputs:")
    print("  data/sites_manifest.csv          confirmed binding sites, with citations")
    print("  results/pwm.txt                  Ec_PhoP PWM with per-position and total IC")
    print("  results/positive_control.csv     E. coli control results (report FIRST)")
    print("  results/hits_all.csv             every C. glutamicum hit, all classifications")
    print("  results/hits_high_concern.csv    the actionable subset")
    print("  results/REPORT.md                findings")
    print("=" * 70)


if __name__ == "__main__":
    main()
