#!/usr/bin/env python3
"""Single entry point (v2). Runs offline from cached data.

    python3 run_domain_annotation_v2.py
    python3 run_domain_annotation_v2.py --refresh-tm   # re-run DeepTMHMM (needs network)

Writes:
    data/domains_manifest_v2.csv
    results/domain_boundaries_v2.csv
    results/tm_predictions_v2.csv
Never overwrites the v1 files of the same stem.
"""
import csv, subprocess, sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import domain_annotation_v2 as M


def hmmer_version():
    out = subprocess.run(["hmmscan", "-h"], capture_output=True, text=True).stdout
    return next((l.strip("# ").strip() for l in out.split("\n") if l.startswith("# HMMER")), "HMMER ?")


def overlaps(a1, a2, b1, b2):
    return not (a2 < b1 or a1 > b2)


def main():
    refresh = "--refresh-tm" in sys.argv
    print("=" * 78)
    print("Pfam domain annotation / TM prediction / H-box location  (v2)")
    print("=" * 78)

    seqs = M.ensure_inputs()
    accs = [t[1] for t in M.TARGETS]
    all_accs = accs + ["WP_043878053.1"]
    for a in all_accs:
        print(f"  {a:16} {len(seqs[a][0]):>4} aa   retrieved {seqs[a][2]}")

    ver = hmmer_version()
    ga_thr = M.ga_thresholds()
    hcols = M.hbox_columns()
    db = M.build_db()
    ga_hits, perm_hits, ga_aln, perm_aln = M.run_hmmscan(db, seqs, all_accs, "v2")
    alns = M.parse_alignments(perm_aln)
    print(f"\n{ver} | hmmscan --cut_ga -> {len(ga_hits)} domains; "
          f"permissive -> {len(perm_hits)} raw hits")
    print(f"H-box match-state column per model (from HMM emissions): {hcols}")

    # ---- H-box calibration against experimentally confirmed phosphohistidines ----
    print("\nH-box calibration (UniProt ECO:0000269, experimental):")
    for acc, pos in M.HBOX_EXPERIMENTAL.items():
        for a in alns:
            if a["accession"] == acc and a["model"] in M.HISKA_FAMILY:
                col = hcols[a["model"]][0]
                p, r = M.hmm_column_to_residue(a, col)
                if p:
                    ok = (p == pos and r == "H")
                    print(f"  {acc}: {a['model']} col {col} -> {r}{p} vs experimental His{pos}"
                          f"  {'AGREE' if ok else 'DISAGREE'}")
                    break

    # -------------------------------- manifest --------------------------------
    with open(M.DATA / "domains_manifest_v2.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["requested_accession", "accession_used", "organism", "protein_name",
                    "length_aa", "retrieval_date", "source_url", "resolution_note"])
        for req, acc, org, name, note in M.TARGETS:
            w.writerow([req, acc, org, name, len(seqs[acc][0]), seqs[acc][2],
                        f"https://rest.uniprot.org/uniprotkb/{acc}.fasta", note])
        req, acc, org, name, note = M.REFSEQ_ECA
        w.writerow([req, acc, org, name, len(seqs[acc][0]), seqs[acc][2],
                    "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
                    "?db=protein&id=WP_043878053.1&rettype=fasta", note])
    print(f"\nWrote data/domains_manifest_v2.csv ({len(M.TARGETS) + 1} rows)")

    # ------------------------------- domain rows ------------------------------
    ga_key = {(h["accession"], h["model"], h["start"], h["end"]) for h in ga_hits}
    by_acc = defaultdict(list)
    for h in perm_hits:
        by_acc[h["accession"]].append(h)

    rows, medlow, competing, subga = [], [], [], []
    entries = [(r, a, o, n) for r, a, o, n, _x in M.TARGETS] + \
              [(M.REFSEQ_ECA[0], M.REFSEQ_ECA[1], M.REFSEQ_ECA[2], M.REFSEQ_ECA[3])]

    for req, acc, org, _name in entries:
        hs = sorted(by_acc[acc], key=lambda r: -r["dom_bitscore"])
        kept = [h for h in hs if (h["accession"], h["model"], h["start"], h["end"]) in ga_key]
        for h in hs:
            passes = (h["accession"], h["model"], h["start"], h["end"]) in ga_key
            if not passes and h["dom_bitscore"] < 5:
                continue  # pure noise, not worth a row
            sga, dga = ga_thr[h["model"]]
            comp = [f"{o['model']}({o['dom_bitscore']})" for o in kept
                    if o is not h and overlaps(h["start"], h["end"], o["start"], o["end"])]
            # independent boundary cross-check vs InterPro
            ip = M.INTERPRO.get((acc, h["model"]))
            ip_list = ip if isinstance(ip, list) else ([ip] if ip else [])
            best = None
            for s, e in ip_list:
                d = abs(s - h["start"]) + abs(e - h["end"])
                if best is None or d < best[0]:
                    best = (d, s, e)
            ip_txt, ip_delta = ("", "")
            if best:
                ip_txt = f"{best[1]}-{best[2]}"
                ip_delta = max(abs(best[1] - h["start"]), abs(best[2] - h["end"]))

            if not passes:
                conf = "LOW"
                reason = (f"BELOW Pfam gathering threshold (dom {h['dom_bitscore']} < GA {dga}"
                          f"; seq {h['seq_bitscore']} vs seq-GA {sga}) - Pfam would not call this a domain")
                subga.append((req, acc, h, sga, dga))
            elif h["i_evalue"] >= 1e-10:
                conf = "MEDIUM"
                reason = f"passes GA but weak: i-E = {h['i_evalue']:.2g} (>= 1e-10)"
            elif ip_delta != "" and ip_delta > 5:
                conf = "MEDIUM"
                reason = f"InterPro boundary differs by {ip_delta} aa (> 5)"
            elif comp:
                conf = "MEDIUM"
                reason = f"another retained model overlaps this region: {','.join(comp)}"
            else:
                conf = "HIGH"
                reason = (f"i-E {h['i_evalue']:.2g} < 1e-10, passes GA"
                          + (f", InterPro agrees within {ip_delta} aa" if ip_delta != "" else ""))

            hb = hbr = ""
            if h["model"] in M.HISKA_FAMILY:
                col = hcols[h["model"]][0]
                for a in alns:
                    if a["accession"] == acc and a["model"] == h["model"] \
                            and abs(a["ali_from"] - h["start"]) <= 2:
                        p, r = M.hmm_column_to_residue(a, col)
                        if p:
                            hb, hbr = p, r
                        break

            if comp:
                competing.append((acc, h["model"], h["dom_bitscore"], comp))
            row = {
                "requested_accession": req, "accession": acc, "organism": org,
                "model": h["model"], "model_acc": h["model_acc"],
                "start": h["start"], "end": h["end"], "length": h["end"] - h["start"] + 1,
                "env_start": h["env_from"], "env_end": h["env_to"],
                "bit_score": h["dom_bitscore"], "seq_bit_score": h["seq_bitscore"],
                "i_evalue": h["i_evalue"], "hmm_from": h["hmm_from"], "hmm_to": h["hmm_to"],
                "pfam_GA_seq": sga, "pfam_GA_dom": dga,
                "passes_pfam_GA": "YES" if passes else "NO",
                "interpro_boundary": ip_txt, "interpro_max_delta_aa": ip_delta,
                "hbox_his_position": hb, "hbox_residue": hbr,
                "method": f"hmmscan ({ver}) --cut_ga vs Pfam "
                          + "/".join(f"{m}:{M.MODEL_NAME[m]}" for m in M.MODELS),
                "confidence": conf, "confidence_reason": reason,
                "competing_models": ";".join(comp),
            }
            rows.append(row)
            if conf != "HIGH":
                medlow.append(row)

    with open(M.RESULTS / "domain_boundaries_v2.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"Wrote results/domain_boundaries_v2.csv ({len(rows)} rows; "
          f"{sum(1 for r in rows if r['passes_pfam_GA']=='YES')} pass Pfam GA)")

    # ---------------------------------- TM ------------------------------------
    if refresh:
        import biolib
        qf = M.CACHE / "queries_v2.fasta"
        job = biolib.load("DTU/DeepTMHMM").cli(args=f"--fasta {qf}")
        job.wait(); job.save_files(str(M.DTM))
    dtm = M.parse_deeptmhmm(M.DTM / "TMRs_uniprot7.gff3")
    dtm.update(M.parse_deeptmhmm(M.DTM / "TMRs_WP_043878053.gff3"))
    TOOL = "DeepTMHMM 1.0.57 (DTU/DeepTMHMM via pybiolib 1.4.363, BioLib cloud)"
    SIDE = {"inside": "cytoplasmic", "outside": "periplasmic", "TMhelix": "membrane"}

    tm_rows, tm_medlow = [], []
    for req, acc, org, _name in entries:
        key = acc.split(".")[0] if acc.startswith("WP_") else acc
        feats = dtm.get(key, [])
        kd = M.kyte_doolittle_tm(seqs[acc][0])
        up = M.UNIPROT_TM.get(acc)
        n_tm = sum(1 for f in feats if f[0] == "TMhelix")
        idx = 0
        for lab, s, e in feats:
            if lab == "TMhelix":
                idx += 1
                # cross-checks
                ups = up[idx - 1] if up and len(up) >= idx else None
                if acc.startswith("WP_") and M.UNIPROT_TM["Q6D515"]:
                    shifted = [(a + M.ECA_OFFSET, b + M.ECA_OFFSET)
                               for a, b in M.UNIPROT_TM["Q6D515"]]
                    ups = shifted[0] if idx == 2 else None
                d_up = max(abs(ups[0] - s), abs(ups[1] - e)) if ups else ""
                near_kd = [k for k in kd if not (k["end"] < s - 10 or k["start"] > e + 10)]
                d_kd = min((max(abs(k["start"] - s), abs(k["end"] - e)) for k in near_kd),
                           default="")
                if d_up == "":
                    conf = "MEDIUM"
                    reason = ("DeepTMHMM only; no UniProt-annotated helix to cross-check"
                              + (f"; Kyte-Doolittle differs by {d_kd} aa" if d_kd != "" else ""))
                elif d_up > 5:
                    conf = "MEDIUM"
                    reason = f"DeepTMHMM and UniProt disagree by {d_up} aa (> 5)"
                else:
                    conf = "HIGH"
                    reason = (f"DeepTMHMM and UniProt agree within {d_up} aa"
                              + (f"; Kyte-Doolittle within {d_kd} aa" if d_kd != "" else ""))
                r = {"requested_accession": req, "accession": acc, "organism": org,
                     "feature": f"TM{idx}", "start": s, "end": e, "length": e - s + 1,
                     "side": "membrane", "n_tm_helices": n_tm, "tool": TOOL,
                     "deeptmhmm_boundary": f"{s}-{e}",
                     "uniprot_boundary": f"{ups[0]}-{ups[1]}" if ups else "",
                     "uniprot_evidence": M.UNIPROT_TM_EVIDENCE.get(acc, ""),
                     "kyte_doolittle_nearest": ";".join(f"{k['start']}-{k['end']}" for k in near_kd),
                     "max_delta_vs_uniprot_aa": d_up, "max_delta_vs_kd_aa": d_kd,
                     "confidence": conf, "confidence_reason": reason}
            else:
                r = {"requested_accession": req, "accession": acc, "organism": org,
                     "feature": f"{SIDE[lab]}_region", "start": s, "end": e,
                     "length": e - s + 1, "side": SIDE[lab], "n_tm_helices": n_tm,
                     "tool": TOOL, "deeptmhmm_boundary": f"{s}-{e}", "uniprot_boundary": "",
                     "uniprot_evidence": M.UNIPROT_TM_EVIDENCE.get(acc, ""),
                     "kyte_doolittle_nearest": "", "max_delta_vs_uniprot_aa": "",
                     "max_delta_vs_kd_aa": "",
                     "confidence": "HIGH" if n_tm else "HIGH",
                     "confidence_reason": "DeepTMHMM topology label"}
            tm_rows.append(r)
            if r["confidence"] != "HIGH":
                tm_medlow.append(r)
        if not feats:
            tm_rows.append({"requested_accession": req, "accession": acc, "organism": org,
                            "feature": "none", "start": "", "end": "", "length": 0,
                            "side": "", "n_tm_helices": 0, "tool": TOOL,
                            "deeptmhmm_boundary": "", "uniprot_boundary": "",
                            "uniprot_evidence": "", "kyte_doolittle_nearest": "",
                            "max_delta_vs_uniprot_aa": "", "max_delta_vs_kd_aa": "",
                            "confidence": "HIGH",
                            "confidence_reason": "NO TM HELIX PREDICTED (soluble)"})
    with open(M.RESULTS / "tm_predictions_v2.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(tm_rows[0].keys()))
        w.writeheader(); w.writerows(tm_rows)
    print(f"Wrote results/tm_predictions_v2.csv "
          f"({sum(1 for r in tm_rows if str(r['feature']).startswith('TM'))} helices, "
          f"{len(tm_rows)} rows)")

    # -------------------------------- summaries -------------------------------
    def head(t):
        print("\n" + "=" * 78 + f"\n{t}\n" + "=" * 78)

    head("MISSING EXPECTED DOMAINS")
    expect = {"P0DM80": {"HAMP", "HisKA", "HATPase_c"}, "P0AEJ4": {"HAMP", "HisKA", "HATPase_c"},
              "P0DM78": {"Response_reg"}, "P0AA16": {"Response_reg"},
              "Q9HVF8": {"dCache_1", "HAMP"}, "Q6D515": {"dCache_1"}, "Q92SH9": {"dCache_1", "HAMP"}}
    got = defaultdict(set)
    for r in rows:
        if r["passes_pfam_GA"] == "YES":
            got[r["accession"]].add(r["model"])
    for acc, exp in expect.items():
        miss = exp - got[acc]
        print(f"  {acc:8} found: {', '.join(sorted(got[acc])) or 'NOTHING'}"
              + (f"   >>> MISSING: {', '.join(sorted(miss))}" if miss else "   (none missing)"))

    head("HisKA-FAMILY HITS WITHOUT AN IDENTIFIABLE H-BOX HISTIDINE")
    hk = [r for r in rows if r["model"] in M.HISKA_FAMILY]
    if not hk:
        print("  no HisKA-family hits at all")
    for r in hk:
        ok = r["hbox_residue"] == "H"
        print(f"  {r['accession']:14} {r['model']:9} GA={r['passes_pfam_GA']:3} "
              f"-> {'H' + str(r['hbox_his_position']) if ok else '*** NO H-BOX HISTIDINE ***'}")

    head("SUB-GATHERING-THRESHOLD HITS (reported, but Pfam rejects them)")
    for req, acc, h, sga, dga in subga:
        print(f"  {acc:14} {h['model']:9} {h['start']}-{h['end']}  dom {h['dom_bitscore']} "
              f"< GA {dga}   seq {h['seq_bitscore']} vs {sga}")

    head("COMPETING MODELS OVER THE SAME REGION (within the requested seven)")
    print("  none" if not competing else "")
    for acc, m, sc, comp in competing:
        print(f"  {acc}: {m} ({sc}) vs {comp}")

    head("MEDIUM / LOW CONFIDENCE BOUNDARIES  -- all of them")
    for r in medlow:
        print(f"  [{r['confidence']:6}] DOMAIN {r['accession']:14} {r['model']:12} "
              f"{r['start']}-{r['end']}  {r['confidence_reason']}")
    for r in tm_medlow:
        print(f"  [{r['confidence']:6}] TM     {r['accession']:14} {r['feature']:12} "
              f"{r['start']}-{r['end']}  {r['confidence_reason']}")
    return rows, tm_rows


if __name__ == "__main__":
    main()
