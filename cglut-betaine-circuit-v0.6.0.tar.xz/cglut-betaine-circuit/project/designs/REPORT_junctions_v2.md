# Junction panel v2 — recentred register scans, renamed strategies
### Revision of `designs/junctions.csv` / `.fasta`; v1 left intact

Run date **2026-08-23**. Entry point: `run_junction_design_v2.py`.
Outputs: `designs/junctions_v2.csv`, `designs/junctions_v2.fasta`,
`designs/junctions_rename_map.csv`.

Claims tagged **[EVIDENCE]**, **[INFERENCE]** (step named), **[NOT FOUND]**.

---

## Lead: final count and envelope verdict

**Kinase panel: 24 constructs** (unchanged in number — recentring moves join points, it does not
add or remove designs). Includes the **6 EnvZ alternate-backbone designs, kept as instructed.**

| Component | Constructs |
|---|---:|
| Kinase panel (this file, incl. 6 EnvZ alternate-backbone) | **24** |
| Existing non-kinase panels | **69** |
| **Campaign total** | **93** |
| CRO envelope | 48-96 |

### Verdict: **within envelope. No cut needed. Headroom 3.**

**[EVIDENCE]** The 69 was verified against the repo, not taken on trust:
`designs/order_manifest_v2.csv` has exactly **69** data rows and
`designs/order_submit_v2.fasta` exactly **69** sequences.

**[EVIDENCE]** The ranked first cut, **Ptuf**, is present as exactly **3** constructs
(`V2-OTH-13_Ptuf_1x_opA_gap03_repl_v2`, `V2-OTH-14_..._reta_v2`, `V2-OTH-15_Ptuf_noop_ctrl_v2`).
**It has not been cut** — nothing needed cutting. Cutting it would drop the campaign to 90, three
below where it already sits inside the envelope, for no gain.

**[INFERENCE]** (step: 96 − 93) The margin is 3. Any future addition beyond 3 constructs triggers
the ranked cut, and Ptuf goes first — its −35 cannot be located better than 12% of max, it carries
a −20.6 kcal/mol secondary-structure flag, and it carries an EcoRV site. The insertion arm's
wrap-around pairs and the EnvZ arm rank behind it and are not candidates.

---

## Standing caveat: the register measure is being scanned, not trusted

Carried forward verbatim in substance from v1, because recentring does **not** repair it.

**[EVIDENCE]** In all 24 designs the residue immediately upstream of the junction sits inside
**TM2**. A transmembrane helix is hydrophobic at every heptad position, so all seven phases score
alike. Upstream phase contrast never exceeds **0.677**, against **1.66-1.73** for a genuine coiled
coil (PhoQ HAMP AS1 1.73, EnvZ HAMP AS1 1.66). **[EVIDENCE]** Not one design has a well-determined
phase on both sides of its junction.

**[INFERENCE]** (step: a delta computed against a poorly determined phase reference inherits that
uncertainty) Delta is computable, and recentring genuinely moves the triplet so it **spans** the
computed in-phase point rather than sitting entirely off it. That is all it does. **It does not
make delta a reliable predictor of which join will function.** The panel scans register
empirically precisely because register cannot be triaged computationally here. Nothing in this
revision should be read as having identified a best design.

---

## Task 1 — recentring

Rule applied mechanically: search **|shift| ≤ 3** (one heptad period — delta cycles mod 7, so where
the phase mapping is locally linear a delta=0 always exists inside that window); the new nominal
must stay inside the strategy's intended structural element; and for `dhp_direct` the H-box
histidine must survive. Failing any of these, the triplet is left alone.

### 6 of 8 triplets recentred

| Triplet | Old nominal | New nominal | Shift | Δ at −1 / 0 / +1 | Recentred |
|---|---:|---:|---:|:---:|---|
| ECA / PHOQ / **A** | 206 | **204** | **−2** | +1 / **0** / −1 | YES |
| ECA / PHOQ / **linker_retained** | 264 | 264 | 0 | −1 / −2 / −3 | **NO** |
| ECA / PHOQ / **C** | 206 | **209** | **+3** | +1 / **0** / −1 | YES |
| ECA / PHOQ / **dhp_direct** | 268 | **269** | **+1** | +1 / **0** / +3 | YES |
| MCPX / PHOQ / **A** | 206 | **209** | **+3** | +1 / **0** / −1 | YES |
| MCPX / PHOQ / **dhp_direct** | 268 | 268 | 0 | −2 / −3 / +3 | **NO** |
| ECA / ENVZ / **A** | 170 | **169** | **−1** | +1 / **0** / −1 | YES |
| ECA / ENVZ / **dhp_direct** | 234 | **235** | **+1** | −2 / **0** / −1 | YES |

**[EVIDENCE]** In-phase designs rose from **3/24 (v1) to 6/24 (v2)** — one per recentred triplet.
**[EVIDENCE]** Exactly **6 of 24** v2 constructs are byte-identical to their v1 counterpart, which
is precisely the two un-recentred triplets (2 × 3). Every recentred design changed.

**[INFERENCE]** (step: Δ is not perfectly linear in `a_start`, because the downstream phase window
moves with it) Two recentred triplets do not give a clean +1/0/−1 ladder — `ECA/PHOQ/dhp_direct`
gives +1/0/**+3** and `ECA/ENVZ/dhp_direct` gives **−2**/0/−1. The centre is in phase in both; the
flanks are simply not symmetric. This is why the in-phase point was found by **computing** Δ at
every candidate rather than extrapolating from the v1 triplet.

### The 2 triplets that could not be centred — and why

**1. `ECA / PHOQ / linker_retained`** — left at nominal 264.

**[EVIDENCE]** Δ=0 occurs at acceptor residues **255, 262, 269, 273**. The intended element is the
HAMP→DHp linker, **264-267**. **None of the four is inside it.**

**[INFERENCE]** (step: checking each candidate against what the strategy is for)
- 262 lies inside the HAMP (218-263), so the construct would retain 2 HAMP residues — contradicting
  the defining property that the acceptor resumes *past* its HAMP.
- 269 and 273 lie inside the DHp. Worse, **269 is exactly where `ECA/PHOQ/dhp_direct` is now
  centred** — centring `linker_retained` there would make the two strategies the *same construct*,
  destroying the very comparison the pair exists to make.

Not forced. Triplet stands at 263/264/265, Δ = −1/−2/−3, flagged `TRIPLET_NOT_RECENTRED`.

**2. `MCPX / PHOQ / dhp_direct`** — left at nominal 268.

**[EVIDENCE]** **No Δ=0 exists within ±3.** Scanning wider: Δ=0 at 258 (−10, outside DHp), 265 (−3,
outside DHp — it is in the linker), and **276 (+8, genuinely inside the DHp and H-box-preserving)**.

**[INFERENCE]** (step: asking what a +8 shift would physically do) Starting at 276 deletes DHp
residues 268-275, leaving **one residue of α1 before the phosphoacceptor His277**. The H-box would
sit at the extreme N-terminus of the construct's DHp with essentially no helix preceding it. That
is not a recentred design, it is a truncated one. Rejected as forcing it, exactly as the brief
directs.

Not forced. Triplet stands at 267/268/269, Δ = −2/−3/+3, flagged `TRIPLET_NOT_RECENTRED`.

---

## Task 2 — strategy renaming

Applied in the **files** — construct IDs, the `strategy` column, and FASTA headers — not only here.
Full old→new mapping for all 24 designs: **`designs/junctions_rename_map.csv`**.

| Old | New | What the construct actually contains |
|---|---|---|
| A | **A** *(unchanged)* | hybrid TM2 (sensor first half + acceptor second half); **acceptor HAMP retained** |
| **B** | **`linker_retained`** | sensor TM2 intact; acceptor resumes past its HAMP → **no HAMP present**, but the **HAMP→DHp linker is retained** |
| C | **C** *(unchanged)* | hybrid TM2 + 5-residue `GSGSG` linker; **acceptor HAMP retained** |
| **D** | **`dhp_direct`** | sensor TM2 intact; acceptor resumes at the DHp proper → **no HAMP and no HAMP→DHp linker** |

**[EVIDENCE]** The rename was necessary because `WP_043878053.1` has **no HAMP** in
`domain_boundaries_v2.csv` (only `dCache_1` 41-312), so old-B anchored on the acceptor side and its
constructs contain no HAMP at all — the label "immediately after the HAMP region" implied a HAMP was
retained when none is.

**[EVIDENCE]** The two remain genuinely distinct: `linker_retained` resumes at **264** (HAMP→DHp
linker kept, 264-267), `dhp_direct` at **269** on ECA (DHp proper). Both are HAMP-less; they differ
by the retained linker.

ID format changed from `JXN_ECA_PHOQ_B0` to `JXN_ECA_PHOQ_linker_retained_0` — an explicit separator
was added to every ID (`A_m1`, `C_0`, …) so multi-word strategy names parse unambiguously.

---

## Task 3 — checks re-run on the revised set

**[EVIDENCE]** Every check was re-run from scratch on the v2 sequences. **Nothing was carried
forward from v1.** The revised constructs were re-optimised and re-repaired end to end.

| Check | v2 result |
|---|---|
| BsaI / BsmBI / BbsI / SapI / AarI, **both strands** | **0** across all 24 |
| Homopolymer runs > 6 | **0** |
| GC vs 53.8% | **53.62-53.82%**, **0** outliers |
| Unique at DNA level | **24/24** |
| Unique at protein level | **24/24** |
| Translate in frame, no internal stop | **24/24** |
| Spurious SigA ext-10 **at a junction** | **0** |
| Spurious SD+ATG **at a junction** | **0** |
| **H-box histidine present** | **24/24** |

### Checks that failed on v2 but passed on v1

**[NOT FOUND]** — none. Every check passing on v1 also passes on v2. (Searched: the full v2 check
set above, compared against the v1 results for the same eight checks.)

**[EVIDENCE]** The iterative re-synonymisation fix **was applied to the revised sequences**. It is
not optional: the constrained greedy pass alone leaves Golden Gate sites, because when every
synonymous codon violates a constraint the fallback must take one anyway. The global repair
(`repair_all`) then re-synonymises the surrounding codons until nothing remains, alternating with
junction repair because fixing one can create the other. Result above: 0 sites.

**[INFERENCE]** (step: recentring changes the junction sequence, so junction-created defects are
re-rolled) Whole-construct scanning was re-run rather than assumed to still hold. This is the point
the brief makes about load-bearing scanning — a junction-created SigA hit at 0.722 of max was found
in the previous pass, present in neither parent alone, and it was the fourth junction-created defect
in this project. The v2 junctions are new sequence and were re-scanned as such.

**[EVIDENCE]** Codon assignment used the **repo-derived** table from `BX927147.1`
(*C. glutamicum* ATCC 13032, 3,056 CDS, 951,704 codons, CDS GC 54.95%, stop TAA at 53.3%), cached at
`data/cache/codon/cglut_codon_usage.json`. No external codon service was contacted.

### H-box position in every revised construct

**[EVIDENCE]** All 24 retain the phosphoacceptor. Positions shift with the recentred join:

| Design group | Native | Construct position |
|---|---|---|
| `ECA_PHOQ_A_*` | PhoQ His277 | **401-403** |
| `ECA_PHOQ_linker_retained_*` | PhoQ His277 | **351-353** |
| `ECA_PHOQ_C_*` | PhoQ His277 | **401-403** |
| `ECA_PHOQ_dhp_direct_*` | PhoQ His277 | **346-348** |
| `MCPX_PHOQ_A_*` | PhoQ His277 | **396-398** |
| `MCPX_PHOQ_dhp_direct_*` | PhoQ His277 | **347-349** |
| `ECA_ENVZ_A_*` | EnvZ His243 | **402-404** |
| `ECA_ENVZ_dhp_direct_*` | EnvZ His243 | **346-348** |

Exact per-construct positions are in the `hbox_construct_position` column; every one was verified to
carry an **H** at that position, not merely assumed from arithmetic.

---

## Task 4 — panel and campaign reconciliation

Revised kinase panel, unchanged at 24:

| Panel | Sensor | Backbone | Strategies | n |
|---|---|---|---|---:|
| `core_primary` | `WP_043878053.1` | PhoQ | A, linker_retained, C, dhp_direct × 3 | 12 |
| `core_second_sensor` | `Q92SH9` (McpX) | PhoQ | A, dhp_direct × 3 | 6 |
| `alt_backbone` | `WP_043878053.1` | EnvZ | A, dhp_direct × 3 | 6 |

**The EnvZ arm is kept.** **[EVIDENCE]** PhoQ's architecture is divergent — it has **no
Pfam-acceptable HisKA** under gathering thresholds (26.2 bits against GA 26.9) and a PhoQ-specific
HAMP family **PF26769** rather than the generic PF00672. **[INFERENCE]** (step: a panel built
entirely on a divergent backbone cannot distinguish "this junction strategy fails" from "this
backbone is unusual") EnvZ, whose HisKA and HAMP both pass gathering thresholds at HIGH confidence,
is the canonical-architecture control that separates those two explanations. It is a control, not a
luxury.

**Campaign total 93 against an envelope of 48-96 — within range, no cut required.**

---

## Files

```
designs/junctions_v2.csv           24 rows; recentring columns, register, checks, H-box, flags
designs/junctions_v2.fasta         24 DNA sequences, renamed headers
designs/junctions_rename_map.csv   old ID -> new ID, old/new residue, shift, recentred YES/NO
designs/REPORT_junctions_v2.md     this file
run_junction_design_v2.py          entry point -- offline, deterministic
```

Reproduce with `python3 run_junction_design_v2.py`. No network required.

**v1 files were not overwritten**: `designs/junctions.csv`, `designs/junctions.fasta` and
`designs/REPORT_junctions.md` are untouched, and all four v2 paths were confirmed absent before
writing.
