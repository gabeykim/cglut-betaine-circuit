# Final order manifest: all 93 constructs, checked as one combined set

Built by `scripts/consolidate_final.py`; this report generated from the written data files by `scripts/report_order_final.py`. No existing path was overwritten and no builder was re-run: the two source panels (`designs/order_manifest_v2.csv`, `designs/junctions_v2.csv` + `.fasta`) were read as-is and every sequence in the output is byte-identical to its source.

Tags: **[EVIDENCE]** computed here or stated by a citable source. **[INFERENCE]** reasoning from evidence, step named. **[NOT FOUND]** searched and absent.

**No construct here is claimed to work.** Nothing below is a prediction of expression, of signalling, or of assembly success.

---

## 0. LEAD — what the combined set found that the per-panel checks did not

**No check that a per-panel pass actually ran, fails at the combined level.** Golden Gate is clean across all 93 constructs on both strands (0 BsaI/BsmBI/BbsI/SapI/AarI sites found), there are no identical sequences, no homopolymer run longer than 6, and no junction-created SigA or SD element on the sense strand. Saying that explicitly rather than leaving it implied by absence: **the four historical boundary defects have not recurred, and no new one of that exact class was found.** [EVIDENCE, computed over all 93]

**Four things are true only at the combined level, and were invisible to every per-panel check.** Ranked by consequence:

**1 — 18 of 24 kinase constructs carry an internal NcoI site, and NcoI is the other panels' vector's own opening enzyme. This is the HP-4 defect, one panel over.** [EVIDENCE] The kinase panel's own check screened exactly five enzymes (the Golden Gate set) — `scripts/junction_design.py` defines `GOLDEN_GATE` and nothing else — so no per-panel pass ever looked for NcoI in a kinase construct. Scanning the same 35-enzyme catalogue the promoter panels use finds NcoI in every PhoQ-acceptor construct. It is **not** a Golden Gate blocker, and it is **not** yet a confirmed blocker at all, because **the kinase panel declares no destination vector anywhere in the repo** [NOT FOUND: `pECXT99A` appears only in the promoter and translational panel files]. If the kinase constructs go into pECXT99A — the vector the other 69 use, opened with NcoI/NdeI — those 18 are blocked. The site sits in codon-optimised synthetic DNA, not in borrowed sequence, so it is removable by re-synonymising one codon pair.

**2 — 436 restriction sites across 9 enzymes sit in the kinase constructs and had never been looked for.** [EVIDENCE] Same root cause as (1): the kinase panel screened 5 of 35 enzymes. None of them interferes with Golden Gate.

**3 — Constructs in different kinase sub-panels share up to 1020 bp of exact DNA.** [EVIDENCE] `JXN_ECA_ENVZ_dhp_direct_m1` and `JXN_ECA_PHOQ_dhp_direct_0` share a 1020 bp identical run — the shared sensor, codon-optimised deterministically to the same string in both. Cross-panel sequence sharing was never a per-panel question. It does not cause Golden Gate misassembly (joins are set by overhangs), but it does mean a sequencing read landing inside that run cannot be assigned to a construct.

**4 — The Golden Gate overhangs do not exist yet.** [NOT FOUND] Golden Gate is named as the selected route in every panel, but a search of `scripts/`, `designs/`, `results/`, `*.py` and `*.md` for `overhang`, `fusion site` or `sticky` returns zero hits. This is a remaining design step, not a check failure — but it is the step that decides whether (3) matters.

Two further things changed only because this pass ran checks nobody had run before — a different claim from 'a check failed', and labelled as such throughout. The **reverse strand** was scanned for SigA elements for the first time (§3.2): it found 3 windows, all in kinase constructs, and **one of them does span the sensor/acceptor junction** at 0.722 of matrix max — the follow-up parent-alone test in §3.2 shows it does not exceed what its own sensor component already carried, so it is a note rather than a fifth boundary defect. And the kinase constructs were put through the **synthesis-difficulty and folding** screen for the first time (§4.4–4.5): all 24 carry a strong local hairpin, which is a cost signal, not a defect.

---

## 1. Task 1 — consolidation and count

Counted, not assumed: every number below is a row count or a FASTA record count taken at read time.

| panel | constructs | length range (bp) | total bp |
|---|---|---|---|
| `combinatorial_1_independence_3x4` | 9 | 157–157 | 1413 |
| `combinatorial_2_tuning_curve` | 8 | 157–157 | 1256 |
| `combinatorial_3_leadered_probe` | 2 | 229–229 | 458 |
| `insertion_phasing` | 18 | 80–159 | 1826 |
| `kinase_junction_alt_backbone` | 6 | 1662–1836 | 10494 |
| `kinase_junction_core_primary` | 12 | 1671–1842 | 21123 |
| `kinase_junction_core_second_sensor` | 6 | 1674–1827 | 10503 |
| `phasing_swap_controls` | 3 | 80–87 | 247 |
| `retained_context` | 4 | 74–210 | 522 |
| `substitution_phasing` | 14 | 80–80 | 1120 |
| `tier1_nonphasing` | 11 | 64–200 | 1349 |
| **TOTAL** | **93** | **64–1842** | **50311** |

**93 constructs.** Reconciliation against the expected 93: 69 non-kinase (all 69 rows of `order_manifest_v2.csv`, which equals the 69 records of `order_submit_v2.fasta`) + 24 kinase (all 24 rows of `junctions_v2.csv`, which equals the 24 records of `junctions_v2.fasta`, ids matching set-for-set) = **93. MATCH.** [EVIDENCE]

**The fore-cistron / translational panel is not a separate order line, and that is why the expected total is 93 rather than 104.** [EVIDENCE] `designs/translational_variants.csv` holds 12 rows but `designs/translational_variants.fasta` holds 11 records: the 12th, `T2_MCD_ctrl`, has an empty sequence because the monocistronic control *is* the promoter fragment with nothing appended. The other 11 are 77 bp elements, not constructs — each needs a promoter in front of it, and each appears inside the 19 combinatorial constructs as a component. The panel is therefore fully represented in the order, as components with their own provenance line, and is not double-counted.

**Retained-context variants** are broken out as their own panel here (4 constructs) because the task names them as a panel; in `order_manifest_v2.csv` they sat inside `tier-1 non-phasing (rebuilt)`. No construct moved, only its label.

### The component map is verified, not asserted

Every one of the 93 constructs was decomposed into named components (`designs/order_manifest_final_components.csv`, 400 rows) and **the concatenation of the parts was asserted equal to the stored `full_sequence`, base for base, for all 93.** [EVIDENCE] For the kinase constructs the DNA was additionally back-translated and checked against `protein_seq`, and the sensor prefix and acceptor suffix checked against the source FASTA files. Without that, every 'spans a junction' claim below would be guesswork.

### construct_id is parseable, including the kinase multi-word strategies

`JXN_<sensor>_<acceptor>_<strategy>_<offset>` — the strategy field may itself contain `_` (`linker_retained`, `dhp_direct`), so the rule is: field 0 is `JXN`, fields 1–2 are sensor and acceptor, the **last** field is the register offset (`m1`/`0`/`p1`), and everything between is the strategy. That parse was run against all 24 and checked against the `strategy` and `register_offset` columns of `junctions_v2.csv`; all 24 agree. [EVIDENCE] Non-kinase ids match `^V2-(SUB|INS|CTL|OTH|CX)-\d{2}_` and are unique. No id collides across the 93.

---

## 2. Task 2 — enzyme check, enumerated from provenance

The list is read off the **sourced components**, not off the assembly plan. That is the failure mode that produced the HP-4 NcoI collision, the NsiI/SphI collision, and the ScaI/StuI/EcoRV/XhoI misses: enzymes arrive *with* borrowed sequence, so the only safe list is the one the sequences themselves dictate. Every sourced component actually used in the 93 was scanned against the **35-enzyme catalogue** on both strands.

**Sourced DNA — sequence physically borrowed into the construct. Any enzyme site here arrived *with* the borrowed bases and cannot be removed without changing sourced sequence.**

| sourced DNA component | enzymes it brings | provenance |
|---|---|---|
| `core:PsodA` | **ScaI**, **StuI** | core promoter PsodA: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC78 |
| `core:Ptuf` | **EcoRV** | core promoter Ptuf: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC783 |
| `ctx:Psyn_N105_tail` | **NsiI**, **SphI** | retained upstream context: PMC7835838 Table 2, vector-homology tail of primer  |
| `forecistron:HP-12` | **XhoI** | fore-cistron HP-12 (NCgl2826, NCgl2826): Liu et al. 2023 ACS Synth Biol 12:215 |
| `forecistron:HP-6` | **BamHI** | fore-cistron HP-6 (NCgl2501, NCgl2501): Liu et al. 2023 ACS Synth Biol 12:2157 |

**Enzymes arriving with borrowed sequence: `BamHI`, `EcoRV`, `NsiI`, `ScaI`, `SphI`, `StuI`, `XhoI` (7).** [EVIDENCE, computed] Four of them — `ScaI`, `StuI`, `EcoRV`, `XhoI` — are the ones a 15-enzyme list derived from the assembly plan missed, and all four are still here, still inside sourced sequence, still invisible to any plan-derived list.

**Sourced protein, synthetic DNA — the kinase constructs. These are the trap this table exists to avoid falling into.** Their sourced components are *proteins*; the DNA was written by the codon optimiser against the BX927147.1 CDS table. Sites in them are therefore **not borrowed** — they are artefacts of an optimiser that screened for exactly five enzymes (`scripts/junction_design.py` `_bad_spans` checks `GOLDEN_GATE` and homopolymers, nothing else). [INFERENCE, reasoning named] They are listed separately because that distinction decides whether a site can be removed: these can, by re-synonymising, without changing one amino acid.

| protein-sourced segment | enzymes in its synthetic DNA | protein accession |
|---|---|---|
| `acceptor:P0AEJ4` | `KpnI`, `PvuII`, `SphI` | UniProt P0AEJ4 (EnvZ), Escherichia coli K-12 |
| `acceptor:P0DM80` | `BglII`, `HpaI`, `NcoI`, `PstI`, `PvuII`, `ScaI`, `SphI` | UniProt P0DM80 (PhoQ), Salmonella Typhimurium LT2 |
| `sensor:Q92SH9` | `PstI`, `PvuII` | UniProt Q92SH9 (McpX), Rhizobium meliloti 1021 |
| `sensor:WP_043878053.1` | `EcoRI`, `KpnI`, `PstI`, `PvuII` | RefSeq WP_043878053.1, methyl-accepting chemotaxis protein, Pect |

**Working list: 14 enzymes** = 7 arriving with borrowed sequence ∪ the pECXT99A opening sites (`NcoI`, `NdeI`) ∪ the Golden Gate set. But **all 93 constructs were scanned against the full 35-enzyme catalogue on both strands regardless**, so nothing below depends on that working list being complete — which is the point, since a provenance-derived list is only as good as the provenance you thought to read.

### 2.1 Golden Gate — the explicit confirmation

**Zero BsaI, BsmBI, BbsI, SapI or AarI sites across all 93 constructs, on BOTH strands.** [EVIDENCE, computed] The finder was positive-control tested before this null was trusted: it is shown to find a BsaI site formed only across a component join, a non-palindromic site present only on the minus strand, and to report a palindromic site on both strands, and *not* to call a site wholly inside one component a junction-spanning one. Those assertions run at the top of every execution of `scripts/consolidate_final.py`.

### 2.2 Every site found, by enzyme

| enzyme | site | hits (both strands) | constructs | non-kinase / kinase | class |
|---|---|---|---|---|---|
| `PstI` | CTGCAG | 92 | 24 | 0 / 24 | note |
| `BglII` | AGATCT | 80 | 18 | 0 / 18 | note |
| `PvuII` | CAGCTG | 68 | 24 | 0 / 24 | note |
| `ScaI` | AGTACT | 56 | 28 | 10 / 18 | note |
| `KpnI` | GGTACC | 46 | 18 | 0 / 18 | note |
| `EcoRI` | GAATTC | 36 | 18 | 0 / 18 | note |
| `NcoI` | CCATGG | 36 | 18 | 0 / 18 | CONDITIONAL |
| `SphI` | GCATGC | 34 | 16 | 2 / 14 | note |
| `StuI` | AGGCCT | 20 | 10 | 10 / 0 | note |
| `HpaI` | GTTAAC | 12 | 6 | 0 / 6 | note |
| `BamHI` | GGATCC | 8 | 4 | 4 / 0 | note |
| `EcoRV` | GATATC | 6 | 3 | 3 / 0 | note |
| `XhoI` | CTCGAG | 6 | 3 | 3 / 0 | note |
| `NsiI` | ATGCAT | 4 | 2 | 2 / 0 | note |

Palindromic sites are counted once per strand, so a single physical site contributes 2 hits. Full detail — construct, position, strand, and the component the site sits in — is one row per site in **`designs/order_manifest_final_sites.csv`** (504 rows). [EVIDENCE]

**Not one of the 504 sites spans a component junction.** [EVIDENCE] Every site lies wholly inside a single component; none was created by two components meeting. The junction-straddling positive control passes, so this null is a real null.

### 2.3 Blockers versus notes

| class | count | which | why |
|---|---|---|---|
| **BLOCKER** — interferes with Golden Gate, the selected route | **0** | — | no Type IIS site of the five exists in any of the 93 |
| **CONDITIONAL BLOCKER** — interferes with the *other* route this repo declares | **18 constructs** | `NcoI` in 18 kinase constructs, every one PhoQ-acceptor; `NdeI`: none found | pECXT99A is opened with NcoI/NdeI and supplies the target ATG at that NcoI site. Blocked **only if** the kinase panel uses that vector, which is nowhere stated |
| **NOTE** | 468 sites | `BamHI`, `BglII`, `EcoRI`, `EcoRV`, `HpaI`, `KpnI`, `NsiI`, `PstI`, `PvuII`, `ScaI`, `SphI`, `StuI`, `XhoI` | none is used by the selected assembly route or by the declared vector opening. They matter only for downstream sub-cloning and diagnostic digests, and are recorded so a later route change is a lookup rather than a rediscovery |

The `NcoI`-carrying constructs, from the data: `JXN_ECA_PHOQ_A_0`, `JXN_ECA_PHOQ_A_m1`, `JXN_ECA_PHOQ_A_p1`, `JXN_ECA_PHOQ_C_0`, `JXN_ECA_PHOQ_C_m1`, `JXN_ECA_PHOQ_C_p1`, `JXN_ECA_PHOQ_dhp_direct_0`, `JXN_ECA_PHOQ_dhp_direct_m1`, `JXN_ECA_PHOQ_dhp_direct_p1`, `JXN_ECA_PHOQ_linker_retained_0`, `JXN_ECA_PHOQ_linker_retained_m1`, `JXN_ECA_PHOQ_linker_retained_p1`, `JXN_MCPX_PHOQ_A_0`, `JXN_MCPX_PHOQ_A_m1`, `JXN_MCPX_PHOQ_A_p1`, `JXN_MCPX_PHOQ_dhp_direct_0`, `JXN_MCPX_PHOQ_dhp_direct_m1`, `JXN_MCPX_PHOQ_dhp_direct_p1`. [EVIDENCE] The six ENVZ-acceptor constructs are clean of it.

#### The NcoI sites are one codon pair, and one synonymous change removes all of them

Every one of the 18 sites is the **same residue pair**: `SMD` — PhoQ Ser364–Met365 in `P0DM80` numbering, which the deterministic optimiser encodes identically in every construct that contains it (`TCC ATG GAC`). [EVIDENCE, computed] The `ATG` is a real methionine and cannot move; the serine codon can.

| construct | NcoI at (nt) | construct residue | native P0DM80 residue | one-codon synonymous fix | C. glutamicum relative usage of the replacement |
|---|---|---|---|---|---|
| `JXN_ECA_PHOQ_A_0` | 1465 | Met490 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_A_m1` | 1468 | Met491 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_A_p1` | 1462 | Met489 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_C_0` | 1465 | Met490 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_C_m1` | 1468 | Met491 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_C_p1` | 1462 | Met489 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_dhp_direct_0` | 1300 | Met435 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_dhp_direct_m1` | 1303 | Met436 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_dhp_direct_p1` | 1297 | Met434 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_linker_retained_0` | 1315 | Met440 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_linker_retained_m1` | 1318 | Met441 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_ECA_PHOQ_linker_retained_p1` | 1312 | Met439 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_MCPX_PHOQ_A_0` | 1450 | Met485 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_MCPX_PHOQ_A_m1` | 1453 | Met486 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_MCPX_PHOQ_A_p1` | 1447 | Met484 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_MCPX_PHOQ_dhp_direct_0` | 1303 | Met436 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_MCPX_PHOQ_dhp_direct_m1` | 1306 | Met437 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |
| `JXN_MCPX_PHOQ_dhp_direct_p1` | 1300 | Met435 | Met365 | `TCC`→`TCT` (Ser) | 0.174 |

**All 18 are removable by a single synonymous substitution, verified by back-translation: `TCC`→`TCT` at the serine immediately 5′ of Met365, protein unchanged.** [EVIDENCE, computed] `TCT` sits at 0.174 relative usage in the BX927147.1 codon table, above the optimiser's own 0.10 floor, so the fix needs no rare codon and no relaxation of the optimiser's constraints — only `NcoI` and `NdeI` added to its forbidden set.

---

## 3. Task 3 — whole-construct scans, with junction attribution

Every scan below ran on the **complete construct**, never on a component. Each hit is then attributed to the component(s) it overlaps, so a hit created where two components meet is separated from a hit that lives inside one of them. This is the class of defect the whole task exists to find.

**Standing caveat on the SigA matrix, carried into every number in this section.** It is a reasoned approximation built from the *textual* IUPAC consensus of Patek & Nesvera 2011 and Pfeifer-Sancar et al. 2013, not a PWM trained on aligned, confirmed C. glutamicum promoters. Scores are reported as a fraction of the matrix maximum. A clean scan means *no consensus-like cryptic promoter*, not *no cryptic promoter*. [EVIDENCE: `scripts/siga_consensus.py` module docstring]

### 3.1 SigA-like extended −10 elements

| class | windows | constructs | score range (fraction of max) | which set |
|---|---|---|---|---|
| `SPURIOUS_WITHIN_COMPONENT` | 84 | 24 | 0.630–0.722 | kinase |
| `INTENDED_CORE_MINUS10` | 69 | 69 | 0.630–1.000 | non-kinase |
| `ANTISENSE_WITHIN_COMPONENT` | 2 | 2 | 0.630–0.630 | kinase |
| `ANTISENSE_JUNCTION_CREATED` | 1 | 1 | 0.722–0.722 | kinase |

Threshold 0.55 of matrix max, window width 13 nt. `INTENDED_CORE_MINUS10` = the hit the design put there, checked against the **mapped** extended −10 coordinates in `data/cache/promoter_elements.json` rather than against the whole amplicon. Full detail in **`designs/order_manifest_final_motifs.csv`**.

**Sense strand: zero spurious SigA elements in any of the 69 non-kinase constructs** — the construct-aware background redesign holds up in the combined set. [EVIDENCE] The 84 sense-strand spurious hits are all in the 24 kinase constructs, all **inside a single component** (codon-optimised CDS), none at a junction. The kinase panel already counted these — `junctions_v2.csv` carries a `spurious_sigA_ext10_total` column — and flagged only the junction ones, so this is a confirmation of the per-panel result, not a new finding.

**A cryptic sense-strand promoter inside a coding sequence is a different risk from one in a promoter fragment** [INFERENCE, reasoning named]: it would initiate a truncated transcript of the same gene, not drive an unintended gene, and the kinase constructs are CDSs whose own promoter is supplied by whatever vector they land in. It is recorded as a note, not a blocker.

### 3.2 Reverse strand — a scan no previous pass ran

The repo's convention has been to scan the sense strand only, which is right for the question 'does a cryptic promoter drive the reporter'. It misses antisense promoters. Scanning the reverse strand of all 93 for the first time finds **3 windows at or above 0.55 of max, all in kinase constructs**, of which 1 spans the sensor/acceptor junction. [EVIDENCE]

| construct | start | strand | fraction of max | window | spans junction | component(s) |
|---|---|---|---|---|---|---|
| `JXN_MCPX_PHOQ_dhp_direct_m1` | 1011 | - | 0.722 | `TGCGGTACTTTGC` | YES | `acceptor:P0DM80[aa 267-487]\|sensor:Q92SH9[aa 1-338]` |
| `JXN_ECA_ENVZ_A_p1` | 1440 | - | 0.63 | `CTGGGTACAGTGC` | no | `acceptor:P0AEJ4[aa 170-450]` |
| `JXN_ECA_ENVZ_dhp_direct_m1` | 1278 | - | 0.63 | `CTGGGTACAGTGC` | no | `acceptor:P0AEJ4[aa 234-450]` |


**Parent-alone check for the one junction-spanning window** (`JXN_MCPX_PHOQ_dhp_direct_m1`, reverse strand @1011, 0.722 of max, window `TGCGGTACTTTGC`):

| parent component | best sense score in that component alone | best antisense score alone |
|---|---|---|
| `sensor:Q92SH9[aa 1-338]` | 0.722 | 0.537 |
| `acceptor:P0DM80[aa 267-487]` | 0.63 | 0.529 |

**Verdict: junction-created by construction — the 13-mer straddles the join, so it exists in neither parent as a contiguous window — but NOT a new severity level.** [EVIDENCE] The `sensor:Q92SH9[aa 1-338]` component *alone* already reaches 0.722 of max on its own sense strand, so this construct was already carrying an element of exactly this strength inside a single component. The junction did not raise the ceiling. Recorded as a note. This is the check that the four historical defects would have tripped, and it is doing its job: it fired, and the follow-up test told us the hit is not the dangerous kind.

### 3.3 SD-like motifs and unintended start codons

Scan: `GGAGG`/`AGGAG`/`GGAG` followed by an `ATG` 3–14 nt downstream, excluding each design's own intended start (the fore-cistron AUG in a BCD construct, the initiator in a CDS). **6 hits across all 93, 0 of them spanning a component junction.** [EVIDENCE]

| construct | detail | spans junction | component | class |
|---|---|---|---|---|
| `JXN_ECA_PHOQ_A_m1` | SD(GGAGG)+ATG@1627 spacing=3 | no | `acceptor:P0DM80[aa 203-487]` | SPURIOUS_WITHIN_COMPONENT |
| `JXN_ECA_PHOQ_linker_retained_p1` | SD(GGAGG)+ATG@1471 spacing=3 | no | `acceptor:P0DM80[aa 265-487]` | SPURIOUS_WITHIN_COMPONENT |
| `JXN_ECA_PHOQ_C_m1` | SD(GGAGG)+ATG@1627 spacing=3 | no | `acceptor:P0DM80[aa 208-487]` | SPURIOUS_WITHIN_COMPONENT |
| `JXN_ECA_PHOQ_dhp_direct_p1` | SD(GGAGG)+ATG@1456 spacing=3 | no | `acceptor:P0DM80[aa 270-487]` | SPURIOUS_WITHIN_COMPONENT |
| `JXN_MCPX_PHOQ_A_m1` | SD(GGAGG)+ATG@1612 spacing=3 | no | `acceptor:P0DM80[aa 208-487]` | SPURIOUS_WITHIN_COMPONENT |
| `JXN_MCPX_PHOQ_dhp_direct_m1` | SD(GGAGG)+ATG@1465 spacing=3 | no | `acceptor:P0DM80[aa 267-487]` | SPURIOUS_WITHIN_COMPONENT |

**Zero in the 69 non-kinase constructs; all 6 sit inside the codon-optimised `P0DM80` acceptor segment of a kinase construct, none at a junction.** [EVIDENCE] Each is an internal-initiation risk that would yield an N-terminally truncated kinase — a note, and removable by re-synonymising, since the DNA is synthetic. The same six show in the kinase panel's own `spurious_SD_ATG_total` column, so this too confirms rather than contradicts the per-panel result.

### 3.4 Junction-spanning summary — the answer to the question this task was built around

| scan | hits total | hits inside one component | hits SPANNING a component junction |
|---|---|---|---|
| restriction sites (35 enzymes, both strands) | 504 | 504 | 0 |
| SigA extended −10, sense | 153 | 153 | 0 |
| SigA extended −10, antisense | 3 | 2 | 1 |
| SD-like + ATG | 6 | 6 | 0 |

**One junction-spanning hit in total across every scan, and it is shown above not to exceed what its own parent component already carried.** [EVIDENCE]

---

## 4. Task 4 — remaining checks

### 4.1 Uniqueness, DNA and protein

- **Identical sequences: 0.** No two of the 93 share a full sequence. [EVIDENCE]
- **DNA pairs at ≥95% ungapped identity: 9.**
- **Protein pairs at ≥95% ungapped identity (kinase only, 24 proteins): 3.** No two kinase proteins are identical.

| a | b | identity % | level | intended matched pair | relationship |
|---|---|---|---|---|---|
| `V2-CX-06_SUB_Psyn_opA_gap03__HP07_gpmA` | `V2-CX-15_SUB_Psyn_opA_gap03__HP07_fcATGtoATC_NEG` | 99.36 | DNA | YES | same designed series, swept variable only (phasing gap / fore-cistron identity) |
| `V2-CX-06_SUB_Psyn_opA_gap03__HP07_gpmA` | `V2-CX-17_SUB_Psyn_opA_gap03__HP07_fcATGtoGTG_PARTIAL` | 99.36 | DNA | YES | same designed series, swept variable only (phasing gap / fore-cistron identity) |
| `JXN_ECA_PHOQ_A_0` | `JXN_ECA_PHOQ_C_0` | 99.24 | DNA | YES | same sensor+acceptor, different junction strategy (deliberate strategy comparison) |
| `JXN_ECA_PHOQ_A_p1` | `JXN_ECA_PHOQ_C_p1` | 99.18 | DNA | YES | same sensor+acceptor, different junction strategy (deliberate strategy comparison) |
| `JXN_ECA_PHOQ_A_m1` | `JXN_ECA_PHOQ_C_m1` | 99.18 | protein | YES | same sensor+acceptor, different junction strategy (deliberate strategy comparison) |
| `JXN_ECA_PHOQ_A_0` | `JXN_ECA_PHOQ_C_0` | 99.18 | protein | YES | same sensor+acceptor, different junction strategy (deliberate strategy comparison) |
| `JXN_ECA_PHOQ_A_p1` | `JXN_ECA_PHOQ_C_p1` | 99.18 | protein | YES | same sensor+acceptor, different junction strategy (deliberate strategy comparison) |
| `JXN_ECA_PHOQ_A_m1` | `JXN_ECA_PHOQ_C_m1` | 99.08 | DNA | YES | same sensor+acceptor, different junction strategy (deliberate strategy comparison) |
| `V2-CX-15_SUB_Psyn_opA_gap03__HP07_fcATGtoATC_NEG` | `V2-CX-17_SUB_Psyn_opA_gap03__HP07_fcATGtoGTG_PARTIAL` | 98.73 | DNA | YES | same designed series, swept variable only (phasing gap / fore-cistron identity) |
| `V2-CX-06_SUB_Psyn_opA_gap03__HP07_gpmA` | `V2-CX-16_SUB_Psyn_opA_gap03__HP07_SDmut_NEG` | 96.82 | DNA | YES | same designed series, swept variable only (phasing gap / fore-cistron identity) |
| `V2-CX-15_SUB_Psyn_opA_gap03__HP07_fcATGtoATC_NEG` | `V2-CX-16_SUB_Psyn_opA_gap03__HP07_SDmut_NEG` | 96.18 | DNA | YES | same designed series, swept variable only (phasing gap / fore-cistron identity) |
| `V2-CX-16_SUB_Psyn_opA_gap03__HP07_SDmut_NEG` | `V2-CX-17_SUB_Psyn_opA_gap03__HP07_fcATGtoGTG_PARTIAL` | 96.18 | DNA | YES | same designed series, swept variable only (phasing gap / fore-cistron identity) |

**Every ≥95% pair is a declared matched pair. 0 are unaccounted for.** [EVIDENCE] The A-vs-C pairs at 99.18% (protein) and 99.08–99.24% (DNA) are the deliberate linker comparison — strategy C is strategy A with five acceptor residues replaced by `GSGSG` at constant length, which is exactly what `strategy_contains` says it is. The other 6 DNA pairs are all within the HP-7 group: the fore-cistron parent against its own declared disabling and attenuating mutants — the fore-cistron-identity sweep at gap 3.

The register triplets are **not** near-duplicates at the DNA level despite being near-identical designs: the codon optimiser is a deterministic greedy walk from the 5′ end, so shifting the acceptor start by one residue re-derives every downstream codon. Within-triplet DNA identity runs around 71%. [EVIDENCE, from `order_manifest_final_pairs.csv`] That is worth knowing before anyone designs a diagnostic PCR expecting the triplet members to behave alike.

### 4.2 Homopolymer runs longer than 6

**0 of 93 constructs carry a run longer than 6.** [EVIDENCE] The finder is positive-control tested (it finds `A×7`, and does not fire on `A×6`) before this null is trusted.

### 4.3 GC against the 53.8% host average

- Kinase constructs: **53.62–53.82% GC**, every one inside ±0.22 points of the 53.84% host average. Codon optimisation targets host GC explicitly, and it worked.
- Non-kinase constructs: **30.61–47.37% GC**.
- **38 constructs fall outside ±15 points of 53.84%. Every one is Psyn-cored, and every one is *below* the host average, spanning 30.61–37.36%.** [EVIDENCE, computed]

The known Psyn band is 29.6–36.5%. The observed band is 30.61–37.36%, so 4 constructs sit just above the top of that band (`V2-INS-12_INS_Psyn_opA_gap11` 37.36%, `V2-INS-13_INS_Psyn_opA_gap12` 36.96%, `V2-INS-11_INS_Psyn_opA_gap10` 36.67%, `V2-INS-14_INS_Psyn_opA_gap13` 36.56%). All 4 are long-gap insertion-arm variants, where the rebuilt `FILL_A` filler (53.8% GC, host-matched by design) adds up to 13 GC-rich bases to an AT-rich construct. [INFERENCE, reasoning named] That is the corrected filler doing what it was rebuilt to do, pulling composition *toward* the host — not a new bias. No construct fell below the band.

#### Is the AT-richness in the core elements, or spread across spacers and flanks?

| component class | occurrences | total bp | GC% | sourced or designed |
|---|---|---|---|---|
| sourced sensor CDS (codon-optimised DNA) | 24 | 23976 | 53.7 | sourced |
| sourced acceptor CDS (codon-optimised DNA) | 24 | 18027 | 53.9 | sourced |
| sourced core promoter: rest of amplicon (spacer + downstream) | 69 | 3387 | 34.9 | sourced |
| designed background / upstream flank | 94 | 1950 | 53.3 | designed |
| sourced fore-cistron (leaderless BCD) | 19 | 1178 | 51.4 | sourced |
| sourced operator (PRODORIC Sal_PhoP site) | 67 | 1072 | 12.9 | sourced |
| sourced SD2 motif | 19 | 247 | 46.2 | sourced |
| designed gap filler | 29 | 159 | 47.8 | designed |
| sourced retained upstream context | 4 | 122 | 55.7 | sourced |
| stop codon | 24 | 72 | 0.0 | designed |
| designed peptide linker | 3 | 45 | 73.3 | designed |
| sourced TAATG coupling frame (5' 2 nt) | 19 | 38 | 0.0 | sourced |
| designed scramble control | 2 | 32 | 12.5 | designed |
| designed inter-operator spacer | 3 | 6 | 50.0 | designed |

The sourced core amplicon, split into its **mapped** elements:

| core promoter sub-element | occurrences | total bp | GC% |
|---|---|---|---|
| mapped −35 hexamer | 69 | 414 | 34.1 |
| mapped extended −10 | 69 | 897 | 32.7 |
| core amplicon, everything else (spacer + downstream) | 69 | 2076 | 36.0 |

**Verdict: the AT sits in the two sourced elements that are AT-rich by nature, and every designed flank sits at host composition. This is expected concentration, not systematic design bias.** [EVIDENCE, computed from the component table] The sourced operator runs 12.9% GC and the core promoter's own mapped elements run 34.1% (−35) and 32.7% (extended −10) — extended −10 regions are AT-rich, which is what makes them extended −10 regions. Against that, the **designed** backgrounds and upstream flanks run 53.3% GC and the designed gap filler 47.8%, against a host average of 53.84%. Nothing designed drifts AT-ward.

One honest qualification: the rest of the core amplicon — spacer and downstream, 36.0% GC — is also AT-rich and is *not* a mapped promoter element. It is still **sourced natural sequence** (the real sodA/tuf promoter regions, and the published synthetic Psyn), so it is not design bias either; it is simply what those fragments are. [INFERENCE, reasoning named]

### 4.4 Secondary structure — DEFECT SCREEN ONLY

**Folding energy is not used to rank anything here, and no dG below is a strength prediction.** It has already been shown to fail as a rank predictor in this host: HP-12 is the least structured tier-2 element and ranks only intermediate in measured strength. [EVIDENCE: `designs/REPORT_translational.md` §3] dG is reported to catch synthesis and cloning defects and for nothing else.

Folded with ViennaRNA (python bindings, RNA 2.7.2). Two numbers per construct: whole-fragment MFE, which scales with length and therefore mostly reports length, and the worst 60-nt local window, which does not.

| set | whole-fragment MFE (kcal/mol) | worst 60-nt window (kcal/mol) | windows ≤ −20.6 |
|---|---|---|---|
| non-kinase (69) | -88.9 … -6.3 | -24.5 … -4.1 | 3 |
| kinase (24) | -665.1 … -586.4 | -27.5 … -23.9 | 24 |

**27 of 93 constructs carry a 60-nt window at or below −20.6 kcal/mol**, the bar the tier-1 panel already used. [EVIDENCE] By panel: kinase_junction_alt_backbone 6, kinase_junction_core_primary 12, kinase_junction_core_second_sensor 6, retained_context 1, tier1_nonphasing 2.

**24 of them are the kinase constructs — all 24 of them — and this is the first time the kinase panel has been through this screen at all.** [EVIDENCE: `scripts/junction_design.py` computes Golden Gate sites, homopolymers and GC, and no folding.] The five worst: `JXN_MCPX_PHOQ_dhp_direct_m1` -27.5, `JXN_MCPX_PHOQ_dhp_direct_0` -27.5, `JXN_MCPX_PHOQ_dhp_direct_p1` -27.5, `JXN_MCPX_PHOQ_A_m1` -26.2, `JXN_MCPX_PHOQ_A_0` -26.2. A 1.7 kb codon-optimised CDS at host GC will fold; that is expected and is a synthesis-cost signal, not a design fault. It is flagged so the vendor quote is not a surprise.

### 4.5 Synthesis-difficulty flags

| flag | constructs | non-kinase / kinase | panels |
|---|---|---|---|
| `UNDER_VENDOR_MIN` | 39 | 39 / 0 | insertion_phasing 14, phasing_swap_controls 3, retained_context 2, substitution_phasing 14, tier1_nonphasing 6 |
| `EXTREME_GC` | 30 | 30 / 0 | insertion_phasing 8, phasing_swap_controls 3, retained_context 2, substitution_phasing 14, tier1_nonphasing 3 |
| `STRONG_LOCAL_HAIRPIN` | 27 | 3 / 24 | kinase_junction_alt_backbone 6, kinase_junction_core_primary 12, kinase_junction_core_second_sensor 6, retained_context 1, tier1_nonphasing 2 |
| `G_TRACT` | 25 | 7 / 18 | combinatorial_1_independence_3x4 3, combinatorial_3_leadered_probe 1, kinase_junction_alt_backbone 6, kinase_junction_core_primary 12, retained_context 1, tier1_nonphasing 2 |

`INTERNAL_REPEAT_20nt` fires on **0** constructs: no 20-mer occurs twice inside any single construct. [EVIDENCE] `G_TRACT` counts runs of ≥4 G and G-quadruplex-like `G3N1-7 ×4` motifs. These four flags are the ones vendors price on; none of them blocks anything.

### 4.6 Length distribution and the vendor minimum

| length (bp) | constructs | share |
|---|---|---|
| 0 – 125 | 39 | 42% |
| 125 – 200 | 26 | 28% |
| 200 – 400 | 4 | 4% |
| 400 – 1000 | 0 | 0% |
| 1000 – ∞ | 24 | 26% |

min 64 bp, median 157 bp, max 1842 bp, total 50311 bp.

**39 of 93 constructs fall below 125 bp.** [EVIDENCE] By panel: 

| panel | constructs under 125 bp | length range |
|---|---|---|
| `insertion_phasing` | 14 | 80–93 |
| `phasing_swap_controls` | 3 | 80–87 |
| `retained_context` | 2 | 74–76 |
| `substitution_phasing` | 14 | 80–80 |
| `tier1_nonphasing` | 6 | 64–103 |

Common vendor minimum fragment lengths sit at or above 125 bp, so these 39 may be excluded from a gene-fragment order outright. **All 39 are 64–103 bp, which is squarely in annealed-oligo-pair territory and is very likely cheaper that way** — two oligos, annealed, with the assembly overhangs built into the ends. [INFERENCE, reasoning named: length alone; no vendor quote was obtained, so this is a routing recommendation, not a price claim.] That splits the order into two purchase types, which is a decision for whoever places it.

---

## 5. Task 5 — cross-panel interaction

Checks that do not exist below the combined level.

### 5.1 Do constructs from different panels share enough sequence to misassemble or to read ambiguously?

Method: index every 20-mer across all 93 constructs to find candidate pairs, then compute the **exact** longest common substring for each candidate by binary search. 2218 of 4278 pairs share a 20-mer at all. [EVIDENCE]

| a | b | panels | longest exact shared run (bp) | ungapped identity |
|---|---|---|---|---|
| `JXN_ECA_ENVZ_dhp_direct_m1` | `JXN_ECA_PHOQ_dhp_direct_0` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1020 | 71.62 |
| `JXN_ECA_ENVZ_dhp_direct_m1` | `JXN_ECA_PHOQ_linker_retained_0` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1017 | 71.17 |
| `JXN_ECA_ENVZ_dhp_direct_p1` | `JXN_ECA_PHOQ_dhp_direct_m1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1015 | 69.59 |
| `JXN_ECA_ENVZ_dhp_direct_p1` | `JXN_ECA_PHOQ_linker_retained_p1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1015 | 71.12 |
| `JXN_ECA_ENVZ_dhp_direct_m1` | `JXN_ECA_PHOQ_dhp_direct_m1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1014 | 71.44 |
| `JXN_ECA_ENVZ_dhp_direct_m1` | `JXN_ECA_PHOQ_dhp_direct_p1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1014 | 71.39 |
| `JXN_ECA_ENVZ_dhp_direct_m1` | `JXN_ECA_PHOQ_linker_retained_m1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1014 | 70.98 |
| `JXN_ECA_ENVZ_dhp_direct_m1` | `JXN_ECA_PHOQ_linker_retained_p1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1014 | 69.75 |
| `JXN_ECA_ENVZ_dhp_direct_p1` | `JXN_ECA_PHOQ_dhp_direct_0` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1014 | 70.67 |
| `JXN_ECA_ENVZ_dhp_direct_p1` | `JXN_ECA_PHOQ_dhp_direct_p1` | kinase_junction_alt_backbone ↔ kinase_junction_core_primary | 1014 | 71.63 |

…1751 cross-panel pairs in total; full list in `designs/order_manifest_final_pairs.csv`.

| pair type | pairs sharing ≥20 nt | longest exact shared run |
|---|---|---|
| kinase ↔ kinase, different sub-panel | 146 | **1020 bp** |
| non-kinase ↔ non-kinase, different panel | 1605 | 171 bp |
| kinase ↔ non-kinase | **0** | — (no shared 20-mer exists between the two sets) |

**The one that matters: `JXN_ECA_ENVZ_dhp_direct_m1` and `JXN_ECA_PHOQ_dhp_direct_0` — different sub-panels — share 1020 bp of exactly identical DNA.** [EVIDENCE] The cause is not a mistake: both use the same `WP_043878053.1` sensor, and the codon optimiser is deterministic, so it emits the identical string for the identical protein prefix in both panels. Consequences, separated:

- **Golden Gate misassembly: no.** [INFERENCE, reasoning named] Joins in Golden Gate are defined by the 4-nt overhangs, not by internal homology. Shared interior sequence does not create a mis-join. This holds *provided* the overhangs are unique — see §5.2, which is exactly why that section is not a formality.
- **Homologous recombination in the host: a real, unquantified risk if two such constructs ever share a cell.** [INFERENCE] A >1 kb perfect repeat is a strong recombination substrate. The panel design has one construct per strain, so this only bites if strains are ever pooled.
- **Sequencing: yes, this is the live one.** [INFERENCE, reasoning named] A read landing entirely inside the shared run cannot be assigned to a construct. Verification must be anchored — Sanger from a vector primer, or a read that reaches the junction. For pooled NGS verification, the junction region is the only discriminating sequence and every read must span it.

### 5.2 Do the Golden Gate overhangs collide across panels?

**The overhangs are not defined anywhere in this repo, so there is nothing to collide yet.** [NOT FOUND] A case-insensitive search of `scripts/`, `designs/`, `results/`, `*.py` and `*.md` for `overhang`, `fusion site` and `sticky` returns zero hits, and no Type IIS site exists in any construct to imply one. **This is a remaining design step, not a check failure.**

It is, however, the step that decides §5.1. Two constraints the eventual overhang set has to meet, which the combined view makes concrete: all 93 fragments must carry mutually unique 4-nt overhangs across panels, not just within a panel, and no chosen overhang may recreate a BsaI/BsmBI/BbsI/SapI/AarI site when it is appended — a fresh scan will be needed after they are chosen, because everything in §2 is a statement about the fragments as they stand today.

### 5.3 Is any construct a subsequence of another?

**Yes — 19 exact-containment relations, and all 19 are the same declared parent/derivative relationship.** [EVIDENCE]

| contained construct | bp | container | bp | panels |
|---|---|---|---|---|
| `V2-INS-16_INS_PsodA_opA_gap03` | 152 | `V2-CX-18_INS_PsodA_opA_gap03__HP07_gpmA` | 229 | insertion_phasing ↔ combinatorial_3_leadered_probe |
| `V2-INS-16_INS_PsodA_opA_gap03` | 152 | `V2-CX-19_INS_PsodA_opA_gap03__HP06_NCgl2501` | 229 | insertion_phasing ↔ combinatorial_3_leadered_probe |
| `V2-SUB-01_SUB_Psyn_opA_gap00` | 80 | `V2-CX-01_SUB_Psyn_opA_gap00__HP06_NCgl2501` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-01_SUB_Psyn_opA_gap00` | 80 | `V2-CX-02_SUB_Psyn_opA_gap00__HP12_NCgl2826` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-01_SUB_Psyn_opA_gap00` | 80 | `V2-CX-03_SUB_Psyn_opA_gap00__HP07_gpmA` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-04_SUB_Psyn_opA_gap03__HP06_NCgl2501` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-05_SUB_Psyn_opA_gap03__HP12_NCgl2826` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-06_SUB_Psyn_opA_gap03__HP07_gpmA` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-10_SUB_Psyn_opA_gap03__HP01_groES` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-11_SUB_Psyn_opA_gap03__HP02_ndk` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-12_SUB_Psyn_opA_gap03__HP09_clpP` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-13_SUB_Psyn_opA_gap03__HP10_adk` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-14_SUB_Psyn_opA_gap03__HP08_eno` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-15_SUB_Psyn_opA_gap03__HP07_fcATGtoATC_NEG` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-16_SUB_Psyn_opA_gap03__HP07_SDmut_NEG` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-04_SUB_Psyn_opA_gap03` | 80 | `V2-CX-17_SUB_Psyn_opA_gap03__HP07_fcATGtoGTG_PARTIAL` | 157 | substitution_phasing ↔ combinatorial_2_tuning_curve |
| `V2-SUB-06_SUB_Psyn_opA_gap05` | 80 | `V2-CX-07_SUB_Psyn_opA_gap05__HP06_NCgl2501` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-06_SUB_Psyn_opA_gap05` | 80 | `V2-CX-08_SUB_Psyn_opA_gap05__HP12_NCgl2826` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |
| `V2-SUB-06_SUB_Psyn_opA_gap05` | 80 | `V2-CX-09_SUB_Psyn_opA_gap05__HP07_gpmA` | 157 | substitution_phasing ↔ combinatorial_1_independence_3x4 |

Every one is a promoter fragment sitting as the exact 5′ prefix of its own combinatorial derivative, which is how the combinatorial design is defined: the cross construct **is** the promoter fragment with a fore-cistron element appended, and `combinatorial_design.csv` names the parent in its `promoter_variant` column. [EVIDENCE] It is by design and it is not a defect — but it is worth stating rather than leaving implicit, because a prefix relationship means any primer or probe designed against the short construct also matches the long one, and no diagnostic that reads only the 5′ end can tell them apart.

---

## 6. Task 6 — order-ready output, and the envelope

| file | contents |
|---|---|
| `designs/order_manifest_final.csv` | 93 rows, one per construct: `construct_id`, `panel`, `tier`, `component_provenance`, `full_sequence`, `length_bp`, `GC_percent`, `flags`, `rank_or_rationale` |
| `designs/order_manifest_final_checks.csv` | 93 rows, every check result per construct |
| `designs/order_submit_final.fasta` | 93 records, **id and sequence only** |
| `designs/order_submit_final.csv` | 93 rows, **`construct_id` and `full_sequence` only, nothing else** |
| `designs/order_manifest_final_sites.csv` | 504 rows, one per restriction site: construct, enzyme, position, strand, component, class |
| `designs/order_manifest_final_motifs.csv` | 162 rows, one per SigA / SD+ATG hit with its junction attribution |
| `designs/order_manifest_final_pairs.csv` | 2221 rows, one per sequence-relationship pair |
| `designs/order_manifest_final_components.csv` | 400 rows, the verified component map |

The two submission files carry **only** `construct_id` and `full_sequence`. No existing path was overwritten; `scripts/consolidate_final.py` refuses to start if any output already exists.

**Round-trip verified independently: `scripts/verify_order_final.py` re-reads the source panel files and the written outputs and runs 22 checks against them — 22 pass, 0 fail.** [EVIDENCE] Among them: every sequence in `order_submit_final.csv` and `order_submit_final.fasta` is byte-identical to its row in `order_manifest_final.csv` **and** to its row in the source panel file; `length_bp` and `GC_percent` recompute from the sequence; every sequence is ACGT-only; the component map tiles every construct with no gap and no overlap; and no row carries an UNRESOLVED provenance entry.

### Envelope

**93 constructs against a 48–96 CRO envelope: it fits, with 3 slots of headroom.** [EVIDENCE]

This resolves the open question in `REPORT_phasing.md` §5, which projected 69 + a sensor-kinase panel of unknown size and warned that 69 + 30 = 99 would exceed 96. **The kinase panel came in at 24, so no cut is needed and none has been made.** The ranked cut order in that report (halve the Psyn insertion series; drop the Ptuf arm; drop combinatorial block 3) remains available and unused. Nothing was silently trimmed: the 93 here is every construct in every panel.

The 39 sub-125 bp constructs are inside the 93 count. If the CRO prices a gene-fragment order and an oligo-pair order as separate line items, the gene-fragment line is 54 and the oligo line is 39; both are well inside the envelope either way.

---

## 7. Provenance — every component, and every gap

32 distinct components across the 93 constructs. **0 carry an unresolved provenance entry.** [EVIDENCE] Every component resolves to either an accession/citation or an explicit 'DESIGNED, not sourced' statement naming the script that produced it.

| component | uses | sourced / designed | accession or citation |
|---|---|---|---|
| `SD2` | 19 | sourced | SD2 motif: PMC10367133 body text, verbatim ('AAAGGAGGACAAC') |
| `TAATG_frag` | 19 | sourced | TAATG coupling frame, 5' 2 nt: PMC10367133 body text, TAATG coupling frame (fragment carries the 'TA') |
| `acceptor:P0AEJ4` | 6 | sourced | UniProt P0AEJ4 (EnvZ), Escherichia coli K-12; DNA codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA |
| `acceptor:P0DM80` | 18 | sourced | UniProt P0DM80 (PhoQ), Salmonella Typhimurium LT2; DNA codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA |
| `core:PsodA` | 10 | sourced | core promoter PsodA: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838) Table 2 primers; amplicon recovered from BX927147.1 |
| `core:Psyn` | 56 | sourced | core promoter Psyn: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838) Table 2 primers; amplicon recovered from BX927147.1 |
| `core:Ptuf` | 3 | sourced | core promoter Ptuf: Henke, Krahn & Wendisch 2021, Microorganisms 9:204 (PMC7835838) Table 2 primers; amplicon recovered from BX927147.1 |
| `ctx:PsodA_native40` | 1 | sourced | retained native upstream context (PsodA): BX927147.1, 40 bp immediately 5' of the validated amplicon |
| `ctx:Psyn_N105_tail` | 2 | sourced | retained upstream context: PMC7835838 Table 2, vector-homology tail of primer N105 (Psyn-fw2) |
| `ctx:Ptuf_native40` | 1 | sourced | retained native upstream context (Ptuf): BX927147.1, 40 bp immediately 5' of the validated amplicon |
| `designed:BG_A` | 58 | designed | BG_A: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `designed:BG_B` | 2 | designed | BG_B: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `designed:BG_C` | 2 | designed | BG_C: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `designed:FILL_A` | 28 | designed | FILL_A: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `designed:FILL_B` | 1 | designed | FILL_B: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `designed:TSP_A` | 3 | designed | TSP_A: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `designed:UP_A` | 32 | designed | UP_A: DESIGNED, NOT SOURCED - seeded rejection sampling, scripts/design_backgrounds.py; reproducible from that file alone |
| `forecistron:HP-1` | 1 | sourced | fore-cistron HP-1 (groES, NCgl0572): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-10` | 1 | sourced | fore-cistron HP-10 (adk, NCgl0533): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-12` | 3 | sourced | fore-cistron HP-12 (NCgl2826, NCgl2826): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-2` | 1 | sourced | fore-cistron HP-2 (ndk, NCgl2287): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-6` | 4 | sourced | fore-cistron HP-6 (NCgl2501, NCgl2501): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-7` | 7 | sourced | fore-cistron HP-7 (gpmA, NCgl0390): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-8` | 1 | sourced | fore-cistron HP-8 (eno, NCgl0935): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `forecistron:HP-9` | 1 | sourced | fore-cistron HP-9 (clpP, NCgl2328): Liu et al. 2023 ACS Synth Biol 12:2157-2167 (PMC10367133) Table 1; verified vs BX927147.1 |
| `linker:GSGSG` | 3 | designed | DESIGNED flexible linker GSGSG; DNA codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA |
| `operator:opA_phoP` | 65 | sourced | operator opA_phoP: PRODORIC MX000339 (confirmed Salmonella Sal_PhoP site) |
| `operator:opB_mgtA` | 2 | sourced | operator opB_mgtA: PRODORIC MX000339 (confirmed Salmonella Sal_PhoP site) |
| `operator:scrambled_opA` | 2 | designed | DESIGNED - composition-matched scramble of opA_phoP (scripts/design_promoter_panel.py) |
| `sensor:Q92SH9` | 6 | sourced | UniProt Q92SH9 (McpX), Rhizobium meliloti 1021; DNA codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA |
| `sensor:WP_043878053.1` | 18 | sourced | RefSeq WP_043878053.1, methyl-accepting chemotaxis protein, Pectobacterium atrosepticum (657 aa); DNA codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA |
| `stop:TAA` | 24 | designed | TAA stop codon (53.3% of BX927147.1 stops); DNA codon-optimised to BX927147.1 CDS usage (3056 CDS, 951704 codons); synthetic DNA |

### Constructs with an unresolved provenance gap

**0.** [EVIDENCE] No construct in the order contains a component whose origin is unknown.

### Caveats that travel with the order

These are not unresolved provenance — each has a citation — but each is a known limitation of the cited source, and each is carried forward rather than dropped:

| subject | caveat | reach |
|---|---|---|
| fore-cistron `HP-1` (groES) | published sequence is not an exact genome match — 1 base differs: native start GTG -> published ATG (documented start-codon unification to AUG) | 1 construct |
| fore-cistron `HP-6` (NCgl2501) | published sequence is not an exact genome match — 1 base differs: native start GTG -> published ATG (documented start-codon unification to AUG) | 4 constructs |
| fore-cistron `HP-8` (eno) | published sequence is not an exact genome match — 1 base differs: native start GTG -> published ATG (documented start-codon unification to AUG) | 1 construct |
| core `PsodA` | promoter-element assignment confidence MEDIUM: −35 at 0.705 of max, extended −10 at 0.63 of max | 10 constructs |
| core `Ptuf` | promoter-element assignment confidence MEDIUM: −35 at 0.115 of max, extended −10 at 0.63 of max | 3 constructs |
| kinase panel | **no destination vector is declared anywhere in the repo** — this is what makes the NcoI finding conditional rather than settled | 24 constructs |
| Golden Gate overhangs | **not defined anywhere in the repo** — remaining design step | all 93 |
| SigA matrix | a reasoned approximation from a textual consensus, not an empirically trained PWM; a clean scan means 'no consensus-like cryptic promoter', not 'no cryptic promoter' | all 93 |
| Psyn | synthetic promoter with no genomic locus, so no mapped TSS; every gap value is measured from a computationally assigned −35 | 56 constructs |

`Ptuf`'s −35 sits at 0.115 of matrix max, which is not an assignment worth resting a gap value on — the tier-1 report reached the same conclusion and kept Ptuf in the panel for strength-range breadth only, not as a phasing subject. That is unchanged here. [EVIDENCE]

---

## 8. Blockers, notes, and whether this is order-ready

### Blockers

**None.** [EVIDENCE] Zero Golden Gate sites across all 93 on both strands; zero identical sequences; zero homopolymer runs over 6; zero unaccounted-for near-duplicates; zero components with unresolved provenance; zero junction-created motifs that exceed what their own parent component already carried.

### One conditional blocker, and it is the reason this task exists

**`NcoI` in 18 of the 24 kinase constructs.** [EVIDENCE] Not a Golden Gate blocker. It becomes a hard blocker the moment those constructs are targeted at pECXT99A, the vector the other 69 use, which is opened with NcoI/NdeI and supplies the target ATG at that very site. The kinase panel's vector is undeclared, so this cannot be settled from the repo — it needs one decision from whoever owns the cloning plan. **It is cheap to pre-empt: the sites are in synthetic, codon-optimised DNA, so re-running the optimiser with `NcoI` and `NdeI` added to its forbidden set removes all 18 without changing a single amino acid.** Doing that unconditionally is the recommendation, because it costs nothing and closes the same hole HP-4 opened.

### Notes

| note | why it does or does not matter |
|---|---|
| 468 restriction sites, 13 enzymes | none is used by Golden Gate or by the declared vector opening; recorded so a route change is a lookup, not a rediscovery |
| 84 sense-strand SigA windows ≥0.55 of max | all inside a single kinase CDS component, none junction-created; a cryptic promoter inside a CDS truncates its own transcript rather than driving an unintended gene |
| 3 antisense SigA windows | kinase only; the one at a junction is shown in §3.2 not to exceed its own parent component's best |
| 6 SD+ATG pairs | all inside the codon-optimised P0DM80 acceptor; internal-initiation risk, removable by re-synonymising |
| 38 GC outliers | all Psyn-cored, all below host, 30.6–37.4%; the AT is in the sourced operator and core elements, not in designed flanks |
| 27 strong local hairpins | 24 of them are the kinase CDSs, screened here for the first time; a synthesis-cost signal, never a strength prediction |
| 39 constructs under 125 bp | may fall below vendor minimum fragment length; likely cheaper as annealed oligo pairs |
| 19 containment relations | each is a promoter fragment inside its own declared combinatorial derivative; affects primer/probe design, not assembly |
| up to 1020 bp shared between kinase sub-panels | affects sequencing-read assignment and, if strains are ever pooled, recombination; not Golden Gate misassembly |

### Is the set order-ready?

**Sequence-wise, yes: all 93 constructs pass every check with no blocker.** **Process-wise, no — not yet, and for one reason that has nothing to do with the sequences.**

Exactly what remains, in the order it has to happen:

1. **Define the Golden Gate overhangs.** [NOT FOUND — they do not exist] All 93 fragments need mutually unique 4-nt overhangs *across* panels. Until they exist, no fragment can actually be ordered in an assembly-ready form, because the overhangs change the ends of every sequence in the submission files.
2. **Re-run §2's enzyme scan after step 1.** Appending overhangs and their flanks can create a Type IIS site that does not exist today. Everything in §2 is a statement about the fragments as they stand now.
3. **Settle the kinase panel's destination vector**, or simply strip `NcoI`/`NdeI` from the kinase codon optimiser and regenerate those 24. The second option removes the question rather than answering it, costs no amino-acid change, and is the recommendation.
4. **Decide the purchase split.** 39 constructs at 64–103 bp are probably annealed oligo pairs rather than gene fragments; that is a quote question, not a design one.

Steps 1 and 2 are the real gate. Steps 3 and 4 are decisions, not problems.

---

## 9. What none of this establishes

- **The SigA matrix is not a trained PWM.** Every SigA number in this report is a screening signal from a matrix built out of a textual consensus. A clean scan is evidence of no *consensus-like* element, and nothing stronger.
- **Folding energy predicts nothing about strength here**, and is used only as a defect and cost screen. HP-12 is the least-structured tier-2 element and only intermediate in measured strength.
- **A clean enzyme scan is a statement about 35 enzymes**, chosen because the provenance of the sourced components pointed at them plus the routes this repo declares. It is not a statement about any enzyme outside that catalogue.
- **Component-level provenance is not experimental validation.** Every sequence traces to an accession, a citation, or a named generating script. None of that is evidence that any construct expresses, signals, or assembles.
- **The two-tier architecture has not been demonstrated in any bacterial host.** Nothing in this consolidation changes that.

