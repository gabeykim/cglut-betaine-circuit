# Organism-prefix protein naming convention

Applied 2026-08-23 by `scripts/apply_naming_convention.py`. Mapping table: `designs/naming_map.csv` (36 rows).

Tags: **[EVIDENCE]** a citable source states it. **[INFERENCE]** reasoning from evidence. **[ESTIMATE]** a derived number. **[NOT FOUND]** searched and absent.

---

## 1. The hazard, stated precisely

[EVIDENCE, `results/REPORT_crosstalk.md` §1.4, citing Kocan et al. 2006 *J Bacteriol* 188:724-732, PMC1347282] In *C. glutamicum* the *cgtRS3* genes were renamed ***phoR*** (the **response regulator**) and ***phoS*** (the **sensor kinase**). That is **inverted** relative to the *B. subtilis* PhoP/PhoR convention used across most of the literature, where PhoR is the kinase.

This design imports **Salmonella PhoP** into a host that already contains a protein called **PhoR** filling the same functional role. Two different proteins, one letter apart, in the same document. A reader who knows the *B. subtilis* convention will read "PhoR" as a kinase; here it is a regulator.

A second, quieter hazard: **"PhoP" was ambiguous inside this repo.** It denoted *Salmonella* PhoP (P0DM78, the actual donor) in the design work **and** *E. coli* PhoP (P23836, the proxy whose RegulonDB sites built the scan PWM) in the operator-scan work — the same four letters for two different proteins, in two analyses that share a results directory.

---

## 2. Mapping (full table in `designs/naming_map.csv`)

| Old | New | Organism | Basis |
|---|---|---|---|
| PhoP | **Sal_PhoP** | *Salmonella* Typhimurium LT2 | P0DM78 |
| PhoQ | **Sal_PhoQ** | *Salmonella* Typhimurium LT2 | P0DM80 |
| PhoP | **Ec_PhoP** | *E. coli* K-12 | P23836 — **see §3** |
| OmpR / EnvZ / NarL / NarX | **Ec_OmpR / Ec_EnvZ / Ec_NarL / Ec_NarX** | *E. coli* K-12 | P0AA16 / P0AEJ4 / P0AF28 |
| **PhoR-associated RR** | **Cg_PhoR(CgtR3)** | *C. glutamicum* | cg2888 — **the hazard case** |
| PhoS(CgtS3) | **Cg_PhoS(CgtS3)** | *C. glutamicum* | cg2889 |
| MtrA / MtrB / CitA / CitB / ChrS | Cg_MtrA / Cg_MtrB / Cg_CitA / Cg_CitB / Cg_ChrS | *C. glutamicum* | manifest |
| CopR/CgtR9, ChrA/CgtR8, HrrA/CgtR11, CgtR2/MprA, RegX3/CgtR4 | Cg_CopR(CgtR9), Cg_ChrA(CgtR8), Cg_HrrA(CgtR11), Cg_MprA(CgtR2), Cg_RegX3(CgtR4) | *C. glutamicum* | manifest |
| CgtR1-11, CgtS1-11 | Cg_CgtR*, Cg_CgtS* | *C. glutamicum* | manifest |

**Compound names** take the form `Cg_<primary>(<alias>)` — the prefix is applied once, to the primary name; the alias inside the parentheses is *not* re-prefixed (`Cg_CopR(CgtR9)`, never `Cg_CopR(Cg_CgtR9)`).

**Locus tags are untouched** — `cg2888` stays `cg2888` throughout. Only protein names are prefixed. [EVIDENCE: `designs/naming_map.csv` carries the locus tag verbatim beside each rename.]

---

## 3. Two decisions that went beyond the specification, and why

**3.1 `Ec_PhoP` was added.** The convention as specified lists Sal_PhoP, Sal_PhoQ, Ec_OmpR, Ec_EnvZ, Ec_NarL, Ec_NarX and the Cg_* set — but **no E. coli PhoP**. This repo needs one: P23836 is a donor row in `data/manifest.csv`, and all 36 RegulonDB sites behind `results/pwm.txt` are *E. coli* PhoP sites. Without `Ec_PhoP` the ambiguity the convention exists to remove would have survived in the one place it does the most damage — the PWM that the whole operator scan rests on. [INFERENCE]

**3.2 The chemoreceptor LBD donors do not exist here.** `Pa_PctD`, `Pat_PacA`, `Sm_McpX` are registered in `designs/naming_map.csv` for future use, but **[NOT FOUND]**: a repo-wide search returns no `PctD`, `PacA`, `McpX`, "chemoreceptor" or "ligand-binding domain" outside one unrelated coincidence — `pctD` as a *C. glutamicum* gene symbol (cg1649, an ABC-type phosphate/phosphonate transport permease) in `results/hits_all.csv`, which is genome-annotation text and not a chemoreceptor. **Nothing was renamed for these three.**

---

## 4. Disambiguation method

Only **PhoP** was genuinely ambiguous; every other token maps to exactly one organism in this repo. It was resolved in three tiers, strongest first:

1. **By accession** — for any CSV row carrying `donor_accession` / `native_accession` / `accession`. This is exact, not heuristic, and covers all of `results/identity_*.csv` and `data/manifest.csv`. [EVIDENCE]
2. **By organism column** — `data/sites_manifest.csv`, whose `tf` column is resolved against its own `organism` column (81 *E. coli* rows → `Ec_PhoP`, 9 *Salmonella* rows → `Sal_PhoP`).
3. **By line context, then per-file default** — for prose and code. Every occurrence resolved by file default was logged; **73 were defaulted, 0 were left unresolved.**

**The automation was then hand-audited, and it was wrong in places.** A contradiction scan (a name asserting one organism on a line whose words say the other) plus a manual read of every `PhoP` line in `README.md` found **8 misassignments**, all on lines mentioning *both* organisms — precisely where a line-context heuristic fails. Examples corrected: "Salmonella-specific ~~Ec_PhoP~~ **Sal_PhoP** sites"; the scan PWM described as ~~Sal_PhoP~~ **Ec_PhoP** (it is built from *E. coli* sites); `results/pwm.txt` and `results/pwm_intergenic.txt` relabelled ~~Sal_PhoP~~ **Ec_PhoP**.

The rule applied throughout: **`Sal_PhoP` where the text means the imported protein or the design question; `Ec_PhoP` where it means the sites, matrix or PWM actually used.**

---

## 5. What was deliberately NOT renamed

| Scope | Count | Why |
|---|---|---|
| `data/cache/**`, `data/fasta/**` | all | Fetched records. Must stay byte-identical to source. [task rule] |
| `results/REPORT.md` | 24 | **Write-protected by the task.** |
| `results/REPORT_crosstalk.md` | 38 | **Write-protected by the task.** |
| `designs/REPORT_promoter.md` | 18 | Write-protected except for the Task-1c correction. |
| `results/hits_all.csv` `nearest_gene_product` | 27 | Verbatim product descriptions copied from the BX927147.1 feature table. Rewriting them would falsify the annotation each hit is anchored to. |
| RegulonDB query URLs in `data/sites_manifest.csv` | 36 | `…/regulon?term=PhoP&format=jsp` — **query parameters**. Renaming breaks the URL. |
| 3 script literals | 3 | `fetch_regulondb("PhoP", …)`, `n["label"] == "PhoP"`, `("PhoP", "phop_ecoli_regulon.json")` — API arguments and lookup keys **into cached JSON we are forbidden to modify**. Renaming them silently breaks the fetch/parse code. Masked as `PROTECTED_STRINGS` in the renamer. |
| `scripts/apply_naming_convention.py` | 34 | The mapping table itself. |

### The unavoidable conflict, stated plainly

**The instruction "no bare 'PhoP' or 'PhoR' anywhere in the repo" cannot be satisfied together with the instruction not to write to `results/REPORT.md` and `results/REPORT_crosstalk.md`.** Those two files contain **62 bare hazard tokens** between them. The file-level write protection was treated as the stronger instruction — it was given for a specific reason (earlier sessions overwrote these files) — so the general rule yields.

**80 bare hazard tokens remain repo-wide: 62 in the two write-protected reports, plus 18 in `designs/REPORT_promoter.md`.** Every one is inside a write-protected file. Outside those three files, **zero** bare hazard tokens remain that are not a documented API/URL/annotation exemption. To finish the job, those three files need write permission; `designs/REPORT_promoter.md` now carries a banner pointing readers at `designs/naming_map.csv` so the stale bare names are at least signposted.

---

## 6. Verifier status after renaming

| Verifier | Result |
|---|---|
| `scripts/verify_crosstalk_report.py` | **47/47 checks pass, 0 mismatches** |
| `run_pipeline.py --skip-fetch` | reproduces 156 / 52 / 24 comparisons unchanged |
| `scripts/design_promoter_panel.py` → `design_checks.py` → `rank_panel.py` | 33 variants, chain OK |
| `scripts/design_translational_panel.py` | 12 variants, 23 cells, 19 new — unchanged |
| `scripts/audit_spacing.py` | Psyn 14 positions / 13 bp / 1.24 turns |

**Verifiers with hardcoded old names were updated, as required:**

- **`scripts/verify_crosstalk_report.py`** — its hardcoded expected ranking list (`["PhoR-associated RR", "CopR/CgtR9", …]`) and ~93 name literals were rewritten to the prefixed forms. The numeric claims were not touched; all 47 still pass.
- **`scripts/identity_matrix.py`** — **this one was a real regression, not a cosmetic rename.** The donor-classification test read `gene_label in ("PhoP", "OmpR", "NarL")`, where the single token `"PhoP"` matched **both** PhoP donors. After prefixing, the tuple became `("Sal_PhoP", "Ec_OmpR", "Ec_NarL")` and **silently stopped matching `Ec_PhoP` (P23836)**. `Ec_PhoP` was restored to the tuple. The bug turned out to be latent — the adjacent `"RR" in role` test already caught P23836 via its `DONOR_RR_REFERENCE` role, and the regenerated matrices are unchanged — but it would have become live for any donor whose role string lacked `RR`. This is the exact failure mode the convention is meant to expose: **one name silently covering two proteins.**
- **`scripts/build_pwm.py`, `intergenic_null.py`, `salmonella_pwm.py`** — PWM headers were generated as `tf.upper()`, which would have produced `EC_PHOP`; changed to emit the properly-cased prefixed name, and the four `results/pwm*.txt` headers were relabelled to match what regeneration now produces.

### Two bugs in the renamer, found by audit and fixed at source

1. **Double-prefixing.** Substituted output was re-matched by later rules: `CopR/CgtR9` → `Cg_CopR(CgtR9)` → `Cg_CopR(Cg_CgtR9)`. 42 occurrences across 3 files. Fixed by substituting into placeholders and restoring only at the end, so no rule can fire on a name just written.
2. **The repair for bug 1 caused its own damage.** The collapse pattern `\((Cg|Sal|Ec)_(\w+)\)` also stripped prefixes from *standalone* parenthesised names — `(Ec_OmpR)` → `(OmpR)`. Caught by a follow-up scan; 2 occurrences in `results/REPORT_followup.md`, both repaired. The lesson is that the fix needed the same audit as the original change.

Both are corrected in `scripts/apply_naming_convention.py`, so a rerun is now correct.
