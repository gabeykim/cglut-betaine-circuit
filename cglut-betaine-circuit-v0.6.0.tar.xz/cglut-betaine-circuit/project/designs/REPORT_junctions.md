# Fusion-junction designs: sensor → signalling chimeras
### Junction definition, heptad register, and *C. glutamicum*-optimised DNA

Run date **2026-08-23**. Entry point: `run_junction_design.py`.
Outputs: `designs/junctions.csv`, `designs/junctions.fasta`.
Boundaries were **read** from `results/domain_boundaries_v2.csv` and
`results/tm_predictions_v2.csv`, never re-derived.

Claims are tagged **[EVIDENCE]**, **[INFERENCE]** (with the step named), or **[NOT FOUND]**.

---

## Final design count

**24 designs**, all passing every basic check.

| Panel | Sensor | Signalling part | Strategies | Designs |
|---|---|---|---|---:|
| `core_primary` | `WP_043878053.1` (ECA_RS10935) | PhoQ `P0DM80` | A, B, C, D × 3 registers | **12** |
| `core_second_sensor` | `Q92SH9` (McpX) | PhoQ `P0DM80` | A, D × 3 registers | **6** |
| `alt_backbone` | `WP_043878053.1` | EnvZ `P0AEJ4` | A, D × 3 registers | **6** |
| | | | | **24** |

**18 of these are the count the brief specifies** (12 primary + 6 second sensor). The 6
`alt_backbone` designs are an **addition**: EnvZ was listed as the alternate signalling part but
the specified counts covered only the primary. They are tagged in the `panel` column and can be
dropped with one filter if not wanted. Flagging rather than silently including them.

---

## Read this first — what is uncertain

### 1. The heptad-register test is a weak instrument here, in every single design

**[EVIDENCE]** In all 24 designs the residue immediately upstream of the junction lies inside a
**transmembrane helix** (`TM2` in every case, read from `tm_predictions_v2.csv`). A TM helix is
hydrophobic at *every* heptad position, so the seven candidate phases score almost alike and the
register is not really determinable there.

**[EVIDENCE]** Quantified, as phase contrast (best phase minus runner-up, mean Kyte-Doolittle at
a/d minus elsewhere, 21-residue window):

| Window | Contrast | Determinacy |
|---|---:|---|
| PhoQ HAMP AS1 218-238 | **1.73** | well determined — genuinely amphipathic |
| EnvZ HAMP AS1 177-197 | **1.66** | well determined |
| EnvZ DHp α1 234-254 | 0.98 | weak |
| ECA TM2 core 318-338 | 0.56 | weak |
| PhoQ DHp α1 268-288 | 0.54 | weak |
| PhoQ TM2 195-215 | 0.40 | weak |

**[EVIDENCE]** The upstream contrast never exceeds **0.677** in any of the 24 designs, and
**not one design has a well-determined phase on both sides of its junction.**

**[INFERENCE]** (step: a verdict computed from a degenerate window carries no information) The
in-phase / register-break calls below should be used to **rank plausibility at most**, and must
not be used to accept or reject a design. Every design carries its per-side determinacy in
`up_determinacy` / `dn_determinacy` so this cannot be read off the CSV as though it were solid.

### 2. Strategy B could not be anchored on the primary sensor as intended

**[NOT FOUND]** `WP_043878053.1` has **no HAMP domain** in `domain_boundaries_v2.csv` — its only
domain there is `dCache_1` 41-312. (Searched: every row for that accession. The v2 extended scan
behind that file also found no HAMP.)

**[INFERENCE]** (step: strategy B places the join "immediately after the HAMP region", which
requires a HAMP boundary to anchor to) On this sensor the anchor had to come from the **acceptor**
side instead: the sensor contributes through its TM2 end (338), and PhoQ resumes one residue past
its own HAMP. The resulting constructs therefore contain **no HAMP at all**, which is not what the
strategy name implies. B and D remain distinct — B retains PhoQ's HAMP→DHp linker (resumes at 264),
D starts at the DHp proper (resumes at 268) — but **B is not a "HAMP retained" design on this
sensor.** Anyone reading strategy B as HAMP-preserving would be misled; that is why it is here and
not in a footnote.

### 3. Two acceptor boundaries are inferences, not file reads

- **[INFERENCE]** (step: the brief directs that PhoQ's HAMP is PF26769, and the PF00672 hit in the
  CSV is LOW confidence / fails Pfam's gathering threshold) PhoQ HAMP taken as **218-263** from
  `results/REPORT_domains.md` §7, *not* the CSV's PF00672 213-262.
- **[INFERENCE]** (step: transfer of the H-box-to-domain-start offset from a HIGH-confidence
  reference) PhoQ's **DHp start = 268**, from the experimentally confirmed H-box **His277** minus
  the 9-residue offset measured in EnvZ (His243 inside HisKA 234-290, both HIGH confidence).
  PhoQ's own HisKA hit was **not** used — it fails Pfam's gathering threshold and is LOW.
  **[EVIDENCE]** Sanity check: the inferred start 268 lands within 2 residues of that rejected hit's
  start (270), from an entirely independent route.

### 4. One sensor boundary carried into the designs is only MEDIUM

**[EVIDENCE]** `WP_043878053.1` **TM1 18-38 is MEDIUM** confidence in `tm_predictions_v2.csv`
(DeepTMHMM only, no UniProt helix to cross-check). It is not a junction point, but it is inside
every ECA construct. No junction was placed on a MEDIUM or LOW boundary: all four junction anchors
(sensor TM2 318-338, acceptor TM2 195-215, HAMP, DHp) are HIGH-confidence rows or the
experimentally confirmed H-box.

### 5. No structure predictor was available

**[NOT FOUND]** Searched: `colabfold_batch`, `alphafold`, `run_alphafold.py`, `esmfold`, `boltz`,
`chai`, `omegafold`, `foldseek` on PATH; Python modules `alphafold`, `colabfold`, `esm`,
`openfold`, `boltz`, `chai_lab`. None present. The ESM Atlas remote folding endpoint
(`api.esmatlas.com`) returned **HTTP 000** — it is shut down. `facebook/esmfold_v1` on Hugging Face
is **8.44 GB** and would run on CPU against 554-616-residue constructs; not practical here.

**No design was rejected on structural grounds, because nothing was folded.**

**[EVIDENCE]** Stated regardless, as required: **no published method validates structure prediction
as a prospective predictor of which fusion junction will function.** Had a predictor been
available it would have been used only to *exclude* obviously broken folds — never to rank designs
or choose a winner. Confidence metrics such as pLDDT/PAE report model self-consistency, not
signalling competence.

---

## Task 1 — fusion points

Construct architecture: `SENSOR[1 … s_end]` + `[linker]` + `ACCEPTOR[a_start … C-terminus]`.

### Nominal junction points (register offset 0)

| Strategy | Description | Sensor last residue | Sensor element | Acceptor first residue | Acceptor element |
|---|---|---:|---|---:|---|
| **A** | within TM2 | **328** (ECA) / **328** (McpX) | TM2 (membrane) | **206** PhoQ / **170** EnvZ | TM2 (membrane) |
| **B** | immediately after the HAMP region | **338** | TM2 (membrane) | **264** PhoQ | cytoplasmic |
| **C** | within TM2 + 5-residue linker `GSGSG` | **328** | TM2 (membrane) | **206** PhoQ | TM2 (membrane) |
| **D** | HAMP omitted; TM2 → DHp | **338** | TM2 (membrane) | **268** PhoQ / **234** EnvZ | cytoplasmic (EnvZ: also HisKA) |

**[EVIDENCE]** Every number above traces to a file row:
- sensor TM2 `318-338` (ECA and McpX alike) — `tm_predictions_v2.csv`, HIGH
- PhoQ TM2 `195-215`, EnvZ TM2 `160-178` — same file, HIGH
- EnvZ HAMP `177-226` and HisKA `234-290` — `domain_boundaries_v2.csv`, HIGH, both GA-passing
- midpoints are `(start+end)//2`; A/C join at the sensor midpoint and resume one past the acceptor midpoint, preserving native TM2 length (11 sensor + 10 acceptor = 21 residues)

**[EVIDENCE]** Spot check on `JXN_ECA_PHOQ_D0`: sensor tail `…SILLVSALLGWV` | acceptor head
`YRTTLTDLTHSL…`, and the H-box **His277 lands at construct position 348 as an H**.

### Register variants

**[INFERENCE]** (step: only a shift that changes the *relative* phase actually scans register)
The acceptor start slides by δ ∈ {−1, 0, +1} while the sensor end stays fixed. Shifting *both* ends
together would move the crossover point but leave the relative heptad phase unchanged — algebraically
`(s_end + linker + 1 − a_start − φ_sensor + φ_acceptor) mod 7` is independent of δ when both shift.
Only a one-sided shift scans the register. Construct length therefore varies by ∓1 residue across a
register triplet, which is the intended cost.

---

## Task 2 — coiled-coil register

Method: for the 21 residues ending at the junction (sensor side) and the 21 beginning at it
(acceptor side), the heptad phase maximising mean Kyte-Doolittle hydrophobicity at **a/d** versus
the other five positions is taken as that side's intrinsic register; the two are then compared
across the junction, accounting for linker length. Δ is reported in −3…+3, where **0 = in phase**.

### Result: 3 in phase, 21 register breaks

**[EVIDENCE]** In phase (Δ = 0): **`JXN_ECA_PHOQ_Dp1`**, **`JXN_ECA_ENVZ_Am1`**,
**`JXN_ECA_ENVZ_Dp1`**.

**[EVIDENCE]** Register breaks — all 21 others, flagged individually in `junctions.csv` as
`REGISTER_BREAK:±n` and listed here in full:

| |Δ| | n | Designs |
|---|---:|---|
| **1** | 5 | `ECA_PHOQ_Am1` (−1), `ECA_PHOQ_Bm1` (−1), `ECA_PHOQ_D0` (+1), `ECA_ENVZ_A0` (−1), `ECA_ENVZ_Dm1` (−1) |
| **2** | 8 | `ECA_PHOQ_A0` (−2), `ECA_PHOQ_B0` (−2), `ECA_PHOQ_Cp1` (+2), `ECA_PHOQ_Dm1` (+2), `MCPX_PHOQ_Ap1` (+2), `MCPX_PHOQ_Dm1` (−2), `ECA_ENVZ_Ap1` (−2), `ECA_ENVZ_D0` (−2) |
| **3** | 8 | `ECA_PHOQ_Ap1` (−3), `ECA_PHOQ_Bp1` (−3), `ECA_PHOQ_Cm1` (−3), `ECA_PHOQ_C0` (+3), `MCPX_PHOQ_Am1` (−3), `MCPX_PHOQ_A0` (+3), `MCPX_PHOQ_D0` (−3), `MCPX_PHOQ_Dp1` (+3) |

**[INFERENCE]** (step: exactly one δ in a triplet can bring Δ to 0, since δ shifts Δ by 1) Finding
in-phase joins in only 3 of 8 strategy×backbone triplets means the nominal junction point is more
than one residue away from in-phase in the other 5. Widening the register scan to ±3 would be needed
to reach Δ = 0 for those — a concrete, testable follow-up, not done here because the brief specifies
±1.

**As stated in §1 above, every one of these verdicts rests on at least one indeterminate or weak
window.** The a/d hydrophobic occupancy across each junction is reported separately in
`junction_ad_hydrophobic_frac` (range 0.5-1.0) as an independent, assumption-free descriptor.

---

## Task 3 — DNA output

### Codon table source

**[EVIDENCE]** The table was **derived from the host genome itself**, not taken from a third-party
service: *C. glutamicum* ATCC 13032 genome **BX927147.1** with CDS features from
`BX927147.ft.txt`, both already cached in this repo.

- **3,056 CDS** used (of 3,058 parsed; 2 rejected for frame/length/internal-stop)
- **951,704 codons** counted
- CDS codon **GC 54.95%** (genome average 53.8%, per the brief)
- stop codon usage: **TAA 53.3%**, TAG 30.1%, TGA 16.6% → **TAA** used
- cached at `data/cache/codon/cglut_codon_usage.json`

**[INFERENCE]** (step: choosing a genome-derived table over an external database) This is
preferable to Kazusa or a similar lookup because it is reproducible offline, versioned with the
repo, and derived from the exact strain already used elsewhere in this project.

### Optimisation method

Deterministic constrained greedy, then repair — no randomness, so runs are byte-reproducible:

1. **Per residue**, among synonymous codons with relative usage ≥ 0.10 (rare codons excluded),
   prefer those that do not complete a Golden Gate site or a >6 homopolymer in the 3′ context;
   pick the one moving running GC toward 53.8%; tie-break on higher *C. glutamicum* usage.
2. **Global repair** — iteratively re-synonymise codons overlapping any remaining forbidden site or
   long run until none remain, widening to rare codons only if necessary.
3. **Junction repair** — re-synonymise any spurious regulatory element created *within ±13 nt of the
   junction*, then re-run step 2. Steps 2 and 3 alternate until both are clean, because fixing one
   can create the other.

**[EVIDENCE]** Output: 24 sequences, **1665-1851 nt**, GC **53.62-53.81%**, all beginning `ATG` and
ending `TAA`. **All 24 translate back to exactly their intended protein**, in frame, with no
internal stop.

---

## Task 4 — basic checks

**[EVIDENCE]** Every check run on the **full assembled construct**, not on parts:

| Check | Result |
|---|---|
| BsaI / BsmBI / BbsI / SapI / AarI sites (both strands) | **0** across all 24 |
| Homopolymer runs > 6 | **0** |
| GC vs 53.8% host average | **53.62-53.81%**, spread of 0.19 points — **0 outliers** |
| Two constructs identical | **0** — 24/24 unique DNA *and* 24/24 unique protein |
| Spurious SigA extended-10 **at a junction** | **0** |
| Spurious SD + ATG initiation **at a junction** | **0** |
| Translation fidelity | 24/24 exact, in frame, no internal stop |

**[EVIDENCE]** On the junction-created regulatory element the brief warned about: the first
optimisation pass produced exactly that failure — `JXN_ECA_ENVZ_Dp1` carried a SigA extended-10 hit
scoring **0.722 of maximum at nt 1008**, spanning the junction, present in neither parent part
alone. It was removed by junction repair (step 3 above). This is the specific reason the scan runs
on assembled constructs and on a junction-spanning window rather than on parts.

**[EVIDENCE]** Scoring matrix and thresholds are the ones already used elsewhere in this repo
(`scripts/siga_consensus.py`, extended-10 at ≥55% of maximum; SD motif `GGAGG|AGGAG|GGAG` followed
by ATG at 4-12 nt). **[INFERENCE]** (step: carried caveat) that matrix is built from a *textual*
consensus (Patek & Nesvera 2011), not trained on aligned confirmed *C. glutamicum* promoters, so
these hits are a screening signal, not a calibrated probability.

**Full enzyme-catalogue checking was deliberately not done** — the brief assigns it to the later
consolidation step. Only the Golden Gate set plus the basics were checked here.

---

## Files

```
designs/junctions.csv        24 rows; junction residues, elements, sources, register, all flags
designs/junctions.fasta      24 DNA sequences, headers carry panel/strategy/offset/GC
designs/REPORT_junctions.md  this file
scripts/junction_design.py   library (boundary loading, register, codon optimisation)
run_junction_design.py       entry point -- offline, deterministic
data/cache/codon/cglut_codon_usage.json   genome-derived codon table
```

Reproduce with `python3 run_junction_design.py`. No network access is required.

**No existing file was overwritten**; all three output paths were confirmed absent beforehand.
