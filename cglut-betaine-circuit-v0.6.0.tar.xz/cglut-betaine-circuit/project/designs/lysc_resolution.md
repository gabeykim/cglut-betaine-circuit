# Closing the lysC operator-distance question

The predicted Sal_PhoP operator upstream of *lysC* was previously reported at **151 bp**, measured from the translational start. That was flagged at the time as an upper bound, not the biologically relevant number, with the actual transcription start site recorded as [NOT FOUND]. **That gap is now closed.** The TSS was retrieved, the distance recomputed, and the conclusion changes materially — but not in the direction that makes the hit go away.

Regenerate with:
```
python3 scripts/lysc_tss_resolution.py    # TSS retrieval, coordinate verification, distances
python3 scripts/lysc_leakiness.py         # PWM score gap, affinity ratio, occupancy model
```

Tags: **[EVIDENCE]** a citable source states it, cited inline. **[INFERENCE]** reasoning from evidence, reasoning step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent, with what was searched.

---

## Bottom line

The operator sits **115 bp upstream of the mapped TSS** (not 151 bp), and **102 bp upstream of the only promoter element this promoter actually has**. [INFERENCE] That is outside the window where bacterial activators are documented to work, so the site is **unlikely to function as a Sal_PhoP activator site at this promoter** — the distance question resolves *against* the site being functional.

But two findings cut the other way and are the more important output of this analysis:

1. **The "keep Sal_PhoP expression low" mitigation is worth far less than assumed.** The panel's designed operators beat the genomic lysC site by only **1.2–1.9 bits ≈ 2.3–3.6× in affinity** [ESTIMATE]. At Sal_PhoP levels giving 90% occupancy of the designed operator, the lysC site would be **71–79% occupied**. There is no expression window that engages the engineered promoter while leaving lysC alone.
2. **If lysC *were* activated, the likely consequence is not toxicity — it is loss of orthogonality.** [INFERENCE] Industrial strains deliberately overexpress lysC; the hazard is silently coupling the sensor's input to central carbon flux, not poisoning the strain.

---

## Task 1 — The TSS

**Mapped TSS: BX927147.1 position 269,335, + strand. 5′-UTR length: 36 nt. Start codon: GTG.** [EVIDENCE]

**Source**: Pfeifer-Sancar K, Mentz A, Rückert C, Kalinowski J (2013) "Comprehensive analysis of the *Corynebacterium glutamicum* transcriptome using an improved RNAseq technique." *BMC Genomics* 14:888 (PMC3890552), Additional file 1, **Table S1** (TSSs with σA promoter motifs) and **Table S3** (protein-coding genes with 5′-UTR length and sequence).

**How it was retrieved** — this matters, because an earlier pass on this project recorded this value as [NOT FOUND]: PMC's own supplementary-file endpoint sits behind a JavaScript proof-of-work bot challenge (`cloudpmc-viewer`) that a plain HTTP client cannot solve, and the Springer/BMC mirror returns 403. **Europe PMC serves the identical supplementary bundle from different infrastructure with no such gate**, at `https://www.ebi.ac.uk/europepmc/webservices/rest/PMC3890552/supplementaryFiles`. That returns a zip containing Additional file 1 (itself a zip of Tables S1–S10 as `.xlsx`). Tables S1 and S3 are now cached at `data/cache/literature/pfeifer2013_tables/`. The earlier [NOT FOUND] was a retrieval-route failure, not a genuine absence of the data.

**The coordinate was verified, not assumed** — three independent checks, all passing:

| Check | Result |
|---|---|
| Do Tables S1 and S3 independently agree on the TSS? | Both give **269,335** ✓ |
| Does S3's stated UTR length match its own arithmetic? | 269,371 − 269,335 = 36 = stated length ✓ |
| Does S3's published 36 nt UTR sequence match the cached genome at those coordinates? | `GTAACTGTCAGCACGTAGATCGAAAGGTGCACAAAG` — **exact match** ✓ |
| Does S1's published 60 bp promoter context (−59..+1) match the cached genome? | `CAGAAAGAAAACACTCCTCTGGCTAGGTAGACACAGTTTATAAAGGTAGAGTTGAGCGGG` — **exact match** ✓ |

The exact sequence matches confirm the table's coordinates are BX927147.1 coordinates, so no coordinate-system translation is needed.

**Only one TSS exists here.** Scanning Table S1 across BX927147.1 268,900–269,800 (a ~900 bp window spanning the operator) returns **exactly one mapped TSS on either strand** — the lysC TSS at 269,335. [EVIDENCE] There is no alternative transcript, antisense or otherwise, that the operator might be better positioned for.

**Promoter architecture at this TSS** [EVIDENCE, from Table S1]: the authors' Improbizer analysis calls a **−10 element `TAGAGT` at 269,322–269,327** (score 8.51), 7 bp from the TSS, and **no −35 element at all** (null in both the −35 score and spacer columns). This is independently consistent with the extended-10-dominant σA architecture described for this host and used throughout this project's promoter panel — a useful internal corroboration, since that architecture was established from a completely different source.

**Second dataset**: Albersmeier, Pfeifer-Sancar, Rückert & Kalinowski 2017, *J Biotechnol* (PMID 28412515, DOI 10.1016/j.jbiotec.2017.04.008) — checked via Europe PMC and confirmed **not open access** (`pmcid: None`, `inEPMC: N`, `isOpenAccess: N`, `hasSuppl: N`); ScienceDirect returns a bot-detection challenge. [NOT FOUND] as an accessible dataset. It was not needed: Pfeifer-Sancar answers the question definitively.

**Correction to a prior claim**: earlier work in this repo described the lysC translational start as "the ATG at 269,371." The start codon is **GTG**, per Table S3 and confirmed directly against the cached genome (`g[269370:269373]` = `GTG`). This has no effect on any distance, but it was stated wrongly before and is corrected here.

---

## Task 2 — Recomputed distance

### The numbers [EVIDENCE / arithmetic]

| Measurement | Distance |
|---|---|
| Operator 3′ edge → translational start (269,371) | **151 bp** — reproduces the originally reported figure exactly |
| Operator 3′ edge → **TSS (269,335)** | **115 bp** |
| Operator **center** (269,212) → TSS | **123 bp** (i.e. centred at ≈ **−123**) |
| Operator 5′ edge → TSS | 131 bp |
| Operator 3′ edge → **−10 element** (269,322) | **102 bp** |

Operator interval: BX927147.1 269,204–269,220 (+ strand), sequence `AATATATGGTCTGTTTA`.

The 5′-UTR correction moves the operator **36 bp closer** to the relevant landmark: 151 → 115 bp. The direction of the correction is favourable to the site being functional; the magnitude is not enough to bring it into range.

### The assessment [INFERENCE] — stated separately, as a judgement

**Judgement: implausible as a direct activator site at this promoter.** Reasoning, step by step:

1. **Reference window.** Bacterial activators contact RNAP from constrained positions: Class II sites overlap the −35; Class I sites sit upstream and centre near integral helical turns (≈ −41, −61, −71, −82, −92), with documented Class I activation falling off past roughly −90 to −100.
2. **This project's own donor-specific data agrees with that window.** The confirmed *E. coli* Ec_PhoP sites cached in this repo from the earlier RegulonDB fetch carry `distanceToPromoter` values of **−32 to −60** (mgrRp −44, mgtSp −35, ompTp −59.5, hdeAp −32). Real Ec_PhoP sites sit close in. [EVIDENCE]
3. **This site is at −123 (centre), with its nearest edge 102 bp from the −10.** That is beyond both the general Class I range and, by a factor of roughly two, the observed range of actual Sal_PhoP sites.
4. **The promoter has no −35 to overlap.** With only an extended −10 called here, a Class II mechanism (the one that tolerates the closest positioning) has no target element to engage.

**What would overturn this judgement, and why I am not invoking it**: an unmapped, condition-specific TSS further upstream would change the arithmetic entirely, and the Pfeifer-Sancar RNAseq sampled particular growth conditions, so a conditional promoter could in principle be missed. DNA looping could also, in principle, permit action at a distance. Both are real possibilities — but the task instructs not to estimate a TSS that isn't mapped, and neither possibility is evidence. The honest statement is: **against the only experimentally mapped TSS, the site is too far upstream to work by the standard mechanisms.**

**Net effect on the panel's risk register**: the *positional* case against lysC being a functional Sal_PhoP target is now substantially stronger than it was. The *affinity* case (Task 4) is unchanged and is the part that still matters.

---

## Task 3 — Operon structure, direction, and published regulation

### Structure, from the annotation [EVIDENCE]

| Locus | Gene | Strand | Coordinates | Product | Notes |
|---|---|---|---|---|---|
| cg0305 | — | + | 269,030–269,128 | hypothetical protein | **no mapped TSS** (Table S3) |
| **cg0306** | **lysC** | **+** | **269,371–270,636** | aspartokinase, α and β subunits | GTG start; 1266 bp = **421 aa** |
| cg0307 | asd | + | 270,660–271,694 | aspartate-semialdehyde dehydrogenase | ATG start; 344 aa |

**lysC is not monocistronic.** [EVIDENCE] Three independent lines:

1. **Spacing**: only **23 bp** separates the lysC stop from the *asd* start — far too short to house an independent promoter and 5′-UTR.
2. **No TSS in the gap**: Table S1 calls no TSS anywhere between the lysC stop (270,636) and the *asd* start (270,660).
3. **Published**: the *lysC/asd* cluster of *C. glutamicum* ATCC 13032 was cloned and characterised as a unit by Kalinowski J, Cremer J, Bachmann B, Eggeling L, Sahm H & Pühler A (1991) *Mol Microbiol* 5:1197–1204 (byline verified via NCBI esummary; full text not fetched — paywalled, so cited for the cluster's existence and the lysCα/lysCβ two-in-frame-overlapping-ORF architecture, both of which the genome annotation independently corroborates). **Independent arithmetic corroboration**: the annotated CDS is exactly **421 aa**, matching the reported lysCα length precisely.

**New finding — *asd* also has its own internal promoter.** [EVIDENCE, from Tables S1/S3] Two TSSs are mapped for cg0307 (*asd*), at **270,068 and 270,070** — both of which lie **inside the lysC coding sequence** (269,371–270,636, verified). Their nominal "5′-UTRs" of 590–592 nt are in fact the 3′ portion of lysC's own CDS. So the real architecture is:

> **lysC → asd co-transcription from the lysC promoter, PLUS an independent internal promoter within lysC driving asd on its own.**

[INFERENCE] This matters for the risk assessment in a specific way: *asd* is partially buffered against changes at the lysC promoter, because it retains an independent transcriptional input. Activation at the lysC promoter would therefore raise lysC and asd **non-proportionally** — lysC fully, asd only in its readthrough component.

### Published transcriptional regulation of lysC in this host

**Dominant characterised control is post-translational, not transcriptional.** [EVIDENCE] Aspartokinase is subject to concerted allosteric feedback inhibition by **lysine + threonine**; this is the regulatory node that 50+ years of strain engineering has targeted, almost entirely via feedback-resistant point mutations obtained by random mutagenesis and selection, and more recently by coevolutionary/statistical-coupling analysis of the regulatory domain (e.g. Chen et al. 2011, *Appl Environ Microbiol* 77:4352, PMC3127711).

**No characterised transcription factor is known to bind the lysC promoter.** [NOT FOUND] Searched: Europe PMC (`"lysC" AND "C. glutamicum" AND (promoter OR transcription)` — 190 hits; `... AND (regulator OR "transcriptional regulation" OR "promoter region")` — 115 hits), returning metabolic-engineering papers but no lysC promoter-regulator characterisation; the Pátek & Nesvera open-access promoter review (PMC3917453) discusses lysC only as an overexpression *target*, not as a regulated promoter; and the earlier pass in this project surfaced only **McbR**, whose target motif (`TAGAC-N6-GTCTA`, an inverted repeat of the sulfur regulon) is structurally unrelated to Sal_PhoP's `GTTTA` direct repeat and whose ~45-gene regulon does not include lysC.

**Industrial practice is to increase lysC transcription deliberately.** [EVIDENCE] In lysine-hyperproducing strains, lysC is overexpressed by **replacing its native promoter with P*sod***, alongside pyc, dapB and tkt (Becker et al. 2011, as reviewed in Pátek & Nesvera, PMC3917453). Worth flagging the coincidence: P*sodA* is one of the three core promoters in this project's own panel (`designs/REPORT_promoter.md`) — the same promoter industry uses to push lysC.

### Would Sal_PhoP activation of lysC be harmful, neutral, or beneficial? [INFERENCE]

Reasoning, step by step:

1. **Direction of industrial intent.** More lysC transcription is what lysine producers actively engineer *toward* (point 3 above). A perturbation that raises lysC is therefore not prima facie damaging to the production phenotype.
2. **But the wild-type enzyme is feedback-limited.** In a background carrying wild-type lysC, extra transcript yields extra enzyme that is still allosterically shut down at high lysine — so the benefit **saturates**, and the effect tends toward neutral. In a production strain carrying a feedback-resistant lysC allele (the norm), extra transcript converts more directly into extra flux, so the effect tends toward **beneficial**.
3. **Co-transcription partially propagates.** Because *asd* is co-transcribed, activation raises the next pathway step too — generally favourable, as it avoids bottlenecking at aspartyl-phosphate. But only partially, since *asd* retains an independent internal promoter (above).
4. **Counterweight — branch-point drain.** Aspartokinase feeds threonine, methionine and isoleucine as well as lysine. Unregulated increase pulls aspartate flux at a branch point, which is not automatically benign in a strain balanced for a specific product.
5. **The real problem is not metabolic, it is architectural.** This would be an *unintended, inducer-coupled* perturbation: whenever the engineered Sal_PhoP switch is induced, central amino-acid flux would move with it. That confounds the sensor readout (the reporter is no longer measuring only the intended signal), confounds the production phenotype (titre shifts with induction state for reasons unrelated to the designed circuit), and defeats the orthogonality the whole imported-system architecture exists to provide.

**Conclusion [INFERENCE]: plausibly neutral-to-beneficial metabolically, but genuinely harmful architecturally.** The hazard is not that Sal_PhoP activation would poison a lysine producer — it probably would not, and might even help. The hazard is that it would **silently couple the sensor's input to the product pathway**, which is precisely the pleiotropy the imported two-component system was chosen to avoid. This reframes lysC from "dangerous off-target" to "orthogonality-breaking off-target" — a different, and in some ways more insidious, failure.

---

## Task 4 — Leakiness sensitivity: what does "keep Sal_PhoP low" actually buy?

### Score gap [EVIDENCE / ESTIMATE]

Scored against the **Salmonella-derived Sal_PhoP PWM** (`data/cache/pwm_phop_salmonella.json`, 9 confirmed sites, 16 bp) — the same matrix the panel's operators were selected against, so the comparison is like-for-like. The lysC genomic region was scored as the best 16 bp window within ±15 bp of the called hit, avoiding the ~12 bp frame-offset artifact this project diagnosed earlier (`results/REPORT_followup.md` Task 5).

| Sequence | Score | % of max (20.21) | Gap vs lysC | Approx. affinity ratio |
|---|---|---|---|---|
| **lysC genomic site** `TATATGGTCTGTTTAT` | **17.19** | 85% | — | 1× (reference) |
| `opA_phoP` — panel primary operator | 19.04 | 94% | **+1.85 bits** | **≈ 3.6× tighter** |
| `opB_mgtA` — panel secondary operator | 18.41 | 91% | **+1.22 bits** | **≈ 2.3× tighter** |

Second opinion, *E. coli*-derived PWM (17 bp, 29 sites): lysC site scores 15.35 = **76% of max**. The two 16 bp designed operators cannot be scored on a 17 bp matrix and were **skipped rather than padded with invented bases**.

**Affinity-ratio conversion** [ESTIMATE, assumptions named]: a log2-odds PWM score is treated as proportional to binding free energy with independent, additive position contributions, so a gap of *d* bits ≈ a 2^*d* ratio in dissociation constant. This ignores position interdependence, DNA shape, cooperativity and all cellular context. It is an order-of-magnitude guide, not a measurement.

**Context**: the lysC site ranks **6th of the 82** intergenic-null survivors by intergenic-background score — it is genuinely near the top of the genomic field, not a marginal case.

### What that gap buys, concretely [ESTIMATE]

Single-site equilibrium occupancy, θ = [P]/([P] + K_d), assuming the affinity ratios above and no cooperativity or competition:

| Designed operator occupancy | → lysC site occupancy (opA, 3.6×) | → lysC site occupancy (opB, 2.3×) |
|---|---|---|
| 50% | 22% | 30% |
| 75% | 45% | 56% |
| **90%** | **71%** | **79%** |
| 95% | 84% | 89% |

### Interpretation

**The "keep Sal_PhoP expression low" mitigation buys almost nothing.** [INFERENCE] Occupancy is a saturating function of [Sal_PhoP~P]/K_d, and a 2.3–3.6× K_d difference is roughly one and a half doublings of headroom. To drive the engineered promoter hard enough to be useful (say 90% operator occupancy), the lysC site would sit at **71–79% occupancy** — not a spared bystander. Conversely, tuning Sal_PhoP down far enough to leave lysC substantially unoccupied (say ≤20%) leaves the designed operator below ~50% occupancy, likely too low for a usable dynamic range.

**There is no expression window that cleanly separates the two.** The mitigation that would actually work is **increasing the discrimination**, not lowering the driver: a designed operator with a substantially larger score gap over the best genomic site. The panel's current operators were selected as the highest-scoring *real, PMID-cited* Salmonella sites (94% and 91% of PWM max), which is the right call for testing whether the system functions at all — but it means they sit only ~1–2 bits above the genomic background field, because the genome's best matches are themselves already near the top of what this low-information (≈8–10 bit) motif can distinguish.

**This is the same resolution ceiling identified in `results/REPORT_followup.md`, now expressed as a design constraint rather than a statistical one.** A motif that cannot resolve real sites from genomic background in a scan also cannot be engineered into an operator that a wild-type regulator binds selectively over that background. [INFERENCE] If selectivity against native genomic sites turns out to be required, the honest options are: accept that Sal_PhoP-based regulation in this host will co-modulate its top genomic matches; or change donor (the Ec_EnvZ/Ec_OmpR fallback already scaffolded in this project — though note its motif has *lower* IC, 6.60 bits, so it would need its own check and is not automatically better); or move to a regulator whose operator has enough information content to be made genuinely selective — which the standing constraint on modifying the response regulator does not forbid, since it constrains protein engineering, not donor choice.

---

## What changed, and what did not

| Question | Before | Now |
|---|---|---|
| Distance to the functional landmark | 151 bp (to ATG), TSS [NOT FOUND] | **115 bp to TSS; 102 bp to the −10** [EVIDENCE] |
| Is the spacing plausible for an activator? | "plausible-to-borderline, unresolvable" | **Implausible at this promoter** [INFERENCE] |
| Is lysC monocistronic? | "likely operon, inferred from 23 bp spacing" | **Confirmed operon, plus a newly identified internal *asd* promoter** [EVIDENCE] |
| Would activation hurt a lysine producer? | not assessed | **Probably not metabolically — but it breaks orthogonality** [INFERENCE] |
| Does "keep Sal_PhoP low" protect lysC? | assumed to help | **No — only ~2.3–3.6× headroom; 71–79% lysC occupancy at 90% design occupancy** [ESTIMATE] |

**The lysC hit is now less likely to be functional and less separable if it is.** Those pull in opposite directions and should not be averaged into a single verdict: the positional evidence says this specific site probably cannot act at this specific promoter, while the affinity analysis says the panel's operators are not selective enough over the genomic field generally. The second finding outlives the first — it applies to every genomic Sal_PhoP-like site, not just lysC, and it is a property of the motif's information content rather than of any one locus.

**No experimental claim is made here.** As with the promoter panel, nothing above demonstrates that Sal_PhoP binds, activates, or fails to activate anything in this host. These are sequence- and position-level analyses that sharpen where the experiment should look.

---

## Files

- `designs/lysc_resolution.md` — this file
- `scripts/lysc_tss_resolution.py` — TSS retrieval, coordinate verification, distance computation
- `scripts/lysc_leakiness.py` — PWM score gap, affinity ratio, occupancy model
- `data/cache/literature/pfeifer2013_tables/Table_S1.xlsx`, `Table_S3.xlsx` — newly cached TSS/5′-UTR data (Europe PMC)
- `data/cache/lysc_tss_facts.json`, `data/cache/lysc_leakiness.json` — machine-readable results

No existing path was written to. `results/REPORT.md`, `results/lysc_analysis.md`, `designs/REPORT_promoter.md` and all other prior outputs are unmodified.
