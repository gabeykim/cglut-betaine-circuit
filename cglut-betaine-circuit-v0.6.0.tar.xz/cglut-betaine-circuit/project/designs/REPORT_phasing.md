# Tier-1 operator phasing series, rebuilt as two matched arms

Built 2026-08-23. Scripts: `scripts/design_backgrounds.py` (designed sequences), `scripts/build_phasing_v2.py` (arms + controls), `scripts/check_manifest_v2.py` (consolidation + combined-set checks). Nothing existing was overwritten; all outputs are new or `_v2`-versioned.

Tags: **[EVIDENCE]** a citable source states it. **[INFERENCE]** reasoning from evidence, step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent.

**No construct here is claimed to work.** The two-tier architecture has not been demonstrated in any bacterial host, and nothing below changes that.

---

## 0. TASK 0 VERDICT — feasibility

**Substitution is feasible on Psyn, and feasible on PsodA but not advisable there. Both arms were built on Psyn; PsodA keeps its coarse 4-point insertion cross-check.**

### Psyn — FEASIBLE, with room to spare

- **Upstream available inside the amplicon: 0 bp.** [EVIDENCE, computed] Psyn's validated fragment is 34 bp and its −35 sits at index 0, so the amplicon contains *no* sequence upstream of the −35. Psyn is synthetic and has no genomic locus, so its upstream context is whatever the construct defines and nothing is lost by defining it.
- **Current upstream in the existing variants: 30 bp** of generic filler. **It can be extended without limit** — there is no natural boundary to respect, only synthesis cost. [INFERENCE]
- **Required length: operator (16 bp) + 14 = 30 bp minimum.** The existing 30 bp therefore *just* fits, with zero 5′ margin at gap 13.
- **Chosen: 46 bp.** This gives 16 bp of headroom, and it makes the arms comparable by construction: at every gap the construct is **80 bp**, which is exactly the length of the *existing* gap-0 insertion construct, and at gap 0 the operator sits behind 30 bp of background — the same layout the insertion arm uses. [ESTIMATE: 46 = 16 operator + 30 retained background]

```
 SUBSTITUTION   BG_A[0 : 30-gap]   OPERATOR(16)   BG_A[46-gap : 46]   core_from_-35(34)   = 80 bp, always
                \___ 30-gap bp ___/               \____ gap bp ____/
 INSERTION      UP_A(30)           OPERATOR(16)   FILL_A[:gap]        core_from_-35(34)   = 80+gap bp
```

### PsodA — geometrically feasible, but substitution into native sequence is the wrong move

- **Upstream available inside the amplicon: 68 bp of real genomic sequence** (171 bp amplicon, −35 at index 68). [EVIDENCE, computed] That is more than the 30 bp a substitution design needs, so it fits geometrically.
- **But the current design already discards all 68 bp** and replaces them with filler — every existing PsodA variant is built from `amplicon[68:]` only. So a designed-background substitution on PsodA destroys nothing, because nothing genomic is there to destroy in the first place.
- **Substituting the operator into the native 68 bp instead would be actively harmful** [INFERENCE, reasoning named]: sliding a 16 bp operator through it ablates a *different* 16 bp of real genomic sequence at each of 14 positions, so the series would confound operator position with which native element happened to be destroyed. That is a worse confound than the one being fixed.
- **The retained-context arm is not at risk either way.** `PsodA_1x_opA_gap03_native` uses a separate 40 bp extension taken from immediately 5′ of the amplicon, not `amplicon[0:68]`, and that extension was re-verified against BX927147.1 in this build. [EVIDENCE]

**Decision:** PsodA is not given a 14-point substitution series — not for feasibility reasons but for envelope reasons (§5). Its role in the panel is a coarse cross-check on a structurally different core, and it keeps its 4 points, **rebuilt with the corrected filler** (the old PsodA gap-3 filler was `GGG`).

Ptuf is untouched as a phasing subject: its −35 could not be confidently assigned (best candidate 12% of max), so no gap value on Ptuf is trustworthy. [EVIDENCE: `designs/REPORT_promoter.md` §2]

---

## 1. What was wrong, and what the substitution arm fixes

The old filler was the first *n* characters of one fixed hash-derived string. [EVIDENCE, computed]

| gap | old filler | old GC | new filler `FILL_A[:n]` | new GC |
|---|---|---|---|---|
| 1 | `G` | 100% | `T` | 0% |
| 2 | `GG` | 100% | `TG` | 50% |
| 3 | `GGG` | 100% | `TGA` | 33% |
| 5 | `GGGCT` | 80% | `TGAGT` | 40% |
| 8 | `GGGCTGAG` | 75% | `TGAGTGTG` | 50% |
| 10 | `GGGCTGAGGT` | 70% | `TGAGTGTGGC` | 60% |
| 13 | `GGGCTGAGGTTGT` | 62% | `TGAGTGTGGCGTT` | 54% |

### The substitution arm is exactly invariant, not approximately

[EVIDENCE, computed over all 14 constructs]

- **Length: 80 bp at every gap.** Identical.
- **GC: 33.75% at every gap — 27 GC bases out of 80, identical.** Spread **0.00 points**.

This is stronger than the task asked for. The task anticipated residual variation "because the operator's own composition differs from the background it displaces" — and that is real, but it shifts every construct by the *same* amount. The construct's GC is `GC(background) − GC(displaced window) + GC(operator) + GC(core)`, and only the displaced window varies with gap. So **BG_A was designed with the added constraint that base *i* and base *i+16* are always in the same GC class** for the 13 offsets the operator can occupy, which forces every displaceable 16-mer to have identical GC content (9 GC bases). The series is then GC-invariant by construction rather than by luck. All three backgrounds share the same displaced-window GC count, so the swap controls are matched too.

The insertion arm, by contrast, still varies: **length 80-93 bp, GC 33.33-37.36%, spread 4.03 points.** That is inherent to inserting rather than substituting, and it is exactly why the substitution arm is primary.

---

## 2. The designed sequences — `designs/background_sequences.fasta`

**Provenance: DESIGNED, NOT SOURCED.** No natural record is cited because none exists. They are produced by a seeded search in `scripts/design_backgrounds.py` and are reproducible from that file alone.

| Name | Len | GC | Use |
|---|---|---|---|
| `BG_A` | 46 | 54.3% | primary substitution background |
| `BG_B`, `BG_C` | 46 | 54.3% | background-swap controls (matched displaced-window GC = 9) |
| `UP_A` | 30 | 53.3% | insertion-arm upstream context |
| `UP_B` | 30 | 53.3% | designed spare — **reserved, used in no construct** |
| `FILL_A` | 13 | 53.8% | insertion-arm gap filler |
| `FILL_B` | 13 | 53.8% | filler-swap control |
| `TSP_A` | 2 | — | tandem inter-operator spacer |

**Criteria, all verified rather than asserted:** GC within ±4 points of the host's 53.84%; no homopolymer > 3; no direct repeat > 6; no dinucleotide microsatellite and no 4-mer used more than twice; no site for **any** of a 35-enzyme catalogue on either strand; no `ATG` and no SD-like `GGAG`/`AGGA`/`GAGG`; no SigA-like element; ViennaRNA MFE > −8 kcal/mol; shares **no 10-mer** with any of the **82 intergenic-null-surviving genomic Sal_PhoP matches** — the lysC site among them, confirmed present in that set at BX927147.1:269204-269220 [EVIDENCE] — and **no window scores within 60% of the operator's own Sal_PhoP PWM score** (operator = 19.043).

### Three things this design pass got wrong first, and how they were caught

1. **Checking parts instead of constructs.** The first BG_A passed every criterion in isolation yet produced a spurious SigA extended-10 at 0.72 of max in four constructs. The hit was **junction-created**: background `CGGGCTACAA` + operator `TTT` scored 0.72 while neither piece alone exceeded 0.34, and the operator on its own scores 0.07 — it does not resemble a −10. The designer now validates **the 14 constructs a candidate would produce**, not the candidate. Spurious SigA hits went from 7 to **0**.
2. **Designing against the narrow enzyme list.** BG_B initially carried an **MluI** site, because the design criteria used the repo's 15-enzyme working list while the check used a broader catalogue. A designed sequence has no provenance excuse for carrying any site, so the criteria now use the full 35-enzyme catalogue.
3. **A "matched composition" control that was not matched.** The first BG_B gave a swap control at 32.5% GC against a 33.75% reference. Both swap backgrounds are now constrained to the same displaced-window GC count, so all three read **exactly 80 bp / 33.75%**.

The first attempt also produced `TGTGTGTG` and a `CCCT` triplication — compliant with "no direct repeat longer than 6" and still bad sequence, so a low-complexity filter was added.

---

## 3. The panel — `phasing_substitution.csv`, `phasing_insertion.csv`, `phasing_controls.csv`

| Arm | Constructs | Geometry |
|---|---|---|
| **Substitution (primary)** | 14 — Psyn, gaps 0-13 | operator slides through fixed `BG_A`; 80 bp, 33.75% GC, invariant |
| **Insertion (secondary)** | 18 — Psyn gaps 0-13 (14) + PsodA gaps 0/3/6/10 (4) | operator inserted into a growing gap; 80-93 bp |
| **Swap controls** | 3 — all at gap 7 | 2 background swaps (`BG_B`, `BG_C`), 1 filler swap (`FILL_B`) |

**Why both arms are kept.** They are controls on each other. If the phasing result agrees across substitution and insertion, it is robust to design geometry. If it disagrees, **the geometry itself matters — which is a finding about the architecture, not a failure of the experiment**, and it would say that operator *context* (length, spacing composition) contributes as much as operator *position*. Neither arm alone can distinguish those.

**Residual extremity, reported not obscured.** At gaps 1-3 the insertion filler is 1-3 nt: `T` (0% GC), `TG` (50%), `TGA` (33%). A single nucleotide is 0% or 100% GC and no design fixes that. The improvement is real — the old series was 100%/100%/100% at those gaps, and monotonic thereafter — but the first three insertion points remain compositionally noisy, and the substitution arm is the one to trust there.

**Swap controls, gap 7** (chosen in the clean region, ≥4, away from the 1-3 extremes). Each is identical to its reference except for the swapped element, and each is **exactly length- and GC-matched to it**: substitution reference and both background swaps are 80 bp / 33.75%; insertion reference and the filler swap are 87 bp / 34.48%. [EVIDENCE, computed] If the swaps read the same as their references, background identity does not matter and the phasing series is clean. If they differ, that difference **bounds** how much of any phasing signal is sequence identity rather than position.

---

## 4. Combined-set checks — `order_manifest_v2.csv`, `order_manifest_v2_checks.csv`

### 4.1 The enzyme list, derived from provenance rather than from the plan

This is the failure mode that produced both the HP-4 NcoI collision and the NsiI/SphI collision: **enzymes arrive WITH borrowed sequence.** So the list was read off the sourced components by scanning each against a 35-enzyme catalogue, rather than taken from the assembly strategy. [EVIDENCE, computed]

| Sourced component | Enzymes it brings |
|---|---|
| PsodA core amplicon (PMC7835838) | **ScaI, StuI** |
| Ptuf core amplicon (PMC7835838) | **EcoRV** |
| Psyn retained context, primer N105 tail | NsiI, SphI |
| fore-cistron HP-4 (*tpx*, PMC10367133) | NcoI *(element excluded from the panel)* |
| fore-cistron HP-6 (NCgl2501) | BamHI |
| fore-cistron HP-12 (NCgl2826) | **XhoI** |
| Henke reverse Gibson tail | EcoRI, KpnI, SacI |
| Psyn N106 reverse tail | EcoRI, PstI, SacI, SalI, XbaI |

**Four enzymes are new relative to the 15-enzyme list used in the previous manifest: ScaI, StuI, EcoRV, XhoI.** All four sit inside *sourced* sequence — two core-promoter amplicons and one fore-cistron — and none was visible to any per-panel check. The working list is now **20 enzymes** (provenance-derived ∪ pECXT99A opening sites ∪ Golden Gate set).

### 4.2 Golden Gate — explicitly verified

**GOLDEN GATE VERDICT: 0 of 69 constructs carry a BsaI, BsmBI, BbsI, SapI or AarI site. The full combined set is CLEAN for the selected assembly route.** [EVIDENCE, computed, both strands]

### 4.3 Everything else

| Check | Result |
|---|---|
| Restriction sites (20 enzymes, both strands) | 21/69 constructs; ScaI 20, StuI 20, BamHI 8, EcoRV 6, XhoI 6, NsiI 4, SphI 4 — **every one inside sourced sequence** |
| Identical sequences | **0** |
| ≥95% identity pairs | 6, **all intended** (HP-7 background vs its own disabling mutants) |
| Spurious internal SigA promoters | **0** (was 7 before the construct-aware redesign) |
| Spurious start codons / SD-like motifs | **0** |
| Homopolymer runs > 6 | **0** |
| GC outliers (±15 pts of 53.84%) | 38 |
| Secondary structure | **defect screen only** — 3 constructs flagged on worst local 60-nt window (all Ptuf, −21 to −22 kcal/mol, inherent to that native fragment) |
| Synthesis difficulty | 42 constructs: 39 under vendor minimum, 30 extreme GC, 3 strong local hairpin |

**Folding energy is not used to rank anything.** It has already been shown to fail as a strength predictor in this host — HP-12 is the least-structured tier-2 element yet ranks only intermediate. [EVIDENCE: `designs/REPORT_translational.md` §3]

### 4.4 AT-distribution: expected concentration, not design bias

| Segment | Substitution arm | Insertion arm |
|---|---|---|
| operator (16 bp, **sourced**) | 12.5% GC | 12.5% GC |
| core from −35 (34 bp, **sourced**) | 26.5% GC | 26.5% GC |
| designed background / upstream | 54.3% | 53.3% |
| retained background (30 bp) | **53.3%, invariant** | n/a |
| gap filler | n/a — no filler exists | 0-63.6% |

**The AT-richness sits in the two sourced elements that are AT-rich by nature, and every designed flank sits at host composition.** This is the expected pattern, not the design bias the v1 check found — where the filler ran to 88.4% GC and inverted the whole distribution. The remaining variation is confined to the insertion arm's filler, which is the arm's known and reported cost.

---

## 5. Construct count and envelope

| Component | Constructs |
|---|---|
| Substitution phasing series (Psyn 0-13) | 14 |
| Insertion phasing series (Psyn 0-13, PsodA 0/3/6/10) | 18 |
| Swap controls | 3 |
| Tier-1 non-phasing, rebuilt with corrected filler | 15 |
| Combinatorial (promoter × translational) | 19 |
| **Total** | **69** (8,191 bp) |

| Scenario | Total | Verdict |
|---|---|---|
| 69 + SK 10 | 79 | fits 48-96 |
| 69 + SK 20 | 89 | fits 48-96 |
| **69 + SK 30** | **99** | **EXCEEDS 96 by 3** |

**The two-arm design pushes past the envelope if the sensor-kinase panel comes in at its upper bound.** It fits at 10 and 20; it fails only at 30. Nothing has been silently trimmed — the ranked cut order is below, in the order the task specifies (insertion first, because substitution is the cleaner design).

| # | Cut | Frees | Total | Cost |
|---|---|---|---|---|
| **B** | Halve the Psyn insertion series to gaps 0, 2, 4, 7, 9, 11, 13 | 7 | 62 | Keeps two of three wrap pairs (11↔0, 13↔2) and a coarse cross-arm comparison. **Recommended first cut.** |
| **C** | Drop the Ptuf arm (3 constructs) | 3 | 66 | Ptuf's −35 is unassignable, so it contributes nothing positional; all 3 carry the hairpin flag. |
| **D** | Drop combinatorial block 3 (leadered probe) | 2 | 67 | Already confounded — it changes core *and* requires the SD1 modification. |
| **A** | Drop the Psyn insertion series entirely | 14 | 55 | **Last resort.** Surrenders the cross-arm control that §3 exists to provide. |

**Recommended if SK lands at 30: B + C → 59 constructs, 89 with the sensor-kinase panel.** That keeps both arms, both wrap comparisons at the extremes, and all three swap controls.

**Do not cut** the substitution series, any swap control, any negative control, or the retained-context variants.

---

## 6. What each arm can and cannot resolve

### The wrap-around logic, pair by pair

With gaps 0-13 the comparisons are **11 vs 0, 12 vs 1, 13 vs 2** — one full helical turn apart at 10.5 bp/turn, so each pair sits on approximately the same helical face at different distances.

| | Substitution arm | Insertion arm |
|---|---|---|
| Helical face | ~matched (within 0.5 bp of a turn) | ~matched |
| Distance to −35 | differs by 11 bp — **the variable under test** | differs by 11 bp |
| Construct length | **identical (80 bp)** | **differs by 11 bp** |
| Total GC | **identical (33.75%)** | differs by 2.4-3.6 points |
| Sequence between operator and −35 | different 11 bp of the same background | 11 bp of filler vs none |

[EVIDENCE, computed for all three pairs.] **In the substitution arm each wrap pair isolates face-and-distance with length and composition held exactly fixed. In the insertion arm the same pair also changes length and GC**, which is precisely the defect that made the original wrap-around control unable to do its job.

### Substitution arm alone

**A positive result — output varying periodically with gap, with the three wrap pairs agreeing — would license concluding** that operator output depends on rotational position relative to the −35, at fixed construct length, fixed GC, and fixed background identity, and that the dependence has ~10.5 bp periodicity rather than being monotonic in distance.

**What stays ambiguous:** which *mechanism* produces the periodicity (α-CTD contact geometry, sigma region-4 contact, local curvature) — the panel measures output, not contacts. Also *which* face is productive in absolute terms, since the −35's own rotational register is inferred from sequence, not measured.

### Insertion arm alone

**A positive result would license** the weaker conclusion that output varies with gap — but distance, length and spacer composition all move together, so periodicity cannot be separated from a length or composition effect. **On its own this arm cannot establish face-of-helix dependence.** It is retained as a geometry control, not as evidence.

### The two arms together

**Agreement across arms would license** the stronger claim that the phasing result is robust to design geometry — that it survives both a constant-length and a variable-length realisation, so it is unlikely to be an artifact of either.

**Disagreement is also informative, and is a finding rather than a failure:** it would mean spacer identity/length contributes materially, and the swap controls then bound how much. That is a real result about the architecture — it would say a hybrid promoter's output is sensitive to what sits between the operator and the core, which matters for every future design on this scaffold.

### Residual confounds no version of this design removes

1. **The 5′ background flank changes length with gap in the substitution arm** — 30 bp at gap 0 down to 17 bp at gap 13 (the total background stays 30 bp, but its split across the operator changes). The operator's immediate 5′ neighbours therefore differ between gaps. Unavoidable in any sliding design. [INFERENCE]
2. **The operator's neighbouring sequence differs at every position in both arms.** Holding composition constant is not holding sequence constant. The swap controls bound the *magnitude* of sequence-identity effects at one gap; they cannot remove them at all gaps.
3. **The −35 register is inferred, not measured.** Every gap value is measured from a computationally assigned −35. For Psyn that assignment is high-confidence (100% of consensus max) but still not experimental.
4. **No mapped TSS for Psyn.** [NOT FOUND] Psyn is synthetic; its transcription start is inferred from −10 placement calibrated on a single measured promoter (lysC). If the real TSS differs by a few bases, every distance-to-promoter statement shifts with it.
5. **The SigA matrix is a reasoned approximation from a textual consensus, not an empirically trained PWM.** A clean spurious-promoter scan means "no consensus-like cryptic promoter", not "no cryptic promoter". This caveat is carried into every check above.
6. **Periodicity detection still rests on 14 points and 3 wrap pairs.** If the true effect is small relative to construct-to-construct noise, no amount of design geometry rescues it — that is a replication and measurement question, not a design one.
