# Consolidated order manifest: combined-set checks and budget reconciliation

Built 2026-08-23 by `scripts/build_order_manifest.py`. Outputs: `designs/order_manifest.csv` (52 rows), `designs/order_manifest_checks.csv` (52 rows), `designs/order_submit.fasta` / `.csv` (id + sequence only).

Tags: **[EVIDENCE]** a citable source states it. **[INFERENCE]** reasoning from evidence, step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent.

**No construct in this manifest is claimed to work.** Nobody has demonstrated an imported wild-type response regulator driving a hybrid promoter in this host, and the two-tier architecture has not been demonstrated in any bacterial host.

---

## 0. LEAD: what failed across the combined set that passed per-panel

**Three findings. Two are genuinely new — invisible to every per-panel check and visible only once the panels were put in one table. One is an escalation of a known flag.**

### 0.1 NEW — two constructs carry NsiI and SphI sites that the tier-1 panel reported as clean

`Psyn_1x_opA_gap03_reta` and `Psyn_1x_opA_gap05_reta` (the retained-upstream-context variants added this session) each carry **NsiI `ATGCAT`@0 and SphI `GCATGC`@2**, on both strands.

The tier-1 panel's own check reports `enzyme_sites='none'` for both. [EVIDENCE: `designs/design_checks.csv`.] It is not wrong — it is checking a 13-enzyme list that **does not contain NsiI or SphI**. The combined check enumerates 15 enzymes, derived by tracing the actual assembly strategy of *every* panel back to its primers, and the two extra enzymes are exactly the two that appear in the Psyn N105 forward homology tail `ATGCATGCCGCTTCGCCTTCG` — the very sequence these two variants were built from.

This is the same failure mode as the HP-4/NcoI collision that motivated this task: **a site that is invisible while each panel checks only the enzymes it happens to know about.** The sourced vector tail was adopted for good provenance reasons, and it silently imported two restriction sites with it.

- Tier-1 enzyme list (13): BsaI, BsmBI, BbsI, EcoRI, BamHI, HindIII, NcoI, NdeI, XbaI, SalI, PstI, KpnI, SacI
- **Added for the combined check (2): NsiI, SphI** — justified in §2.1

### 0.2 NEW — the gap-sweep filler is a fixed GC-rich prefix, confounding the position sweep

The AT-distribution analysis Task 3b asks for gives, averaged over Psyn constructs [EVIDENCE, computed]:

| Segment | mean GC% |
|---|---|
| upstream (30 bp filler) | 47.5% |
| operator | 13.4% |
| **gap filler** | **88.4%** |
| core from −35 | 26.5% |

The AT-richness *is* concentrated in the core promoter and the operator — which is expected and correct, and is the answer to the question as posed. But the same analysis surfaces something else: **the gap filler runs the opposite way, and it is not composition-neutral.**

`make_generic_filler(n)` returns the first *n* characters of one fixed deterministic string, so every spacer in the sweep is a prefix of the same sequence [EVIDENCE, computed]:

| gap | filler | GC% |
|---|---|---|
| 1 | `G` | 100% |
| 2 | `GG` | 100% |
| 3 | `GGG` | 100% |
| 5 | `GGGCT` | 80% |
| 8 | `GGGCTGAG` | 75% |
| 10 | `GGGCTGAGGT` | 70% |
| 13 | `GGGCTGAGGTTGT` | 61.5% |

Two consequences [INFERENCE, reasoning named]:

1. **Short gaps insert a G-tract directly between the operator and the −35.** Gaps 1-3 are pure poly-G. G-tracts alter local curvature and rigidity, so the smallest spacings carry a structural perturbation that the larger ones do not.
2. **Filler GC falls monotonically as the gap grows** — along the exact axis being swept. Any monotonic trend in output across the sweep is therefore confounded between "operator distance/phase" and "spacer composition", and the two cannot be separated within this panel.

The sharpest version: **the three wrap-around comparisons added this session (gap 11 vs 0, 12 vs 1, 13 vs 2) — the comparisons whose entire purpose is to separate helical periodicity from monotonic distance decay — are also the comparisons with the largest filler-composition difference** (0-2 bp of filler versus 11-13 bp). The design intent survives, but it is weaker than the geometry alone suggests.

**This is a design note, not a synthesis blocker, and it is not fixed here** — changing the filler would alter every sweep variant and invalidate the panel's internal comparability mid-flight. The recommended fix if the panel is rebuilt: draw the filler from a composition-matched source (host intergenic ~47% GC) rather than a hash prefix, and hold filler composition constant across the sweep by varying only which composition-matched segment is used. The 30 bp upstream "replaced" filler is fine as-is (46.7% GC).

### 0.3 ESCALATION — HP-6's BamHI site now sits in four orderable constructs

The tier-2 panel already flagged BamHI in HP-6 [EVIDENCE: `designs/translational_variants.csv`]. What the combined set adds is scope: HP-6 is the **low calibration anchor**, so it appears in `CX-01`, `CX-04`, `CX-07` and `CX-19` — 4 of the 19 combinatorial constructs, including three of the nine cells of the independence factorial. It cannot be silently mutated away: HP-6's published rank is the panel's only low-end anchor, and changing the element voids it.

### 0.4 What did NOT fail

**NcoI: zero hits across all 52 constructs.** [EVIDENCE, computed.] The HP-4 exclusion made during the tier-2 design held through consolidation — the known collision did not reach the order. **Zero identical sequence pairs. Zero unintended near-duplicates. Zero spurious SigA promoters. Zero spurious internal initiation signals. Zero homopolymer runs > 6.**

---

## 1. Final construct count

| Tier | Constructs |
|---|---|
| Tier 1 (promoter panel, non-control) | 28 |
| Combinatorial (promoter × translational, non-control) | 17 |
| Controls (3 no-operator, 2 scrambled, 2 tier-2 disabling) | 7 |
| **Total to order** | **52** |

By panel of origin: tier-1 promoter panel **33**; combinatorial block 1 (independence 3×4) **9**; block 2 (tuning curve) **8**; block 3 (leadered probe) **2**.
By core promoter: Psyn **39**, PsodA **10**, Ptuf **3**.
Length **64-229 bp**, **6,872 bp** total. [EVIDENCE, computed]

The tier-2 translational panel contributes **no standalone rows** — its elements are not independently orderable. All 11 sequence-bearing tier-2 elements appear inside combinatorial constructs (3 anchors in block 1, the other 8 in block 2), and the 12th (`T2_MCD_ctrl`) is the monocistronic column, which is the tier-1 constructs themselves.

**Fragment boundary**: every ordered fragment ends immediately **before** the target ATG, which the vector supplies (pECXT99A is opened with NcoI/NdeI; the Henke reverse tail ends `…GAATTCCATG`). BCD fragments therefore end in the `TA` of the TAATG coupling frame, and the vector's ATG completes both the fore-cistron stop and the target start. [EVIDENCE: PMC7835838 Table 2; PMC10367133 body text]

---

## 2. Checks run across the union

### 2.1 Restriction sites — 15 enzymes, enumerated explicitly, both strands, every construct

| Enzyme | Site | Why it is in the list |
|---|---|---|
| BsaI / BsmBI / BbsI | GGTCTC / CGTCTC / GAAGAC | Type IIS, named in every panel's design spec |
| NcoI / NdeI | CCATGG / CATATG | the enzymes pECXT99A is opened with; NcoI also supplies the target ATG |
| KpnI / SacI / EcoRI | GGTACC / GAGCTC / GAATTC | present in the Henke reverse homology tail `CCGGGTACCGAGCTCGAATTCCATG` |
| **NsiI / SphI** | ATGCAT / GCATGC | **present in the Psyn N105 forward tail `ATGCATGCCGCTTCGCCTTCG` — added this round; see §0.1** |
| PstI / SalI / XbaI / BamHI | CTGCAG / GTCGAC / TCTAGA / GGATCC | present in the Psyn N106 reverse tail |
| HindIII | AAGCTT | standard MCS enzyme, carried over from the tier-1 check |

**Result: 6 of 52 constructs carry ≥1 site** — 16 hits total (each palindrome counted on both strands): BamHI 8, NsiI 4, SphI 4. No BsaI/BsmBI/BbsI anywhere, so Golden Gate is clean across the whole order.

### 2.2 Sequence uniqueness

**0 identical pairs. 6 pairs ≥95% identity, all 6 intended.** All six are the HP-7 background against its own disabling mutants on the same promoter (`HP07_gpmA` vs `fcATGtoATC_NEG` / `SDmut_NEG` / `fcATGtoGTG_PARTIAL`, 96.2-99.4%) — matched pairs by construction; near-identity is the point.

**Method caveat [INFERENCE]:** identity is computed ungapped over the overlap, and pairs differing in length by >6 bp are not compared. The tier-1 gap-sweep variants are near-identical in *content* but frame-shifted relative to each other by the gap, so they do not register. For a vendor, adjacent sweep variants differing by 1 bp are a real mix-up and recombination risk even though this check does not flag them — **worth stating on the order.**

### 2.3 Unintended internal promoters — **zero**, with the matrix caveat carried forward

Every construct was scanned with the repo's SigA extended-10 matrix outside its intended core-promoter window; **no hit ≥55% of max in any of the 52.**

**[INFERENCE — this null is weaker than it looks.]** The matrix is a *reasoned approximation built from a textual IUPAC consensus* (Patek & Nesvera 2011: extended −10 `tgngnTA(c/t)aaTgg`, −35 `ttgnca`), **not a PWM trained on aligned confirmed *C. glutamicum* promoters** — no extractable table of individually-mapped confirmed SigA sites was found. It scores the consensus it was built from, so it will reliably find consensus-like promoters and may well miss the divergent ones that matter. A clean scan here means "no consensus-like cryptic promoter", not "no cryptic promoter".

### 2.4 Unintended start codons / SD-like motifs — **zero**

No SD-like motif (`GGAGG`/`AGGAG`/`GGAG`) followed by an ATG at initiation-plausible spacing (4-12 nt), excluding each construct's intended fore-cistron start.

### 2.5 Secondary structure — **defect screen only**

Whole-fragment MFE spans **−6.9 to −93.6 kcal/mol**, but that scales with length and flags long constructs for being long. The reported screen uses the **worst local 60-nt window** instead, against the −20.6 kcal/mol bar the tier-1 panel already uses: **3 constructs flagged, all Ptuf** (`Ptuf_1x_opA_gap03_reta` −22.0, `Ptuf_1x_opA_gap03_repl` −21.0, `Ptuf_noop_ctrl` −21.0). Consistent with the tier-1 finding that the −20.6 signal comes from Ptuf's own native downstream fragment, not from operator engineering.

**dG is used here as a defect screen and nothing else.** It has already been shown to fail as a strength predictor in this host — HP-12 is the least-structured tier-2 element of all twelve yet ranks only intermediate, while HP-7 is stronger and more structured. No construct is ranked, ordered or prioritised on dG.

### 2.6 GC content

**26 of 52 flagged** outside 53.84% ± 15 points, all Psyn-based, **29.6-46.7%**. Expected, not a defect: Psyn is a short AT-rich synthetic promoter built to match the AT-rich −10/−35 consensus, and the Sal_PhoP operator is itself AT-rich. §0.2 confirms the AT sits where it should (core 26.5%, operator 13.4%) rather than being smeared across the flanks — the 30 bp upstream filler is 47.5% GC, close to host intergenic.

### 2.7 Homopolymers — **zero** runs > 6 nt across all 52.

### 2.8 Synthesis difficulty — 15 of 52

| Flag | Count | Assessment |
|---|---|---|
| `EXTREME_GC` (<35%) | 12 | All Psyn constructs, 29.6-34.9%. Priced higher; not refused at this length. |
| `STRONG_LOCAL_HAIRPIN` (dG60 ≤ −20.6) | 3 | All Ptuf; inherent to the native fragment. |

**A practical issue the per-panel checks never had to face: 22 of 52 constructs are 64-103 bp** — below the ~125 bp minimum of common synthetic-fragment products. [ESTIMATE] They will need to be ordered as annealed oligo duplexes, padded with removable flanks, or quoted under a different product line. 20 of the 22 are tier-1 constructs. **This is an ordering-logistics blocker, not a design defect**, and it needs a decision before submission.

---

## 3. Provenance

Every sequence in the manifest traces to a fetched record or a primary publication; the `provenance` column carries the citation per construct.

- **Core promoters** — Henke, Krahn & Wendisch 2021, *Microorganisms* 9:204 (PMC7835838); amplicons recovered from BX927147.1 using the paper's own primers. [EVIDENCE]
- **Operators** — confirmed *Salmonella* Sal_PhoP sites, PRODORIC MX000339. [EVIDENCE]
- **Retained upstream context (Psyn)** — 21 nt vector-homology tail of primer N105 (Psyn-fw2), PMC7835838 Table 2, transcribed from cached raw HTML and verified to sit in a single unbroken `<td>` cell. [EVIDENCE]
- **Fore-cistrons** — Liu et al. 2023, *ACS Synth Biol* 12:2157-2167 (PMC10367133) Table 1; each 62-mer verified base-for-base against BX927147.1, the only differences being the documented GTG→ATG start unification in HP-1/6/8. [EVIDENCE]
- **SD2 `AAAGGAGGACAAC` and the TAATG frame** — same paper, body text verbatim. [EVIDENCE]

### Provenance gaps — components that are ours, not sourced

Four component classes are **not** natural sequences and cannot be cited to any record. All are deterministic and reproducible from the scripts, and all are declared:

1. **Gap filler and upstream "replaced" filler** — generated by a documented seeded hash in `scripts/design_promoter_panel.py`. Not a natural sequence and not claimed to be. See §0.2 for the composition problem this creates.
2. **Tandem inter-operator spacer (2 bp)** — arbitrary, explicitly not data-grounded, in the 2×-operator variants.
3. **Scrambled operator** — seeded shuffle of opA; composition-matched, sequence invented by design.
4. **The SD mutant `GGAGG→CCTCC`** in `T2_BCD_HP07_SDmut_NEG` — the *requirement* is published, but **this specific substitution is ours**; Liu et al.'s exact SD mutant is in a supplementary figure. **[NOT FOUND]**

No other construct contains a component whose source cannot be cited.

---

## 4. Every flagged construct: blocker or note

| Construct(s) | Flag | Verdict |
|---|---|---|
| `T1-25_Psyn_1x_opA_gap03_reta`, `T1-26_..._gap05_reta` | NsiI + SphI | **BLOCKER if either enzyme is used in assembly.** Both come from the sourced N105 vector tail. Removing them breaks the provenance that justifies the variants; the fix is to choose an assembly route that avoids NsiI/SphI. Decision required before ordering. |
| `CX-01`, `CX-04`, `CX-07`, `CX-19` (all HP-6) | BamHI | **BLOCKER if BamHI is used.** HP-6 is the only low-end calibration anchor; mutating it voids its published rank. Same resolution: avoid BamHI. |
| 12 Psyn constructs | EXTREME_GC 29.6-34.9% | **Note.** Expected for an AT-rich synthetic promoter; a pricing issue, not a defect. |
| 3 Ptuf constructs | STRONG_LOCAL_HAIRPIN −21 to −22 | **Note.** Inherent to Ptuf's native fragment; identical across its operator-bearing and no-operator variants, so it is not operator-induced. |
| 26 constructs | GC_OUT_OF_RANGE | **Note.** Same cause as above. |
| 22 constructs | 64-103 bp, under vendor fragment minimum | **Logistics blocker.** Needs a product-line decision. |
| Whole Psyn sweep | GC-rich filler confound (§0.2) | **Interpretation note, not a synthesis issue.** Weakens but does not void the wrap-around design. |

**Nothing in the manifest is a hard synthesis failure.** The two restriction blockers are conditional on assembly-route choice; the length issue is a product-line choice.

---

## 5. Budget reconciliation

| Component | Constructs |
|---|---|
| Tier-1 promoter panel | 33 |
| Combinatorial (new cells only) | 19 |
| **Subtotal in this manifest** | **52** |
| Sensor-kinase junction panel (reserved, not designed here) | 10-30 |
| **Campaign total** | **62-82** |

**It fits.** The 48-96 envelope accommodates the full order at both ends: 62 at the low reservation, 82 at the high. Headroom is **14-34 constructs**. [ESTIMATE, inputs shown]

The saving that makes it fit: the tier-1 constructs *are* the monocistronic column of the factorial, so the 23-cell combinatorial design costs only 19 new constructs, not 23.

### If it tightens — lowest-value drop candidates, in order

1. **The 3 Ptuf constructs** (`T1-31/32/33`). The panel's own report states Ptuf's −35 "is not trustworthy" (best candidate 12% of max), so they contribute nothing to the positional analysis; all three carry the hairpin flag; and they form a closed unit that must be dropped together. **Frees 3.**
2. **Block 3, the leadered probe** (`CX-18`, `CX-19`). Only 2 constructs, and structurally confounded — it changes the core promoter *and* requires the conventional-BCD SD1 modification, so a difference cannot be attributed to either. Dropping it also removes one of the four BamHI constructs. **Frees 2.**
3. **PsodA coarse-sweep redundancy** (`gap06`, `gap10`). The PsodA sweep is `{0, 3, 6, 10}` and is already only a coarse cross-check; two points still sample distinct faces. **Frees 2.**

**Do not drop** the wrap-around gaps 11-13 (they are the reason the sweep can distinguish periodicity from decay), the retained-context variants (they are what separates "the architecture fails" from "we truncated something needed"), any negative control, or any of the three tier-2 calibration anchors.

---

## 6. Is the panel order-ready?

**Not yet — three decisions remain, none of them a redesign.**

1. **Assembly-route decision on NsiI/SphI and BamHI.** 6 constructs carry sites for enzymes that appear in the panels' own homology tails. If the route uses only Type IIS enzymes, all 6 are fine as-is — **Golden Gate is clean across all 52** — and this closes immediately.
2. **Product-line decision for the 22 constructs under 125 bp.** Annealed duplexes, padded flanks, or a different vendor product.
3. **Acknowledge the filler confound (§0.2)** in the analysis plan, or rebuild the sweep with a composition-matched spacer before ordering. This is a scientific decision about what the sweep can prove, not a synthesis one.

Everything else is ready: sequences are final, unique, provenance-complete, free of Type IIS sites, free of spurious promoters and initiation signals, free of long homopolymers, and `designs/order_submit.fasta` / `.csv` are vendor-submittable as-is.
