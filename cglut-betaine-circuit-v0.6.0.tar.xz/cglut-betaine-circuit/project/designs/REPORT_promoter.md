# Hybrid PhoP-operator promoter panel for *C. glutamicum* ATCC 13032

> ### Revision note (2026-08-23)
>
> **The panel described below has been revised from 28 to 33 variants; the per-check counts in §4 and the "28 variants" statements elsewhere in this file refer to the superseded 28-variant panel.** Five variants were added: gaps **11, 12, 13** on the Psyn opA_phoP x1 replaced series (extending the sweep from 0.952 to **1.24 helical turns** and adding three wrap-around comparisons against gaps 0/1/2), and two **retained-upstream-context** Psyn variants at gaps 3 and 5 (`Psyn_1x_opA_gap03_reta`, `Psyn_1x_opA_gap05_reta`). Two off-by-one statements about helical-turn coverage are corrected inline below and marked *(Corrected 2026-08-23: …)*.
>
> Protein names in this file use the pre-2026-08-23 bare form (PhoP, PhoR, …). The repo-wide organism-prefix convention (Sal_PhoP, Cg_PhoR, …) and the full old→new mapping are in `designs/naming_map.csv` and `designs/REPORT_naming.md`. Current panel contents, combined-set checks and the order-ready build are in `designs/REPORT_order.md`.

**This panel exists to find out whether a wild-type imported response regulator can drive transcription in this host at all.** No variant here is claimed to work. Nobody has demonstrated an imported wild-type response regulator (from a Gram-negative donor) driving a hybrid promoter in a Gram-positive host — the direct precedent (E. coli NarX-NarL with its native *PdcuS* promoter, moved into *B. subtilis*) shows sensing and phosphotransfer surviving the transplant while transcriptional output did not [EVIDENCE: Schmidl et al. 2019, *Nat Chem Biol* 15:690-698; US 10,793,840 FIG. 19]. This panel tests the fix proposed for that exact failure mode — keep PhoP (Salmonella, UniProt P0DM78) completely unmodified and change only the promoter — by building constructs that span the plausible design space rather than betting on one guess.

Tags: **[EVIDENCE]** a citable source states it, cited inline. **[INFERENCE]** reasoning from evidence, reasoning step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent, with what was searched.

Regenerate with (order matters — each script consumes the previous one's cached output):
```
python3 scripts/fetch_core_promoters.py
python3 scripts/map_promoter_elements.py
python3 scripts/design_promoter_panel.py
python3 scripts/design_checks.py
python3 scripts/rank_panel.py
```
Fully offline: the genome, feature table, and PhoP PWM were all already cached by earlier analyses in this repo; the one new fetch (PMC7835838, the core-promoter source paper) is cached at `data/cache/literature/pmc7835838.html`.

---

## 1. Core promoter provenance (Task 1)

Source: **Henke, Krahn & Wendisch 2021, *Microorganisms* 9:204 (PMC7835838)**, "Improved Plasmid-Based Inducible and Constitutive Gene Expression in *Corynebacterium glutamicum*" — verified byline via NCBI esummary, not assumed. This is the paper the task's starting-strength table is drawn from.

**5/5 of the task's named starting-set promoters were sourced** — none were dropped at the *acquisition* stage (all 5 have a real, citable sequence); 2 were later excluded at the *element-mapping* stage (§2) for a different, explicit reason.

| Promoter | Strength (% of IPTG-induced Ptrc) | Sequence source | How obtained |
|---|---|---|---|
| PsodA | 10.8 ± 1% | genome, primer-validated | see below |
| PgapA | 19 ± 9% | genome, primer-validated | see below |
| Ptuf | 50 ± 15% | genome, primer-validated | see below |
| P45 | 56 ± 7% | literature, verbatim | see below |
| Psyn | 286 ± 4% | literature, verbatim | see below |

**Native promoters (PsodA, PgapA, Ptuf)** [EVIDENCE]: rather than guessing an upstream-window size, this analysis recovered the **exact fragment the paper itself amplified, cloned, and functionally characterized**. PMC7835838 Methods 2.3 states the primer pairs used (HN12/13 = Ptuf, HN14/15 = PgapA, HN30/31 = PsodA) and the exact locus tags (cg0587, cg1791, cg3237 respectively). Each primer has a constant Gibson-homology tail followed by a gene-specific annealing sequence; stripping the tail and locating the gene-specific remainder in the cached BX927147.1 genome record identifies the real amplicon boundaries. This matters because an earlier attempt using an assumed 150 bp upstream window missed a real, better-scoring promoter element for Ptuf entirely (it sat further upstream), and widening to an arbitrary 250 bp with an arbitrary "proximal search zone" then broke a previously-fine PsodA assignment — an unstable parameter with nothing to calibrate it against. The primer-recovered amplicon is real evidence; a window size is a guess. Final fragment lengths: PsodA 171 bp, PgapA 115 bp, Ptuf 174 bp.

**Synthetic promoters (P45, Psyn)** [EVIDENCE]: exact sequences are given verbatim in Methods 2.3 (*"The synthetic promoters Psyn (5′-TTGACATTAATTTGAATCTGTGTTATAATGGTTC-3′) ... and P45 (5′-TTGGTCAGGGATTTTTTCCCGAGGGCACTAATTTTGCTAAAGTAAGTGACGAAGAAGTTC-3′)..."*), transcribed exactly and individually re-verified against the raw HTML. A third synthetic promoter from the same paper, **PH36, was dropped**: its sequence spans a PDF-to-HTML paragraph break in the fetched text with a stray period mid-sequence, and — following the task's explicit instruction to drop rather than reconstruct — it was not used, even though the two flanking fragments almost certainly concatenate cleanly. PH36 was never part of the task's named starting set, so nothing required is lost.

**The two "also consider" sets were checked and are [NOT FOUND] as usable sequence data from this environment:**
- **Native gradient PUTR set** (Microb Cell Fact 19:76/120, 2020, PMC7268698) — fetched in full; body text contains no locus tags, no gene names, and no sequences of any kind for the 17 characterized PUTRs. The actual data lives only in a supplementary table not present in the fetched HTML.
- **Shen et al. 2018** (*Biotechnol Lett*, PMID 29605941) — no PMC full text exists for this article (confirmed via NCBI elink — only "cited-by" links returned, not the paper itself); the publisher URL (Springer) returned 404.

Both are reported here rather than reconstructed from the strength numbers alone, per the task's explicit instruction.

---

## 2. Core element mapping (Task 2)

**No genuine empirically-trained SigA PWM was obtainable.** Patek & Nesvera 2011 (*J Biotechnol*, PMID 21277915 — the paper this task cites for the consensus) has no PMC full text and returned 403 from ScienceDirect. The consensus used throughout this analysis — extended -10 `tgngnTA(c/t)aaTgg` (13 nt), -35 `ttgnca` (6 nt, "much less conserved") — is therefore used **exactly as given in the task brief**, cited to Patek & Nesvera 2011 and Pfeifer-Sancar et al. 2013, not independently re-derived. `scripts/siga_consensus.py` converts this textual IUPAC consensus into a log2-odds scoring matrix (uppercase positions weighted 85% to the consensus base, lowercase 40%, `n` uniform 25% each) — **this is a reasoned approximation [INFERENCE], not a PWM built from real aligned confirmed C. glutamicum promoters**, because no extractable table of individually-mapped, confirmed SigA sites was found in any source checked. It gave a clean, informative self-check regardless: the synthetic Psyn promoter — designed, evidently, to match this exact consensus — scores a **perfect 100%/100%** match on both elements, which is not circular (the scoring matrix was built from the textual consensus alone, before ever being run against any sequence) and is a genuine, useful validation that the scoring approach recovers what it should when the answer is known.

| Promoter | Extended -10 (score, % of max) | -35 (score, % of max) | Spacer (bp) | Confidence |
|---|---|---|---|---|
| Psyn | `TGTGTTATAATGG`, 100% | `TTGACA`, 100% | 12 | **HIGH** |
| PsodA | `AGGCCTATCATTG`, 63% | `TTGCAA`, 70% | 11 | MEDIUM |
| Ptuf | `TTAGATATCTTGA`, 63% | `TAGGGT`, **12%** | 18 | MEDIUM* |
| PgapA | `GTCTGTATGATTT`, 45% | none found in the mechanistically plausible 13-25 bp spacer window | — | **LOW — excluded** |
| P45 | `TTTGCTAAAGTAA`, 40% | `TGGTCA`, 70% | 25 | **LOW — excluded** |

*Ptuf's extended-10 is confidently placed, but its best -35 candidate anywhere in a chemically plausible spacer window scores only 12% of max — a widened search (up to 33 bp spacer, all positions in the 174 bp fragment) found nothing stronger nearby. [INFERENCE]: this is consistent with, not contradictory to, the host's stated extended-10-dominant architecture — but it means the *specific position* of Ptuf's -35 is not trustworthy, so **Ptuf's role in this panel is limited to strength-range breadth at one fixed nominal position, not the fine positional sweep** (§3).

**PgapA and P45 are excluded from the panel entirely**, per the task's explicit instruction to exclude promoters whose elements cannot be confidently assigned rather than force a design onto them. This is a real finding, not a search-parameter artifact: for both, the extended-10 search covered every position in the correctly-bounded (primer-validated, for PgapA) or already-minimal (P45, a 60 bp fully-given sequence) promoter, and 40-45% of max was the genuine ceiling.

**Net effect on the core-promoter axis**: 3 of the 5 named promoters remain usable (PsodA 10.8%, Ptuf 50%, Psyn 286% — a 26.5× strength range), with Ptuf usable only in a limited, position-caveated role. This is a real, defensible reduction, reported plainly rather than padded.

---

## 3. Panel design (Task 3)

**Construct grammar** (5'→3'): `[upstream context] [operator, 1-2 copies] [gap, bp] [-35-onward core promoter, held EXACTLY constant per core]`. The "-35-onward" segment — which contains the extended-10 — is sliced directly from the validated amplicon and is never touched by any variant on that core. **The extended -10 is therefore unmodified by construction, in every one of the 28 variants**, not verified after the fact.

**Operator sequences**: two REAL, PMID-cited, confirmed *Salmonella* PhoP sites (from `data/sites/phop_salmonella_sites.fasta`, PRODORIC MX000339, fetched in the earlier follow-up analysis in this repo — not re-fetched, not invented) [EVIDENCE]. Primary (`opA_phoP`, `TTTATTAACTGTTTAT`) is the PhoP autoregulatory site itself, scoring 94% of the Salmonella-PWM maximum — the highest of the 9 confirmed sites. Secondary (`opB_mgtA`, `TTTATCGTTGGTTTAA`) is the *mgtA* site, 91%, used to test whether exact box identity matters at a fixed position. **No PWM-derived synthetic "ideal" operator was used anywhere** — every operator-bearing variant carries a sequence that some real Salmonella promoter actually uses.

**28 variants total.** Axis coverage:

| Axis | How covered | Grounded in data, or reasoned? |
|---|---|---|
| Core promoter identity | Psyn (strong), Ptuf (medium, caveated), PsodA (weak) | **Data-grounded** — real, published, measured strengths (PMC7835838) |
| Operator position (gap to -35) | 11 single-bp steps (0-10 bp) on Psyn; 4-point coarse cross-check (0, 3, 6, 10 bp) on PsodA | **[INFERENCE], reasoning named below** — not calibrated against any confirmed C. glutamicum PhoP-driven promoter (none exists) |
| Operator copy number | 1 vs 2 tandem, tested at gap=0 and gap=5 on Psyn, and gap=3 on PsodA | **[INFERENCE]** — tandem inter-copy spacer (2 bp) is an arbitrary, explicitly-flagged placeholder; no data source for optimal PhoP tandem spacing was sought or found |
| Upstream context | native-retained vs generic-filler-replaced, on PsodA and Ptuf | **[INFERENCE]** — tests whether *unknown* native cis-context matters; by definition there is no data on what that context does |
| Operator identity | opA (phoP site, 94%) vs opB (mgtA site, 91%), at gap=0 and gap=5 on Psyn | **Data-grounded** choice of *which* real sites to compare (both PMID-cited, footprint/EMSA-confirmed); whether the *difference* matters is exactly what the panel tests |

**Gap-sweep spacing rationale** [INFERENCE, reasoning named]: originally 0-10 bp, now **0-13 bp** (see the revision note at the top of this file), was chosen from (a) general Class I/II bacterial activator positioning theory (activators typically contact RNAP from a site overlapping or immediately upstream of -35, not far upstream of it) and (b) the actual `distanceToPromoter` values in the confirmed *E. coli* PhoP site set already cached in this repo from the earlier RegulonDB fetch (mgrRp -44, mgtSp -35, ompTp -59.5, hdeAp -32 bp) — real PhoP sites sit close to the promoter, consistent with a short gap. *(Corrected 2026-08-23: the original text read "0-10 bp (11 steps = one ~10.5 bp helical turn)". That was an off-by-one: 11 points at 1 bp spacing span **10 bp, not 10.5**, and 10 bp is **0.952 turns / 342.9 deg**, not one turn. Worse, a sweep that covers one period exactly once, with no repeated helical face, cannot separate periodicity from monotonic decay with distance. The sweep is now 0-13 bp = 14 consecutive positions = 13 bp = 1.24 turns, with gaps 11/12/13 re-sampling the faces of gaps 0/1/2.)* This is the best available reasoning, explicitly **not** a calibrated distance, because no confirmed PhoP-driven promoter in *any* host with base-pair-resolved spacing to a mapped TSS was sourced for this analysis.

**Budget** (Task 3's explicit ask): **28 constructs budgeted for the promoter panel**, within the task's own 20-40 target range. Combined with the kinase-junction panel's own stated range (10-30 variants, not designed here), total campaign size is **38-58 constructs** — comfortably inside the 48-96 outsourced-characterization envelope even at its lower bound, leaving 10-20 spare slots for either panel to expand into, or for replicates.

**Cross-check against genomic matches** (required by the task): every operator sequence used (`opA_phoP`, `opB_mgtA`, and the scrambled negative control) was compared against all 82 intergenic-null-surviving genomic matches from the earlier follow-up analysis (`results/hits_high_concern.csv`, `passes_p1e-4_intergenic_null=True`), via best-ungapped-window identity. **No operator sequence closely resembles any surviving genomic match, including lysC specifically**: best identity anywhere in the genome-wide survivor set was 56-62% (opA vs. *pstS*, opB vs. *pvdS1*, scrambled vs. cg2824); against the lysC hit specifically, 38-50%. None approach a level that would be called "closely resembling" by any reasonable threshold.

---

## 4. Design checks (Task 4)

All 28 variants checked; full results in `designs/design_checks.csv`.

- **Assembly/cloning enzyme sites** (BsaI, BsmBI, BbsI, plus EcoRI/BamHI/HindIII/NcoI/NdeI/XbaI/SalI/PstI/KpnI/SacI, both strands): **zero hits across all 28 variants.** The enzyme-site finder was positive-control-tested (correctly finds all three Type IIS sites in a synthetic test string) before trusting this null result.
- **Spurious internal SigA promoters**: every variant scanned in full with the same extended-10 scoring matrix from §2, flagging any hit ≥55% of max *outside* the intended, constant core-promoter segment. **Zero spurious hits across all 28 variants** — positive-control-tested (correctly re-finds an embedded Psyn consensus planted mid-sequence) before trusting this null result too.
- **Secondary structure** (ViennaRNA `RNA.fold`, last 60 bp of each variant as a proxy for the 5′ region a downstream translational-tuning layer would sit in): Psyn- and PsodA-based variants fold weakly (dG -2.5 to -8.5 kcal/mol). **All 3 Ptuf-based variants flagged** at dG = -20.6 kcal/mol — but this value is *identical* across all of them (including the no-operator control), because it comes entirely from Ptuf's own native downstream sequence (the last 60 bp of its 174 bp validated fragment), which is constant regardless of what operator or gap sits upstream. This is a real property of the Ptuf fragment, not an artifact of operator engineering — flagged honestly rather than hidden, and a further reason (beyond the weak -35, §2) that Ptuf-based variants carry more risk than the Psyn/PsodA backbone of the panel. Caveat: for the short Psyn fragment (34 bp total), the 60 bp fold window is dominated by upstream filler/operator sequence rather than a true post-transcriptional 5′ region, since no reporter/RBS is appended yet — this check is a proxy, not a final answer, for any construct that short.
- **GC content** (host genome average 53.84%, computed exactly from the cached BX927147.1 FASTA in the earlier cross-talk analysis; ±15 points flagged): **17/28 variants flagged**, all Psyn-based (29.6-36.5% GC) — expected and not a design flaw: Psyn itself is a short, AT-rich synthetic promoter (built to match the AT-rich extended-10/-35 consensus), and the PhoP operator itself is AT-rich (matching a `GTTTA`-direct-repeat motif established in the earlier operator-scan analysis in this repo). PsodA- and Ptuf-based variants sit within range (41-47% GC).
- **Homopolymer runs >6 nt**: **zero** across all 28 variants.

---

## 5. Ranking by informativeness (Task 5)

Ranked in `designs/variants.csv` by a 4-tier scheme (`scripts/rank_panel.py`), **not** by predicted expression: tier 1 = load-bearing negative controls (nothing else is interpretable without them); tier 2 = the Psyn position-sweep backbone, ordered by **bisection** (gap=0 and gap=10 rank ahead of gap=5, which ranks ahead of gap=2/1, etc.) so that even a partially-completed panel readout already spans the full sweep rather than covering one end of it first; tier 3 = cross-validation on PsodA and the copy-number/context/operator-identity axes at the two most face-differentiated Psyn positions; tier 4 = remaining secondary variants.

**This panel does not cluster around a best guess.** Tier 2 alone spans **1.24 helical turns** on the strongest core, including three wrap-around positions *(Corrected 2026-08-23: originally "spans an entire helical turn"; at 0-10 bp it spanned 0.952 turns and did not close the circle.)*; tier 1 and the remaining negative controls (5 total: 3 no-operator, 2 scrambled) anchor every comparison; tier 3 deliberately repeats the position question on an independently-sourced, structurally different core (PsodA) rather than assuming the Psyn result generalizes.

### What this panel CAN distinguish
- Whether *any* tested position/core/copy-number combination produces detectable PhoP-dependent activation above the matched no-operator and scrambled-operator baselines — the core yes/no question this whole exercise exists to answer.
- Face-of-helix periodicity in operator positioning, if it exists and is large enough to see against construct-to-construct noise, on the strong core (full **14-point**, 13 bp, 1.24-turn sweep with three wrap-around comparisons) with a coarser cross-check on the weak core.
- Whether a strong core (Psyn, 286% Ptrc) shows more baseline leakiness (no-operator control) than a weak core (PsodA, 10.8%) — the dynamic-range/leakiness tradeoff the task named explicitly.
- Whether two tandem operator copies change output relative to one, at two positions.
- Whether retaining native upstream sequence changes output relative to a clean synthetic replacement, on two native cores.
- Whether the exact operator sequence (phoP-site vs. mgtA-site, 94% vs. 91% of PWM max) matters at a fixed position.

### What this panel CANNOT distinguish
- **Anything about the medium-strength range in fine detail**: with PgapA and P45 excluded (§2), there is a real gap between PsodA (10.8%) and Ptuf's caveated ~50% data point, and nothing confidently anchored between ~50% and 286%. A true strength gradient (as the task's "spanning the range" framing implies) is only 2.5 points wide with high confidence (PsodA, Psyn), not a smooth curve.
- **Whether a position effect, if seen, is specific to PhoP** or would appear for inserting any 16 bp sequence at that spacing — the scrambled control at one fixed position (gap=3, on 2 cores) partially addresses this, but the panel does not scramble-control *every* sweep position, so a position-dependent artifact unrelated to PhoP recognition specifically cannot be fully ruled out from this panel alone.
- **Absolute expression level in physically meaningful units** — this panel produces DNA sequences, not calibrated fluorescence data; a reporter fusion and the actual characterization campaign are what would generate that.
- **Anything about the reverse direction** (native *C. glutamicum* kinases phosphorylating the imported PhoP, or PhoP cross-reacting with native RRs) — out of scope for this panel, covered by the separate cross-talk analysis already in this repo.
- **Tandem-operator cooperativity mechanism** — the panel can show *whether* 2 copies differ from 1, not *why*, and the 2 bp inter-copy spacer used is an unvalidated placeholder (§3), so a null tandem result could reflect wrong spacing rather than absence of cooperativity.

### The single most likely failure mode

**[INFERENCE, reasoning named]**: the most likely failure mode is not wrong operator positioning — it is **complete transcriptional silence regardless of position**, mirroring the NarL/*B. subtilis* precedent exactly [EVIDENCE: Schmidl et al. 2019]. That failure would show as every operator-bearing variant reading indistinguishably from its matched no-operator and scrambled-operator controls, across every core promoter, every position, and both operator identities simultaneously. If that is what the panel shows, the correct conclusion is that the C. glutamicum RNAP holoenzyme (or whatever endogenous factor Class I/II bacterial activators require to make productive alpha-CTD or sigma-region-4 contact) cannot be engaged by this response regulator's activation surface at all — a finding about the protein-RNAP interface, not the promoter engineering, and one this panel is specifically built to surface rather than obscure with a single-design bet.

---

## 6. Outputs

```
designs/variants.fasta        28 variants, systematically named (core_operators_gapNN_context)
designs/variants.csv          rank, name, core, operator identity/copy number, gap, context, length, GC%, flags, rationale
designs/design_checks.csv     per-variant: enzyme sites, spurious-promoter hits, homopolymers, GC flag, fold dG/structure
designs/REPORT_promoter.md    this file
```

`results/REPORT.md` and every other existing path in this repo were checked before writing and were not touched.
