# Tier 2: the translational tuning layer for a two-tier inducible architecture in *C. glutamicum*

Panel designed: 2026-08-22. Reproduce with:

```bash
python3 scripts/fetch_translational_sources.py   # fetches + caches both papers, verifies sequences vs the genome
python3 scripts/design_translational_panel.py    # builds the panel, runs checks, writes the reduced factorial
```

Tags: **[EVIDENCE]** a citable source states it, cited inline. **[INFERENCE]** reasoning from evidence, reasoning step named. **[ESTIMATE]** a derived number, inputs shown. **[NOT FOUND]** searched and absent, with what was searched.

**This report does not claim the two-tier architecture will work.** It has not been demonstrated in any bacterial host. Everything below is the design of an experiment that finds out.

---

## 0. VERDICT (Task 1) — read this first

**Build the panel from Approach B: leaderless bicistronic design (BCD) fore-cistrons, Liu et al. 2023.** Approach A (cRBS / CLM-RDR) contributes **zero sequences and zero predicted values** to this panel.

### The training-host answer, stated explicitly

**CLM-RDR was trained in *Escherichia coli* BL21(DE3).** [EVIDENCE: Ding et al. 2020, *Nucleic Acids Res* 48:10602-10613, PMC7544201 — "*Escherichia coli* BL21 (DE3) cells containing the plasmid libraries were cultured to saturation…"; cloning in *E. coli* JM109; the FACS sub-libraries, the NGS, and every dynamic-range measurement are BL21(DE3).]

The strings **"Corynebacterium" and "glutamicum" appear zero times in the entire full text** [EVIDENCE: verbatim string count over the fetched PMC7544201 HTML, cached at `data/cache/literature/pmc7544201_ding2020_clmrdr.html`]. The paper's own transferability claim is bounded to its host: it reports "a certain degree of universality in predicting the dynamic ranges of biosensors **in *E. coli***" [EVIDENCE, direct quote], with accuracies of 72.2% / 61.1% / 50.0% on glucarate / arabinose / glycolate biosensors — the 50% figure being a five-class problem's coin-flip-grade tail.

So applying CLM-RDR here would indeed be an unvalidated cross-host transfer. **But that turned out not to be the binding objection.** Four further findings, each independently disqualifying:

**1. It does not predict translational strength.** It is a five-class classifier of the **dynamic range of a specific two-gene *E. coli* biosensor** (CdaR activator + sfGFP, induced with 20 g/L glucarate). [EVIDENCE: paper; and `conf/config.py` in the model repo sets `no_of_classes = 5`.] The class means are 13-, 29-, 53-, 106- and 247-fold dynamic range for sub-libraries I–V [EVIDENCE]. A "prediction" from this model is a bin of a CdaR/glucarate fold-change, not a translation rate — there is no rescaling that turns it into one.

**2. Our sequences cannot be fed to it.** The model's input is a single **50-nt string in a fixed *E. coli* scaffold** — `RBSm(25) ++ RBSn(25)`, where `RBSn = TAACCATGCATA-SDn-GACTT` (for *cdaR*) and `RBSm = TCTTAATCATG-SDm-GGTTTC` (for *sfgfp*). Only the two 8-nt SD windows vary (`SDn = NNGGAGNN`, `SDm = NNNGANNN`) — **16 degenerate nucleotides in total.** [EVIDENCE: scaffolds quoted in the paper; confirmed by decomposing the actual training rows in `data/train.csv` of the model repo, e.g. `TCTTAATCATG|AAGAGAAG|GGTTTC` + `TAACCATGCATA|ATGGAGTG|GACTT`, label `1`.] A 62-nt *C. glutamicum* fore-cistron is not representable in this input format at all. This is not a domain-shift problem; it is a type error.

**3. No trained model ships.** The repository at `github.com/YuDengLAB/CLM-RDR` contains 30 files and **zero weight/checkpoint files** (no `.h5`, `.ckpt`, `.pb`, `.pth`, `.pkl`, `.index`, `.meta`, `.hdf5`) [EVIDENCE: full recursive tree via the GitHub API, recorded in `data/cache/translational_sources.json`]. The README documents training, not loading: "put dataset in data folder … `python3 training.py` … results will be saved to `runs/`". Getting any number out of it requires retraining under its stated prerequisites, **TensorFlow-gpu 1.9.0 and Python 3.5 — both long end-of-life** [EVIDENCE: repo README].

**4. The host biology the model encodes is the wrong host's, in the exact features it uses.** Its features are literally base-composition frequencies (GC/A/T/C/G of the cRBS, plus GC of SDn and SDm) [EVIDENCE: paper]. Meanwhile:

| Host property | *C. glutamicum* | *E. coli* | Source |
|---|---|---|---|
| Genome GC | **53.84%** | **50.79%** | [EVIDENCE] computed from cached BX927147.1 and NC_000913.3 |
| 16S 3′ anti-SD tail | 3′-`UCUUUCCUCCACUAGGU`-5′ | 3′-`AUUCCUCCACUAGGUUG`-5′ | [EVIDENCE] extracted from the cached genomes (BX927147.1:76644-78167; NC_000913.3 *rrs*) |
| Leaderless transcripts | **32.9%** of mapped TSS (707/2147) | rare | [EVIDENCE] Pfeifer-Sancar 2013 Table S3, cached |

The two anti-SD tails share the `CCUCC` core but differ in the 3′-terminal extension (`…CCUCCUUUCU` vs `…CCUCCUUA`), which is the part that sets SD register and spacing preference. And a third of the host's transcripts do not use an SD at all — a mode the model has no representation of.

### Does Approach A have *any* role?

**The model: no. The concept: worth keeping, separately.** The genuinely good idea in Ding et al. is *cross*-RBS — co-tuning the **regulator's** RBS and the **output's** RBS as one paired element, because biosensor dynamic range is not monotone in either alone (they found maximum dynamic range at an *intermediate* translation level, not the highest [EVIDENCE]). That is directly relevant to a two-tier TCS design, where Sal_PhoP abundance and output abundance both matter, and it predicts something this panel will not see: **the best tier-2 element may not be the strongest one.** Adopting that idea costs nothing and requires none of the model. It is recorded here as a future axis (Sal_PhoP-side RBS × output-side element), **explicitly out of scope for this panel**, which tunes the output side only.

**Fewer data points in the right organism beat more in the wrong one** — and here the "more data points" are not even addressable data points.

---

## 1. Provenance of every sequence element used

Nothing in this panel is written from memory. Every base traces to a fetched record, and the fore-cistrons are additionally checked against the genome rather than trusted from the published table.

### 1.1 The source

[EVIDENCE] Liu X, Sun Y, Gao Y, Ledesma-Amaro R, Fang H, Yang Y, Bai Z. **"Leaderless Bicistronic Design for Precise and Reliable Control of Gene Expression in *Corynebacterium glutamicum*."** *ACS Synth Biol* 2023;12(7):2157-2167. doi:10.1021/acssynbio.3c00246, PMC10367133. Cached at `data/cache/literature/pmc10367133_liu2023_leaderless_bcd.html`. **Conducted in *C. glutamicum*.**

### 1.2 Genome verification of all 12 fore-cistrons [EVIDENCE]

Table 1's 12 sequences were parsed out of the fetched HTML table and each 62-mer located in the cached **BX927147.1** genome (both strands):

- **9 of 12 are exact 62/62 matches** to the genome.
- **3 differ by exactly one base each** — HP-1 (*groES*), HP-6 (NCgl2501), HP-8 (*eno*) — always at position 0, always native `G` → published `A`, i.e. **native start codon GTG → ATG**.

Those three differences are precisely what the paper documents: Table 1's footnote reads "*Red base represents mutation*" (colour is lost in HTML, so the footnote alone is uninterpretable), and the body text states "*the start codons of all of these 12 fore-cistron sequences were unified into AUG*" [EVIDENCE]. **The independent genome check is what converts an uninterpretable footnote into a known, understood, single-base edit.** Full record in `data/cache/translational_sources.json`.

### 1.3 The element grammar [EVIDENCE, with an arithmetic check]

```
[62 nt fore-cistron][AAAGGAGGACAAC][TA] | ATG <target ORF>
 \___ from a top-12 highly    /  \_ SD2 _/  \_ TAA overlaps the target's ATG _/
      expressed C. glut gene /
```

- **Fore-cistron**: "*The N-terminal 62 bp from the top 12 highly expressed genes in C. glutamicum*" [EVIDENCE].
- **SD2 = `AAAGGAGGACAAC`**: "*Each fore-cistron sequence includes a conserved SD sequence (AAAGGAGGACAAC) with a strong affinity for C. glutamicum 16S rRNA*" [EVIDENCE, verbatim]. Independently checked: this SD forms an **8 bp** exact duplex with the *C. glutamicum* 16S 3′ tail (`AAAGGAGG`:`CCUCCUUU`) versus **7 bp** with *E. coli*'s [EVIDENCE, computed from the two cached genomes] — i.e. the motif really is host-matched, not generic.
- **TAATG coupling**: "*The stop codon (TAA) in the terminus of the SD motif overlaps 1 bp with the start codon (ATG) of the EGFP to form the widely used translation coupling frame TAATG*" [EVIDENCE, verbatim].

**Arithmetic check [ESTIMATE→EVIDENCE]:** 62 + 13 = **75 nt = exactly 25 codons**, so the fore-cistron ORF's 26th codon is the `TAA` formed by the `TA` junction plus the target ATG's own `A`. Verified by translation for all 12: every one yields a clean 25-residue peptide ending `…KEDN` with **no internal stop codon**. The SD sits **8 nt upstream of the target ATG**, a canonical spacing. The frame is not asserted — it is computed, and the script refuses to emit an element that fails it.

### 1.4 What the published measurements actually are, and what is missing

- [EVIDENCE] The 12 BCDs span **313 to 3,813 fluorescence units = 1.27× to 15.44× the monocistronic P_H36**.
- [EVIDENCE] Ranking of the three group representatives, consistent across EGFP, VHH **and** LacZ: **HP-7 > HP-12 > HP-6**. HP-7 is also the benchmark the sorted library was scored against.
- **[NOT FOUND] Per-element values for the individual 12 are in Figure 1B, an image, and are not text-extractable.** Searched: the full PMC HTML body, the single HTML table (Table 1, which has no measurement column), and the supplementary link `sb3c00246_si_001.pdf` — the last returned an HTML interstitial rather than a PDF from this environment. So the panel carries **three ranked anchors and eight unranked elements**, and the CSV says so per row rather than inventing values.
- [EVIDENCE] The **55,901-fore-cistron library is a diversity census**, confirming the caution already established in this project: "*The 62 bp fore-cistron sequence was fully designed with random bases (indicated with N) except for the start codon ATG*". The paired sequence-and-measurement data is the 12 characterized elements plus 42 sorted clones (Table S4); per-clone values for those 42 are in Figure 5E, also an image. **[NOT FOUND]**

### 1.5 Is any predicted strength value a cross-host extrapolation?

**No — because this panel reports no predicted values at all.** Every strength entry in `designs/translational_variants.csv` is one of: a measured published value, a published rank, an explicit `NOT MEASURED`, or a mechanistically expected direction from the paper's own mutational analysis. Since CLM-RDR is not used, the cross-host-extrapolation flag Task 3 asks for **does not apply to any row**. That is the deliberate consequence of the Task 1 verdict, not an omission.

---

## 2. Architectural compatibility (Task 2) — the load-bearing question

### 2.1 Are the tier-1 core promoters leadered or leaderless?

Answered from **measured TSS data**, not inferred — Pfeifer-Sancar et al. 2013 (*BMC Genomics* 14:888) Table S3, already cached in this repo by the lysC work and re-queried here (`data/cache/tier1_leaderless_check.json`):

| Core | Locus | Mapped TSS | 5′-UTR lengths (nt) | Verdict |
|---|---|---|---|---|
| **PsodA** | cg3237 | 4 | **15, 26, 92, 94** | **LEADERED** [EVIDENCE] |
| **Ptuf** | cg0587 | 3 | **125, 151, 200** | **LEADERED** [EVIDENCE] |
| PgapA | cg1791 | 2 | 128, 183 | LEADERED [EVIDENCE] |
| **Psyn** | — | 0 | — | **[NOT FOUND]** — synthetic, not in the genome |

Genome-wide control on the same table: **707/2147 mapped TSS (32.9%) are leaderless** [EVIDENCE], confirming the ~one-third figure the task cites. So leaderless promoters are entirely normal in this host — but **none of the two mapped tier-1 cores is one.** Not one of the seven mapped TSSs across PsodA and Ptuf has a 5′-UTR of 0.

**Psyn is the interesting case.** It has no mapped TSS, but its position can be inferred: its extended −10 is a perfect-scoring `TGTGTTATAATGG` (100% of max), giving a −10 hexamer `TATAAT` at fragment index 23-28. Calibrating the −10→TSS offset on the one measured case in this repo (lysC: TSS − last base of −10 = **8 nt**) puts Psyn's TSS at index **36** — **3 nt past the 3′ end of the 34-nt fragment**. Across the plausible 5-9 nt spacing range the TSS lands at index 33-37, i.e. **an inferred 5′-UTR of 0-3 nt**. [INFERENCE, reasoning named; calibration from a single measured promoter, so treat the ±2 nt as real uncertainty.]

**Psyn is therefore plausibly near-leaderless as built, and is the one tier-1 core that may be directly compatible with leaderless BCD.** This is a prediction requiring 5′RACE confirmation — exactly the experiment Liu et al. ran on their own constructs [EVIDENCE: "*A 5′RACE experiment proved that all transcripts of these BCDs were leaderless*"].

### 2.2 Blocker, modification, or non-issue?

**A modification — not a blocker — and it is not free.** Three separable facts:

1. **BCD does not require a leaderless promoter.** The original bicistronic design is a *leadered* architecture: "*a short leader peptide coding sequence (fore-cistron) ended with a second RBS (SD2) inserted upstream of the target gene*", with an SD1 in the 5′UTR initiating the fore-cistron [EVIDENCE]. Leaderless BCD is Liu et al.'s *innovation*, not a prerequisite.
2. **The reason they went leaderless is precisely our problem.** "*Previous studies … have focused on canonical promoters containing a 5′UTR. A potential problem with the presence of 5′UTR is that different 5′UTR–fore-cistron junctions will form when combined with different promoters. This can cause undesirable variation in gene expression levels, thereby reducing the reusability of expression elements*" [EVIDENCE, verbatim]. Pairing these fore-cistrons with leadered PsodA/Ptuf reintroduces exactly the variability the source paper removed.
3. **Therefore the cost is the calibration, not the buildability.** All published values (313-3,813; 1.27-15.44×; the HP-7 > HP-12 > HP-6 rank) were measured on leaderless P_H36. Move the same elements into a leadered context and the architecture still works in principle, but **the numbers stop being anchors** — they become a hypothesis about a context nobody has measured.

**Costed options:**

| Option | What it costs | Verdict |
|---|---|---|
| **Use Psyn as the leaderless-BCD partner** | one 5′RACE experiment; possibly ±2-3 nt of junction trimming | **Recommended.** Preserves both tiers' published calibrations. |
| Conventional BCD on PsodA/Ptuf (add SD1) | forfeits the Liu calibration; reintroduces junction variability | Worth **2 constructs** as a probe, not an arm. Included as Block 3. |
| Truncate PsodA/Ptuf to leaderless | forfeits *their* published strengths (PsodA 10.8% of Ptrc etc.), and PsodA has 4 TSSs — going leaderless means choosing one and losing three | **Not recommended.** Breaks tier-1's calibration to save tier-2's. |

**Would cRBS have avoided this?** Yes — conventional SD-based RBSs work with leadered transcripts, which is what a cRBS is. That is the one genuine architectural advantage Approach A had, and it is not enough: the model still cannot accept our sequences, still predicts the wrong variable, and still ships no weights. Trading a *measured-in-host* element set for an *unrunnable out-of-host* model to avoid one 5′RACE experiment is a bad trade.

---

## 3. The panel (Task 3) — `designs/translational_variants.csv` / `.fasta`

**12 variants: 1 baseline + 8 functional BCD elements + 3 mechanism controls.** All 77 nt (62 + 13 + 2) except the baseline.

| # | Name | Element | Strength basis |
|---|---|---|---|
| 1 | `T2_MCD_ctrl` | none (direct ATG fusion) | **1.00× by definition** — the denominator [EVIDENCE] |
| 2 | `T2_BCD_HP07_gpmA` | HP-7 / NCgl0390 | **HIGH ANCHOR**, rank 1 of 3 [EVIDENCE]; 3,813 units / 15.44× [INFERENCE] |
| 3 | `T2_BCD_HP12_NCgl2826` | HP-12 / NCgl2826 | **MID ANCHOR**, rank 2 of 3 [EVIDENCE]; value NOT MEASURED |
| 4 | `T2_BCD_HP06_NCgl2501` | HP-6 / NCgl2501 | **LOW ANCHOR**, rank 3 of 3 [EVIDENCE]; panel min 313 units / 1.27× |
| 5-9 | `HP01_groES`, `HP02_ndk`, `HP08_eno`, `HP09_clpP`, `HP10_adk` | 5 unranked elements | NOT MEASURED individually; inside the published 313-3,813 range |
| 10 | `T2_BCD_HP07_fcATGtoATC_NEG` | HP-7, fore-cistron AUG→AUC | **NEGATIVE CONTROL** [EVIDENCE, the paper's own disabling mutation] |
| 11 | `T2_BCD_HP07_SDmut_NEG` | HP-7, SD core GGAGG→CCTCC | **NEGATIVE CONTROL** [EVIDENCE for the requirement; **[INFERENCE] the specific substitution is ours**] |
| 12 | `T2_BCD_HP07_fcATGtoGTG_PARTIAL` | HP-7, fore-cistron AUG→GUG | **GRADED CONTROL** [EVIDENCE: attenuates *less* than other start mutations] |

**Anchoring.** The task asked for the strongest and weakest characterized elements. HP-7 is the strongest with [EVIDENCE] behind it. For the weak end, honesty requires a distinction: **HP-6 is the *low-group representative*, confirmed weakest of the three tested — it is *not* established to be the weakest of all 12**, because the per-element values are in an image. The panel min (313 units / 1.27×) belongs to *some* element among the 12; attributing it to HP-6 specifically would be a guess, so the CSV does not.

**On "span the range, do not cluster."** The panel spans by *anchoring on measured ranks* and adding diversity, and it must be said plainly that **the eight unranked elements' positions on the strength axis are unknown**. There is no validated predictor of fore-cistron strength, and the obvious candidate fails on this dataset: folding energy does not reproduce the one known ranking — HP-12 is the *least*-structured element of all twelve (ΔG = −8.7) yet ranks only *intermediate*, while HP-7 (−12.4) is strongest. [EVIDENCE, computed.] Structure is therefore used **only as a defect screen, never as a rank predictor**. Where each unranked element lands is an experimental result of this panel, not a design input.

### 3.1 Design checks (Task 5)

Same standard and same enzyme list as the tier-1 panel. Per-variant results in the CSV `flags` column.

- **Type IIS assembly sites (BsaI, BsmBI, BbsI): zero hits across all 12 variants, both strands.** Golden Gate is clean.
- **Standard cloning sites: one real conflict and one exclusion.**
  - **HP-6 carries a BamHI site (`GGATCC`@44).** HP-6 is a *required calibration anchor*, and **the site cannot be removed without altering the published element and voiding its rank** — so it is retained and flagged, and the assembly method must avoid BamHI. This tension is stated rather than resolved by silently mutating the anchor.
  - **HP-4 (*tpx*) was EXCLUDED** for an internal **NcoI** site (`CCATGG`@7) — NcoI is the cloning enzyme of the tier-1 source vector pECXT99A. [EVIDENCE, computed.]
  - HP-11 was excluded for an internal SD-like `GGAG`@6 (spurious internal initiation risk); HP-3 and HP-5 were not selected as compositionally redundant, **with no defect found**. All exclusions are printed by the script, not silently dropped.
- **Fore-cistron ORF integrity: all 12 clean** — 75 nt = 25 codons, no internal stop, TAATG frame verified by translation.
- **Spurious internal initiation:** no SD-like motif followed by an ATG at initiation-plausible spacing in any retained element.
- **GC content:** 44.2-57.1%, all within ±15 points of the host's 53.84% [EVIDENCE, computed from the cached genome]. **Zero GC flags** — notably better than the tier-1 promoter panel, where 17/28 variants flagged.
- **Homopolymer runs > 6 nt: zero** across all 12.
- **Secondary structure (ViennaRNA 2.7.2):** element-alone ΔG from **−8.7** (HP-12) to **−22.2** (HP-6) kcal/mol.
- **TAATG coupling-frame compatibility: verified for every variant**, including all three mutants (none introduces a stop or a frameshift; the SD mutant preserves the 25-codon frame).

---

## 4. Combinatorial budget (Task 4) — `designs/combinatorial_design.csv`

### 4.1 The full space does not fit — plainly

**A note on the tier-1 count.** The task states tier 1 occupies 31-33 constructs; `designs/variants.csv` currently holds **28**. The gap is consistent with the 3-construct helical-turn extension recommended in this repo's spacing audit (28 + 3 = 31). Budget arithmetic below is given for both, and **the conclusion is identical either way.**

| tier 1 | tier 2 | Full factorial | + SK junctions | Total |
|---|---|---|---|---|
| 28 | 12 | 336 | +10 | **346** |
| 31 | 12 | 372 | +10 | **382** |
| 33 | 12 | 396 | +30 | **426** |

**The envelope is 48-96. The full cross overruns it by roughly 4-9×.** Even the most generous trim — 8 tier-2 variants against 31 promoters — is 248 + SK, still ~3× over. There is no version of the full factorial that fits.

### 4.2 The reduced factorial: **19 new constructs**

The design exploits one structural fact: **the tier-1 constructs already end immediately before the target ATG, so they *are* the monocistronic (MCD) column of the factorial.** Only non-MCD cells cost new constructs.

| Block | Design | Cells | New constructs |
|---|---|---|---|
| **1. Independence test** | 3 promoters × 4 translational states (MCD, HP-6, HP-12, HP-7) | 12 | **9** |
| **2. Tuning curve** | reference promoter × the other 8 tier-2 variants | 8 | **8** |
| **3. Leadered probe** | PsodA(gap=3) × {MCD, HP-7, HP-6} | 3 | **2** |
| | | **23** | **19** |

**Promoter selection, and why these three** [EVIDENCE from the tier-1 report]:
- `Psyn_1x_opA_gap03_repl` — **reference.** gap=3 is tier-1's own cross-core reference position (used for the Psyn scrambled control, both Ptuf variants, and the PsodA retained/scrambled/2× variants), so tier-2 numbers anchored here are comparable to the widest set of existing constructs.
- `Psyn_1x_opA_gap00_repl` and `Psyn_1x_opA_gap05_repl` — helical phases **0°** and **~171°** (opposite faces). These are not our choice: the tier-1 report already designates them "*the two most face-differentiated Psyn positions*" and built its own cross-validation axes there.
- All three are Psyn, per the Task 2 verdict that Psyn is the one plausibly leaderless-compatible core.

**Fit:**

| tier 1 | SK | + 19 | Total | |
|---|---|---|---|---|
| 28 | 10 | | **57** | fits 48-96 |
| 31 | 10 | | **60** | fits |
| 31 | 20 | | **70** | fits |
| 33 | 30 | | **82** | fits |

**It fits in every scenario, including the worst case.** Coverage: 23 of 372 cells = **6.2%** of the full space for 19 new constructs.

### 4.3 The independence test, concretely

The question is whether output is **multiplicative** — `output ≈ f(promoter) × g(element)` — because if it is, the tiers can be characterized separately and combined on paper, and the campaign never has to pay for a full cross again.

**Analysis:** two-way ANOVA on **log** output over the 3×4 grid (multiplicative independence = additive in log), with a 4-df interaction term, run **twice — once on the induced state and once on the uninduced state.**

Running it on both states is the point, not a detail:

- If `log(ON)` **and** `log(OFF)` are both additive **with the same tier-2 coefficient**, then tier 2 is a pure gain: it moves absolute expression and **leaves ON/OFF — the dynamic range — unchanged.**
- Tier 2 only earns its place if its coefficient **differs between ON and OFF**. That difference *is* dynamic-range tuning.

**A sequencing recommendation:** the three promoters should ideally be chosen by *measured* tier-1 output — strongest / mid / leakiest — once tier 1 reads out, rather than by designed helical phase. The committed choice above is what to build if the two tiers must be ordered together; splitting the campaign makes the 3×3 strictly more informative at no extra construct cost.

### 4.4 What the reduced design can and cannot distinguish

**Can:**
- Whether tier 1 and tier 2 combine multiplicatively, for absolute output and for leakiness **separately** (the 3×4 grid, 4 df of interaction).
- Whether tier 2 tunes **dynamic range** at all, or only rescales both states (§4.3).
- The shape of the tier-2 tuning curve across 8 elements plus a mechanistic floor, at one fixed tier-1 context.
- Whether the BCD mechanism operates at all in this construct (the three controls) — and via the graded AUG→GUG point, whether it fails sharply or smoothly.
- Whether a leadered core behaves differently (2-construct probe, Block 3).

**Cannot:**
- **Interaction with core-promoter identity.** Blocks 1-2 are entirely within Psyn. Block 3's PsodA probe is 2 constructs and is *confounded*: it changes the core **and** requires the conventional-BCD SD1 modification, so a difference there cannot be attributed to either cause alone. It is a flag, not a measurement.
- **Where the 8 unranked elements sit on any promoter but the reference.** Their crossing behaviour is assumed, not tested.
- **Any tier-2 × sensor-kinase-junction interaction.** Completely untested — the SK panel is not crossed with anything here. If the chimeric junction affects Sal_PhoP phosphorylation kinetics, that interaction is invisible to this design.
- **Non-monotone interaction surfaces.** 4 df across 3 levels detects a monotone interaction; a curved or threshold surface would likely read as noise.
- **Operator identity (opB) and copy-number (2×) axes crossed with tier 2** — not tested at all.
- Nothing here counts biological replicates; those are measurement cost, not construct cost, but the ANOVA needs them.

### 4.5 A design-check finding on the crosses

Folding the actual tier-1|tier-2 junctions (tier-1 3′ 40 nt + element + target ATG) gives ΔG from **−4.4 to −34.7 kcal/mol**. Two things are worth stating precisely.

**The tier-2 element dominates the junction, not the promoter.** The four MCD cells are by far the least structured (−4.4 to −6.8); every cell carrying a BCD element is more structured than every cell without one. That is expected — the element adds 77 nt of real coding sequence — but it means **13 of 23 cells (a majority) breach the −20.6 kcal/mol bar** inherited from the tier-1 panel. Applied here that bar is close to non-discriminating, so it is recorded in the CSV as a comparative signal, not a pass/fail gate.

**Structure again fails to track strength.** HP-6 (the low anchor) does give the most structured junction against every promoter tested — 4/4 flagged, and the three worst absolute values. But **HP-7, the *strongest* element, is flagged in 3 of its 4 cells too.** So a structured junction is not a marker of a weak element, and the §3 conclusion holds at the junction level as well: **folding energy is a defect screen, not a rank predictor**, and nothing in this panel should be reordered on the basis of ΔG.

What survives as a real caution is narrower: HP-6 is simultaneously the low anchor and the structural extreme (−22.2 alone, −34.7 at the junction). Its low output *may* be a secondary-structure effect rather than a fore-cistron-efficiency effect, and a strongly structured junction is one concrete mechanism by which tier 2 could behave **non**-multiplicatively. That makes HP-6's row in Block 1 the single most informative cell for the interaction question — and the one most likely to be misread if ΔG is ignored.

---

## 5. The single most likely failure mode

**Tier 2 will act as a pure multiplicative gain — scaling the ON and OFF states by the same factor — and therefore will not change dynamic range at all.** [INFERENCE, reasoning named.]

The reasoning: every published tier-2 number is a *fold-change over monocistronic* (1.27-15.44×), measured on a constitutive promoter with no ON/OFF states to distinguish. A translational element that multiplies ribosome loading multiplies whatever mRNA is present. If tier 1 comes out leaky — the exact scenario tier 2 exists to compensate — then a 15× element gives 15× more product **and** 15× more leak, and ON/OFF is unchanged. Tier 2 would then be a useful absolute-expression knob and a **complete non-solution to the problem it was added to solve**.

This is not a reason to skip the panel — it is the reason the panel is built as a factorial rather than a strength ladder. §4.3's paired ON/OFF ANOVA is designed to detect exactly this, and Block 1 is the minimum experiment that can. **If tier 2's log-coefficient is the same in the induced and uninduced states, the two-tier premise is falsified for this element class**, cheaply, before any full cross is paid for.

Two further modes, ranked:

2. **The leadered-junction failure.** If Psyn's TSS does not fall where §2.1 infers (an inference calibrated on a *single* measured promoter), the tier-1|tier-2 junction produces a short 5′UTR instead of a leaderless transcript, the fore-cistron loses leaderless initiation, and the published anchors stop applying. Detected by 5′RACE — which should be run **before** the 19 constructs are committed, not after.

3. **Total transcriptional silence, inherited from tier 1.** The tier-1 report already names this as its own most likely failure (the Ec_NarL/*B. subtilis* precedent). If tier 1 is silent, every tier-2 variant reads at the floor, and this panel returns no information about tier 2 whatsoever. Tier 2 cannot rescue a promoter that does not fire — **there is no mRNA to translate.** The MCD baseline and the three mechanism controls are what let that be diagnosed in one glance rather than misread as tier-2 failure.

---

## 6. Files written

| Path | Contents |
|---|---|
| `designs/translational_variants.fasta` | 11 tier-2 element sequences (the MCD control has no sequence by definition) |
| `designs/translational_variants.csv` | name, approach, source element, measured/ranked strength, provenance, flags, rationale, sequence |
| `designs/combinatorial_design.csv` | the 23-cell reduced factorial; which promoter crosses which element, junction ΔG, what is new vs already built |
| `designs/REPORT_translational.md` | this report |
| `scripts/fetch_translational_sources.py` | fetches + caches both papers; verifies all 12 fore-cistrons against BX927147.1; probes the CLM-RDR repo |
| `scripts/design_translational_panel.py` | builds the panel, runs every design check, determines leadered/leaderless, writes the factorial |
| `data/cache/literature/pmc7544201_ding2020_clmrdr.html` | Ding et al. 2020 full text (Approach A) |
| `data/cache/literature/pmc10367133_liu2023_leaderless_bcd.html` | Liu et al. 2023 full text (Approach B) |
| `data/cache/translational_sources.json` | structured provenance: quotes, genome-verification results, CLM-RDR repo audit |
| `data/cache/tier1_leaderless_check.json` | the leadered/leaderless determination from Pfeifer-Sancar Table S3 |

No pre-existing file was modified.
