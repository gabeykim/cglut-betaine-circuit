#!/usr/bin/env python3
"""Single entry point: Pfam domain annotation + TM prediction + H-box location.

    python3 run_domain_annotation.py

Runs entirely from cached data once data/fasta/ and data/cache/pfam/ are
populated; the first run fetches and caches them. Writes:
    data/domains_manifest.csv
    results/domain_boundaries.csv
    results/tm_predictions.csv
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
from domain_annotation import (TARGETS, MODELS, MODEL_NAME, HISKA_FAMILY, DATA, RESULTS,
                               ensure_inputs, build_db, run_hmmscan, parse_alignments,
                               residue_to_hmm_column, hmm_column_to_residue,
                               kyte_doolittle_tm, KD_WINDOW, KD_THRESHOLD)

# Experimentally confirmed phosphohistidines used to calibrate the H-box column.
# UniProt "Phosphohistidine; by autocatalysis", evidence ECO:0000269 (experimental).
HBOX_REFERENCE = {"P0AEJ4": 243, "P0DM80": 277}
HBOX_PRIMARY = "P0AEJ4"     # E. coli EnvZ -- the calibration reference named in the report


def main():
    seqs = ensure_inputs()
    db = build_db()
    print("\nRunning hmmscan (HMMER 3.4) against the 7-model database...")
    hits, aln_path = run_hmmscan(db, seqs)
    alns = parse_alignments(aln_path)
    print(f"  {len(hits)} domain hits, {len(alns)} alignments parsed")

    # ---------------------------------------------------------------- manifest
    DATA.mkdir(exist_ok=True)
    with open(DATA / "domains_manifest.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["requested_accession", "accession_used", "organism", "protein_name",
                    "length_aa", "retrieval_date", "source_url", "resolution_note"])
        for req, acc, org, note in TARGETS:
            s, hdr, dt = seqs[acc]
            name = hdr.split(" ", 1)[1].split(" OS=")[0] if " " in hdr else hdr
            w.writerow([req, acc, org, name, len(s), dt,
                        f"https://rest.uniprot.org/uniprotkb/{acc}.fasta", note])
    print(f"Wrote data/domains_manifest.csv ({len(TARGETS)} rows)")

    # ------------------------------------------------------- H-box calibration
    ref_col = None
    for a in alns:
        if a["accession"] == HBOX_PRIMARY and a["model"] in HISKA_FAMILY:
            ref_col = residue_to_hmm_column(a, HBOX_REFERENCE[HBOX_PRIMARY])
            ref_model = a["model"]
            break
    print(f"\nH-box calibration: {HBOX_PRIMARY} His{HBOX_REFERENCE[HBOX_PRIMARY]} "
          f"-> {ref_model} match-state column {ref_col}")
    for acc, pos in HBOX_REFERENCE.items():
        for a in alns:
            if a["accession"] == acc and a["model"] in HISKA_FAMILY:
                got = hmm_column_to_residue(a, ref_col)
                agree = (got[0] == pos and got[1] == "H")
                print(f"  cross-check {acc}: column {ref_col} -> {got[1]}{got[0]}  "
                      f"(UniProt experimental: His{pos})  {'AGREE' if agree else 'DISAGREE'}")
                break

    # ------------------------------------------------------------- boundaries
    by_acc = defaultdict(list)
    for h in hits:
        by_acc[h["accession"]].append(h)
    overlaps = []
    rows = []
    for req, acc, org, _n in TARGETS:
        hs = sorted(by_acc[acc], key=lambda r: -r["dom_bitscore"])
        for h in hs:
            # competing models over the same region?
            comp = [o["model"] for o in hs if o is not h
                    and not (o["end"] < h["start"] or o["start"] > h["end"])]
            if comp:
                overlaps.append((acc, h["model"], comp, h["dom_bitscore"]))
            hbox = hbox_res = ""
            if h["model"] in HISKA_FAMILY and ref_col is not None:
                for a in alns:
                    if a["accession"] == acc and a["model"] == h["model"] \
                            and a["ali_from"] >= h["start"] - 2:
                        p, r = hmm_column_to_residue(a, ref_col)
                        if p:
                            hbox, hbox_res = p, r
                        break
            weak = h["i_evalue"] >= 1e-3
            conf = "HIGH" if (h["i_evalue"] < 1e-10 and not comp) else \
                   ("LOW" if weak else "MEDIUM")
            reason = ("i-E < 1e-10, single unambiguous model" if conf == "HIGH" else
                      (f"competing model(s) over the same region: {','.join(comp)}" if comp
                       else f"weak hit, i-E = {h['i_evalue']:.2g}"))
            rows.append({
                "requested_accession": req, "accession": acc, "organism": org,
                "model": h["model"], "model_acc": h["model_acc"],
                "start": h["start"], "end": h["end"], "length": h["end"] - h["start"] + 1,
                "bit_score": h["dom_bitscore"], "i_evalue": h["i_evalue"],
                "hmm_from": h["hmm_from"], "hmm_to": h["hmm_to"],
                "hbox_his_position": hbox, "hbox_residue": hbox_res,
                "method": "hmmscan HMMER 3.4 vs Pfam PF02743/PF00672/PF00512/PF07568/PF07730/PF02518/PF00072",
                "confidence": conf, "confidence_reason": reason,
                "competing_models": ",".join(comp) if comp else "",
            })
    RESULTS.mkdir(exist_ok=True)
    cols = list(rows[0].keys())
    with open(RESULTS / "domain_boundaries.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
    print(f"\nWrote results/domain_boundaries.csv ({len(rows)} domain hits)")

    # ---------------------------------------------------------------- TM
    tm_rows = []
    for req, acc, org, _n in TARGETS:
        s = seqs[acc][0]
        hel, topo = kyte_doolittle_tm(s)
        for i, h in enumerate(hel, 1):
            tm_rows.append({
                "requested_accession": req, "accession": acc, "organism": org,
                "feature": f"TM{i}", "start": h["start"], "end": h["end"],
                "length": h["end"] - h["start"] + 1, "peak_kd_score": h["peak_kd"],
                "tool": "NONE AVAILABLE - Kyte-Doolittle fallback",
                "method": f"Kyte-Doolittle hydropathy, window {KD_WINDOW}, threshold {KD_THRESHOLD}",
                "confidence": "LOW",
                "note": "no trained TM predictor installed; boundaries approximate",
            })
        for t in topo:
            tm_rows.append({
                "requested_accession": req, "accession": acc, "organism": org,
                "feature": t["region"], "start": t["start"], "end": t["end"],
                "length": t["end"] - t["start"] + 1, "peak_kd_score": "",
                "tool": "NONE AVAILABLE - positive-inside rule",
                "method": f"von Heijne positive-inside rule; K+R fraction = {t['kr_frac']}",
                "confidence": "LOW", "note": f"predicted {t['side']}",
            })
        if not hel:
            tm_rows.append({
                "requested_accession": req, "accession": acc, "organism": org,
                "feature": "none", "start": "", "end": "", "length": 0, "peak_kd_score": "",
                "tool": "NONE AVAILABLE - Kyte-Doolittle fallback",
                "method": f"Kyte-Doolittle hydropathy, window {KD_WINDOW}, threshold {KD_THRESHOLD}",
                "confidence": "LOW", "note": "NO TM HELIX PREDICTED (soluble protein expected)",
            })
    with open(RESULTS / "tm_predictions.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(tm_rows[0].keys()))
        w.writeheader(); w.writerows(tm_rows)
    ntm = sum(1 for r in tm_rows if r["feature"].startswith("TM"))
    print(f"Wrote results/tm_predictions.csv ({ntm} TM helices, {len(tm_rows)} rows)")

    # ------------------------------------------------------------- summaries
    print("\n" + "=" * 74)
    print("MISSING EXPECTED DOMAINS (called out, not left as a table absence)")
    print("=" * 74)
    got = {a: {h["model"] for h in by_acc[a]} for _r, a, _o, _n in TARGETS}
    expect = {"P0DM80": {"HAMP", "HisKA", "HATPase_c"}, "P0AEJ4": {"HAMP", "HisKA", "HATPase_c"},
              "P0DM78": {"Response_reg"}, "P0AA16": {"Response_reg"},
              "Q9HVF8": {"dCache_1", "HAMP"}, "Q6D515": {"dCache_1", "HAMP"},
              "Q92SH9": {"dCache_1", "HAMP"}}
    for acc, exp in expect.items():
        miss = exp - got.get(acc, set())
        print(f"  {acc}: {'none missing' if not miss else 'MISSING ' + ', '.join(sorted(miss))}"
              f"   (found: {', '.join(sorted(got.get(acc, set()))) or 'NOTHING'})")
    print("\n" + "=" * 74)
    print("HisKA-family hits WITHOUT an identifiable H-box histidine")
    print("=" * 74)
    any_missing = False
    for r in rows:
        if r["model"] in HISKA_FAMILY:
            ok = r["hbox_residue"] == "H"
            print(f"  {r['accession']:8} {r['model']:10} H-box = "
                  f"{(r['hbox_residue'] + str(r['hbox_his_position'])) if ok else 'NOT IDENTIFIABLE'}")
            any_missing |= not ok
    if not any_missing:
        print("  -> every HisKA-family hit has an identifiable H-box histidine")
    print("\n" + "=" * 74)
    print("COMPETING MODELS OVER THE SAME REGION")
    print("=" * 74)
    if overlaps:
        for acc, m, comp, sc in overlaps:
            print(f"  {acc}: {m} (score {sc}) overlaps {comp}")
    else:
        print("  none")
    print("\n" + "=" * 74)
    print("MEDIUM / LOW CONFIDENCE BOUNDARIES")
    print("=" * 74)
    for r in rows:
        if r["confidence"] != "HIGH":
            print(f"  [{r['confidence']}] {r['accession']:8} {r['model']:12} "
                  f"{r['start']}-{r['end']}  {r['confidence_reason']}")
    return rows, tm_rows


if __name__ == "__main__":
    main()
