#!/usr/bin/env python3
"""Revision of the junction panel (v2).

Two changes to v1, nothing redesigned from scratch:
  1. RECENTRE each register triplet on its computed in-phase point, so the
     triplet spans delta=0 instead of sitting entirely off it.
  2. RENAME strategy B -> linker_retained and D -> dhp_direct, in the files.

Recentring rule, applied mechanically:
  * search |shift| <= 3 -- one heptad period. delta cycles mod 7, so where the
    phase mapping is locally linear a delta=0 always exists inside that window;
    needing more than 3 means the local mapping is NOT linear and the "centre"
    would be an artefact of a distant, differently-phased window.
  * the new nominal must stay inside the strategy's intended structural element.
  * for dhp_direct the H-box histidine must survive the truncation.
A triplet failing any of these is LEFT AS IT WAS and reported, not forced.

    python3 run_junction_design_v2.py

Writes designs/junctions_v2.csv, designs/junctions_v2.fasta,
designs/junctions_rename_map.csv. Never touches the v1 files.
"""
import csv, re, sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import junction_design as J
from siga_consensus import EXT10_PWM, score_window, max_score

STOP, EXT10_THRESH, MAX_SHIFT = "TAA", 0.55, 3
OFFSETS = [(-1, "m1"), (0, "0"), (+1, "p1")]

# strategy renaming: old label -> new label
RENAME = {"A": "A", "B": "linker_retained", "C": "C", "D": "dhp_direct"}
CONTAINS = {
    "A": "hybrid TM2 (sensor first half + acceptor second half); acceptor HAMP RETAINED",
    "linker_retained": "sensor TM2 intact; acceptor resumes past its HAMP, so NO HAMP is "
                       "present, but the HAMP-to-DHp linker IS retained",
    "C": "hybrid TM2 + 5-residue GSGSG linker; acceptor HAMP RETAINED",
    "dhp_direct": "sensor TM2 intact; acceptor resumes at the DHp proper, so NO HAMP and "
                  "NO HAMP-to-DHp linker",
}
HBOX = {"P0DM80": 277, "P0AEJ4": 243}

# (sensor tag, sensor acc, acceptor tag, acceptor acc, old strategy, s_end, old nominal, linker)
TRIPLETS = [
    ("ECA",  "WP_043878053.1", "PHOQ", "P0DM80", "A", 328, 206, ""),
    ("ECA",  "WP_043878053.1", "PHOQ", "P0DM80", "B", 338, 264, ""),
    ("ECA",  "WP_043878053.1", "PHOQ", "P0DM80", "C", 328, 206, J.LINKER_C),
    ("ECA",  "WP_043878053.1", "PHOQ", "P0DM80", "D", 338, 268, ""),
    ("MCPX", "Q92SH9",         "PHOQ", "P0DM80", "A", 328, 206, ""),
    ("MCPX", "Q92SH9",         "PHOQ", "P0DM80", "D", 338, 268, ""),
    ("ECA",  "WP_043878053.1", "ENVZ", "P0AEJ4", "A", 328, 170, ""),
    ("ECA",  "WP_043878053.1", "ENVZ", "P0AEJ4", "D", 338, 234, ""),
]
PANEL = {("ECA", "PHOQ"): "core_primary", ("MCPX", "PHOQ"): "core_second_sensor",
         ("ECA", "ENVZ"): "alt_backbone"}
# intended structural element on the acceptor side, per (acceptor, new strategy)
ELEMENT = {
    ("PHOQ", "A"): ("acceptor TM2", 195, 215), ("PHOQ", "C"): ("acceptor TM2", 195, 215),
    ("PHOQ", "linker_retained"): ("HAMP->DHp linker", 264, 267),
    ("PHOQ", "dhp_direct"): ("DHp", 268, 327),
    ("ENVZ", "A"): ("acceptor TM2", 160, 178),
    ("ENVZ", "dhp_direct"): ("DHp (HisKA)", 234, 290),
}


def spurious_ext10(dna):
    w, mx = EXT10_PWM["width"], max_score(EXT10_PWM)
    return [(i, i + w, round(score_window(dna[i:i + w], EXT10_PWM) / mx, 3))
            for i in range(len(dna) - w + 1)
            if score_window(dna[i:i + w], EXT10_PWM) / mx >= EXT10_THRESH]


def spurious_sd(dna):
    out = []
    for m in re.finditer(r"GGAGG|AGGAG|GGAG", dna):
        for a in re.finditer(r"ATG", dna[m.end() + 3:m.end() + 15]):
            pos = m.end() + 3 + a.start()
            if pos:
                out.append((m.start(), pos + 3, f"SD({m.group(0)})@{m.start()}+ATG@{pos}"))
    return out


def recentre(prot, sacc, s_end, aacc, a0, link, elem, hbox):
    """Nearest in-phase acceptor start within MAX_SHIFT that keeps the join legal."""
    name, lo, hi = elem
    cands = []
    for sh in range(-MAX_SHIFT, MAX_SHIFT + 1):
        a = a0 + sh
        if not (lo <= a <= hi):
            continue
        if hbox and a > hbox:            # would delete the phosphoacceptor
            continue
        r = J.register_analysis(prot[sacc], s_end, prot[aacc], a, len(link))
        if r and r["delta"] == 0:
            cands.append((abs(sh), sh, a))
    if not cands:
        return None
    cands.sort()
    return cands[0][1], cands[0][2]


def build(enzymes, csv_path, fasta_path, rename_path, tag_note=""):
    """Shared builder. `enzymes` is the optimiser's CONSTRAINT set.

    v2 passes the 5-enzyme Golden Gate set explicitly, because it exists to
    reproduce a frozen artifact byte-for-byte. v4 passes None, which means the
    module default -- the full 35-enzyme catalogue.
    """
    bnd = J.load_boundaries()
    prot = {a: J.load_protein(a) for a in
            ["WP_043878053.1", "Q92SH9", "P0DM80", "P0AEJ4"]}
    meta, freq = J.load_codon_table()
    print(f"codon table: BX927147.1, {meta['n_cds_used']} CDS, {meta['n_codons']} codons, "
          f"CDS GC {meta['cds_gc_percent']}%  (repo-derived, not an external service)")

    rows, fasta, rename_rows, centring = [], [], [], []

    for stag, sacc, atag, aacc, old_strat, s_end, a0, link in TRIPLETS:
        new_strat = RENAME[old_strat]
        elem = ELEMENT[(atag, new_strat)]
        hbox = HBOX[aacc] if new_strat == "dhp_direct" else None
        res = recentre(prot, sacc, s_end, aacc, a0, link, elem, hbox)

        if res:
            shift, a_new = res
            centred, why = True, ""
        else:
            shift, a_new, centred = 0, a0, False
            # explain precisely why, by finding where delta=0 actually is
            found = []
            for a in range(a0 - 12, a0 + 14):
                r = J.register_analysis(prot[sacc], s_end, prot[aacc], a, len(link))
                if r and r["delta"] == 0:
                    inel = elem[1] <= a <= elem[2]
                    found.append((a, a - a0, inel))
            why = "; ".join(
                f"delta=0 at {a} (shift {d:+d}, {'in' if ie else 'OUTSIDE'} {elem[0]})"
                for a, d, ie in found) or "no delta=0 anywhere in +/-12"
        centring.append((stag, atag, old_strat, new_strat, a0, a_new, shift, centred, why, elem))

        for off, tag in OFFSETS:
            a_start = a_new + off
            sseq, aseq = prot[sacc], prot[aacc]
            protein = sseq[:s_end] + link + aseq[a_start - 1:]
            reg = J.register_analysis(sseq, s_end, aseq, a_start, len(link))
            jpos = s_end + len(link)
            phi = (s_end - 21 + 1 + J.best_phase(sseq[max(0, s_end - 21):s_end])[0]) % 7
            ad_frac = J.junction_ad_hydrophobicity(protein, jpos, phi)
            jnt = jpos * 3

            def junc_off(d, _j=jnt):
                bad = [(a, b) for a, b, _s in spurious_ext10(d) if a <= _j + 13 and b >= _j - 13]
                bad += [(a, b) for a, b, _l in spurious_sd(d) if a <= _j + 15 and b >= _j - 15]
                return bad

            lbl = f"{stag}/{atag}/{new_strat}{tag}"
            dna = J.optimise(protein, freq, enzymes=enzymes)
            clean = False
            for _ in range(12):
                dna, clean = J.repair_all(dna, protein, freq, enzymes=enzymes, label=lbl)
                if not junc_off(dna):
                    break
                dna = J.repair(dna, protein, freq, junc_off, enzymes=enzymes)
            dna, clean = J.repair_all(dna, protein, freq, enzymes=enzymes, label=lbl)
            if not clean:
                raise RuntimeError(
                    f"OPTIMISER FAILED to satisfy the constraint set for {lbl}. "
                    f"Remaining violations: {J._bad_spans(dna, enzymes)}. "
                    f"The fallback ladder is exhausted; this must not be emitted silently.")
            dna_full = dna + STOP

            # H-box position in this construct
            hb_native = HBOX[aacc]
            hb_pos = s_end + len(link) + (hb_native - a_start + 1) if a_start <= hb_native else None
            hb_res = protein[hb_pos - 1] if hb_pos and hb_pos <= len(protein) else None

            ext10, sd = spurious_ext10(dna_full), spurious_sd(dna_full)
            j_ext10 = [f"{a}({s})" for a, b, s in ext10 if a <= jnt + 13 and b >= jnt - 13]
            j_sd = [l for a, b, l in sd if a <= jnt + 15 and b >= jnt - 15]
            enz = J.forbidden_hits(dna_full)                 # Golden Gate subset, for the column
            cat = J.catalogue_hits(dna_full)                 # FULL 35, for the real screen
            homo, gc = J.homopolymers(dna_full), J.gc_pct(dna_full)

            flags = []
            if enz: flags.append("ENZYME:" + ",".join(enz))
            if cat and enzymes is None: flags.append("CATALOGUE:" + ",".join(cat))
            if homo: flags.append("HOMOPOLYMER:" + ",".join(homo))
            if abs(gc - J.HOST_GC) > J.GC_TOL: flags.append(f"GC_OUTLIER:{gc}")
            if j_ext10: flags.append("JUNCTION_SIGA:" + ",".join(j_ext10))
            if j_sd: flags.append("JUNCTION_SD:" + ";".join(j_sd))
            if hb_res != "H": flags.append("HBOX_MISSING")
            if reg and not reg["in_phase"]: flags.append(f"REGISTER_BREAK:{reg['delta']:+d}")
            if not centred: flags.append("TRIPLET_NOT_RECENTRED")

            old_id = f"JXN_{stag}_{atag}_{old_strat}{tag}"
            new_id = f"JXN_{stag}_{atag}_{new_strat}_{tag}"
            rename_rows.append({
                "old_design_id": old_id, "new_design_id": new_id,
                "old_strategy": old_strat, "new_strategy": new_strat,
                "old_acceptor_first_residue": a0 + off,
                "new_acceptor_first_residue": a_start,
                "nominal_shift_applied": shift,
                "triplet_recentred": "YES" if centred else "NO",
            })
            rows.append({
                "design_id": new_id, "previous_design_id": old_id,
                "panel": PANEL[(stag, atag)], "strategy": new_strat,
                "previous_strategy": old_strat, "strategy_contains": CONTAINS[new_strat],
                "register_offset": off,
                "sensor_accession": sacc, "sensor_last_residue": s_end,
                "sensor_element": J.element_at(bnd, sacc, s_end),
                "acceptor_accession": aacc, "acceptor_first_residue": a_start,
                "acceptor_element": J.element_at(bnd, aacc, a_start),
                "intended_element": elem[0],
                "nominal_old": a0, "nominal_new": a_new, "nominal_shift": shift,
                "triplet_recentred": "YES" if centred else "NO",
                "linker": link or "none", "linker_len": len(link),
                "protein_len": len(protein), "dna_len": len(dna_full),
                "junction_protein_pos": jpos, "junction_nt_pos": jnt,
                "heptad_delta": "" if not reg else reg["delta"],
                "heptad_in_phase": "" if not reg else ("YES" if reg["in_phase"] else "NO"),
                "up_contrast": "" if not reg else reg["up_contrast"],
                "dn_contrast": "" if not reg else reg["dn_contrast"],
                "up_determinacy": "" if not reg else reg["up_determinacy"],
                "dn_determinacy": "" if not reg else reg["dn_determinacy"],
                "junction_ad_hydrophobic_frac": ad_frac,
                "hbox_native_residue": hb_native,
                "hbox_construct_position": hb_pos or "", "hbox_residue": hb_res or "",
                "gc_percent": gc,
                "golden_gate_sites": ",".join(enz) or "none",
                "homopolymer_gt6": ",".join(homo) or "none",
                "spurious_sigA_ext10_total": len(ext10),
                "spurious_sigA_at_junction": ",".join(j_ext10) or "none",
                "spurious_SD_ATG_total": len(sd),
                "spurious_SD_at_junction": ";".join(j_sd) or "none",
                "flags": " | ".join(flags) or "none",
                "protein_seq": protein,
            })
            # the full-catalogue column is emitted only when the optimiser actually
            # constrained against the full catalogue; v2's column set stays frozen.
            if enzymes is None:
                rows[-1]["catalogue_sites_35"] = ",".join(cat) or "none"
            fasta.append((new_id, PANEL[(stag, atag)], new_strat, off, len(protein), gc, dna_full))

    # ------------------------------------------------------------------ write
    cols = [c for c in rows[0] if c != "protein_seq"] + ["protein_seq"]
    with open(csv_path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
    with open(fasta_path, "w") as fh:
        for nid, pan, st, off, plen, gc, dna in fasta:
            fh.write(f">{nid} panel={pan} strategy={st} register_offset={off:+d} "
                     f"protein_aa={plen} dna_nt={len(dna)} GC={gc}\n")
            for i in range(0, len(dna), 60):
                fh.write(dna[i:i + 60] + "\n")
    if rename_path is not None:
        with open(rename_path, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rename_rows[0].keys()))
            w.writeheader(); w.writerows(rename_rows)

    def head(t): print("\n" + "=" * 78 + f"\n{t}\n" + "=" * 78)

    head("RECENTRING PER TRIPLET")
    for stag, atag, olds, news, a0, anew, sh, ok, why, elem in centring:
        ds = [next(r["heptad_delta"] for r in rows
                   if r["design_id"] == f"JXN_{stag}_{atag}_{news}_{t}") for _o, t in OFFSETS]
        status = f"shift {sh:+d}" if ok else "NOT RECENTRED"
        print(f"  {stag}/{atag}/{olds}->{news:16} old {a0} -> new {anew}  {status:14} "
              f"deltas(-1/0/+1) = {ds[0]:+d}/{ds[1]:+d}/{ds[2]:+d}")
        if not ok:
            print(f"      reason: {why}")

    head("CHECKS ON THE REVISED SET")
    dnas = [f[-1] for f in fasta]; prots = [r["protein_seq"] for r in rows]
    print(f"  designs                                     : {len(rows)}")
    print(f"  optimiser constraint set                    : "
          f"{len(J.CONSTRAINT_ENZYMES) if enzymes is None else len(enzymes)} enzymes{tag_note}")
    print(f"  Golden Gate sites (BsaI/BsmBI/BbsI/SapI/AarI): "
          f"{sum(1 for r in rows if r['golden_gate_sites'] != 'none')}")
    if enzymes is None:
        _cs = [r.get("catalogue_sites_35", "none") for r in rows]
        print(f"  FULL 35-catalogue sites                     : "
              f"{sum(1 for c in _cs if c != 'none')} constructs, "
              f"{sum(len(c.split(',')) for c in _cs if c != 'none')} sites")
    print(f"  fallback-ladder relaxations invoked          : {len(J.RELAXATION_LOG)}")
    print(f"  homopolymer runs > 6                        : "
          f"{sum(1 for r in rows if r['homopolymer_gt6'] != 'none')}")
    print(f"  GC range / outliers                         : "
          f"{min(r['gc_percent'] for r in rows)}-{max(r['gc_percent'] for r in rows)}% / "
          f"{sum(1 for r in rows if 'GC_OUTLIER' in r['flags'])}")
    print(f"  duplicate DNA / protein                     : "
          f"{len(dnas) - len(set(dnas))} / {len(prots) - len(set(prots))}")
    print(f"  spurious SigA ext-10 at a junction          : "
          f"{sum(1 for r in rows if r['spurious_sigA_at_junction'] != 'none')}")
    print(f"  spurious SD+ATG at a junction               : "
          f"{sum(1 for r in rows if r['spurious_SD_at_junction'] != 'none')}")
    print(f"  H-box histidine present                     : "
          f"{sum(1 for r in rows if r['hbox_residue'] == 'H')}/{len(rows)}")
    print(f"  in phase (delta=0)                          : "
          f"{sum(1 for r in rows if r['heptad_in_phase'] == 'YES')}/{len(rows)}")

    head("H-BOX POSITION PER CONSTRUCT")
    for r in rows:
        print(f"  {r['design_id']:38} {r['acceptor_accession']} His{r['hbox_native_residue']}"
              f" -> construct {r['hbox_construct_position']} ({r['hbox_residue']})")

    head("FLAGGED")
    for r in rows:
        if r["flags"] != "none":
            print(f"  {r['design_id']:38} {r['flags']}")
    return rows


def main():
    # v2 reproduces a frozen artifact: it must keep the historical NARROW
    # constraint set, named explicitly here so the narrowing is greppable.
    return build(J.GOLDEN_GATE, J.DESIGNS / "junctions_v2.csv",
                 J.DESIGNS / "junctions_v2.fasta", J.DESIGNS / "junctions_rename_map.csv",
                 tag_note="  (Golden Gate only -- frozen v2 behaviour)")


if __name__ == "__main__":
    main()
