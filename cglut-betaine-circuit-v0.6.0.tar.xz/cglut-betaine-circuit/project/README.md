# *C. glutamicum* Sal_PhoP/Ec_OmpR two-component-system engineering: cross-talk, operator-motif, and follow-up analyses

Three related, independently reproducible analyses supporting the decision to import a Gram-negative
Sal_PhoQ/Sal_PhoP (primary) or Ec_EnvZ/Ec_OmpR (backup) two-component system into *Corynebacterium glutamicum*
ATCC 13032:

1. **Sequence/domain cross-talk triage** (`run_pipeline.py`, report: `results/REPORT_crosstalk.md`) —
   how similar is every native *C. glutamicum* response regulator / sensor kinase to the donor
   proteins, at full-length and at the functionally relevant domain level?
2. **Sal_PhoP operator-motif genome scan** (`run_scan_pipeline.py`, report: `results/REPORT.md`) — does
   the native genome already contain a close match to the Sal_PhoP operator, such that an engineered
   Sal_PhoP-responsive promoter would also switch on a native gene?
3. **Follow-up: is the scan's 304-hit count real or artifact?** (`run_followup.py`, report:
   `results/REPORT_followup.md`, plus `results/lysc_analysis.md`) — rescores every hit against a
   properly-matched intergenic null instead of whole-genome background, checks whether a 9.56-bit
   motif can resolve the question at all, does a manual deep-dive on the single highest-stakes hit
   (upstream of *lysC*), and retries — successfully this time, via PRODORIC — Salmonella-specific
   Sal_PhoP sites for the actual primary donor rather than the *E. coli* proxy. **Read this one last; it
   revises the verdict of analysis 2.**

**All three reports were specified to write to `results/REPORT.md` in their original task
instructions.** Since they share this repo, `results/REPORT.md` holds analysis 2 (the operator scan,
the most recent to claim that filename); analysis 1's report was recovered from context and saved as
`results/REPORT_crosstalk.md` rather than lost; analysis 3 was explicitly instructed to use a
different filename (`results/REPORT_followup.md`) to avoid repeating the collision. **Read
`results/REPORT_followup.md` first if you want the current bottom line** — it leads with whether
analysis 2's headline number holds up, and retracts the part of analysis 2's verdict that doesn't.

---

## Analysis 1: Cross-talk triage (`results/REPORT_crosstalk.md`)

Sequence-identity triage comparing the donor response regulator and sensor kinase (Sal_PhoQ/Sal_PhoP primary, *E. coli* Ec_EnvZ/Ec_OmpR backup) against all 13 native *C. glutamicum* TCS pairs, at
full length and restricted to the functionally relevant REC/DHp domains (HMMER).

### What was fetched, when, from where

Pipeline first run: **2026-08-22**.

- **6 donor sequences** — UniProt REST (`rest.uniprot.org/uniprotkb/<ACC>.fasta`). Two requested accessions (P14146, P14147) were dead/demerged in current UniProt and resolved to their strain-LT2 successors (P0DM78, P0DM80) — see `results/REPORT_crosstalk.md` §1.2.
- **26 native *C. glutamicum* ATCC 13032 sequences** (13 response regulators + 13 paired sensor kinases) — NCBI Entrez `efetch` (protein db), using `CAF#####` accessions read from genome record **BX927147.1** (EMBL/GenBank, Kalinowski et al. 2003).
- **2 genome feature tables** cached in `data/cache/` (`BX927147.ft.txt`, `NC_003450.ft.txt`) — used to resolve every locus tag to a protein accession and to cross-reference `cg####` against `NCgl####` numbering; see `results/REPORT_crosstalk.md` §1.3-1.4 for the resolution method and every conflict found. **Reused as-is (not re-fetched) by Analysis 2 below.**
- **5 Pfam HMM profiles** cached in `data/cache/pfam/` (PF00072/REC, PF00512/HisKA, PF07568/HisKA_2, PF07730/HisKA_3, PF02518/HATPase_c — the last one fetched but not ultimately used) — fetched from the EBI InterPro API (`ebi.ac.uk/interpro/wwwapi/entry/pfam/<ID>?annotation=hmm`).

Every fetched record is cached with its accession and never hand-transcribed; `data/manifest.csv` maps locus tag → accession → description → source URL for all 32 sequences. Full locus-resolution provenance (including every conflict, near-miss, and unresolved cross-reference) is in `data/resolved_loci.json`.

### Layout

```
data/fasta/                per-accession cached FASTA (never hand-written)
data/resolved_loci.json    locus-tag resolution ground truth, with every conflict documented
data/manifest.csv          locus tag -> accession -> description -> source URL
results/identity_full.csv  full-length pairwise identity, both denominators (Task 2)
results/identity_rec.csv   REC-domain-only identity matrix (Task 3, the one to trust)
results/identity_dhp.csv   DHp-domain-only identity matrix (bonus; noisier, see report)
results/rec_domain_hits.csv / dhp_domain_hits.csv   HMMER domain boundaries
results/rec_domains.fasta / dhp_domains.fasta       extracted domain sequences
results/REPORT_crosstalk.md   findings
scripts/parse_feature_table.py / fetch_sequences.py / identity_matrix.py / domain_hmmer.py
run_pipeline.py            entry point
```

**Task 4 of this analysis** (DHp-REC interface residue comparison) was skipped: the response-regulator-side residue numbers from Capra et al. 2010 could only be verified in a non-text-extractable figure, not in body text — see `results/REPORT_crosstalk.md` §4. `results/interface_residues.csv` does not exist.

### Reproduce

```bash
pip install -r requirements.txt
brew install hmmer        # or your platform's package manager; hmmscan/hmmpress must be on PATH
python3 run_pipeline.py               # first run: fetches + caches, then computes everything
python3 run_pipeline.py --skip-fetch  # later runs: fully offline against data/fasta/
```

---

## Analysis 2: Sal_PhoP operator-motif genome scan (`results/REPORT.md`)

Go/no-go check: scans the *C. glutamicum* genome, both strands, for matches to a PWM built from
experimentally confirmed Ec_PhoP binding sites, with an empirical (dinucleotide-shuffled-genome) null
model, and validates the whole pipeline with a positive control against known *E. coli* Ec_PhoP
promoters before trusting any *C. glutamicum* result.

### What was fetched, when, from where

Pipeline first run: **2026-08-22** (same session as Analysis 1).

- **BX927147.1 genome FASTA** — NCBI Entrez `efetch` (`db=nuccore&rettype=fasta`). The matching feature-table annotation (`BX927147.ft.txt`) was **reused from Analysis 1, not re-fetched.**
- **NC_000913.3 genome FASTA + feature table** (*E. coli* K-12 MG1655) — NCBI Entrez `efetch`, fetched fresh for the Task 5 positive control.
- **Ec_PhoP and Ec_OmpR confirmed binding sites** — live GraphQL query against **RegulonDB** (`regulondb.ccg.unam.mx/graphql`): 36 unique, PMID-cited *E. coli* Ec_PhoP sites (17 distinct primary-literature citations) and 45 unique Ec_OmpR sites (31 citations), with exact genomic coordinates, strand, and DNase-footprint/EMSA/ChIP-confirmed core sequence. **CollecTF** (the other database named in the task, which additionally covers *Salmonella*) was attempted and found unreachable from this environment (`Could not resolve host` / connection refused on its current domain, `collectf.umbc.edu`) — see `results/REPORT.md` §2 for the full account. Every site used is therefore an *E. coli* K-12 MG1655 site.

Every fetched record is cached with its source and never hand-transcribed; `data/sites_manifest.csv` lists every confirmed site with its PMID citation(s) and whether it was used in the PWM.

### Layout

```
data/sites/phop_ecoli_sites.fasta / ompr_ecoli_sites.fasta   aligned confirmed sites used to build each PWM
data/sites_manifest.csv         every confirmed site, citations, PWM-inclusion flag
data/cache/BX927147.fasta       C. glutamicum genome (new; .ft.txt reused from Analysis 1)
data/cache/NC_000913.fasta / .ft.txt   E. coli K-12 MG1655 genome + annotation (positive control)
data/cache/regulondb/           raw RegulonDB GraphQL responses
data/cache/pwm_phop.json / pwm_ompr.json   machine-readable PWMs
data/cache/*_dinucshuffled_seed1337.fasta  cached empirical-null genomes (deterministic seed)
results/pwm.txt                 Ec_PhoP PWM: matrix, per-position IC, total IC (results/pwm_ompr.txt: backup donor)
results/positive_control.csv    E. coli control results -- read this section of the report FIRST
results/hits_all.csv            every C. glutamicum hit (149,001 rows @ empirical p<=0.05): score, p, position, strand, classification, nearest gene
results/hits_high_concern.csv   the actionable subset (304 rows @ empirical p<=1e-4, classification=HIGH_CONCERN;
                                 3 columns were later APPENDED in place by Analysis 3 -- original columns unchanged)
results/REPORT.md               findings -- start here for this analysis, but see Analysis 3 for a revision
scripts/prepare_sites.py / pwm_lib.py / build_pwm.py / dinuc_shuffle.py / scan_genome.py / annotate_hits.py / fetch_scan_data.py
run_scan_pipeline.py            entry point (checks positive control before running the main scan)
```

### Reproduce

```bash
pip install -r requirements.txt
python3 run_scan_pipeline.py               # first run: fetches + caches everything not already cached
python3 run_scan_pipeline.py --skip-fetch  # later runs: fully offline
```
The script prints a positive-control PASS/FAIL check and refuses to proceed to the *C. glutamicum* scan on FAIL, per the task's instructions.

---

## Analysis 3: follow-up — is the 304-hit count real or artifact? (`results/REPORT_followup.md`)

Three checks on Analysis 2's headline number, run entirely from data already cached by Analyses 1-2 (the only new fetch is a Salmonella-specific Sal_PhoP binding-site matrix): (1) rebuild the null from **intergenic** composition instead of whole-genome composition, since Sal_PhoP boxes are AT-rich and intergenic DNA in this GC-rich organism is AT-enriched relative to coding sequence, and rescore every hit; (2) check directly whether a 9.56-bit motif can resolve anything at 3.3 Mb scale at all; (3) retry Salmonella-specific Sal_PhoP sites for the actual primary donor, since the original PWM had to substitute *E. coli* sites when CollecTF was unreachable.

**Headline finding**: most of the 304 was compositional artifact (82 survive the intergenic-null correction, close to the ~54-64 expected by chance alone) — the earlier verdict ("the operator is not clean") is **retracted for the bulk of the list** and replaced with "this motif lacks the resolving power to answer the question," per the task's own instruction to distinguish those two claims. The exception: the single most extreme candidate — a hit 151 bp upstream of ***lysC*** (aspartokinase, the committed step of the pathway the whole production thesis runs through) — survives every check thrown at it (both null models, both an *E. coli*-derived and an independently-built *Salmonella*-derived PWM) and remains the top experimental priority.

### What was fetched, when, from where

Pipeline run: **2026-08-22** (same session as Analyses 1-2). No genome, feature table, or *E. coli*/Ec_OmpR site data was re-fetched — all reused from Analysis 2's cache.

- **Salmonella-specific Sal_PhoP binding sites** — CollecTF was retried on both its old domain (`collectf.umbc.edu`, still DNS-unreachable) and its rebuilt `collectf.org` (live, but a client-side SPA with no discoverable public read API — confirmed by two independent tools). **PRODORIC** (`prodoric.de`) was retried and succeeded: its documented OpenAPI spec (`/api/openapi.json`) led to matrix `MX000339`, a curated collection of 9 confirmed Sal_PhoP sites (DNase footprinting/EMSA/mutagenesis/expression-assay evidence) citing four Groisman-lab primary papers, resolved via CrossRef. Cached at `data/cache/prodoric/`.

### Layout

```
data/sites/phop_salmonella_sites.fasta   9 confirmed Sal_PhoP sites (PRODORIC MX000339)
data/cache/prodoric/                     raw PRODORIC API responses (organisms, regulatory network, matrix)
data/cache/pwm_phop_intergenic.json / pwm_phop_salmonella.json   machine-readable PWMs
data/cache/intergenic_null_summary.json / salmonella_pwm_comparison.json / lysc_facts.json
                                          structured numbers the two reports below are written from
results/pwm_intergenic.txt               Ec_PhoP PWM rebuilt against intergenic (not whole-genome) background
results/pwm_salmonella.txt               Sal_PhoP PWM built from the Salmonella-specific sites
results/intergenic_null.csv              every one of the original 304 hits, rescored (score, new p, pass/fail)
results/hits_high_concern.csv            same 304 rows as Analysis 2, with 3 columns appended in place
results/REPORT_followup.md               findings -- read this first for the current bottom line
results/lysc_analysis.md                 manual deep-dive on the lysC hit specifically
scripts/intergenic_null.py / salmonella_pwm.py / lysc_deep_dive.py / fetch_prodoric_salmonella.py
run_followup.py                          entry point
```

### Reproduce

```bash
pip install -r requirements.txt
python3 run_followup.py
```
Idempotent: safe to rerun — the PRODORIC fetch skips already-cached files, and both `hits_high_concern.csv` (Analysis 3's added columns) and `data/sites_manifest.csv` (the Salmonella site rows) are rewritten cleanly rather than duplicated on rerun.

---

## Shared setup notes

Requires Python 3.10+ (uses `X | None` type hints). Tested on Python 3.14, HMMER 3.4, NumPy 2.4.

### A note on macOS + python.org SSL

Some macOS python.org builds ship without a populated CA trust store, causing every HTTPS fetch to fail with `CERTIFICATE_VERIFY_FAILED`. The fetch scripts in both analyses work around this themselves (point `urllib`/`Bio.Entrez` at `certifi`'s bundle) rather than requiring a one-off system fix — no action needed.
