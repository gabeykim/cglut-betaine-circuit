#!/usr/bin/env python3
"""Entry point for the follow-up analysis on the Sal_PhoP operator scan.

Runs, in order, entirely from cached data (only new fetch: the PRODORIC
Sal_PhoP matrix, which was not previously cached; everything else --
genome FASTA, feature table, RegulonDB sites, the original scan's hit lists
-- is reused from the two earlier analyses in this repo and never re-fetched):

  1. scripts/fetch_prodoric_salmonella.py  -- Task 5 data acquisition
  2. scripts/intergenic_null.py            -- Task 2: intergenic background + null,
                                               rescoring, updates hits_high_concern.csv
  3. scripts/salmonella_pwm.py             -- Task 5: second PWM, position comparison,
                                               confirmatory spot-check on the extreme hits
  4. scripts/lysc_deep_dive.py             -- Task 4: verified facts for lysc_analysis.md

Task 1 (surfacing the existing Sal_PhoP identity numbers) and Task 3 (the
information-theoretic resolving-power calculation) are read/arithmetic-only
against already-cached CSVs and are not separate scripts; their numbers are
verified inline in results/REPORT_followup.md.

Usage:
    python3 run_followup.py
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "scripts"


def run(script: str):
    cmd = [sys.executable, str(SCRIPTS / script)]
    print(f"\n{'='*70}\n>>> {' '.join(cmd)}\n{'='*70}")
    subprocess.run(cmd, check=True, cwd=ROOT)


def main():
    run("fetch_prodoric_salmonella.py")
    run("intergenic_null.py")
    run("salmonella_pwm.py")
    run("lysc_deep_dive.py")

    print("\n" + "=" * 70)
    print("Follow-up pipeline complete. Outputs:")
    print("  results/REPORT_followup.md      findings -- start here (headline finding first)")
    print("  results/lysc_analysis.md        the lysC manual examination")
    print("  results/intergenic_null.csv     every original HIGH_CONCERN hit, rescored")
    print("  results/hits_high_concern.csv   updated in place with 3 new columns")
    print("  results/pwm_intergenic.txt      Sal_PhoP PWM rebuilt against intergenic background")
    print("  results/pwm_salmonella.txt      Sal_PhoP PWM built from confirmed Salmonella sites")
    print("=" * 70)


if __name__ == "__main__":
    main()
